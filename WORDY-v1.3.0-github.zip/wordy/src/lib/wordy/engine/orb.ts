import type { MotionMode, OrbShape, TrailKind, ElementKind, SphereStyle, SphereDimension, MoodKind } from '../types'
import type { ParticleSystem } from './particles'
import { drawHeart } from './particles'

/* ==========================================================================
   WORDY Orb — the core entity.
   Composable state channels: motion × spin × shape × trail × elements.
   ========================================================================== */

interface TrailPoint { x: number; y: number; t: number }

function rnd(a: number, b: number) {
  return a + Math.random() * (b - a)
}

export class Orb {
  x = 0
  y = 0
  vx = 0
  vy = 0
  px = 0   // previous x (for motion blending)
  py = 0

  scale = 1
  targetScale = 1
  rotation = 0
  spin = 0
  targetSpin = 0

  shape: OrbShape = 'orb'
  prevShape: OrbShape = 'orb'
  morphT = 1

  color = '#a78bfa'
  targetColor = '#a78bfa'
  glow = 1
  targetGlow = 1
  alpha = 1
  targetAlpha = 1

  burning = 0
  frozen = 0
  wet = 0
  electric = 0
  lava = 0

  motion: MotionMode = 'idle'
  private modeT = 0

  /* ---- v1.1 — the core becomes an actor ---- */
  style: SphereStyle = 'energy'
  dimension: SphereDimension = '3d'
  bloomMul = 1
  halo = 0
  private haloTarget = 0
  heartbeat = 0
  private heartbeatTarget = 0
  chrome = 0
  private chromeTarget = 0
  private chromePhase = 0
  private heartPhase = 0
  sleeping = 0
  private sleepTarget = 0
  speaking: { text: string; t: number; dur: number } | null = null
  private flipT = -1
  flipRot = 0
  private flipHop = 0
  private strideT = 0
  private strideSign = 1

  /* ---- v1.2 — the sphere is alive ---- */
  mood: MoodKind | null = null
  private moodT = 0            // 1 → 0, how strongly the mood is felt
  rainOn = 0                    // engine feeds 0..1 while it rains
  hardLanding = 0               // impact strength for the engine to consume
  pointerProx = 0               // 0..1 — how near the cursor is
  private liftFrom = -1         // fly take-off anchor Y
  private jumpBounces = 0
  private rainRings: number[] = []
  private rainRingT = 0
  private motes = [
    { ang: 0.0, dist: 1.62, sp: 0.55, size: 2.0 },
    { ang: 2.1, dist: 1.86, sp: -0.42, size: 1.4 },
    { ang: 4.4, dist: 1.74, sp: 0.36, size: 1.7 },
  ]

  private wanderX = 0
  private wanderY = 0
  private wanderTX = 0
  private wanderTY = 0
  private bobPhase = Math.random() * 10
  private orbitAng = 0
  private orbitSpeed = 0.9
  private figT = 0
  private spiralAng = 0
  private spiralR = 40
  private zigT = 0
  private dashT = -1
  private diveT = -1
  private boomerangT = -1
  private jumpV = 0
  private jumpV0 = -1
  private jumpActive = false
  private clones: Array<{ x: number; y: number; life: number; maxLife: number }> = []
  private cloneTimer = 0
  private rippleTimer = 0
  private trail: TrailPoint[] = []
  trailKind: TrailKind = null
  private time = 0

  squish = 0
  squishV = 0

  w = 0
  h = 0

  resize(w: number, h: number) {
    const first = this.w === 0
    this.w = w
    this.h = h
    if (first) {
      this.x = w / 2
      this.y = h * 0.42
    }
  }

  setMotion(m: MotionMode) {
    if (m !== this.motion) {
      // preserve position, hand over cleanly
      this.motion = m
      this.modeT = 0
      this.orbitAng = Math.atan2(this.y - h42(this.h), this.x - w2(this.w)) - Math.PI / 2
      this.spiralAng = Math.atan2(this.y - h42(this.h), this.x - w2(this.w))
      this.spiralR = Math.hypot(this.x - w2(this.w), this.y - h42(this.h))
      this.wanderX = this.x
      this.wanderY = this.y
      this.wanderTX = this.x
      this.wanderTY = this.y
      if (m === 'bounce') {
        this.y = Math.min(this.y, this.h * 0.8 - this.radius())
      }
      if (m === 'fly') this.liftFrom = this.y   // remember where lift-off began
    }
  }

  /** v1.2 — the sphere feels something, briefly, then returns to neutral */
  setMood(m: MoodKind | null) {
    if (m === null) {
      this.mood = null
      this.moodT = 0
    } else {
      this.mood = m
      this.moodT = 1
    }
  }

  /** how strongly the current mood is felt (0..1) */
  moodK(): number {
    return this.mood ? this.moodT : 0
  }

  /** mood-modulated time multiplier — energetic spheres move quicker */
  private moodSpeed(): number {
    const k = this.moodK()
    if (!this.mood) return 1
    switch (this.mood) {
      case 'energetic': return 1 + k * 0.85
      case 'jubilant': return 1 + k * 0.45
      case 'curious': return 1 + k * 0.25
      case 'tense': return 1 + k * 0.55
      case 'calm': return 1 - k * 0.35
      case 'sleepy': return 1 - k * 0.5
      default: return 1
    }
  }

  radius(): number {
    return Math.min(this.w, this.h) * 0.075 * this.scale
  }

  floorY(): number {
    return this.h * 0.82
  }

  squishImpulse(v: number) {
    this.squishV += v
  }

  setStyle(s: SphereStyle) {
    if (this.style !== s) {
      this.style = s
      this.morphT = Math.min(this.morphT, 0.4) // soft re-glint
    }
  }

  setDimension(d: SphereDimension) {
    this.dimension = d
  }

  setHalo(on: boolean) { this.haloTarget = on ? 1 : 0 }
  setHeartbeat(on: boolean) { this.heartbeatTarget = on ? 1 : 0 }
  setChrome(on: boolean) { this.chromeTarget = on ? 1 : 0 }
  setSleeping(on: boolean) { this.sleepTarget = on ? 1 : 0 }

  speakText(text: string) {
    this.speaking = { text, t: 0, dur: Math.min(7, 1.9 + text.length * 0.06) }
  }

  flip() {
    if (this.flipT < 0) {
      this.flipT = 0
      this.squishImpulse(-5)
    }
  }

  resetState() {
    this.motion = 'idle'
    this.modeT = 0
    this.targetSpin = 0
    this.spin = 0
    this.targetScale = 1
    this.scale = 1
    this.targetColor = '#a78bfa'
    this.targetGlow = 1
    this.alpha = 1
    this.targetAlpha = 1
    this.shape = 'orb'
    this.prevShape = 'orb'
    this.morphT = 1
    this.trailKind = null
    this.trail = []
    this.haloTarget = 0
    this.heartbeatTarget = 0
    this.chromeTarget = 0
    this.sleepTarget = 0
    this.speaking = null
    this.burning = 0
    this.frozen = 0
    this.wet = 0
    this.electric = 0
    this.lava = 0
    this.clones = []
    this.vx = 0
    this.vy = 0
    this.rotation = 0
    this.jumpActive = false
    this.dashT = -1
    this.diveT = -1
    this.boomerangT = -1
    this.flipT = -1
    this.flipRot = 0
    this.flipHop = 0
    this.mood = null
    this.moodT = 0
    this.rainOn = 0
    this.hardLanding = 0
    this.liftFrom = -1
    this.jumpBounces = 0
    this.rainRings.length = 0
    this.pointerProx = 0
  }

  addClone() {
    this.clones.push({ x: this.x, y: this.y, life: 0, maxLife: 2.6 })
    this.clones.push({ x: this.x - 34, y: this.y + 10, life: -0.12, maxLife: 2.6 })
    this.clones.push({ x: this.x + 34, y: this.y + 18, life: -0.24, maxLife: 2.6 })
  }

  jump() {
    this.jumpActive = true
    this.jumpBounces = 0
    this.jumpV = -Math.min(this.w, this.h) * 1.15
    this.jumpV0 = this.jumpV
    this.squishImpulse(-7)
  }

  dash() {
    this.dashT = 0
    this.squishImpulse(5)
  }

  dive() {
    this.diveT = 0
  }

  boomerang() {
    this.boomerangT = 0
  }

  toss() {
    this.vx += (Math.random() - 0.5) * 340
    this.vy -= Math.random() * 220
  }

  /* ---------------- per-frame ---------------- */

  update(dt: number, opts: {
    gravity: number
    timeScale: number
    pointer: { x: number; y: number; active: boolean }
  }) {
    this.time += dt
    const { gravity } = opts
    const w = this.w
    const h = this.h
    const cx = w / 2
    const cy = h * 0.42
    this.modeT += dt

    // smooth channels
    this.scale += (this.targetScale - this.scale) * Math.min(1, dt * 5)
    this.spin += (this.targetSpin - this.spin) * Math.min(1, dt * 4)
    this.glow += (this.targetGlow - this.glow) * Math.min(1, dt * 3)
    this.morphT = Math.min(1, this.morphT + dt * 2.2)
    // color lerp
    this.color = lerpHex(this.color, this.targetColor, Math.min(1, dt * 4))

    // v1.1 channels ease in / out
    this.halo += (this.haloTarget - this.halo) * Math.min(1, dt * 3)
    this.heartbeat += (this.heartbeatTarget - this.heartbeat) * Math.min(1, dt * 3)
    this.chrome += (this.chromeTarget - this.chrome) * Math.min(1, dt * 4)
    this.sleeping += (this.sleepTarget - this.sleeping) * Math.min(1, dt * 1.4)
    this.chromePhase = (this.chromePhase + dt * 0.42) % 1
    this.heartPhase += dt * 1.25
    this.alpha += (this.targetAlpha - this.alpha) * Math.min(1, dt * 2.2)

    // v1.2 — moods wash through and fade (~6s), never snapping back
    if (this.mood) {
      this.moodT = Math.max(0, this.moodT - dt / 6)
      if (this.moodT <= 0) this.mood = null
    }

    // v1.2 — the sphere notices the cursor
    const px = opts.pointer.active ? opts.pointer.x : this.renderX
    const py = opts.pointer.active ? opts.pointer.y : this.renderY
    const pd = Math.hypot(px - this.renderX, py - this.renderY)
    const proxT = opts.pointer.active ? clamp(1 - pd / 220, 0, 1) : 0
    this.pointerProx += (proxT * proxT - this.pointerProx) * Math.min(1, dt * 3)

    // v1.2 — rain rings ripple across the surface while it rains
    if (this.rainOn > 0.35) {
      this.rainRingT -= dt * this.rainOn
      if (this.rainRingT <= 0) {
        this.rainRingT = 0.5
        if (this.rainRings.length > 3) this.rainRings.shift()
        this.rainRings.push(0)
      }
    }
    for (let i = this.rainRings.length - 1; i >= 0; i--) {
      this.rainRings[i] += dt * 0.9
      if (this.rainRings[i] > 1) this.rainRings.splice(i, 1)
    }

    // v1.2 — idle satellite motes keep orbiting, alive even at rest
    const moteSp = this.moodSpeed()
    for (const m of this.motes) m.ang += m.sp * moteSp * dt

    if (this.speaking) {
      this.speaking.t += dt
      if (this.speaking.t > this.speaking.dur) this.speaking = null
    }
    if (this.flipT >= 0) {
      this.flipT += dt
      const k = Math.min(1, this.flipT / 0.72)
      const e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2
      this.flipRot = e * Math.PI * 2
      this.flipHop = Math.sin(k * Math.PI) * this.radius() * 1.5
      if (k >= 1) {
        this.flipT = -1
        this.flipRot = 0
        this.flipHop = 0
        this.squishImpulse(6)
      }
    }

    const R = this.radius()
    let tx = this.x
    let ty = this.y
    let follow = 0.055 // spring-ish follow speed

    switch (this.motion) {
      case 'idle': {
        follow = 0.03
        tx = cx + Math.sin(this.time * 0.3) * w * 0.02
        ty = cy + Math.sin(this.time * 0.8 + this.bobPhase) * h * 0.012
        break
      }
      case 'float': {
        follow = 0.02
        this.wanderX += (this.wanderTX - this.wanderX) * dt * 0.4
        this.wanderY += (this.wanderTY - this.wanderY) * dt * 0.4
        if (this.modeT > 2.2) {
          this.modeT = 0
          this.wanderTX = cx + (Math.random() - 0.5) * w * 0.3
          this.wanderTY = cy + (Math.random() - 0.5) * h * 0.24
        }
        tx = this.wanderX + Math.sin(this.time * 1.1) * 8
        ty = this.wanderY + Math.sin(this.time * 1.5 + 1) * 8
        break
      }
      case 'fly': {
        follow = 0.045
        tx = cx + Math.sin(this.time * 0.5) * w * 0.1
        ty = h * 0.24 + Math.sin(this.time * 1.2 + this.bobPhase) * h * 0.02
        // v1.2 — lift-off: ease from wherever it stood up to cruising altitude
        if (this.liftFrom >= 0) {
          const liftK = Math.min(1, this.modeT / 0.85)
          const e = 1 - Math.pow(1 - liftK, 3)
          ty = this.liftFrom + (ty - this.liftFrom) * e
          tx = this.x + (tx - this.x) * e
          if (liftK >= 1) this.liftFrom = -1
        }
        break
      }
      case 'floor': {
        follow = 0.06
        tx = this.x
        ty = this.floorY() - R * 0.7
        if (gravity > 0) {
          // fall under gravity
          this.vy += gravity * 900 * dt
          this.y += this.vy * dt
          if (this.y >= ty) {
            this.y = ty
            if (this.vy > 260) {
              this.squishImpulse(Math.min(11, this.vy / 90))
              this.hardLanding = Math.max(this.hardLanding, Math.min(1, this.vy / 900))
              this.vy = 0
            } else this.vy = 0
          }
          tx = this.x
          ty = this.y
        }
        break
      }
      case 'orbit': {
        follow = 0.09
        this.orbitAng += this.orbitSpeed * dt
        const r = Math.min(w, h) * 0.26
        tx = cx + Math.cos(this.orbitAng) * r
        ty = cy + Math.sin(this.orbitAng) * r * 0.62
        break
      }
      case 'figure8': {
        follow = 0.08
        this.figT += dt * 0.9
        tx = cx + Math.sin(this.figT * 2) * w * 0.19
        ty = cy + Math.sin(this.figT) * h * 0.17
        break
      }
      case 'zigzag': {
        follow = 0.16
        this.zigT += dt * 3.2
        const tri = Math.abs(((this.zigT % 2) + 2) % 2 - 1) * 2 - 1
        tx = cx + tri * w * 0.2
        ty = cy + Math.sin(this.time * 0.7) * h * 0.1
        break
      }
      case 'spiral': {
        follow = 0.1
        this.spiralAng += dt * 1.4
        this.spiralR += dt * 26
        if (this.spiralR > Math.min(w, h) * 0.34) this.spiralR = 40
        tx = cx + Math.cos(this.spiralAng) * this.spiralR
        ty = cy + Math.sin(this.spiralAng) * this.spiralR * 0.7
        break
      }
      case 'drift': {
        follow = 0.028
        this.wanderX += (this.wanderTX - this.wanderX) * dt * 0.5
        this.wanderY += (this.wanderTY - this.wanderY) * dt * 0.5
        if (this.modeT > 1.8) {
          this.modeT = 0
          this.wanderTX = clamp(this.x + (Math.random() - 0.5) * w * 0.4, w * 0.12, w * 0.88)
          this.wanderTY = clamp(this.y + (Math.random() - 0.5) * h * 0.3, h * 0.12, h * 0.7)
        }
        tx = this.wanderX
        ty = this.wanderY
        break
      }
      case 'bounce': {
        follow = 0
        this.vy += gravity * 950 * dt
        this.x += this.vx * dt
        this.y += this.vy * dt
        const fy = this.floorY() - R * 0.6
        if (this.y > fy) {
          this.y = fy
          this.vy = -Math.abs(this.vy) * 0.86
          if (Math.abs(this.vy) < Math.min(this.h, this.w) * 0.42) {
            this.vy = -Math.min(this.h, this.w) * 0.5 // never tired
          }
          this.squishImpulse(9)
          this.hardLanding = Math.max(this.hardLanding, 0.25)
          this.vx *= 0.9
        }
        this.x = clamp(this.x, R, w - R)
        tx = this.x
        ty = this.y
        break
      }
      case 'sway': {
        follow = 0.07
        const a = Math.sin(this.time * 0.9)
        tx = cx + a * w * 0.16
        ty = cy + (1 - Math.cos(this.time * 0.9)) * 0.5 * h * 0.06
        this.rotation = a * 0.3
        break
      }
      case 'run':
      case 'walk':
      case 'go': {
        // travel along the ground, stride by stride
        follow = 0
        const pace = this.motion === 'run' ? 1 : this.motion === 'go' ? 0.58 : 0.32
        const speed = Math.min(w, h) * (0.24 + 0.52 * pace)
        this.x += speed * dt
        if (this.x > w + R * 1.6) this.x = -R * 1.6
        this.strideT += dt * (1.7 + 3.5 * pace)
        const bob = Math.abs(Math.sin(this.strideT * Math.PI))
        this.y = this.floorY() - R * (0.85 + bob * (0.14 + 0.32 * pace))
        this.rotation = Math.sin(this.strideT * Math.PI * 2) * 0.055 * (0.4 + pace)
        tx = this.x
        ty = this.y
        break
      }
      case 'stop':
      case 'hover-wait': {
        // decelerate and hold position — a held breath
        follow = 0.02
        this.vx *= 1 - Math.min(1, dt * 5)
        this.vy *= 1 - Math.min(1, dt * 5)
        const sleepK = this.sleeping
        const breathe = Math.sin(this.time * (1.5 - sleepK * 0.85)) * R * (0.05 + sleepK * 0.07)
        tx = this.x
        ty = this.y + breathe
        break
      }
      case 'climb': {
        // v1.2 — hand over hand: alternating reaches while the core works upward
        follow = 0
        this.strideT += dt * 1.9
        const gripDir = Math.sin(this.strideT * Math.PI) >= 0 ? 1 : -1
        const ceiling = h * 0.16
        if (this.y > ceiling) {
          this.y -= (52 + 40 * this.moodSpeed()) * dt
        } else {
          this.y = ceiling + Math.sin(this.time * 1.4) * 6   // summit bob
        }
        this.x = clamp(this.x + gripDir * 42 * dt, R * 1.4, w - R * 1.4)
        this.rotation = gripDir * 0.12 + Math.sin(this.strideT * Math.PI * 2) * 0.05
        tx = this.x
        ty = this.y
        break
      }
    }

    // spring toward target (skip for physical modes)
    if (follow > 0) {
      // v1.2 — the core leans gently toward a nearby cursor
      if (this.pointerProx > 0.04 && this.sleeping < 0.4) {
        tx += clamp(opts.pointer.x - this.x, -34, 34) * 0.05 * this.pointerProx
        ty += clamp(opts.pointer.y - this.y, -26, 26) * 0.04 * this.pointerProx
      }
      const sp = this.moodSpeed()
      this.x += (tx - this.x) * Math.min(1, dt * follow * 60 * sp)
      this.y += (ty - this.y) * Math.min(1, dt * follow * 60 * sp)
    }

    // one-shot motion anims (added on top)
    let ox = 0
    let oy = 0
    if (this.jumpActive) {
      this.jumpV += 1500 * dt
      oy += this.jumpV * dt
      if (this.jumpV >= -this.jumpV0) {
        // touchdown — a proper landing needs a bounce and a breath of dust
        if (this.jumpBounces < 1) {
          this.jumpBounces += 1
          this.hardLanding = Math.max(this.hardLanding, 0.6)
          this.squishImpulse(7)
          this.jumpV0 = this.jumpV0 * 0.3   // a smaller, prouder hop
          this.jumpV = this.jumpV0
          oy = 0
        } else {
          this.jumpActive = false
          this.squishImpulse(6)
          this.hardLanding = Math.max(this.hardLanding, 0.3)
          oy = 0
        }
      }
    }
    if (this.dashT >= 0) {
      this.dashT += dt
      const k = Math.min(1, this.dashT / 0.5)
      ox += Math.sin(k * Math.PI) * w * 0.16
      if (k >= 1) this.dashT = -1
    }
    if (this.diveT >= 0) {
      this.diveT += dt
      const k = Math.min(1, this.diveT / 0.9)
      oy += Math.sin(k * Math.PI) * h * 0.2
      if (k >= 1) this.diveT = -1
    }
    if (this.boomerangT >= 0) {
      this.boomerangT += dt
      const k = Math.min(1, this.boomerangT / 1.2)
      ox += Math.sin(k * Math.PI) * w * 0.24
      if (k >= 1) this.boomerangT = -1
    }
    if (this.flipHop !== 0) oy -= this.flipHop

    this.px = this.x
    this.py = this.y
    this.renderX = this.x + ox
    this.renderY = this.y + oy

    // free-velocity integration (impulse-based commands)
    this.x += this.vx * dt
    this.y += this.vy * dt
    this.vx *= 1 - Math.min(0.9, dt * 1.6)
    this.vy *= 1 - Math.min(0.9, dt * 1.6)
    this.x = clamp(this.x, R * 0.4, w - R * 0.4)
    this.y = clamp(this.y, R * 0.4, h * 0.86)

    // rotation
    this.rotation += this.spin * dt

    // squish spring
    this.squishV += -this.squish * 90 * dt
    this.squishV *= 1 - Math.min(1, dt * 4)
    this.squish += this.squishV * dt

    // trail record
    if (this.trailKind) {
      this.trail.push({ x: this.renderX, y: this.renderY, t: this.time })
      while (this.trail.length > 46) this.trail.shift()
    } else if (this.trail.length) {
      this.trail.shift()
    }

    // clones decay
    this.cloneTimer += dt
    for (let i = this.clones.length - 1; i >= 0; i--) {
      const c = this.clones[i]
      c.life += dt
      if (c.life > c.maxLife) this.clones.splice(i, 1)
    }

    // ambient water ripples
    if (this.wet > 0.4) {
      this.rippleTimer += dt
      if (this.rippleTimer > 0.7) {
        this.rippleTimer = 0
      }
    }
  }

  renderX = 0
  renderY = 0

  /* ---------------- element emission ---------------- */

  emit(dt: number, ps: ParticleSystem, elements: Set<ElementKind>) {
    const x = this.renderX
    const y = this.renderY
    const R = this.radius()

    // v1.2 — flying sheds quiet stardust in its wake
    if (this.motion === 'fly' && this.liftFrom < 0) {
      const n = 7 * dt
      for (let i = 0; i < Math.ceil(n); i++) {
        if (i > 0 && Math.random() > n % 1) break
        ps.spawn('starmote', {
          x: x + (Math.random() - 0.5) * R * 1.4,
          y: y + R * (0.4 + Math.random() * 0.7),
          vx: (Math.random() - 0.5) * 18,
          vy: rnd(14, 52),
          maxLife: rnd(1.2, 2.4), size: rnd(1.4, 3), hue: rnd(220, 275), gf: 0.06,
        })
      }
    }

    // v1.2 — motion blur: speed streaks trail a running core
    if (this.motion === 'run' || this.motion === 'go') {
      const pace = this.motion === 'run' ? 1 : 0.58
      const n = (6 + 9 * pace) * dt
      for (let i = 0; i < Math.ceil(n); i++) {
        if (i > 0 && Math.random() > n % 1) break
        ps.spawn('streak', {
          x: x - R * (0.8 + Math.random() * 0.9),
          y: y + (Math.random() - 0.5) * R * 1.1,
          vx: -rnd(120, 260) * (0.5 + pace),
          vy: rnd(-10, 10),
          maxLife: rnd(0.22, 0.42), size: rnd(5, 12), hue: 262,
        })
      }
    }

    // stride dust for ground travel (run / walk / go)
    if (this.motion === 'run' || this.motion === 'walk' || this.motion === 'go') {
      const pace = this.motion === 'run' ? 1 : this.motion === 'go' ? 0.58 : 0.32
      const bobSign = Math.sin(this.strideT * Math.PI)
      if (this.strideSign > 0 && bobSign <= 0) {
        this.strideSign = -1
        const n = this.motion === 'run' ? 3 : this.motion === 'go' ? 2 : 1
        for (let i = 0; i < n; i++) {
          ps.spawn('dust', {
            x: x - R * 0.5 + (Math.random() - 0.5) * R * 0.6,
            y: this.floorY() - 2,
            vx: -rnd(18, 64) * (0.4 + pace),
            vy: -rnd(8, 44) * (0.4 + pace),
            maxLife: rnd(0.5, 1.1), size: rnd(1.6, 3.6), hue: 262,
          })
        }
      } else if (bobSign > 0) {
        this.strideSign = 1
      }
    }

    // v1.2 — climbing sheds a few chips of whatever it grips
    if (this.motion === 'climb') {
      const bobSign = Math.sin(this.strideT * Math.PI)
      if (this.strideSign > 0 && bobSign <= 0) {
        this.strideSign = -1
        for (let i = 0; i < 2; i++) {
          ps.spawn('dust', {
            x: x + (Math.random() - 0.5) * R * 0.9,
            y: y + R * (0.4 + Math.random() * 0.5),
            vx: (Math.random() - 0.5) * 30,
            vy: rnd(20, 60),
            maxLife: rnd(0.4, 0.9), size: rnd(1.2, 2.6), hue: 262,
          })
        }
      } else if (bobSign > 0) {
        this.strideSign = 1
      }
    }

    if (elements.has('fire') && this.burning > 0.05) {
      const rate = this.burning * 44
      const n = rate * dt
      for (let i = 0; i < Math.ceil(n); i++) {
        if (i > 0 && Math.random() > n % 1) break
        ps.spawn('ember', {
          x: x + (Math.random() - 0.5) * R * 1.2,
          y: y + (Math.random() - 0.5) * R * 0.8,
          vx: (Math.random() - 0.5) * 26,
          vy: -rnd(60, 150) * (0.6 + this.burning * 0.6),
          maxLife: rnd(0.5, 1.1), size: rnd(2, 4.6), hue: rnd(16, 42), gf: -0.35, wf: 1.4,
        })
      }
      // v1.2 — a breath of smoke rises off the flames
      if (this.burning > 0.55 && Math.random() < 1.1 * dt) {
        ps.spawn('smoke', {
          x: x + (Math.random() - 0.5) * R * 0.5, y: y - R * 1.5,
          vx: (Math.random() - 0.5) * 10, vy: -rnd(20, 46),
          maxLife: rnd(1.8, 3), size: rnd(5, 10),
        })
      }
    }
    if (elements.has('lava') && this.lava > 0.05) {
      const n = this.lava * 16 * dt
      for (let i = 0; i < Math.ceil(n); i++) {
        if (i > 0 && Math.random() > n % 1) break
        ps.spawn('ember', {
          x: x + (Math.random() - 0.5) * R,
          y: y + R * 0.5,
          vx: (Math.random() - 0.5) * 18,
          vy: rnd(30, 90),
          maxLife: rnd(0.9, 1.6), size: rnd(2.4, 5), hue: rnd(8, 26), gf: 0.45,
        })
      }
    }
    if (elements.has('water')) {
      const n = 12 * dt
      for (let i = 0; i < Math.ceil(n); i++) {
        if (i > 0 && Math.random() > n % 1) break
        const a = Math.random() * Math.PI * 2
        ps.spawn('droplet', {
          x: x + Math.cos(a) * R * 1.3, y: y + Math.sin(a) * R * 1.3,
          vx: Math.cos(a) * 20, vy: 40 + Math.random() * 60,
          maxLife: rnd(0.5, 1), size: rnd(1.6, 3.2), hue: 205, gf: 0.5,
        })
      }
    }
    if (elements.has('smoke')) {
      const n = 9 * dt
      for (let i = 0; i < Math.ceil(n); i++) {
        if (i > 0 && Math.random() > n % 1) break
        ps.spawn('smoke', {
          x: x + (Math.random() - 0.5) * R, y: y - R * 0.4,
          vx: (Math.random() - 0.5) * 12, vy: -rnd(26, 60),
          maxLife: rnd(2, 3.4), size: rnd(6, 13),
        })
      }
    }
    if (elements.has('steam')) {
      const n = 11 * dt
      for (let i = 0; i < Math.ceil(n); i++) {
        if (i > 0 && Math.random() > n % 1) break
        ps.spawn('steam', {
          x: x + (Math.random() - 0.5) * R, y: y - R * 0.4,
          vx: (Math.random() - 0.5) * 14, vy: -rnd(50, 100),
          maxLife: rnd(1.6, 2.8), size: rnd(7, 15),
        })
      }
    }
    if (elements.has('earth')) {
      const n = 3 * dt
      for (let i = 0; i < Math.ceil(n); i++) {
        if (i > 0 && Math.random() > n % 1) break
        ps.spawn('dust', {
          x: x + (Math.random() - 0.5) * R * 2, y: y + (Math.random() - 0.5) * R,
          vx: (Math.random() - 0.5) * 24, vy: -rnd(6, 22),
          maxLife: rnd(1.4, 2.4), size: rnd(1.6, 3.4), hue: 28,
        })
      }
    }
    if (elements.has('electric') && this.electric > 0.3) {
      const n = 20 * dt
      for (let i = 0; i < Math.ceil(n); i++) {
        if (i > 0 && Math.random() > n % 1) break
        const a = Math.random() * Math.PI * 2
        ps.spawn('spark', {
          x: x + Math.cos(a) * R * rnd(0.9, 1.5), y: y + Math.sin(a) * R * rnd(0.9, 1.5),
          vx: Math.cos(a) * rnd(40, 140), vy: Math.sin(a) * rnd(40, 140),
          maxLife: rnd(0.14, 0.3), size: rnd(1, 2.2), hue: 200 + rnd(-20, 60), light: 84,
        })
      }
    }
  }

  /* ---------------- rendering ---------------- */

  draw(ctx: CanvasRenderingContext2D, t: number) {
    const x = this.renderX
    const y = this.renderY
    const R = this.radius()
    const morph = easeOut(this.morphT)

    // clones (shadow/afterimage)
    for (const c of this.clones) {
      if (c.life < 0) continue
      const k = 1 - c.life / c.maxLife
      ctx.save()
      ctx.globalAlpha = 0.28 * k
      this.drawShape(ctx, c.x, c.y, R * 0.94, t, '#4c1d95', true)
      ctx.restore()
    }

    // heartbeat glow modulation (the sphere “beats”)
    const heartA = this.heartbeat > 0.02 ? heartAmp(this.heartPhase) * this.heartbeat : 0

    // v1.2 — mood energy: breathing rate, glow shimmer, a lively quiver
    const mk = this.moodK()
    const breatheRate = this.sleeping > 0.3 ? 1.15 - this.sleeping * 0.7
      : this.mood === 'energetic' ? 2.6 - (1 - mk) * 1.2
        : this.mood === 'calm' || this.mood === 'sleepy' ? 0.7
          : 1.15
    const breatheAmp = 0.02 + this.sleeping * 0.03 + (this.mood === 'jubilant' ? mk * 0.02 : 0)
    const quiver = this.mood === 'energetic' && mk > 0.25 ? Math.sin(this.time * 26) * 1.1 * mk : 0
    const moodShimmer = (this.mood === 'jubilant' || this.mood === 'energetic') && mk > 0.2
      ? Math.sin(this.time * 8) * 0.06 * mk : 0

    ctx.save()
    ctx.globalAlpha = this.alpha
    ctx.translate(x + quiver, y)
    const sq = clamp(this.squish, -0.5, 0.5)
    const hp = 1 + heartA * 0.05
    const breathe = 1 + Math.sin(this.time * breatheRate) * breatheAmp
    ctx.scale((1 + sq * 0.5) * hp * breathe, (1 - sq * 0.5) * hp * breathe)
    ctx.rotate(this.rotation + this.flipRot)
    this.drawShape(ctx, 0, 0, R * morph, t, this.color, false)
    ctx.restore()

    // sleeping face — content, eyes closed
    if (this.sleeping > 0.45 && this.alpha > 0.3) {
      ctx.save()
      ctx.globalAlpha = this.sleeping * Math.min(1, this.alpha)
      ctx.strokeStyle = 'rgba(30,27,75,0.62)'
      ctx.lineWidth = Math.max(1.6, R * 0.06)
      ctx.lineCap = 'round'
      for (const ex of [-R * 0.32, R * 0.32]) {
        ctx.beginPath()
        ctx.arc(x + ex, y - R * 0.04, R * 0.16, Math.PI * 0.12, Math.PI * 0.88)
        ctx.stroke()
      }
      ctx.restore()
    }

    // halo — a quiet ring of light above the core
    if (this.halo > 0.02) {
      const hy = y - R * 1.7 - Math.sin(this.time * 1.2) * 3
      ctx.save()
      ctx.globalAlpha = this.halo * Math.min(1, this.alpha)
      ctx.strokeStyle = 'rgba(253,230,138,0.8)'
      ctx.lineWidth = R * 0.13
      ctx.shadowColor = 'rgba(253,230,138,0.85)'
      ctx.shadowBlur = 14
      ctx.beginPath()
      ctx.ellipse(x, hy, R * 0.62, R * 0.2, 0, 0, Math.PI * 2)
      ctx.stroke()
      ctx.restore()
    }

    // v1.2 — water wraps the sphere: a wobbling aqua film + highlight
    if (this.wet > 0.3 && this.alpha > 0.3) {
      const wk = Math.min(1, (this.wet - 0.3) / 0.7)
      ctx.save()
      ctx.globalAlpha = this.alpha * wk
      ctx.translate(x, y)
      ctx.beginPath()
      const seg = 26
      for (let i = 0; i <= seg; i++) {
        const a = (i / seg) * Math.PI * 2
        const rr = R * (1.05 + Math.sin(a * 3 + t * 2.6) * 0.035 + Math.sin(a * 5 - t * 1.7) * 0.02)
        const wx = Math.cos(a) * rr
        const wy = Math.sin(a) * rr
        if (i === 0) ctx.moveTo(wx, wy)
        else ctx.lineTo(wx, wy)
      }
      ctx.closePath()
      const wg = ctx.createRadialGradient(-R * 0.3, -R * 0.3, R * 0.2, 0, 0, R * 1.1)
      wg.addColorStop(0, 'rgba(103,232,249,0.22)')
      wg.addColorStop(0.7, 'rgba(56,189,248,0.16)')
      wg.addColorStop(1, 'rgba(14,116,144,0.05)')
      ctx.fillStyle = wg
      ctx.fill()
      ctx.strokeStyle = 'rgba(165,243,252,0.5)'
      ctx.lineWidth = 1.2
      ctx.stroke()
      // a travelling highlight, like light catching a wet surface
      const ha = t * 1.6
      ctx.strokeStyle = 'rgba(224,242,254,0.55)'
      ctx.lineWidth = Math.max(1.4, R * 0.07)
      ctx.beginPath()
      ctx.arc(0, 0, R * 0.88, ha, ha + 1.1)
      ctx.stroke()
      ctx.restore()
    }

    // v1.2 — rain rings ripple across the surface
    if (this.rainRings.length && this.alpha > 0.3) {
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      ctx.translate(x, y)
      ctx.beginPath()
      ctx.arc(0, 0, R * 0.99, 0, Math.PI * 2)
      ctx.clip()
      for (const rk of this.rainRings) {
        ctx.strokeStyle = `rgba(186,230,253,${(1 - rk) * 0.4})`
        ctx.lineWidth = 1.3
        ctx.beginPath()
        ctx.arc(0, 0, R * (0.2 + rk * 0.95), 0, Math.PI * 2)
        ctx.stroke()
      }
      ctx.restore()
    }

    // v1.2 — satellite motes: tiny companions always in orbit
    if (this.sleeping < 0.5 && this.alpha > 0.3) {
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      ctx.translate(x, y)
      const moteGlow = 0.35 + this.glow * 0.22 + this.pointerProx * 0.25
      for (const m of this.motes) {
        const mx = Math.cos(m.ang) * R * m.dist
        const my = Math.sin(m.ang) * R * m.dist * 0.62
        const tw = 0.6 + Math.sin(t * 3 + m.ang * 4) * 0.4
        ctx.fillStyle = `rgba(196,181,253,${moteGlow * tw})`
        ctx.beginPath()
        ctx.arc(mx, my, m.size, 0, Math.PI * 2)
        ctx.fill()
        ctx.fillStyle = `rgba(103,232,249,${moteGlow * 0.3 * tw})`
        ctx.beginPath()
        ctx.arc(mx, my, m.size * 2.4, 0, Math.PI * 2)
        ctx.fill()
      }
      ctx.restore()
    }

    // Siri-like reactive waveform while speaking
    if (this.speaking) {
      const s = this.speaking
      const env = Math.min(1, s.t / 0.18) * Math.min(1, Math.max(0, (s.dur - s.t) / 0.4))
      if (env > 0.01) {
        // pseudo-syllables — the waves swell with the voice
        const syll = 0.55 + 0.45 * Math.pow(Math.sin(s.t * 7.3) * 0.5 + 0.5, 1.4)
        ctx.save()
        ctx.globalCompositeOperation = 'lighter'
        ctx.translate(x, y)
        for (let ring = 0; ring < 3; ring++) {
          const baseR = R * (1.3 + ring * 0.26)
          ctx.beginPath()
          for (let a = 0; a <= Math.PI * 2 + 0.01; a += Math.PI / 26) {
            const wob = Math.sin(a * (3 + ring) + this.time * (7 + ring * 2.6)) * R * 0.16 * env * syll
            const rr = baseR + wob
            const px = Math.cos(a) * rr
            const py = Math.sin(a) * rr
            if (a === 0) ctx.moveTo(px, py)
            else ctx.lineTo(px, py)
          }
          ctx.closePath()
          const hue = 196 + ring * 44 + Math.sin(this.time * 3 + ring) * 16
          ctx.strokeStyle = `hsla(${hue},92%,72%,${(0.55 - ring * 0.14) * env})`
          ctx.lineWidth = 2.2 - ring * 0.5
          ctx.stroke()
        }
        // side sound-waves — little bars pulsing outward, like a voice made visible
        const bars = 4
        for (let side = -1; side <= 1; side += 2) {
          for (let b = 0; b < bars; b++) {
            const amp = (0.35 + 0.65 * Math.abs(Math.sin(s.t * 6.1 + b * 1.9 + side))) * env * syll
            const bh = R * 0.12 * amp * (1 - b * 0.16)
            const bx = side * (R * 1.65 + b * R * 0.22)
            ctx.strokeStyle = `hsla(${190 + b * 26},92%,74%,${0.5 * env * (1 - b * 0.18)})`
            ctx.lineWidth = Math.max(1.6, R * 0.055)
            ctx.lineCap = 'round'
            ctx.beginPath()
            ctx.moveTo(bx, -bh)
            ctx.lineTo(bx, bh)
            ctx.stroke()
          }
        }
        ctx.restore()
      }
    }

    // animated flames — real fire, not a tint
    if (this.burning > 0.04) {
      const b = Math.min(1.2, this.burning)
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      for (let f = 0; f < 3; f++) {
        const fxo = (f - 1) * R * 0.42
        const flick = Math.sin(this.time * (9 + f * 2.7) + f * 2.1) * 0.5 + Math.sin(this.time * (15 + f * 3.1) + f) * 0.5
        const h = R * (0.9 + b * 0.9) * (0.72 + 0.28 * flick) * (f === 1 ? 1.25 : 0.85)
        const wHalf = R * (f === 1 ? 0.42 : 0.3)
        const grad = ctx.createLinearGradient(fxo, y - R * 0.3, fxo, y - R * 0.3 - h)
        grad.addColorStop(0, `rgba(251,191,36,${0.55 * b})`)
        grad.addColorStop(0.55, `rgba(249,115,22,${0.42 * b})`)
        grad.addColorStop(1, 'rgba(239,68,68,0)')
        ctx.fillStyle = grad
        ctx.beginPath()
        ctx.moveTo(fxo - wHalf, y - R * 0.25)
        ctx.quadraticCurveTo(fxo - wHalf * 0.7, y - R * 0.25 - h * 0.55, fxo + Math.sin(this.time * 7 + f * 2) * R * 0.16, y - R * 0.25 - h)
        ctx.quadraticCurveTo(fxo + wHalf * 0.7, y - R * 0.25 - h * 0.55, fxo + wHalf, y - R * 0.25)
        ctx.closePath()
        ctx.fill()
      }
      // warm light emission
      const warm = ctx.createRadialGradient(x, y, R * 0.3, x, y, R * 3.1)
      warm.addColorStop(0, `rgba(251,146,60,${0.22 * b * this.bloomMul})`)
      warm.addColorStop(1, 'rgba(251,146,60,0)')
      ctx.fillStyle = warm
      ctx.beginPath()
      ctx.arc(x, y, R * 3.1, 0, Math.PI * 2)
      ctx.fill()
      ctx.restore()
    }

    // glow halo
    ctx.save()
    ctx.globalCompositeOperation = 'lighter'
    const glowNow = this.glow * (1 + heartA * 0.34 + moodShimmer + this.pointerProx * 0.16) * (this.speaking ? 1 + Math.sin(this.time * 9) * 0.12 : 1)
    const glowR = R * 3.4 * glowNow
    const g = ctx.createRadialGradient(x, y, R * 0.2, x, y, glowR)
    const c = hexToRgba(this.color, 0.34 * glowNow * morph * this.bloomMul)
    g.addColorStop(0, c)
    g.addColorStop(1, 'rgba(0,0,0,0)')
    ctx.fillStyle = g
    ctx.beginPath()
    ctx.arc(x, y, glowR, 0, Math.PI * 2)
    ctx.fill()
    ctx.restore()
  }

  private drawShape(ctx: CanvasRenderingContext2D, x: number, y: number, R: number, t: number, color: string, ghost: boolean) {
    ctx.save()
    ctx.translate(x, y)

    const makeGrad = (r: number) => {
      if (this.dimension === '2d') {
        // flat, lightweight — for the 2D mode and slower devices
        const g = ctx.createRadialGradient(0, 0, r * 0.3, 0, 0, r)
        g.addColorStop(0, ghost ? 'rgba(76,29,149,0.3)' : lighten(color, 0.2))
        g.addColorStop(1, ghost ? 'rgba(30,20,60,0.1)' : darken(color, 0.18))
        return g
      }
      const g = ctx.createRadialGradient(-r * 0.32, -r * 0.36, r * 0.08, 0, 0, r * 1.05)
      g.addColorStop(0, ghost ? 'rgba(76,29,149,0.4)' : lighten(color, 0.55))
      g.addColorStop(0.42, ghost ? 'rgba(76,29,149,0.28)' : color)
      g.addColorStop(1, ghost ? 'rgba(30,20,60,0.12)' : darken(color, 0.45))
      return g
    }

    const frozen = this.frozen
    const wet = this.wet

    switch (this.shape) {
      case 'cube': {
        ctx.fillStyle = makeGrad(R)
        roundRect(ctx, -R * 0.82, -R * 0.82, R * 1.64, R * 1.64, R * 0.18)
        ctx.fill()
        break
      }
      case 'star': {
        ctx.fillStyle = makeGrad(R)
        star(ctx, 0, 0, 5, R, R * 0.44, t * 0.2)
        ctx.fill()
        break
      }
      case 'ring': {
        ctx.strokeStyle = makeGrad(R)
        ctx.lineWidth = R * 0.42
        ctx.beginPath()
        ctx.ellipse(0, 0, R * 0.95, R * 0.38, 0, 0, Math.PI * 2)
        ctx.stroke()
        break
      }
      case 'crystal': {
        ctx.fillStyle = makeGrad(R)
        ctx.beginPath()
        ctx.moveTo(0, -R)
        ctx.lineTo(R * 0.58, -R * 0.18)
        ctx.lineTo(R * 0.36, R * 0.92)
        ctx.lineTo(-R * 0.36, R * 0.92)
        ctx.lineTo(-R * 0.58, -R * 0.18)
        ctx.closePath()
        ctx.fill()
        ctx.strokeStyle = 'rgba(255,255,255,0.35)'
        ctx.lineWidth = 1
        ctx.beginPath()
        ctx.moveTo(0, -R)
        ctx.lineTo(0, R * 0.92)
        ctx.moveTo(-R * 0.58, -R * 0.18)
        ctx.lineTo(R * 0.58, -R * 0.18)
        ctx.stroke()
        break
      }
      case 'diamond': {
        ctx.fillStyle = makeGrad(R)
        ctx.beginPath()
        ctx.moveTo(0, -R)
        ctx.lineTo(R * 0.72, 0)
        ctx.lineTo(0, R)
        ctx.lineTo(-R * 0.72, 0)
        ctx.closePath()
        ctx.fill()
        break
      }
      case 'heart': {
        ctx.save()
        ctx.scale(R / 26, R / 26)
        drawHeartPath(ctx, 0, 0)
        ctx.fillStyle = makeGrad(26)
        ctx.fill()
        ctx.restore()
        break
      }
      case 'planet': {
        ctx.fillStyle = makeGrad(R * 0.78)
        ctx.beginPath()
        ctx.arc(0, 0, R * 0.78, 0, Math.PI * 2)
        ctx.fill()
        ctx.save()
        ctx.rotate(-0.42)
        ctx.strokeStyle = 'rgba(196,181,253,0.72)'
        ctx.lineWidth = R * 0.16
        ctx.beginPath()
        ctx.ellipse(0, 0, R * 1.34, R * 0.4, 0, 0, Math.PI * 2)
        ctx.stroke()
        ctx.restore()
        break
      }
      case 'rocket': {
        ctx.fillStyle = '#e2e8f0'
        ctx.beginPath()
        ctx.moveTo(0, -R * 1.1)
        ctx.quadraticCurveTo(R * 0.55, -R * 0.2, R * 0.4, R * 0.72)
        ctx.lineTo(-R * 0.4, R * 0.72)
        ctx.quadraticCurveTo(-R * 0.55, -R * 0.2, 0, -R * 1.1)
        ctx.closePath()
        ctx.fill()
        ctx.fillStyle = '#60a5fa'
        ctx.beginPath()
        ctx.arc(0, -R * 0.16, R * 0.2, 0, Math.PI * 2)
        ctx.fill()
        ctx.fillStyle = '#f472b6'
        ctx.beginPath()
        ctx.moveTo(-R * 0.4, R * 0.3)
        ctx.lineTo(-R * 0.85, R * 0.85)
        ctx.lineTo(-R * 0.4, R * 0.72)
        ctx.closePath()
        ctx.moveTo(R * 0.4, R * 0.3)
        ctx.lineTo(R * 0.85, R * 0.85)
        ctx.lineTo(R * 0.4, R * 0.72)
        ctx.closePath()
        ctx.fill()
        const fl = 0.6 + Math.sin(t * 22) * 0.4
        ctx.fillStyle = `rgba(251,191,36,${0.85 * fl})`
        ctx.beginPath()
        ctx.moveTo(-R * 0.22, R * 0.72)
        ctx.quadraticCurveTo(0, R * (1.3 + fl * 0.4), R * 0.22, R * 0.72)
        ctx.closePath()
        ctx.fill()
        break
      }
      case 'ball': {
        ctx.fillStyle = makeGrad(R)
        ctx.beginPath()
        ctx.arc(0, 0, R, 0, Math.PI * 2)
        ctx.fill()
        ctx.strokeStyle = 'rgba(255,255,255,0.5)'
        ctx.lineWidth = 1.4
        ctx.beginPath()
        ctx.arc(0, 0, R * 0.62, 0.3, Math.PI - 0.3)
        ctx.stroke()
        ctx.beginPath()
        ctx.arc(0, 0, R * 0.62, Math.PI + 0.3, Math.PI * 2 - 0.3)
        ctx.stroke()
        break
      }
      case 'moon': {
        ctx.fillStyle = '#e2e8f0'
        ctx.beginPath()
        ctx.arc(0, 0, R, 0, Math.PI * 2)
        ctx.fill()
        ctx.fillStyle = 'rgba(148,163,184,0.4)'
        for (const [dx, dy, dr] of [[0.28, -0.2, 0.17], [-0.24, 0.3, 0.13], [0.05, 0.45, 0.1], [-0.38, -0.3, 0.09]] as const) {
          ctx.beginPath()
          ctx.arc(dx * R, dy * R, dr * R, 0, Math.PI * 2)
          ctx.fill()
        }
        break
      }
      case 'comet': {
        ctx.fillStyle = makeGrad(R * 0.8)
        ctx.beginPath()
        ctx.arc(0, 0, R * 0.8, 0, Math.PI * 2)
        ctx.fill()
        const g = ctx.createLinearGradient(0, 0, R * 2.2, R * 1.6)
        g.addColorStop(0, 'rgba(165,243,252,0.5)')
        g.addColorStop(1, 'rgba(165,243,252,0)')
        ctx.fillStyle = g
        ctx.beginPath()
        ctx.moveTo(0, -R * 0.5)
        ctx.quadraticCurveTo(R * 1.8, R * 0.4, R * 2.2, R * 1.6)
        ctx.quadraticCurveTo(R * 0.8, R * 0.9, 0, R * 0.5)
        ctx.closePath()
        ctx.fill()
        break
      }
      case 'asteroid': {
        ctx.fillStyle = makeGrad(R)
        ctx.beginPath()
        const pts = 9
        for (let i = 0; i < pts; i++) {
          const a = (i / pts) * Math.PI * 2
          const rr = R * (0.82 + ((i * 37) % 5) * 0.06)
          if (i === 0) ctx.moveTo(Math.cos(a) * rr, Math.sin(a) * rr)
          else ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr)
        }
        ctx.closePath()
        ctx.fill()
        ctx.fillStyle = 'rgba(0,0,0,0.25)'
        ctx.beginPath()
        ctx.arc(-R * 0.2, R * 0.14, R * 0.2, 0, Math.PI * 2)
        ctx.fill()
        break
      }
      case 'flower': {
        const petals = 6
        for (let i = 0; i < petals; i++) {
          const a = (i / petals) * Math.PI * 2 + t * 0.15
          ctx.save()
          ctx.rotate(a)
          ctx.fillStyle = `hsla(${(i / petals) * 40 + 325},85%,${72 + wet * 8}%,0.92)`
          ctx.beginPath()
          ctx.ellipse(0, -R * 0.62, R * 0.3, R * 0.55, 0, 0, Math.PI * 2)
          ctx.fill()
          ctx.restore()
        }
        ctx.fillStyle = '#fde68a'
        ctx.beginPath()
        ctx.arc(0, 0, R * 0.3, 0, Math.PI * 2)
        ctx.fill()
        break
      }
      case 'portal': {
        ctx.save()
        ctx.rotate(t * 1.4)
        for (let i = 0; i < 3; i++) {
          ctx.strokeStyle = `hsla(${262 + i * 24},90%,${64 + i * 8}%,${0.75 - i * 0.18})`
          ctx.lineWidth = R * 0.1
          ctx.beginPath()
          ctx.ellipse(0, 0, R * (1 - i * 0.24), R * (0.44 - i * 0.09), i * 0.5, 0, Math.PI * 2)
          ctx.stroke()
        }
        ctx.restore()
        const g = ctx.createRadialGradient(0, 0, 0, 0, 0, R * 0.5)
        g.addColorStop(0, 'rgba(237,233,254,0.85)')
        g.addColorStop(0.6, 'rgba(167,139,250,0.5)')
        g.addColorStop(1, 'rgba(167,139,250,0)')
        ctx.fillStyle = g
        ctx.beginPath()
        ctx.ellipse(0, 0, R * 0.5, R * 0.24, 0, 0, Math.PI * 2)
        ctx.fill()
        break
      }
      case 'eye': {
        ctx.fillStyle = '#e2e8f0'
        ctx.beginPath()
        ctx.ellipse(0, 0, R, R * 0.62, 0, 0, Math.PI * 2)
        ctx.fill()
        const blink = Math.max(0.06, Math.abs(Math.sin(t * 0.7)) > 0.96 ? 0.1 : 1)
        ctx.save()
        ctx.scale(1, blink)
        const ir = ctx.createRadialGradient(0, 0, 0, 0, 0, R * 0.4)
        ir.addColorStop(0, '#67e8f9')
        ir.addColorStop(0.75, '#7C3AED')
        ir.addColorStop(1, '#312e81')
        ctx.fillStyle = ir
        ctx.beginPath()
        ctx.arc(0, 0, R * 0.4, 0, Math.PI * 2)
        ctx.fill()
        ctx.fillStyle = '#0B1026'
        ctx.beginPath()
        ctx.arc(0, 0, R * 0.17, 0, Math.PI * 2)
        ctx.fill()
        ctx.fillStyle = 'rgba(255,255,255,0.85)'
        ctx.beginPath()
        ctx.arc(-R * 0.12, -R * 0.12, R * 0.06, 0, Math.PI * 2)
        ctx.fill()
        ctx.restore()
        break
      }
      case 'ghost': {
        ctx.fillStyle = 'rgba(226,232,240,0.88)'
        ctx.beginPath()
        ctx.arc(0, -R * 0.2, R * 0.8, Math.PI, Math.PI * 2)
        const wob = Math.sin(t * 5) * R * 0.12
        ctx.quadraticCurveTo(R * 0.8, R * 0.5 + wob, R * 0.45, R * 0.66)
        ctx.quadraticCurveTo(R * 0.22, R * 0.4 - wob, 0, R * 0.66)
        ctx.quadraticCurveTo(-R * 0.22, R * 0.4 + wob, -R * 0.45, R * 0.66)
        ctx.quadraticCurveTo(-R * 0.8, R * 0.5 - wob, -R * 0.8, -R * 0.2)
        ctx.fill()
        ctx.fillStyle = '#334155'
        ctx.beginPath()
        ctx.arc(-R * 0.26, -R * 0.3, R * 0.09, 0, Math.PI * 2)
        ctx.arc(R * 0.26, -R * 0.3, R * 0.09, 0, Math.PI * 2)
        ctx.fill()
        break
      }
      case 'balloon': {
        ctx.fillStyle = makeGrad(R * 0.85)
        ctx.beginPath()
        ctx.ellipse(0, -R * 0.15, R * 0.68, R * 0.82, 0, 0, Math.PI * 2)
        ctx.fill()
        ctx.fillStyle = makeGrad(R * 0.2)
        ctx.beginPath()
        ctx.moveTo(-R * 0.1, R * 0.62)
        ctx.lineTo(R * 0.1, R * 0.62)
        ctx.lineTo(R * 0.06, R * 0.74)
        ctx.lineTo(-R * 0.06, R * 0.74)
        ctx.closePath()
        ctx.fill()
        ctx.strokeStyle = 'rgba(226,232,240,0.6)'
        ctx.lineWidth = 1
        ctx.beginPath()
        ctx.moveTo(0, R * 0.74)
        ctx.quadraticCurveTo(R * 0.14, R * 1.1, 0, R * 1.4)
        ctx.stroke()
        break
      }
      default: {
        // the classic orb — five souls, one sphere
        if (ghost || this.dimension === '2d') {
          const g2 = makeGrad(R)
          ctx.fillStyle = g2
          ctx.beginPath()
          ctx.arc(0, 0, R, 0, Math.PI * 2)
          ctx.fill()
          if (this.dimension === '2d' && !ghost) {
            // one flat accent ring keeps the style readable in 2D
            ctx.strokeStyle = hexToRgba(lighten(color, 0.45), 0.55)
            ctx.lineWidth = Math.max(1.2, R * 0.05)
            ctx.beginPath()
            ctx.arc(0, 0, R * 0.8, 0, Math.PI * 2)
            ctx.stroke()
          }
          if (ghost && this.dimension === '3d') {
            ctx.globalCompositeOperation = 'lighter'
            const core = ctx.createRadialGradient(-R * 0.2, -R * 0.24, 0, -R * 0.2, -R * 0.24, R * 0.5)
            core.addColorStop(0, 'rgba(255,255,255,0.65)')
            core.addColorStop(1, 'rgba(255,255,255,0)')
            ctx.fillStyle = core
            ctx.beginPath()
            ctx.arc(-R * 0.2, -R * 0.24, R * 0.5, 0, Math.PI * 2)
            ctx.fill()
          }
          break
        }
        switch (this.style) {
          case 'crystal': {
            ctx.fillStyle = makeGrad(R)
            ctx.beginPath()
            const facets = 7
            for (let i = 0; i < facets; i++) {
              const a = (i / facets) * Math.PI * 2 - Math.PI / 2
              const rr = R * (0.86 + ((i * 53) % 3) * 0.07)
              if (i === 0) ctx.moveTo(Math.cos(a) * rr, Math.sin(a) * rr)
              else ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr)
            }
            ctx.closePath()
            ctx.fill()
            ctx.strokeStyle = 'rgba(255,255,255,0.38)'
            ctx.lineWidth = 1
            for (let i = 0; i < facets; i++) {
              const a = (i / facets) * Math.PI * 2 - Math.PI / 2
              ctx.beginPath()
              ctx.moveTo(0, 0)
              ctx.lineTo(Math.cos(a) * R * 0.92, Math.sin(a) * R * 0.92)
              ctx.stroke()
            }
            const glint = 0.5 + Math.sin(t * 1.8) * 0.5
            ctx.fillStyle = `rgba(255,255,255,${0.22 + glint * 0.28})`
            ctx.beginPath()
            ctx.moveTo(-R * 0.1, -R * 0.55)
            ctx.lineTo(R * 0.12, -R * 0.4)
            ctx.lineTo(-R * 0.02, -R * 0.2)
            ctx.closePath()
            ctx.fill()
            break
          }
          case 'galaxy': {
            const g2 = ctx.createRadialGradient(0, 0, 0, 0, 0, R)
            g2.addColorStop(0, '#312e81')
            g2.addColorStop(0.6, '#1e1b4b')
            g2.addColorStop(1, '#0b1026')
            ctx.fillStyle = g2
            ctx.beginPath()
            ctx.arc(0, 0, R, 0, Math.PI * 2)
            ctx.fill()
            ctx.save()
            ctx.beginPath()
            ctx.arc(0, 0, R * 0.98, 0, Math.PI * 2)
            ctx.clip()
            for (let arm = 0; arm < 2; arm++) {
              for (let i = 0; i < 26; i++) {
                const p = i / 26
                const a = p * 2.4 + arm * Math.PI + t * 0.5
                const rr = p * R * 0.92
                ctx.fillStyle = p < 0.3 ? 'rgba(253,230,138,0.75)' : arm === 0 ? 'rgba(167,139,250,0.6)' : 'rgba(96,165,250,0.6)'
                ctx.beginPath()
                ctx.arc(Math.cos(a) * rr, Math.sin(a) * rr, R * 0.045 * (1 - p * 0.5), 0, Math.PI * 2)
                ctx.fill()
              }
            }
            const cg = ctx.createRadialGradient(0, 0, 0, 0, 0, R * 0.4)
            cg.addColorStop(0, 'rgba(226,232,240,0.8)')
            cg.addColorStop(1, 'rgba(226,232,240,0)')
            ctx.fillStyle = cg
            ctx.beginPath()
            ctx.arc(0, 0, R * 0.4, 0, Math.PI * 2)
            ctx.fill()
            ctx.restore()
            break
          }
          case 'liquid': {
            ctx.fillStyle = makeGrad(R)
            ctx.beginPath()
            const seg = 40
            for (let i = 0; i <= seg; i++) {
              const a = (i / seg) * Math.PI * 2
              const rr = R * (1 + Math.sin(a * 3 + t * 2.1) * 0.055 + Math.sin(a * 5 - t * 1.4) * 0.035)
              if (i === 0) ctx.moveTo(Math.cos(a) * rr, Math.sin(a) * rr)
              else ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr)
            }
            ctx.closePath()
            ctx.fill()
            ctx.fillStyle = 'rgba(255,255,255,0.32)'
            ctx.beginPath()
            ctx.ellipse(-R * 0.3, -R * 0.36, R * 0.26, R * 0.14, -0.6, 0, Math.PI * 2)
            ctx.fill()
            break
          }
          case 'pixel': {
            const cell = R / 4.6
            for (let gy = -4; gy <= 4; gy++) {
              for (let gx = -4; gx <= 4; gx++) {
                const d = Math.hypot(gx + 0.5, gy + 0.5)
                if (d > 4.3) continue
                const shade = clamp(1 - d / 4.6, 0, 1)
                const q = Math.floor(shade * 4) / 4
                const tw = Math.sin(t * 3 + gx * 1.3 + gy * 2.1) * 0.5 + 0.5
                ctx.fillStyle = lighten(color, 0.08 + q * 0.42 + tw * 0.08)
                ctx.fillRect(gx * cell, gy * cell, cell + 0.5, cell + 0.5)
              }
            }
            break
          }
          default: {
            // 3D energy core — layered light + slow plasma wisps
            ctx.fillStyle = makeGrad(R)
            ctx.beginPath()
            ctx.arc(0, 0, R, 0, Math.PI * 2)
            ctx.fill()
            ctx.save()
            ctx.beginPath()
            ctx.arc(0, 0, R * 0.96, 0, Math.PI * 2)
            ctx.clip()
            ctx.globalCompositeOperation = 'lighter'
            for (let w = 0; w < 3; w++) {
              const a = t * (0.5 + w * 0.22) + w * 2.1
              const wx = Math.cos(a) * R * 0.42
              const wy = Math.sin(a * 1.3) * R * 0.4
              const wg = ctx.createRadialGradient(wx, wy, 0, wx, wy, R * 0.5)
              wg.addColorStop(0, w === 1 ? 'rgba(103,232,249,0.2)' : 'rgba(167,139,250,0.24)')
              wg.addColorStop(1, 'rgba(0,0,0,0)')
              ctx.fillStyle = wg
              ctx.beginPath()
              ctx.arc(wx, wy, R * 0.5, 0, Math.PI * 2)
              ctx.fill()
            }
            ctx.restore()
            ctx.globalCompositeOperation = 'lighter'
            const core = ctx.createRadialGradient(-R * 0.2, -R * 0.24, 0, -R * 0.2, -R * 0.24, R * 0.5)
            core.addColorStop(0, 'rgba(255,255,255,0.65)')
            core.addColorStop(1, 'rgba(255,255,255,0)')
            ctx.fillStyle = core
            ctx.beginPath()
            ctx.arc(-R * 0.2, -R * 0.24, R * 0.5, 0, Math.PI * 2)
            ctx.fill()
            break
          }
        }
        break
      }
    }

    // frozen overlay — ice grows over time, crystal by crystal
    if (frozen > 0.02 && !ghost) {
      const fr = frozen
      ctx.save()
      ctx.globalAlpha = Math.min(1, fr * 1.4)
      // crystalline spikes around the rim (count + length grow with fr)
      const spikes = 3 + Math.floor(fr * 8)
      for (let i = 0; i < spikes; i++) {
        const a = (i / spikes) * Math.PI * 2 + 0.35 + Math.sin(i * 3.7) * 0.2
        const len = R * fr * (0.28 + ((i * 37) % 7) / 7 * 0.5)
        ctx.fillStyle = `rgba(191,239,255,${0.34 + fr * 0.3})`
        ctx.beginPath()
        ctx.moveTo(Math.cos(a - 0.22) * R * 0.9, Math.sin(a - 0.22) * R * 0.9)
        ctx.lineTo(Math.cos(a) * (R * 0.92 + len), Math.sin(a) * (R * 0.92 + len))
        ctx.lineTo(Math.cos(a + 0.22) * R * 0.9, Math.sin(a + 0.22) * R * 0.9)
        ctx.closePath()
        ctx.fill()
      }
      // frost shell
      ctx.fillStyle = `rgba(191,239,255,${0.16 + fr * 0.2})`
      ctx.beginPath()
      ctx.arc(0, 0, R * 1.02, 0, Math.PI * 2)
      ctx.fill()
      // inner cracks spread as it deepens
      ctx.strokeStyle = `rgba(224,242,254,${0.25 + fr * 0.5})`
      ctx.lineWidth = 1.1
      for (let i = 0; i < 4; i++) {
        const a = i * 1.7 + 0.4
        ctx.beginPath()
        ctx.moveTo(Math.cos(a) * R * 0.15, Math.sin(a) * R * 0.15)
        ctx.lineTo(Math.cos(a + 0.5) * R * 0.55 * fr, Math.sin(a + 0.5) * R * 0.55 * fr)
        ctx.lineTo(Math.cos(a + 0.2) * R * 0.85 * fr, Math.sin(a + 0.2) * R * 0.85 * fr)
        ctx.stroke()
      }
      // icicles reach down as the ice sets in
      for (let j = -1; j <= 1; j++) {
        const ix = j * R * 0.42
        const ilen = R * fr * (0.45 + (j + 1) * 0.13) * (1 + Math.sin(t * 0.9 + j * 2) * 0.1)
        ctx.fillStyle = 'rgba(224,242,254,0.78)'
        ctx.beginPath()
        ctx.moveTo(ix - R * 0.09, R * 0.98)
        ctx.lineTo(ix + R * 0.09, R * 0.98)
        ctx.lineTo(ix, R * 0.98 + ilen)
        ctx.closePath()
        ctx.fill()
      }
      ctx.restore()
    }

    // chrome sheen — a light band sweeping the surface
    if (this.chrome > 0.03 && !ghost) {
      const p = (this.chromePhase * 1.4) % 1
      const sweep = -R + p * R * 2.6
      ctx.save()
      ctx.beginPath()
      ctx.arc(0, 0, R * 1.01, 0, Math.PI * 2)
      ctx.clip()
      const g = ctx.createLinearGradient(sweep - R * 0.35, -R, sweep + R * 0.35, R)
      g.addColorStop(0, 'rgba(255,255,255,0)')
      g.addColorStop(0.5, `rgba(255,255,255,${0.5 * this.chrome})`)
      g.addColorStop(1, 'rgba(255,255,255,0)')
      ctx.fillStyle = g
      ctx.fillRect(-R, -R, R * 2, R * 2)
      ctx.globalAlpha = this.chrome * 0.5
      ctx.fillStyle = 'rgba(203,213,225,0.16)'
      ctx.fillRect(-R, -R * 0.25, R * 2, R * 0.14)
      ctx.fillRect(-R, R * 0.18, R * 2, R * 0.1)
      ctx.restore()
    }

    // electric arcs
    if (this.electric > 0.3 && !ghost) {
      ctx.strokeStyle = `rgba(165,243,252,${0.5 + Math.random() * 0.4})`
      ctx.lineWidth = 1.4
      for (let i = 0; i < 3; i++) {
        const a0 = Math.random() * Math.PI * 2
        ctx.beginPath()
        let ax = Math.cos(a0) * R
        let ay = Math.sin(a0) * R
        ctx.moveTo(ax, ay)
        for (let j = 0; j < 3; j++) {
          ax += (Math.random() - 0.5) * R * 0.5
          ay += (Math.random() - 0.5) * R * 0.5
          ctx.lineTo(ax, ay)
        }
        ctx.stroke()
      }
    }

    ctx.restore()
  }

  /* ---------------- trail ---------------- */

  drawTrail(ctx: CanvasRenderingContext2D) {
    if (!this.trailKind || this.trail.length < 2) return
    const pts = this.trail
    ctx.save()
    ctx.globalCompositeOperation = 'lighter'
    switch (this.trailKind) {
      case 'rainbow': {
        for (let i = 0; i < pts.length; i++) {
          const k = i / pts.length
          const p = pts[i]
          ctx.fillStyle = `hsla(${(t0(p) * 60 + i * 6) % 360},90%,68%,${k * 0.34})`
          ctx.beginPath()
          ctx.arc(p.x, p.y, 5 + k * 8, 0, Math.PI * 2)
          ctx.fill()
        }
        break
      }
      case 'sparkle': {
        for (let i = 0; i < pts.length; i += 2) {
          const k = i / pts.length
          const p = pts[i]
          const s = 2 + Math.random() * 3
          ctx.fillStyle = `rgba(253,246,220,${k * 0.6})`
          ctx.beginPath()
          ctx.arc(p.x, p.y, s, 0, Math.PI * 2)
          ctx.fill()
          ctx.strokeStyle = `rgba(253,230,138,${k * 0.3})`
          ctx.lineWidth = 0.8
          ctx.beginPath()
          ctx.moveTo(p.x - s * 2.4, p.y)
          ctx.lineTo(p.x + s * 2.4, p.y)
          ctx.moveTo(p.x, p.y - s * 2.4)
          ctx.lineTo(p.x, p.y + s * 2.4)
          ctx.stroke()
        }
        break
      }
      case 'gold': {
        for (let i = 0; i < pts.length; i++) {
          const k = i / pts.length
          const p = pts[i]
          ctx.fillStyle = `rgba(251,191,36,${k * 0.4})`
          ctx.beginPath()
          ctx.arc(p.x, p.y, 3 + k * 5, 0, Math.PI * 2)
          ctx.fill()
        }
        break
      }
      case 'fire': {
        for (let i = 0; i < pts.length; i++) {
          const k = i / pts.length
          const p = pts[i]
          ctx.fillStyle = `hsla(${20 + k * 22},95%,${52 + k * 14}%,${k * 0.4})`
          ctx.beginPath()
          ctx.arc(p.x, p.y + (1 - k) * 10, 4 + k * 7, 0, Math.PI * 2)
          ctx.fill()
        }
        break
      }
      case 'ice': {
        for (let i = 0; i < pts.length; i += 2) {
          const k = i / pts.length
          const p = pts[i]
          ctx.fillStyle = `rgba(224,242,254,${k * 0.44})`
          ctx.save()
          ctx.translate(p.x, p.y)
          ctx.rotate(k * 3)
          ctx.fillRect(-3 - k * 3, -1.4 - k, 6 + k * 6, 2.8 + k * 2)
          ctx.restore()
        }
        break
      }
      case 'comet': {
        const grad = ctx.createLinearGradient(pts[0].x, pts[0].y, pts[pts.length - 1].x, pts[pts.length - 1].y)
        grad.addColorStop(0, 'rgba(165,243,252,0)')
        grad.addColorStop(1, 'rgba(165,243,252,0.4)')
        ctx.strokeStyle = grad
        ctx.lineWidth = 10
        ctx.lineCap = 'round'
        ctx.beginPath()
        ctx.moveTo(pts[0].x, pts[0].y)
        for (const p of pts) ctx.lineTo(p.x, p.y)
        ctx.stroke()
        break
      }
      case 'heart': {
        for (let i = 0; i < pts.length; i += 4) {
          const k = i / pts.length
          const p = pts[i]
          drawHeart(ctx, p.x, p.y, 4 + k * 8, `rgba(251,113,133,${k * 0.5})`)
        }
        break
      }
      case 'star': {
        for (let i = 0; i < pts.length; i += 3) {
          const k = i / pts.length
          const p = pts[i]
          ctx.fillStyle = `rgba(254,249,195,${k * 0.55})`
          star(ctx, p.x, p.y, 5, 4 + k * 4, 1.6 + k * 1.6, 0)
          ctx.fill()
        }
        break
      }
      case 'echo': {
        for (let i = pts.length - 4; i >= 0; i -= 5) {
          const k = i / pts.length
          const p = pts[i]
          ctx.strokeStyle = `rgba(196,181,253,${k * 0.34})`
          ctx.lineWidth = 1.4
          ctx.beginPath()
          ctx.arc(p.x, p.y, this.radius() * 0.9 * k, 0, Math.PI * 2)
          ctx.stroke()
        }
        break
      }
      case 'bubble': {
        for (let i = 0; i < pts.length; i += 2) {
          const k = i / pts.length
          const p = pts[i]
          ctx.strokeStyle = `rgba(186,230,253,${k * 0.4})`
          ctx.lineWidth = 1
          ctx.beginPath()
          ctx.arc(p.x, p.y, 2 + k * 7, 0, Math.PI * 2)
          ctx.stroke()
        }
        break
      }
      case 'musical': {
        for (let i = 0; i < pts.length; i += 4) {
          const k = i / pts.length
          const p = pts[i]
          ctx.fillStyle = `hsla(${265 + i * 8},85%,75%,${k * 0.5})`
          ctx.font = `${9 + k * 7}px serif`
          ctx.fillText(Math.random() < 0.5 ? '♪' : '♫', p.x, p.y)
        }
        break
      }
    }
    ctx.restore()
    ctx.globalCompositeOperation = 'source-over'
  }
}

function t0(p: TrailPoint) {
  return p.t * 0.4
}

/* ---------------- shape helpers ---------------- */

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.lineTo(x + w - r, y)
  ctx.quadraticCurveTo(x + w, y, x + w, y + r)
  ctx.lineTo(x + w, y + h - r)
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h)
  ctx.lineTo(x + r, y + h)
  ctx.quadraticCurveTo(x, y + h, x, y + h - r)
  ctx.lineTo(x, y + r)
  ctx.quadraticCurveTo(x, y, x + r, y)
  ctx.closePath()
}

function star(ctx: CanvasRenderingContext2D, cx: number, cy: number, spikes: number, outerR: number, innerR: number, rot: number) {
  let rot0 = rot - Math.PI / 2
  let step = Math.PI / spikes
  ctx.beginPath()
  ctx.moveTo(cx, cy - outerR)
  for (let i = 0; i < spikes; i++) {
    rot0 += step
    ctx.lineTo(cx + Math.cos(rot0) * innerR, cy + Math.sin(rot0) * innerR)
    rot0 += step
    ctx.lineTo(cx + Math.cos(rot0) * outerR, cy + Math.sin(rot0) * outerR)
  }
  ctx.closePath()
}

function drawHeartPath(ctx: CanvasRenderingContext2D, x: number, y: number) {
  ctx.beginPath()
  ctx.moveTo(x, y + 3.2)
  ctx.bezierCurveTo(x - 5.6, y - 1.6, x - 3.4, y - 6, x, y - 3)
  ctx.bezierCurveTo(x + 3.4, y - 6, x + 5.6, y - 1.6, x, y + 3.2)
  ctx.closePath()
}

/* ---------------- color helpers ---------------- */

export function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace('#', '')
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16)
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255]
}

export function rgbToHex(r: number, g: number, b: number): string {
  const c = (v: number) => Math.round(clamp(v, 0, 255)).toString(16).padStart(2, '0')
  return `#${c(r)}${c(g)}${c(b)}`
}

export function lerpHex(a: string, b: string, t: number): string {
  const [ar, ag, ab] = hexToRgb(a)
  const [br, bg, bb] = hexToRgb(b)
  return rgbToHex(ar + (br - ar) * t, ag + (bg - ag) * t, ab + (bb - ab) * t)
}

export function lighten(hex: string, k: number): string {
  const [r, g, b] = hexToRgb(hex)
  return rgbToHex(r + (255 - r) * k, g + (255 - g) * k, b + (255 - b) * k)
}

export function darken(hex: string, k: number): string {
  const [r, g, b] = hexToRgb(hex)
  return rgbToHex(r * (1 - k), g * (1 - k), b * (1 - k))
}

export function hexToRgba(hex: string, a: number): string {
  const [r, g, b] = hexToRgb(hex)
  return `rgba(${r},${g},${b},${a})`
}

function clamp(v: number, min: number, max: number) {
  return v < min ? min : v > max ? max : v
}

function easeOut(t: number) {
  return 1 - Math.pow(1 - t, 3)
}

/** lub-dub — a double heartbeat pulse in [0, ~1.05] */
function heartAmp(ph: number) {
  const p = ph % 1
  const lub = Math.exp(-Math.pow((p - 0.08) / 0.06, 2))
  const dub = 0.55 * Math.exp(-Math.pow((p - 0.32) / 0.055, 2))
  return lub + dub
}

function w2(w: number) { return w / 2 }
function h42(h: number) { return h * 0.42 }
