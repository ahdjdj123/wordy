import type {
  EffectSpec, ActionName, EnvironmentKind, ElementKind, WeatherKind,
  SphereStyle, SphereDimension, MotionMode, TrailKind, MoodKind,
} from '../types'
import { THEMES, lerpTheme, drawScenery, type RenderTheme } from './themes'
import { ParticleSystem, WeatherSystem } from './particles'
import { EffectsSystem } from './effects'
import { Orb } from './orb'

/* ==========================================================================
   WORDY world engine — one canvas, one loop, a whole universe.
   ========================================================================== */

export interface GraphicsConfig {
  quality: 'low' | 'medium' | 'high' | 'ultra'
  fps: 30 | 60 | 120
  density: number   // 0.25 – 2, particle density multiplier
  bloom: number     // 0.4 – 1.6, glow intensity multiplier
  motion: boolean   // camera shake / zoom pulses
  background: boolean // animate the starfield + nebula
}

/** one chip in the Active Effects panel */
export interface EffectChip {
  id: string
  icon: string
  label: string
  /** accent color for the chip's left dot */
  accent?: string
  /** 0..1 for transient effects (speaking) — a duration indicator */
  progress?: number
}

interface Star { x: number; y: number; r: number; tw: number; seed: number }
interface NebulaBlob { x: number; y: number; r: number; hue: number; drift: number; seed: number }

export class WorldEngine {
  private canvas: HTMLCanvasElement | null = null
  private ctx: CanvasRenderingContext2D | null = null
  private raf = 0
  private running = false
  private lastT = 0
  private time = 0
  private w = 0
  private h = 0
  private dpr = 1

  /* state channels */
  orb = new Orb()
  ps = new ParticleSystem()
  weather = new WeatherSystem()
  fx = new EffectsSystem()

  private elements = new Set<ElementKind>()
  private env: EnvironmentKind = 'space'
  private envNext: EnvironmentKind | null = null
  private envBlend = 1
  private renderedTheme: RenderTheme = { ...THEMES.space }
  private gravity = 0
  private timeScale = 1
  private wind = 0
  private windTarget = 0
  private attract: 'attract' | 'repel' | null = null
  private mirror = false
  private invert = 0
  private invertTarget = 0
  private dim = 0
  private dimTarget = 0
  private ambience: 'active' | 'background' = 'active'

  /* v1.1 — sequence system, active effects, graphics settings */
  private timers: Array<{ at: number; fn: () => void }> = []
  private boomBusy = 0
  private lastBoomAt = -99
  private clearing = -1
  private zTimer = 0
  private windStreakT = 0
  private bgT = 0
  private reducedMotion = false
  private gfx: GraphicsConfig = { quality: 'high', fps: 60, density: 1, bloom: 1, motion: true, background: true }

  /* v1.2 — living-world state */
  private stormChargeUntil = -99   // lightning typed during a storm — the sky answers more
  private autoLunar = false       // moon + fly quietly lowers gravity
  private fireSpreadT = 0         // wind + fire — flames creep outward
  private puddleT = 0             // rain — puddles ripple on the ground
  private mistT = 0              // snow — cold mist pools low
  private frameAvg = 16           // rolling frame time — adaptive performance
  private qualityCap = 800        // base particle budget before adaptive scaling
  private perfScale = 1           // 0.62..1 — softens the budget when frames run long

  private pointer = { x: 0, y: 0, active: false }

  private stars: Star[] = []
  private nebula: NebulaBlob[] = []

  onCombo: ((id: string) => void) | null = null
  onSummon: (() => void) | null = null

  /* ------------- lifecycle ------------- */

  mount(canvas: HTMLCanvasElement) {
    this.canvas = canvas
    this.ctx = canvas.getContext('2d', { alpha: false })
    this.running = true
    this.reducedMotion = typeof window !== 'undefined'
      && window.matchMedia('(prefers-reduced-motion: reduce)').matches
    this.resize()
    this.lastT = performance.now()
    this.loop(this.lastT)
  }

  unmount() {
    this.running = false
    cancelAnimationFrame(this.raf)
    this.timers.length = 0
    this.canvas = null
    this.ctx = null
  }

  setGraphics(partial: Partial<GraphicsConfig>) {
    this.gfx = { ...this.gfx, ...partial }
    this.orb.bloomMul = this.gfx.bloom
    this.applyQuality()
  }

  setSphereStyle(s: SphereStyle) {
    this.orb.setStyle(s)
  }

  setDimension(d: SphereDimension) {
    this.orb.setDimension(d)
  }

  setAmbience(a: 'active' | 'background') {
    this.ambience = a
  }

  private get isMobile() {
    return typeof window !== 'undefined' && window.innerWidth < 768
  }

  private get effMotion() {
    return this.gfx.motion && !this.reducedMotion
  }

  private applyQuality() {
    const base = this.gfx.quality === 'low' ? 220
      : this.gfx.quality === 'medium' ? 460
        : this.gfx.quality === 'high' ? 800
          : 1150
    this.qualityCap = Math.floor(base * this.gfx.density * (this.ambience === 'background' ? 0.55 : 1))
    this.ps.setCap(Math.floor(this.qualityCap * this.perfScale))
  }

  resize() {
    if (!this.canvas || !this.ctx) return
    const rect = this.canvas.getBoundingClientRect()
    this.w = Math.max(1, rect.width)
    this.h = Math.max(1, rect.height)
    this.dpr = Math.min(window.devicePixelRatio || 1, this.isMobile ? 1.6 : 2)
    this.canvas.width = Math.floor(this.w * this.dpr)
    this.canvas.height = Math.floor(this.h * this.dpr)
    this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0)
    this.orb.resize(this.w, this.h)
    this.ps.resize(this.w, this.h)
    this.fx.resize(this.w, this.h)
    this.seedStars()
  }

  setPointer(x: number, y: number) {
    this.pointer.x = x
    this.pointer.y = y
    this.pointer.active = true
  }

  pointerLeave() {
    this.pointer.active = false
  }

  private seedStars() {
    const theme = THEMES[this.env]
    const count = Math.max(140, (theme.starCount + 60) * (this.isMobile ? 0.6 : 1))
    this.stars = []
    for (let i = 0; i < count; i++) {
      this.stars.push({
        x: Math.random() * this.w,
        y: Math.random() * this.h,
        r: Math.random() * 1.3 + 0.3,
        tw: Math.random() * Math.PI * 2,
        seed: Math.random() * 10,
      })
    }
    this.nebula = []
    for (let i = 0; i < 4; i++) {
      this.nebula.push({
        x: Math.random() * this.w,
        y: Math.random() * this.h,
        r: (0.28 + Math.random() * 0.3) * Math.max(this.w, this.h),
        hue: i,
        drift: Math.random() * Math.PI * 2,
        seed: Math.random() * 10,
      })
    }
  }

  /* ------------- command application ------------- */

  apply(spec: EffectSpec) {
    const orb = this.orb
    if (spec.motion !== undefined) {
      orb.setMotion(spec.motion)
      if (spec.motion === 'floor' && this.gravity <= 0 && spec.gravity === undefined) this.gravity = 1
      if (spec.motion === 'bounce' && spec.gravity === undefined) this.gravity = 1
      // v1.2 — soft camera follow on take-off
      if (spec.motion === 'fly') this.fx.pulse(this.effMotion ? 1.05 : 1)
    }
    if (spec.spin !== undefined) orb.targetSpin = spec.spin
    if (spec.scale !== undefined) orb.targetScale = clampN(spec.scale, 0.15, 4.4)
    if (spec.scaleMul !== undefined) {
      orb.targetScale = clampN(orb.targetScale * spec.scaleMul, 0.15, 4.4)
      orb.squishImpulse(4)
    }
    if (spec.shape !== undefined && spec.shape !== orb.shape) {
      orb.prevShape = orb.shape
      orb.shape = spec.shape
      orb.morphT = 0
      this.ps.sparkBurst(orb.renderX, orb.renderY, 14, 265)
    }
    if (spec.color !== undefined) {
      // "random" lets the core pick a new favorite from the WORDY palette
      orb.targetColor = spec.color === 'random' ? PALETTE[Math.floor(Math.random() * PALETTE.length)] : spec.color
    }
    if (spec.glow !== undefined) orb.targetGlow = clampN(spec.glow, 0.2, 2)
    if (spec.trail !== undefined) orb.trailKind = spec.trail
    if (spec.alpha !== undefined) orb.targetAlpha = clampN(spec.alpha, 0.15, 1)

    // v1.1 — actor channels
    if (spec.text !== undefined && spec.text.length > 0) orb.speakText(spec.text)
    if (spec.halo !== undefined) orb.setHalo(spec.halo)
    if (spec.heartbeat !== undefined) orb.setHeartbeat(spec.heartbeat)
    if (spec.chrome !== undefined) orb.setChrome(spec.chrome)

    // v1.2 — the sphere reacts emotionally, then settles back to neutral
    orb.setMood(spec.mood ?? inferMood(spec))

    if (spec.clearElements) {
      this.elements.clear()
      orb.burning = 0
      orb.frozen = 0
      orb.wet = 0
      orb.electric = 0
      orb.lava = 0
    }
    if (spec.element !== undefined) {
      if (spec.element === null) {
        this.elements.clear()
        orb.burning = 0
        orb.frozen = 0
        orb.wet = 0
        orb.electric = 0
        orb.lava = 0
      } else {
        this.elements.add(spec.element)
        if (spec.element === 'fire') orb.burning = 1
        if (spec.element === 'ice') orb.frozen = Math.max(orb.frozen, 0.05)
        if (spec.element === 'water') orb.wet = 1
        if (spec.element === 'electric') orb.electric = 1
        if (spec.element === 'lava') { orb.lava = 1; orb.burning = 0.8 }
      }
    }

    if (spec.weather !== undefined) {
      this.weather.set(spec.weather)
      if (spec.weather === 'storm' || spec.weather === 'rain') {
        this.windTarget = spec.weather === 'storm' ? 0.5 : 0.15
      } else if (spec.weather === null) {
        this.windTarget = 0
      }
    }
    if (spec.clearWeather) this.weather.clear()
    if (spec.environment !== undefined && spec.environment !== this.env) {
      this.envNext = spec.environment
      this.envBlend = 0
    }
    if (spec.timeScale !== undefined) this.timeScale = spec.timeScale
    if (spec.gravity !== undefined) this.gravity = spec.gravity
    if (spec.wind !== undefined) this.windTarget = spec.wind
    if (spec.attract !== undefined) this.attract = spec.attract
    if (spec.mirror !== undefined) this.mirror = spec.mirror
    if (spec.invert !== undefined) this.invertTarget = spec.invert ? 1 : 0
    if (spec.dim !== undefined) this.dimTarget = clampN(spec.dim, 0, 0.6)

    if (spec.action !== undefined) {
      const actions = Array.isArray(spec.action) ? spec.action : [spec.action]
      for (const a of actions) this.runAction(a, spec.text)
    }
  }

  /* ------------- sequences — timed choreography ------------- */

  private later(delay: number, fn: () => void) {
    this.timers.push({ at: this.time + delay, fn })
  }

  private runTimers() {
    if (!this.timers.length) return
    for (let i = this.timers.length - 1; i >= 0; i--) {
      if (this.time >= this.timers[i].at) {
        const fn = this.timers[i].fn
        this.timers.splice(i, 1)
        try {
          fn()
        } catch (err) {
          console.error('[WORDY sequence]', err)
        }
      }
    }
  }

  /** boom — buildup → explosion → shockwave → smoke fade → recovery. strength 1 = boom, ~1.6 = explode */
  private runBoom(strength = 1) {
    if (this.boomBusy > 0) return
    this.boomBusy = 1
    const orb = this.orb
    const S = clampN(strength, 0.6, 2)

    // an icy core does not burn — it shatters
    const icy = orb.frozen > 0.3
    if (icy) this.tryComboNow('iceburst')

    // 1. buildup — the core contracts, energy gathers (~0.55s)
    orb.setMood('tense')
    orb.targetScale = Math.max(0.5, orb.targetScale * (0.68 - 0.06 * S))
    orb.targetGlow = 1.9
    orb.squishImpulse(-4)
    this.fx.pulse(this.effMotion ? 1.07 : 1)
    const bx = orb.renderX
    const by = orb.renderY
    for (let i = 0; i < Math.floor(26 * S); i++) {
      const a = Math.random() * Math.PI * 2
      const d = rnd(90, 190) * (0.7 + S * 0.3)
      this.ps.spawn('spark', {
        x: bx + Math.cos(a) * d, y: by + Math.sin(a) * d,
        vx: -Math.cos(a) * d * 2.1, vy: -Math.sin(a) * d * 2.1,
        maxLife: rnd(0.32, 0.55), size: rnd(1.6, 3.6), hue: icy ? 200 : 265 + rnd(-24, 24), light: 78,
      })
    }

    // 2. explosion — everything at once
    this.later(0.55, () => {
      const x = orb.renderX
      const y = orb.renderY
      this.ps.sparkBurst(x, y, Math.floor(60 * S), icy ? 200 : 265, 430 * (0.8 + S * 0.2))
      if (icy) {
        this.ps.frostBurst(x, y)
        this.ps.shatterBurst(x, y)
      } else {
        this.ps.emberBurst(x, y, Math.floor(26 * S))
      }
      this.fx.addShockwave(x, y, Math.max(this.w, this.h) * 0.45 * (0.8 + S * 0.25), icy ? 200 : 265, 74, 8)
      this.later(0.12, () => this.fx.addShockwave(x, y, Math.max(this.w, this.h) * 0.3 * (0.8 + S * 0.25), icy ? 190 : 40, 78, 5))
      this.fx.flash(icy ? 0.5 : 0.45 + 0.1 * S, icy ? 200 : 30)
      this.fx.kick(this.effMotion ? 12 * S : 4)
      this.fx.pulse(this.effMotion ? 1.18 : 1)
      orb.squishImpulse(10)
      orb.alpha = 0.3
      orb.targetScale = 1.15
      this.lastBoomAt = this.time
      // stardust — a star taken apart by a boom
      if (orb.shape === 'star') {
        this.tryComboNow('stardust')
        this.ps.starBurst(x, y, 40)
      }
      // the ice spent itself
      if (icy) {
        this.elements.delete('ice')
        orb.frozen = 0
      }
    })

    // 3. smoke fade — the world breathes out
    this.later(0.7, () => {
      const x = orb.renderX
      const y = orb.renderY
      for (let i = 0; i < Math.floor(9 * S); i++) {
        this.ps.spawn(icy ? 'iceshard' : 'smoke', {
          x: x + (Math.random() - 0.5) * 46, y: y + (Math.random() - 0.5) * 26,
          vx: (Math.random() - 0.5) * 34, vy: -rnd(30, 70),
          maxLife: rnd(1.6, 3), size: icy ? rnd(3, 6) : rnd(8, 16),
          hue: 200, gf: icy ? 0.3 : -0.05,
        })
      }
    })

    // 4. recovery — settle back, gently; the sphere reforms
    this.later(0.78, () => {
      orb.targetScale = 1
      orb.targetGlow = 1.25
    })
    this.later(1.35, () => {
      orb.targetGlow = 1
      this.ps.sparkBurst(orb.renderX, orb.renderY, 10, icy ? 200 : 265, 90)
      orb.setMood(null)
      this.boomBusy = 0
    })
  }

  runAction(a: ActionName, text?: string) {
    const orb = this.orb
    const fx = this.fx
    const ps = this.ps
    const x = orb.renderX
    const y = orb.renderY
    switch (a) {
      case 'boom':
        this.runBoom()
        break
      case 'flip':
        orb.flip()
        break
      case 'growtree':
        fx.addTree(x, orb.floorY())
        ps.sparkBurst(x, orb.floorY() - 8, 12, 110, 70)
        break
      case 'flock':
        fx.addFlock(7)
        break
      case 'sing':
        orb.speakText('♪ ♫ ♪ ♫')
        ps.noteBurst(x, y, 12)
        fx.addRipple(x, y, 170)
        break
      case 'sleep':
        orb.setSleeping(true)
        orb.setMotion('stop')
        orb.targetGlow = 0.75
        break
      case 'wake':
        orb.setSleeping(false)
        orb.squishImpulse(4)
        orb.targetGlow = 1.2
        ps.sparkBurst(x, y, 16, 46)
        break
      case 'speak': {
        const said = (text && text.trim()) || DEFAULT_LINES[Math.floor(Math.random() * DEFAULT_LINES.length)]
        orb.speakText(said)
        fx.addText(`“${said.slice(0, 46)}${said.length > 46 ? '…' : ''}”`, x, y - orb.radius() - 42, 250, 21, orb.speaking?.dur ?? 2.6)
        break
      }
      case 'explode': {
        // explode — boom's louder sibling: same choreography, more of everything
        this.runBoom(1.6)
        break
      }
      case 'implode': {
        for (let i = 0; i < 30; i++) {
          const ang = Math.random() * Math.PI * 2
          const d = 120 + Math.random() * 140
          ps.spawn('spark', {
            x: x + Math.cos(ang) * d, y: y + Math.sin(ang) * d,
            vx: -Math.cos(ang) * d * 2.4, vy: -Math.sin(ang) * d * 2.4,
            maxLife: 0.5, size: 2 + Math.random() * 2, hue: 250, light: 74,
          })
        }
        fx.flash(0.22, 250)
        orb.squishImpulse(-6)
        break
      }
      case 'shockwave':
        fx.addShockwave(x, y, 300, 200, 78, 7)
        fx.kick(5)
        break
      case 'flash':
        fx.flash(0.6)
        break
      case 'strobe': {
        // v1.2 — a proper strobe: rhythmic pulses, alternating temperature
        for (let i = 0; i < 7; i++) {
          this.later(i * 0.13, () => {
            fx.flash(i % 2 === 0 ? 0.38 : 0.52, i % 2 === 0 ? 212 : 26, 62)
            orb.targetGlow = i % 2 === 0 ? 1.75 : 0.7
            ps.sparkBurst(orb.renderX, orb.renderY, 4, i % 2 === 0 ? 212 : 36, 70)
          })
        }
        this.later(7 * 0.13 + 0.22, () => { orb.targetGlow = 1 })
        break
      }
      case 'melt': {
        // v1.2 — thaw: the ice loosens and streams away as water
        this.elements.delete('ice')
        orb.wet = 1
        orb.setMood('calm')
        const R0 = orb.radius()
        for (let i = 0; i < 16; i++) {
          this.later(i * 0.06, () => {
            const a = Math.PI * (0.15 + Math.random() * 0.7)
            const d = R0 * rnd(0.4, 1.05)
            this.ps.spawn('droplet', {
              x: orb.renderX + Math.cos(a) * d,
              y: orb.renderY + Math.sin(a) * d * 0.8,
              vx: (Math.random() - 0.5) * 22,
              vy: rnd(30, 80),
              maxLife: rnd(0.5, 0.9), size: rnd(1.6, 3.2), hue: 200, gf: 0.9,
            })
          })
        }
        // the frost drains away in three unhurried stages
        this.later(0.18, () => { orb.frozen = Math.min(orb.frozen, 0.6) })
        this.later(0.44, () => { orb.frozen = Math.min(orb.frozen, 0.28) })
        this.later(0.75, () => { orb.frozen = 0 })
        fx.addRipple(x, y + R0, 150)
        break
      }
      case 'ripple':
        fx.addRipple(x, y + orb.radius() * 0.8, 200)
        break
      case 'lightning': {
        fx.addBolt(x, y)
        // the charge lingers on the surface, then fades
        orb.electric = 1
        // storm + lightning — the sky takes it personally
        if (this.weather.active() === 'storm') {
          this.stormChargeUntil = this.time + 14
          this.tryComboNow('ragingstorm')
        }
        break
      }
      case 'zoompulse':
        fx.pulse(1.16)
        break
      case 'shake':
        fx.kick(this.effMotion ? 9 : 2)
        break
      case 'sparkburst':
        ps.sparkBurst(x, y, 30, 45)
        break
      case 'confettiburst':
        ps.confettiBurst(x, y, 60)
        break
      case 'heartburst':
        ps.heartBurst(x, y, 18)
        fx.addShockwave(x, y, 170, 340, 78, 4)
        break
      case 'starburst':
        ps.starBurst(x, y, 34)
        fx.addShockwave(x, y, 190, 45, 80, 3)
        break
      case 'meteor':
        fx.addMeteor()
        break
      case 'cometfly':
        fx.addMeteor()
        setTimeout(() => fx.addMeteor(), 500)
        break
      case 'supernova': {
        ps.supernovaBurst(x, y)
        fx.addShockwave(x, y, Math.max(this.w, this.h) * 0.5, 30, 80, 8)
        fx.flash(0.7, 30, 60)
        fx.pulse(1.22)
        fx.kick(this.effMotion ? 12 : 3)
        break
      }
      case 'bigbang': {
        ps.bigbangBurst(x, y)
        fx.addShockwave(x, y, Math.max(this.w, this.h) * 0.75, 265, 82, 10)
        fx.flash(0.95, 220, 10)
        fx.pulse(1.3)
        break
      }
      case 'portalopen':
        fx.addPortal(x, y)
        break
      case 'blackhole':
        fx.addBlackhole(x + this.w * 0.18, y)
        break
      case 'ringwave':
        fx.addShockwave(x, y, 240, 45, 78, 3)
        break
      case 'shatter':
        ps.shatterBurst(x, y)
        fx.flash(0.25, 200)
        break
      case 'frostburst':
        ps.frostBurst(x, y)
        fx.addShockwave(x, y, 180, 200, 85, 3)
        break
      case 'splash':
        ps.splashBurst(x, y + orb.radius() * 0.5)
        fx.addRipple(x, y + orb.radius(), 150)
        break
      case 'greet':
        fx.addText('hello ✦', x, y - orb.radius() - 30, 265)
        ps.sparkBurst(x, y, 24, 250)
        fx.addRipple(x, y, 160)
        break
      case 'toss':
        orb.toss()
        break
      case 'bloom':
        ps.bloomBurst(x, y + orb.radius(), 22)
        break
      case 'orbiters':
        fx.addOrbiters(4)
        break
      case 'satellite':
        fx.clearOrbiters()
        fx.addOrbiters(1, 'satellite')
        break
      case 'squish':
        orb.squishImpulse(7)
        break
      case 'wobble':
        orb.squishImpulse(4)
        orb.squishV *= 3
        break
      case 'clone':
        orb.addClone()
        break
      case 'mirrorworld':
        fx.flash(0.3, 265)
        fx.addShockwave(x, y, 260, 265, 80, 4)
        break
      case 'jump':
        orb.jump()
        break
      case 'dash':
        orb.dash()
        break
      case 'dive':
        orb.dive()
        break
      case 'teleport': {
        ps.sparkBurst(x, y, 20, 265)
        const nx = this.w * (0.25 + Math.random() * 0.5)
        const ny = this.h * (0.2 + Math.random() * 0.4)
        orb.x = nx
        orb.y = ny
        orb.renderX = nx
        orb.renderY = ny
        ps.sparkBurst(nx, ny, 24, 200)
        fx.addRipple(nx, ny, 130)
        break
      }
      case 'boomerang':
        orb.boomerang()
        break
      case 'swing':
        orb.setMotion('sway')
        break
      case 'fireworks':
        fx.fireworkShow(7)
        break
      case 'ufo':
        fx.addUfo()
        break
      case 'galaxyburst':
        ps.galaxyBurst(x, y, 70)
        break
      case 'featherfall':
        ps.featherBurst(14, this.w)
        break
      case 'summon':
        if (this.onSummon) this.onSummon()
        else this.runAction(SPECTACLES[Math.floor(Math.random() * SPECTACLES.length)])
        break
    }
  }

  /* ------------- active effects — what is happening right now ------------- */

  getActiveEffects(): EffectChip[] {
    const chips: EffectChip[] = []
    for (const e of this.elements) {
      const c = ELEMENT_META[e]
      if (c) chips.push({ id: `el:${e}`, icon: c.icon, label: c.label, accent: c.accent })
    }
    const wx = this.weather.active()
    if (wx) {
      const c = WEATHER_META[wx]
      if (c) chips.push({ id: 'wx', icon: c.icon, label: c.label, accent: c.accent })
    }
    const env = this.currentEnvironment()
    if (env !== 'space') {
      const c = ENV_META[env]
      chips.push({ id: 'env', icon: c?.icon ?? '🌌', label: c?.label ?? env, accent: c?.accent ?? '#818cf8' })
    }
    const m = this.orb.motion
    if (m !== 'idle' && m !== 'stop' && m !== 'hover-wait' && m !== 'floor') {
      const c = MOTION_META[m]
      if (c) chips.push({ id: 'motion', icon: c.icon, label: c.label, accent: c.accent })
    }
    if (Math.abs(this.orb.targetSpin) > 0.5) chips.push({ id: 'spin', icon: '🌀', label: 'Spinning', accent: '#a5b4fc' })
    if (this.orb.trailKind) {
      const c = TRAIL_META[this.orb.trailKind]
      if (c) chips.push({ id: 'trail', icon: c.icon, label: c.label, accent: c.accent })
    }
    if (this.orb.halo > 0.5) chips.push({ id: 'halo', icon: '😇', label: 'Halo', accent: '#fde68a' })
    if (this.orb.heartbeat > 0.5) chips.push({ id: 'heartbeat', icon: '❤️', label: 'Heartbeat', accent: '#fb7185' })
    if (this.orb.chrome > 0.5) chips.push({ id: 'chrome', icon: '🪩', label: 'Chrome', accent: '#e2e8f0' })
    if (this.orb.sleeping > 0.5) chips.push({ id: 'sleep', icon: '😴', label: 'Sleeping', accent: '#a5b4fc' })
    if (this.orb.speaking) {
      chips.push({
        id: 'speak', icon: '💬', label: 'Speaking', accent: '#67e8f9',
        progress: 1 - this.orb.speaking.t / this.orb.speaking.dur,
      })
    }
    if (this.orb.targetAlpha < 0.85) chips.push({ id: 'fade', icon: '👻', label: 'Faded', accent: '#c4b5fd' })
    if (this.mirror) chips.push({ id: 'mirror', icon: '🪞', label: 'Mirrored', accent: '#a5f3fc' })
    if (this.invertTarget > 0) chips.push({ id: 'invert', icon: '🌓', label: 'Inverted', accent: '#e2e8f0' })
    if (this.attract) chips.push({ id: 'attract', icon: this.attract === 'attract' ? '🧲' : '💨', label: this.attract === 'attract' ? 'Attracting' : 'Repelling', accent: '#94a3b8' })
    if (this.timeScale < 0.9) chips.push({ id: 'time', icon: '🐌', label: 'Slow time', accent: '#fcd34d' })
    if (this.timeScale > 1.15) chips.push({ id: 'time', icon: '⏩', label: 'Fast time', accent: '#fcd34d' })
    if (Math.abs(this.gravity) > 0.05) chips.push({ id: 'gravity', icon: this.gravity < 0 ? '🎈' : '⬇️', label: this.gravity < 0 ? 'Antigravity' : 'Gravity', accent: '#93c5fd' })
    return chips
  }

  /** remove one active effect (a chip’s × button) */
  removeEffect(id: string) {
    const orb = this.orb
    if (id.startsWith('el:')) {
      const e = id.slice(3) as ElementKind
      this.elements.delete(e)
      if (e === 'fire') orb.burning = 0
      if (e === 'ice') orb.frozen = 0
      if (e === 'water') orb.wet = 0
      if (e === 'electric') orb.electric = 0
      if (e === 'lava') { orb.lava = 0; orb.burning = Math.min(orb.burning, 0.15) }
      if (e === 'wind') this.windTarget = 0
      return
    }
    switch (id) {
      case 'wx':
        this.weather.reset()
        this.windTarget = 0
        break
      case 'env':
        this.envNext = 'space'
        this.envBlend = 0
        break
      case 'motion':
        orb.setMotion('idle')
        break
      case 'spin':
        orb.targetSpin = 0
        break
      case 'trail':
        orb.trailKind = null
        break
      case 'halo': orb.setHalo(false); break
      case 'heartbeat': orb.setHeartbeat(false); break
      case 'chrome': orb.setChrome(false); break
      case 'sleep':
        orb.setSleeping(false)
        orb.targetGlow = 1
        break
      case 'speak': orb.speaking = null; break
      case 'fade': orb.targetAlpha = 1; break
      case 'mirror': this.mirror = false; break
      case 'invert': this.invertTarget = 0; break
      case 'attract': this.attract = null; break
      case 'time': this.timeScale = 1; break
      case 'gravity': this.gravity = 0; break
    }
  }

  /** clear all — dismiss every active effect at once, softly (no scene fade, no reload) */
  clearEffects() {
    for (const c of this.getActiveEffects()) this.removeEffect(c.id)
  }

  /** clear world — everything fades out (~0.4s), resets, fades back in. No reload. */
  clearWorld() {
    if (this.clearing >= 0) return
    this.clearing = 0
    // gentle fade-out of the whole scene while weather/particles wind down
    this.weather.clear()
    this.dimTarget = Math.min(0.6, this.dimTarget + 0.45)
    this.later(0.4, () => {
      // hard reset under the dark
      this.elements.clear()
      this.weather.reset()
      this.ps.particles.length = 0
      this.fx.reset()
      this.timers.length = 0
      this.envNext = 'space'
      this.envBlend = 0
      this.env = 'space'
      this.gravity = 0
      this.timeScale = 1
      this.wind = 0
      this.windTarget = 0
      this.attract = null
      this.mirror = false
      this.invertTarget = 0
      this.invert = 0
      this.dimTarget = 0
      this.dim = 0
      this.boomBusy = 0
      this.orb.resetState()
      this.seedStars()
      this.fx.addText('a new world', this.w / 2, this.h * 0.3, 250, 20)
    })
    // clearing timer advances the fade in step()
  }

  /* ------------- emergent combos ------------- */

  private foundCombos = new Set<string>()
  private comboCheck = 0

  private tryComboNow(id: string) {
    if (this.foundCombos.has(id)) return
    this.foundCombos.add(id)
    this.onCombo?.(id)
  }

  private checkCombos(dt: number) {
    this.comboCheck += dt
    if (this.comboCheck < 0.5) return
    this.comboCheck = 0
    const fire = this.elements.has('fire')
    const water = this.elements.has('water')
    const ice = this.elements.has('ice')
    const wind = this.elements.has('wind')
    const earth = this.elements.has('earth')
    const lava = this.elements.has('lava')
    const electric = this.elements.has('electric')
    const weather = this.weather.active()
    const fireish = fire || this.orb.burning > 0.4

    const tryCombo = (id: string) => this.tryComboNow(id)

    if (fireish && (water || weather === 'rain')) tryCombo('steam')
    if (fireish && ice) tryCombo('mist')
    if (fireish && wind) tryCombo('firestorm')
    if (water && ice) tryCombo('glacier')
    if ((electric || weather === 'storm') && weather === 'storm') tryCombo('thunderstorm')
    if (weather === 'rain' && (this.env === 'dawn' || this.env === 'sunset' || this.env === 'desert')) tryCombo('rainbowbirth')
    if (fireish && earth) tryCombo('obsidian')
    if (lava && (water || weather === 'rain')) tryCombo('geyser')
    if (ice && wind) tryCombo('snowflake')
    if (electric && weather === 'clouds') tryCombo('thundercloud')
    if (this.orb.frozen > 0.5 && this.orb.motion === 'bounce') tryCombo('popsicle')
    // stardust — a star that meets a boom (within a couple of seconds)
    if (this.orb.shape === 'star' && this.time - this.lastBoomAt < 2.5) tryCombo('stardust')
  }

  /* ------------- element reconciliation ------------- */

  private reconcileElements(dt: number) {
    const orb = this.orb
    const fireish = this.elements.has('fire') || this.elements.has('lava')
    const raining = this.weather.active() === 'rain' || this.weather.active() === 'storm'
    const water = this.elements.has('water')

    // fire + water/rain → steam, fire dies
    if (fireish && (water || raining)) {
      orb.burning = Math.max(0, orb.burning - dt * 0.4)
      if (orb.burning <= 0) {
        this.elements.delete('fire')
        this.elements.add('steam')
        orb.wet = 1
        for (let i = 0; i < 20; i++) {
          this.ps.spawn('steam', {
            x: orb.renderX + (Math.random() - 0.5) * 30, y: orb.renderY + (Math.random() - 0.5) * 20,
            vx: (Math.random() - 0.5) * 30, vy: -rnd(40, 90),
            maxLife: rnd(1.4, 2.6), size: rnd(8, 18),
          })
        }
      }
    }
    // fire + ice → mist, both fade
    if (fireish && this.elements.has('ice')) {
      orb.burning = Math.max(0, orb.burning - dt * 0.5)
      orb.frozen = Math.max(0, orb.frozen - dt * 0.5)
      if (orb.burning <= 0.01 && orb.frozen <= 0.01) {
        this.elements.delete('fire')
        this.elements.delete('ice')
        this.elements.add('steam')
      }
    }
    // fire + wind → brighter
    if (fireish && this.elements.has('wind')) {
      orb.burning = Math.min(1.4, orb.burning + dt * 0.25)
    }
    // water + ice → frozen grows
    if (this.elements.has('water') && this.elements.has('ice')) {
      orb.frozen = Math.min(1, orb.frozen + dt * 0.3)
    }
    // v1.2 — rain + freeze → the rain itself turns to snow
    if (this.elements.has('ice') && this.weather.active() === 'rain') {
      this.weather.set('snow')
      this.windTarget = Math.min(this.windTarget, 0.1)
      this.tryComboNow('blizzard')
    }
    // gentle decay of element states when element removed
    if (!this.elements.has('fire') && !this.elements.has('lava')) orb.burning = Math.max(0, orb.burning - dt * 0.24)
    if (!this.elements.has('ice')) orb.frozen = Math.max(0, orb.frozen - dt * 0.12)
    if (!this.elements.has('water')) orb.wet = Math.max(0, orb.wet - dt * 0.2)
    if (!this.elements.has('electric')) orb.electric = Math.max(0, orb.electric - dt * 0.5)
    if (!this.elements.has('lava')) orb.lava = Math.max(0, orb.lava - dt * 0.2)
    // frozen grows slowly when ice element present
    if (this.elements.has('ice')) orb.frozen = Math.min(1, orb.frozen + dt * 0.14)
  }

  /* ------------- the loop ------------- */

  private loop = (now: number) => {
    if (!this.running || !this.ctx || !this.canvas) return
    // cap the loop at the configured fps — some environments fire rAF unthrottled
    const minFrameMs = 1000 / this.gfx.fps
    if (this.lastT > 0 && now - this.lastT < minFrameMs) {
      this.raf = requestAnimationFrame(this.loop)
      return
    }
    try {
      this.step(now)
    } catch (err) {
      // keep the world alive even if something unexpected happens
      console.error('[WORDY engine]', err)
    }
    this.raf = requestAnimationFrame(this.loop)
  }

  private step(now: number) {
    const rawDt = Math.min(0.05, (now - this.lastT) / 1000)
    this.lastT = now
    this.time += rawDt
    if (this.gfx.background) this.bgT += rawDt

    // v1.2 — adaptive performance: long frames soften the particle budget,
    // never the user's chosen quality — and only when targeting 60fps+
    if (this.gfx.fps >= 60 && this.ambience === 'active') {
      this.frameAvg += (rawDt * 1000 - this.frameAvg) * 0.05
      const want = this.frameAvg > 27 ? 0.62 : this.frameAvg < 21 ? 1 : this.perfScale
      if (want !== this.perfScale) {
        this.perfScale += (want - this.perfScale) * 0.06
        if (Math.abs(want - this.perfScale) < 0.01) this.perfScale = want
        this.ps.setCap(Math.max(140, Math.floor(this.qualityCap * this.perfScale)))
      }
    }

    const bgScale = this.ambience === 'background' ? 0.45 : 1
    const dt = rawDt * this.timeScale * bgScale

    // sequences (boom choreography, clear-world reset…)
    this.runTimers()

    // clear-world fade: down 0.4s, hold a breath, up 0.35s
    if (this.clearing >= 0) {
      this.clearing += rawDt
      if (this.clearing > 0.95) this.clearing = -1
    }

    // env transition
    if (this.envNext !== null) {
      this.envBlend = Math.min(1, this.envBlend + rawDt * 0.7)
      if (this.envBlend >= 1) {
        this.env = this.envNext
        this.envNext = null
        this.seedStars()
      }
    }
    const from = THEMES[this.env]
    const to = this.envNext !== null ? THEMES[this.envNext] : from
    this.renderedTheme = lerpTheme(from, to, this.envBlend === 1 && this.envNext === null ? 0 : this.envBlend)

    // smooth globals
    this.wind += (this.windTarget - this.wind) * Math.min(1, rawDt * 1.4)
    this.invert += (this.invertTarget - this.invert) * Math.min(1, rawDt * 3)
    this.dim += (this.dimTarget - this.dim) * Math.min(1, rawDt * 2)

    // update systems
    this.orb.update(dt, { gravity: this.gravity, timeScale: this.timeScale, pointer: this.pointer })

    // v1.2 — the sphere feels the rain on its skin
    this.orb.rainOn = (this.weather.active() === 'rain' || this.weather.active() === 'storm') ? this.weather.intensity : 0

    // v1.2 — hard landings kick up dust and ripple the ground
    if (this.orb.hardLanding > 0.02) {
      const k = this.orb.hardLanding
      const lx = this.orb.renderX
      const ly = this.orb.floorY()
      this.fx.addRipple(lx, ly, 60 + k * 130)
      for (let i = 0; i < Math.floor(4 + k * 12); i++) {
        this.ps.spawn('dust', {
          x: lx + (Math.random() - 0.5) * 30,
          y: ly - 2,
          vx: (Math.random() - 0.5) * 220 * k,
          vy: -rnd(20, 90) * k,
          maxLife: rnd(0.5, 1.2), size: rnd(1.6, 3.8), hue: 262,
        })
      }
      if (k > 0.5) this.fx.kick(this.effMotion ? k * 6 : 2)
      this.orb.hardLanding = 0
    }

    // v1.2 — moon + fly → low gravity: dust rises, arcs go long and dreamy
    const lunar = (this.env === 'night' || this.env === 'midnight' || this.env === 'arctic') && this.orb.motion === 'fly'
    if (lunar && !this.autoLunar && Math.abs(this.gravity) < 0.01) {
      this.gravity = -0.16
      this.autoLunar = true
      this.tryComboNow('moonflight')
    } else if (this.autoLunar && (!lunar || this.gravity > 0)) {
      if (this.gravity < 0) this.gravity = 0
      this.autoLunar = false
    }

    // v1.2 — wind + fire → the flames spread along the ground
    const fireishSpread = this.elements.has('fire') || this.elements.has('lava') || this.orb.burning > 0.4
    if (fireishSpread && Math.abs(this.wind) > 0.12) {
      this.fireSpreadT -= dt
      if (this.fireSpreadT <= 0) {
        this.fireSpreadT = 0.5
        const dir = this.wind >= 0 ? 1 : -1
        const fx = this.orb.renderX + dir * rnd(50, 260)
        for (let i = 0; i < 3; i++) {
          this.ps.spawn('ember', {
            x: fx + (Math.random() - 0.5) * 34,
            y: this.orb.floorY() - rnd(0, 8),
            vx: dir * rnd(20, 90), vy: -rnd(40, 130),
            maxLife: rnd(0.6, 1.4), size: rnd(1.8, 4), hue: rnd(14, 40), gf: -0.3, wf: 1.6,
          })
        }
      }
    }

    // v1.2 — rain leaves puddles that ripple
    if (this.weather.active() === 'rain' || this.weather.active() === 'storm') {
      this.puddleT -= dt
      if (this.puddleT <= 0) {
        this.puddleT = 0.38
        this.fx.addRipple(rnd(0, this.w), this.orb.floorY() + rnd(-8, 10), rnd(26, 64))
      }
    }

    // v1.2 — snow breathes cold mist along the ground
    if (this.weather.active() === 'snow') {
      this.mistT -= dt
      if (this.mistT <= 0) {
        this.mistT = 1.1
        this.ps.spawn('cloud', {
          x: rnd(-40, this.w + 40), y: this.orb.floorY() - rnd(2, 26),
          vx: this.wind * 20 + rnd(4, 12), vy: rnd(-3, 1),
          maxLife: rnd(5, 9), size: rnd(18, 40), hue: 205,
        })
      }
    }

    this.reconcileElements(dt)
    this.orb.emit(dt, this.ps, this.elements)
    this.ps.update(dt, {
      w: this.w, h: this.h, gravity: this.gravity, wind: this.wind,
      attract: this.attract, orbX: this.orb.renderX, orbY: this.orb.renderY,
      floorY: this.orb.floorY(), elements: this.elements,
    })
    this.weather.setDaylight(this.env === 'dawn' || this.env === 'sunset' || this.env === 'desert')
    this.weather.update(dt, this.w, this.h, this.ps, this.ps.cap, this.wind)
    this.fx.update(dt, this.ps)
    // v1.2 — a charged storm answers with faster lightning
    this.fx.stormTick(dt, this.weather.active() === 'storm' && this.ambience === 'active', this.time < this.stormChargeUntil)
    if (this.time < this.stormChargeUntil && Math.random() < dt * 2) {
      this.orb.electric = Math.max(this.orb.electric, 0.5)   // static in the air
    }
    this.checkCombos(rawDt)

    // wind currents — visible streams of air sweeping through
    if (this.elements.has('wind')) {
      this.windStreakT -= dt
      if (this.windStreakT <= 0) {
        this.windStreakT = 0.055
        const dir = this.wind >= 0 ? 1 : -1
        this.ps.spawn('streak', {
          x: dir > 0 ? -20 : this.w + 20,
          y: rnd(this.h * 0.08, this.h * 0.92),
          vx: dir * (220 + Math.abs(this.wind) * 320),
          vy: rnd(-14, 14),
          maxLife: rnd(0.8, 1.5), size: rnd(6, 15), hue: 208,
        })
      }
    }

    // void vortex — a quiet spiral pulling at the world
    if (this.elements.has('void')) {
      const R = this.orb.radius()
      if (Math.random() < 0.55) {
        const a = Math.random() * Math.PI * 2
        const d = R * rnd(1.7, 3.6)
        this.ps.spawn('spark', {
          x: this.orb.renderX + Math.cos(a) * d,
          y: this.orb.renderY + Math.sin(a) * d,
          vx: -Math.cos(a + 1.1) * d * 2.2,
          vy: -Math.sin(a + 1.1) * d * 2.2,
          maxLife: rnd(0.4, 0.75), size: rnd(1.4, 3), hue: 262, light: 66,
        })
      }
    }

    // sleep — tiny z's drift up now and then
    if (this.orb.sleeping > 0.6) {
      this.zTimer -= dt
      if (this.zTimer <= 0) {
        this.zTimer = 1.5
        const R = this.orb.radius()
        const zs = 'z'.repeat(1 + Math.floor(Math.random() * 3))
        this.fx.addText(zs, this.orb.renderX + R * 0.75, this.orb.renderY - R * 0.9, 226, 15)
      }
    }

    // blackhole pulls orb a little
    for (const b of this.fx.blackholes) {
      const dx = b.x - this.orb.x
      const dy = b.y - this.orb.y
      const d = Math.hypot(dx, dy) + 40
      this.orb.vx += (dx / d) * b.strength * 900 * dt / (d / 200)
      this.orb.vy += (dy / d) * b.strength * 900 * dt / (d / 200)
    }

    this.render()

    this.raf = requestAnimationFrame(this.loop)
  }

  /* ------------- rendering ------------- */

  private render() {
    const ctx = this.ctx
    if (!ctx) return
    const { w, h } = this
    const theme = this.renderedTheme

    ctx.save()

    // camera
    const shake = this.effMotion ? this.fx.shake : 0
    const sx = (Math.random() - 0.5) * shake
    const sy = (Math.random() - 0.5) * shake
    const px = this.pointer.active ? (this.pointer.x / w - 0.5) : 0
    const py = this.pointer.active ? (this.pointer.y / h - 0.5) : 0

    ctx.translate(w / 2, h / 2)
    ctx.scale(this.fx.zoom, this.fx.zoom)
    ctx.translate(-w / 2, -h / 2)
    ctx.translate(sx, sy)

    if (this.mirror) {
      ctx.translate(w, 0)
      ctx.scale(-1, 1)
    }

    // background gradient
    const g = ctx.createLinearGradient(0, 0, w * 0.25, h)
    g.addColorStop(0, theme.bg[0])
    g.addColorStop(0.55, theme.bg[1])
    g.addColorStop(1, theme.bg[2])
    ctx.fillStyle = g
    ctx.fillRect(-40, -40, w + 80, h + 80)

    // nebula blobs (frozen when background animation is off)
    if (theme.nebula.length > 0) {
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      for (const n of this.nebula) {
        const nx = n.x + Math.sin(this.bgT * 0.05 + n.drift) * 40 - px * 26
        const ny = n.y + Math.cos(this.bgT * 0.04 + n.drift) * 30 - py * 20
        const color = theme.nebula[n.hue % theme.nebula.length]
        const rg = ctx.createRadialGradient(nx, ny, 0, nx, ny, n.r)
        rg.addColorStop(0, hexToRgbaStr(color, theme.nebulaAlpha))
        rg.addColorStop(1, 'rgba(0,0,0,0)')
        ctx.fillStyle = rg
        ctx.beginPath()
        ctx.arc(nx, ny, n.r, 0, Math.PI * 2)
        ctx.fill()
      }
      ctx.restore()
    }

    // stars (parallax with pointer, twinkle frozen when background is off)
    ctx.save()
    ctx.globalCompositeOperation = 'lighter'
    const starAlpha = clampN(theme.starCount / 220, 0.12, 1)
    const visibleStars = Math.floor(this.stars.length * starAlpha)
    for (let i = 0; i < visibleStars; i++) {
      const s = this.stars[i]
      const tw = 0.45 + Math.sin(this.bgT * 1.4 + s.tw) * 0.4
      const ox = px * (6 + s.r * 9)
      const oy = py * (4 + s.r * 7)
      ctx.fillStyle = theme.starTint.startsWith('#')
        ? hexToRgbaStr(theme.starTint, tw * 0.8)
        : `rgba(226,232,240,${tw * 0.8})`
      ctx.beginPath()
      ctx.arc(s.x - ox, s.y - oy, s.r, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.restore()

    // environment scenery (crossfade)
    drawScenery(ctx, this.env, w, h, this.time, this.envNext === null ? 1 : 1 - this.envBlend)
    if (this.envNext !== null) {
      drawScenery(ctx, this.envNext, w, h, this.time, this.envBlend)
    }

    // weather behind (fog / clouds)
    // (particles are drawn once, below — good enough composition)

    // orbiters behind orb
    this.fx.drawOrbiters(ctx, this.orb.renderX, this.orb.renderY, this.orb.scale)

    // trail
    this.orb.drawTrail(ctx)

    // particles
    this.ps.draw(ctx)

    // orb
    this.orb.draw(ctx, this.time)

    // effects
    this.fx.draw(ctx)

    // theme tint
    if (theme.tint) {
      ctx.fillStyle = theme.tint
      ctx.fillRect(-40, -40, w + 80, h + 80)
    }

    ctx.restore()

    // dim overlay (screen space)
    if (this.dim > 0.01) {
      ctx.fillStyle = `rgba(2,3,10,${this.dim})`
      ctx.fillRect(0, 0, w, h)
    }

    // invert overlay (screen space)
    if (this.invert > 0.02) {
      ctx.save()
      ctx.globalCompositeOperation = 'difference'
      ctx.fillStyle = `rgba(255,255,255,${this.invert})`
      ctx.fillRect(0, 0, w, h)
      ctx.restore()
    }

    // vignette (screen space)
    const vg = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.42, w / 2, h / 2, Math.max(w, h) * 0.78)
    vg.addColorStop(0, 'rgba(3,4,12,0)')
    vg.addColorStop(1, 'rgba(3,4,12,0.52)')
    ctx.fillStyle = vg
    ctx.fillRect(0, 0, w, h)

    // background ambience dim for library/studio views
    if (this.ambience === 'background') {
      ctx.fillStyle = 'rgba(4,6,16,0.42)'
      ctx.fillRect(0, 0, w, h)
    }

    // clear-world fade (dark → reset → reveal)
    if (this.clearing >= 0) {
      const t = this.clearing
      const a = t < 0.4 ? t / 0.4 : t < 0.55 ? 1 : Math.max(0, 1 - (t - 0.55) / 0.4)
      if (a > 0.01) {
        ctx.fillStyle = `rgba(3,4,12,${a * 0.92})`
        ctx.fillRect(0, 0, w, h)
      }
    }
  }

  /* expose for UI state restore */
  currentEnvironment(): EnvironmentKind {
    return this.envNext ?? this.env
  }
  currentWeather(): WeatherKind {
    return this.weather.active()
  }
  hasElement(e: ElementKind): boolean {
    return this.elements.has(e)
  }
}

function hexToRgbaStr(hex: string, a: number): string {
  const h = hex.replace('#', '')
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16)
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`
}

function clampN(v: number, min: number, max: number) {
  return v < min ? min : v > max ? max : v
}

function rnd(a: number, b: number) {
  return a + Math.random() * (b - a)
}

/* a tiny module-level singleton the UI can reach */
let engineInstance: WorldEngine | null = null

export function getEngine(): WorldEngine | null {
  return engineInstance
}

export function setEngine(e: WorldEngine | null) {
  engineInstance = e
}

/* ---------------- chip metadata for the Active Effects panel ---------------- */

type Meta = { icon: string; label: string; accent: string }

const ELEMENT_META: Record<ElementKind, Meta> = {
  fire: { icon: '🔥', label: 'Fire', accent: '#fb923c' },
  water: { icon: '💧', label: 'Water', accent: '#38bdf8' },
  ice: { icon: '🧊', label: 'Ice', accent: '#a5f3fc' },
  wind: { icon: '🌬️', label: 'Wind', accent: '#a5b4fc' },
  earth: { icon: '🪨', label: 'Earth', accent: '#a8a29e' },
  electric: { icon: '⚡', label: 'Electric', accent: '#fde047' },
  lava: { icon: '🌋', label: 'Lava', accent: '#f97316' },
  smoke: { icon: '💨', label: 'Smoke', accent: '#94a3b8' },
  steam: { icon: '♨️', label: 'Steam', accent: '#e2e8f0' },
  void: { icon: '🕳️', label: 'Void', accent: '#7c3aed' },
}

const WEATHER_META: Partial<Record<NonNullable<WeatherKind>, Meta>> = {
  rain: { icon: '🌧️', label: 'Rain', accent: '#60a5fa' },
  snow: { icon: '🌨️', label: 'Snow', accent: '#bae6fd' },
  storm: { icon: '⛈️', label: 'Storm', accent: '#818cf8' },
  fog: { icon: '🌫️', label: 'Fog', accent: '#cbd5e1' },
  leaves: { icon: '🍂', label: 'Leaves', accent: '#fb923c' },
  petals: { icon: '🌸', label: 'Petals', accent: '#f9a8d4' },
  bubbles: { icon: '🫧', label: 'Bubbles', accent: '#a5f3fc' },
  embers: { icon: '🔥', label: 'Embers', accent: '#fb923c' },
  starfall: { icon: '🌠', label: 'Starfall', accent: '#c4b5fd' },
  confetti: { icon: '🎉', label: 'Confetti', accent: '#f472b6' },
  fireflies: { icon: '✨', label: 'Fireflies', accent: '#fde68a' },
  hearts: { icon: '💗', label: 'Hearts', accent: '#fb7185' },
  sparks: { icon: '⚡', label: 'Sparks', accent: '#fde047' },
  dust: { icon: '🌪️', label: 'Dust', accent: '#d6d3d1' },
  clouds: { icon: '☁️', label: 'Clouds', accent: '#e2e8f0' },
  matrix: { icon: '👾', label: 'Matrix', accent: '#4ade80' },
  butterflies: { icon: '🦋', label: 'Butterflies', accent: '#f9a8d4' },
}

const ENV_META: Partial<Record<EnvironmentKind, Meta>> = {
  galaxy: { icon: '🌌', label: 'Galaxy', accent: '#a78bfa' },
  night: { icon: '🌙', label: 'Night', accent: '#93c5fd' },
  midnight: { icon: '🌑', label: 'Midnight', accent: '#6366f1' },
  sunset: { icon: '🌇', label: 'Sunset', accent: '#fb923c' },
  dawn: { icon: '🌅', label: 'Dawn', accent: '#fcd34d' },
  ocean: { icon: '🌊', label: 'Ocean', accent: '#22d3ee' },
  desert: { icon: '🏜️', label: 'Desert', accent: '#fbbf24' },
  winter: { icon: '🏔️', label: 'Winter', accent: '#bae6fd' },
  arctic: { icon: '🧊', label: 'Arctic', accent: '#a5f3fc' },
  storm: { icon: '🌩️', label: 'Storm', accent: '#818cf8' },
  void: { icon: '🕳️', label: 'Void', accent: '#7c3aed' },
  dream: { icon: '💭', label: 'Dream', accent: '#f9a8d4' },
  volcano: { icon: '🌋', label: 'Volcano', accent: '#f97316' },
  jungle: { icon: '🌴', label: 'Jungle', accent: '#4ade80' },
  neon: { icon: '🌆', label: 'Neon', accent: '#e879f9' },
  aurora: { icon: '🌈', label: 'Aurora', accent: '#34d399' },
}

const MOTION_META: Partial<Record<MotionMode, Meta>> = {
  fly: { icon: '🕊️', label: 'Flying', accent: '#a5b4fc' },
  run: { icon: '🏃', label: 'Running', accent: '#fb923c' },
  walk: { icon: '🚶', label: 'Walking', accent: '#a8a29e' },
  go: { icon: '➡️', label: 'Going', accent: '#a5b4fc' },
  orbit: { icon: '🔄', label: 'Orbiting', accent: '#c4b5fd' },
  bounce: { icon: '🏀', label: 'Bouncing', accent: '#fb923c' },
  spiral: { icon: '🌀', label: 'Spiraling', accent: '#a78bfa' },
  zigzag: { icon: '〰️', label: 'Zigzagging', accent: '#67e8f9' },
  figure8: { icon: '♾️', label: 'Figure eight', accent: '#c4b5fd' },
  sway: { icon: '🎐', label: 'Swaying', accent: '#f9a8d4' },
  drift: { icon: '🍃', label: 'Drifting', accent: '#86efac' },
  float: { icon: '🎈', label: 'Floating', accent: '#f9a8d4' },
  climb: { icon: '🧗', label: 'Climbing', accent: '#86efac' },
}

const TRAIL_META: Partial<Record<NonNullable<TrailKind>, Meta>> = {
  rainbow: { icon: '🌈', label: 'Rainbow', accent: '#f472b6' },
  sparkle: { icon: '✨', label: 'Sparkle', accent: '#fde68a' },
  gold: { icon: '🏅', label: 'Gold', accent: '#fbbf24' },
  fire: { icon: '🔥', label: 'Fire trail', accent: '#fb923c' },
  ice: { icon: '❄️', label: 'Ice trail', accent: '#a5f3fc' },
  comet: { icon: '☄️', label: 'Comet', accent: '#67e8f9' },
  heart: { icon: '💗', label: 'Hearts', accent: '#fb7185' },
  star: { icon: '⭐', label: 'Stars', accent: '#fde047' },
  echo: { icon: '👥', label: 'Echo', accent: '#c4b5fd' },
  bubble: { icon: '🫧', label: 'Bubbles', accent: '#a5f3fc' },
  musical: { icon: '🎵', label: 'Music', accent: '#e879f9' },
}

/** the WORDY palette — used when the core “picks a new favorite color” */
const PALETTE = [
  '#f87171', '#fb923c', '#fde047', '#4ade80', '#60a5fa', '#22d3ee',
  '#a78bfa', '#f472b6', '#fbbf24', '#e879f9', '#34d399', '#f43f5e',
]

/** v1.2 — how a command family makes the sphere feel */
function inferMood(spec: EffectSpec): MoodKind | null {
  if (spec.element === 'fire' || spec.element === 'lava') return 'energetic'
  if (spec.element === 'ice' || spec.element === 'void') return 'calm'
  if (spec.element === 'electric') return 'tense'
  if (spec.motion === 'run') return 'energetic'
  if (spec.motion === 'fly' || spec.motion === 'float') return 'curious'
  const actions = spec.action ? (Array.isArray(spec.action) ? spec.action : [spec.action]) : []
  if (actions.includes('lightning') || spec.environment === 'storm') return 'tense'
  if (actions.includes('sleep')) return 'sleepy'
  if (actions.includes('wake')) return 'curious'
  if (actions.includes('speak') || actions.includes('sing')) return 'jubilant'
  if (actions.includes('jump') || actions.includes('dash')) return 'energetic'
  // boom/explode set their own tense mood inside the sequence
  if (spec.weather === 'rain' || spec.weather === 'snow' || spec.weather === 'fog') return 'calm'
  if (spec.glow !== undefined && spec.glow >= 1.4) return 'jubilant'
  return null
}

const DEFAULT_LINES = [
  'hello, world',
  'i am here',
  'words are magic',
  'you called?',
  'i could say anything',
]

const SPECTACLES: ActionName[] = [
  'meteor', 'ufo', 'fireworks', 'flock', 'galaxyburst', 'featherfall',
  'portalopen', 'blackhole', 'starburst', 'confettiburst',
]
