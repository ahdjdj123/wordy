'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { SphereStyle, SphereDimension } from './types'

/* ==========================================================================
   WORDY user state — everything lives locally, nothing leaves the device.
   Discovered words, saved spells, history, settings.
   ========================================================================== */

export interface Spell {
  id: string
  name: string
  steps: string[]
  createdAt: number
}

export interface HistoryEntry {
  word: string
  at: number
}

export interface GraphicsSettings {
  quality: 'low' | 'medium' | 'high' | 'ultra'
  fps: 30 | 60 | 120
  density: number    // 0.25 – 2
  bloom: number      // 0.4 – 1.6
  motion: boolean
  background: boolean
}

export interface AudioSettings {
  master: number     // 0 – 1
  commands: boolean
  ambient: boolean
  voice: boolean
}

export interface SphereSettings {
  style: SphereStyle
  dimension: SphereDimension
}

const DEFAULT_GRAPHICS: GraphicsSettings = {
  quality: 'high',
  fps: 60,
  density: 1,
  bloom: 1,
  motion: true,
  background: true,
}

const DEFAULT_AUDIO: AudioSettings = {
  master: 0.7,
  commands: true,
  ambient: true,
  voice: true,
}

const DEFAULT_SPHERE: SphereSettings = {
  style: 'energy',
  dimension: '3d',
}

interface WordyState {
  /* discoveries */
  discovered: string[]          // visible commands the user has tried
  discoveredSecrets: string[]   // hidden words revealed
  discoveredCombos: string[]    // emergent combos witnessed

  /* history */
  history: HistoryEntry[]

  /* spells */
  spells: Spell[]

  /* settings */
  graphics: GraphicsSettings
  audio: AudioSettings
  sphere: SphereSettings
  seenIntro: boolean

  /* actions */
  recordCommand: (name: string, hidden?: boolean) => void
  recordCombo: (id: string) => void
  pushHistory: (word: string) => void
  saveSpell: (spell: Spell) => void
  deleteSpell: (id: string) => void
  setGraphics: (p: Partial<GraphicsSettings>) => void
  setAudio: (p: Partial<AudioSettings>) => void
  setSphere: (p: Partial<SphereSettings>) => void
  setSeenIntro: (v: boolean) => void
  resetAll: () => void
}

export const useWordy = create<WordyState>()(
  persist(
    (set) => ({
      discovered: [],
      discoveredSecrets: [],
      discoveredCombos: [],
      history: [],
      spells: [],
      graphics: { ...DEFAULT_GRAPHICS },
      audio: { ...DEFAULT_AUDIO },
      sphere: { ...DEFAULT_SPHERE },
      seenIntro: false,

      recordCommand: (name, hidden) =>
        set((s) => {
          if (hidden) {
            if (s.discoveredSecrets.includes(name)) return s
            return { discoveredSecrets: [...s.discoveredSecrets, name] }
          }
          if (s.discovered.includes(name)) return s
          return { discovered: [...s.discovered, name] }
        }),

      recordCombo: (id) =>
        set((s) =>
          s.discoveredCombos.includes(id)
            ? s
            : { discoveredCombos: [...s.discoveredCombos, id] },
        ),

      pushHistory: (word) =>
        set((s) => ({
          history: [{ word, at: Date.now() }, ...s.history.filter((h) => h.word !== word)].slice(0, 40),
        })),

      saveSpell: (spell) =>
        set((s) => ({
          spells: [spell, ...s.spells.filter((p) => p.id !== spell.id)].slice(0, 24),
        })),

      deleteSpell: (id) =>
        set((s) => ({ spells: s.spells.filter((p) => p.id !== id) })),

      setGraphics: (p) => set((s) => ({ graphics: { ...s.graphics, ...p } })),
      setAudio: (p) => set((s) => ({ audio: { ...s.audio, ...p } })),
      setSphere: (p) => set((s) => ({ sphere: { ...s.sphere, ...p } })),
      setSeenIntro: (v) => set({ seenIntro: v }),

      resetAll: () =>
        set({
          discovered: [],
          discoveredSecrets: [],
          discoveredCombos: [],
          history: [],
          spells: [],
          graphics: { ...DEFAULT_GRAPHICS },
          audio: { ...DEFAULT_AUDIO },
          sphere: { ...DEFAULT_SPHERE },
          seenIntro: false,
        }),
    }),
    {
      name: 'wordy-world-v1',
      version: 2,
      /* safe migration — v1 stored { soundOn, quality } flat */
      migrate: (persisted) => {
        const p = (persisted ?? {}) as Record<string, unknown>
        const out: Record<string, unknown> = {}
        // carry over the collections v1 knew about
        for (const key of ['discovered', 'discoveredSecrets', 'discoveredCombos', 'history', 'spells', 'seenIntro']) {
          if (Array.isArray(p[key]) || typeof p[key] === 'boolean') out[key] = p[key]
        }
        // map old settings to the new shape
        const oldSound = typeof p.soundOn === 'boolean' ? p.soundOn : true
        const oldQuality = typeof p.quality === 'string' ? p.quality : 'auto'
        out.graphics = {
          ...DEFAULT_GRAPHICS,
          quality: oldQuality === 'low' ? 'low' : oldQuality === 'high' ? 'ultra' : 'high',
        }
        out.audio = {
          ...DEFAULT_AUDIO,
          master: oldSound ? DEFAULT_AUDIO.master : 0,
          commands: oldSound,
        }
        out.sphere = { ...DEFAULT_SPHERE }
        return out as unknown as WordyState
      },
    },
  ),
)
