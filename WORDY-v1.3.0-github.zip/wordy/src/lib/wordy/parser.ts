import type { CommandDef, Suggestion } from './types'
import { COMMANDS, COMMAND_MAP, findCommand, TOTAL_WORDS } from './commands'

/* ==========================================================================
   WORDY parser — turns a typed word into a command (or a gentle shrug).
   Never technical. Never harsh.
   ========================================================================== */

export interface ParseResult {
  command?: CommandDef
  isSecretReveal: boolean
  /** free text captured after a takesText verb (speak hello → "hello") */
  text?: string
  unknown?: {
    word: string
    suggestions: Suggestion[]
  }
}

function score(cmd: CommandDef, q: string): number {
  const name = cmd.name
  if (name === q) return 1000
  if (name.startsWith(q)) return 500 - name.length
  // word-boundary inside multi-word names ("falling leaves" for "leaves")
  if (name.includes(` ${q}`)) return 320
  if (name.includes(q)) return 260 - name.length
  // alias match
  for (const a of cmd.aliases) {
    if (a === q) return 480
    if (a.startsWith(q)) return 440 - a.length
    if (a.includes(q)) return 240 - a.length
  }
  return 0
}

/** subtle autocomplete while typing */
export function suggest(input: string, limit = 6, includeHidden = false): Suggestion[] {
  const q = input.trim().toLowerCase()
  if (!q) return []
  // while typing free text after a speak verb, chips would only distract
  const head = q.split(' ')[0].replace(/[:：]$/, '')
  const headCmd = COMMAND_MAP.get(head)
  if (headCmd?.takesText && q.includes(' ')) return []
  const scored: Array<{ s: Suggestion; v: number }> = []
  for (const c of COMMANDS) {
    if (c.hidden && !includeHidden) continue
    const v = score(c, q)
    if (v > 0) scored.push({ s: { word: c.name, category: c.category }, v })
  }
  scored.sort((a, b) => b.v - a.v)
  const out: Suggestion[] = []
  const seen = new Set<string>()
  for (const { s } of scored) {
    if (seen.has(s.word)) continue
    seen.add(s.word)
    out.push(s)
    if (out.length >= limit) break
  }
  return out
}

/** soft suggestions for an unknown word — near-misses first */
function nearMisses(word: string): Suggestion[] {
  const q = word.toLowerCase().replace(/[^a-z0-9 ]/g, '')
  const out = suggest(q, 4)
  if (out.length >= 3) return out
  // fuzzy: shared 3-letter window
  const windows = new Set<string>()
  for (let i = 0; i + 3 <= q.length; i++) windows.add(q.slice(i, i + 3))
  const scored: Array<{ s: Suggestion; v: number }> = []
  for (const c of COMMANDS) {
    if (c.hidden) continue
    const hay = (c.name + ' ' + c.aliases.join(' ')).toLowerCase()
    let hits = 0
    for (const w of windows) if (hay.includes(w)) hits++
    if (hits > 0) scored.push({ s: { word: c.name, category: c.category }, v: hits - c.name.length * 0.05 })
  }
  scored.sort((a, b) => b.v - a.v)
  for (const { s } of scored) {
    if (out.find((o) => o.word === s.word)) continue
    out.push(s)
    if (out.length >= 3) break
  }
  return out
}

export function parse(input: string, discoveredSecrets: string[] = []): ParseResult {
  const raw = input.trim().toLowerCase().replace(/\s+/g, ' ')
  if (!raw) {
    return { isSecretReveal: false, unknown: { word: '', suggestions: [] } }
  }

  // speak / say / talk — the first word is the verb, the rest is the message
  const firstWord = raw.split(' ')[0].replace(/[:：]$/, '')
  const speakCmd = COMMAND_MAP.get(firstWord)
  if (speakCmd?.takesText) {
    let text = input.trim().slice(input.trim().indexOf(firstWord) + firstWord.length)
    text = text.replace(/^["'“”«»]+|["'“”«»]+$/g, '').trim()
    const isSecretReveal = !!speakCmd.hidden && !discoveredSecrets.includes(speakCmd.name)
    return { command: speakCmd, isSecretReveal, text }
  }

  const command = findCommand(raw)
  if (command) {
    const isSecretReveal = !!command.hidden && !discoveredSecrets.includes(command.name)
    return { command, isSecretReveal }
  }
  return { isSecretReveal: false, unknown: { word: input.trim(), suggestions: nearMisses(raw) } }
}

export { TOTAL_WORDS, COMMAND_MAP, COMMANDS }
