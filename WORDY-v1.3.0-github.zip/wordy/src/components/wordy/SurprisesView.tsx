'use client'

import { useMemo } from 'react'
import { motion } from 'framer-motion'
import { Lock, Sparkles, Telescope, ArrowRight, Blend } from 'lucide-react'
import { COMMANDS, COMBOS, secretCommands, hintFor } from '@/lib/wordy/commands'
import type { CommandDef, ComboDef } from '@/lib/wordy/types'
import { useWordy } from '@/lib/wordy/store'
import { useWordyUI } from './wordy-context'

/* a poetic nudge that rotates daily */
function todaysWhisper(undiscoveredSecrets: string[], undiscoveredCombos: string[]): string {
  const day = Math.floor(Date.now() / 86400000)
  const pool: string[] = []
  for (const name of undiscoveredSecrets) {
    pool.push(hintFor(name))
  }
  for (const id of undiscoveredCombos) {
    const c = COMBOS.find((x) => x.id === id)
    if (c) pool.push(`Try ${c.recipe} — something new appears.`)
  }
  if (pool.length === 0) return 'You have found everything. The world is quietly impressed.'
  return pool[day % pool.length]
}

function SecretCard({ cmd, discovered }: { cmd: CommandDef; discovered: boolean }) {
  const { tryCommandByName } = useWordyUI()
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className={`relative overflow-hidden rounded-3xl p-5 ${discovered ? 'glass ring-1 ring-amber-400/30' : 'glass'}`}
    >
      {discovered ? (
        <>
          <div className="mb-2 flex items-center justify-between">
            <span className="rounded-full border border-amber-400/30 bg-amber-400/12 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-300">
              discovered
            </span>
            <button
              onClick={() => tryCommandByName(cmd.name)}
              className="rounded-full border border-amber-400/25 bg-amber-400/10 px-3 py-1 text-[11px] font-medium text-amber-200 transition-all hover:bg-amber-400/20 active:scale-95"
            >
              again
            </button>
          </div>
          <h3 className="wordy-gold-gradient-text font-display text-xl font-bold tracking-wide">{cmd.name}</h3>
          <p className="mt-1.5 text-[13px] leading-relaxed text-white/55">{cmd.description}</p>
        </>
      ) : (
        <>
          <div className="mb-3 flex h-8 w-8 items-center justify-center rounded-full bg-white/[0.05] text-white/35">
            <Lock size={13} />
          </div>
          <h3 className="font-display text-xl font-bold tracking-[0.3em] text-white/30">???</h3>
          <p className="mt-1.5 text-[13px] leading-relaxed text-white/45 italic">{hintFor(cmd.name)}</p>
        </>
      )}
    </motion.div>
  )
}

function ComboCard({ combo, discovered }: { combo: ComboDef; discovered: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className={`rounded-3xl p-5 ${discovered ? 'glass ring-1 ring-fuchsia-400/25' : 'glass'}`}
    >
      <div className="mb-2 flex items-center gap-2 text-xs text-white/40">
        <Blend size={13} className="text-fuchsia-300/70" />
        <span className="font-display tracking-wide text-white/70">{combo.recipe}</span>
      </div>
      {discovered ? (
        <p className="text-[13px] leading-relaxed text-white/60">
          <span className="font-semibold text-fuchsia-200">{combo.name}.</span> {combo.description}
        </p>
      ) : (
        <p className="text-[13px] text-white/35 italic">
          Cast both words, one after the other — and watch what appears.
        </p>
      )}
    </motion.div>
  )
}

export function SurprisesView() {
  const discoveredSecrets = useWordy((s) => s.discoveredSecrets)
  const discoveredCombos = useWordy((s) => s.discoveredCombos)
  const discovered = useWordy((s) => s.discovered)
  const { setView } = useWordyUI()

  const secrets = secretCommands
  const secretsFound = secrets.filter((s) => discoveredSecrets.includes(s.name))
  const secretsHidden = secrets.filter((s) => !discoveredSecrets.includes(s.name))
  const combosFound = COMBOS.filter((c) => discoveredCombos.includes(c.id))
  const combosHidden = COMBOS.filter((c) => !discoveredCombos.includes(c.id))

  const whisper = useMemo(
    () => todaysWhisper(secretsHidden.map((s) => s.name), combosHidden.map((c) => c.id)),
    [secretsHidden, combosHidden],
  )

  const pct = Math.round(((secretsFound.length + combosFound.length) / (secrets.length + COMBOS.length)) * 100)

  return (
    <div className="mx-auto w-full max-w-4xl px-4 pb-24 pt-4 sm:px-6">
      <header className="mb-6">
        <h1 className="font-display text-3xl font-bold tracking-wide text-white sm:text-4xl">
          <span className="wordy-gold-gradient-text">Surprises</span>
        </h1>
        <p className="text-sm text-white/45">
          The world keeps a few things to itself. It hopes you’ll try anyway.
        </p>
      </header>

      {/* progress */}
      <div className="glass mb-6 rounded-3xl p-5">
        <div className="mb-3 flex items-end justify-between">
          <div>
            <p className="font-display text-lg font-semibold text-white">Your collection</p>
            <p className="text-xs text-white/40">
              {secretsFound.length}/{secrets.length} secrets · {combosFound.length}/{COMBOS.length} combinations · {discovered.length} words tried
            </p>
          </div>
          <span className="font-display text-2xl font-bold wordy-gold-gradient-text">{pct}%</span>
        </div>
        <div className="h-1.5 overflow-hidden rounded-full bg-white/8">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${Math.max(pct, 2)}%` }}
            transition={{ duration: 1, ease: 'easeOut' }}
            className="h-full rounded-full bg-gradient-to-r from-amber-300 via-amber-400 to-amber-500 shadow-[0_0_12px_rgba(251,191,36,0.5)]"
          />
        </div>
      </div>

      {/* today's whisper */}
      <div className="mb-8 overflow-hidden rounded-3xl border border-fuchsia-400/15 bg-gradient-to-br from-fuchsia-500/10 via-violet-500/5 to-transparent p-5">
        <div className="flex items-start gap-3.5">
          <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-fuchsia-500/15 text-fuchsia-300">
            <Telescope size={16} />
          </span>
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.25em] text-fuchsia-300/70">Today’s whisper</p>
            <p className="mt-1 text-sm leading-relaxed text-white/70">{whisper}</p>
            <button
              onClick={() => setView('playground')}
              className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-fuchsia-400/25 bg-fuchsia-500/12 px-4 py-1.5 text-xs font-medium text-fuchsia-200 transition-all hover:bg-fuchsia-500/22 active:scale-95"
            >
              Go experiment
              <ArrowRight size={12} />
            </button>
          </div>
        </div>
      </div>

      {/* secrets */}
      <section className="mb-10">
        <h2 className="mb-1 font-display text-xl font-semibold text-white/90">Hidden words</h2>
        <p className="mb-4 text-xs text-white/35">Type them in the Playground. That’s the whole game.</p>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {secretsFound.map((c) => (
            <SecretCard key={c.name} cmd={c} discovered />
          ))}
          {secretsHidden.map((c) => (
            <SecretCard key={c.name} cmd={c} discovered={false} />
          ))}
        </div>
      </section>

      {/* combos */}
      <section className="mb-10">
        <h2 className="mb-1 font-display text-xl font-semibold text-white/90">Unusual combinations</h2>
        <p className="mb-4 text-xs text-white/35">Some words react to each other. Nobody will tell you which.</p>
        <div className="grid gap-3 sm:grid-cols-2">
          {combosFound.map((c) => (
            <ComboCard key={c.id} combo={c} discovered />
          ))}
          {combosHidden.map((c) => (
            <ComboCard key={c.id} combo={c} discovered={false} />
          ))}
        </div>
      </section>

      <div className="glass rounded-3xl p-6 text-center">
        <Sparkles className="mx-auto mb-3 h-5 w-5 text-amber-300/80" />
        <p className="mx-auto max-w-md text-sm leading-relaxed text-white/50">
          Nothing here is a test. Every wrong word is just the world saying
          <span className="text-white/80"> “not this one — try another.”</span>
        </p>
        <p className="mt-3 text-[10px] uppercase tracking-[0.3em] text-white/25">
          {COMMANDS.filter((c) => !c.hidden).length} known words · {secrets.length} secrets · {COMBOS.length} combinations
        </p>
      </div>
    </div>
  )
}
