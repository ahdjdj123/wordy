'use client'

import { useEffect, useRef } from 'react'
import { WorldEngine, getEngine, setEngine } from '@/lib/wordy/engine/engine'
import { sound } from '@/lib/wordy/audio'
import { useWordy } from '@/lib/wordy/store'

/**
 * The living world. Fixed behind every view, always breathing.
 * Pointer position feeds gentle parallax + particle nudging.
 * Settings from the store are applied to the engine instantly.
 */
export function WorldCanvas() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const graphics = useWordy((s) => s.graphics)
  const audio = useWordy((s) => s.audio)
  const sphere = useWordy((s) => s.sphere)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const engine = new WorldEngine()
    setEngine(engine)
    engine.mount(canvas)
    ;(window as unknown as { __wordy?: unknown }).__wordy = engine

    const onResize = () => engine.resize()
    const onPointer = (e: PointerEvent) => {
      engine.setPointer(e.clientX, e.clientY)
    }
    const onLeave = () => engine.pointerLeave()

    window.addEventListener('resize', onResize)
    window.addEventListener('pointermove', onPointer, { passive: true })
    window.addEventListener('pointerleave', onLeave)

    return () => {
      window.removeEventListener('resize', onResize)
      window.removeEventListener('pointermove', onPointer)
      window.removeEventListener('pointerleave', onLeave)
      engine.unmount()
      setEngine(null)
    }
  }, [])

  /* graphics — quality / fps / density / bloom / motion / background */
  useEffect(() => {
    getEngine()?.setGraphics(graphics)
  }, [graphics])

  /* audio — master volume + per-channel toggles */
  useEffect(() => {
    sound.setVolume(audio.master)
    sound.setSfx(audio.commands)
    sound.setAmbient(audio.ambient)
    sound.setVoice(audio.voice)
  }, [audio])

  /* sphere — style + dimension, applied instantly, no reload */
  useEffect(() => {
    const engine = getEngine()
    engine?.setSphereStyle(sphere.style)
    engine?.setDimension(sphere.dimension)
  }, [sphere])

  return (
    <canvas
      ref={canvasRef}
      aria-hidden
      className="fixed inset-0 h-full w-full"
      style={{ display: 'block' }}
    />
  )
}
