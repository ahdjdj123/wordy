'use client'

import { useState } from 'react'
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Slider } from '@/components/ui/slider'
import {
  Settings2, Volume2, VolumeX, Gauge, RotateCcw, Sparkles, Monitor, Circle,
  Info, HelpCircle, ShieldCheck,
} from 'lucide-react'
import { useWordy } from '@/lib/wordy/store'
import { COMMANDS, COMBOS, secretCommands, TOTAL_WORDS } from '@/lib/wordy/commands'
import { WORDY_VERSION, WORDY_CODENAME } from '@/lib/wordy/types'
import type { SphereStyle, SphereDimension } from '@/lib/wordy/types'

/* ---------- tiny building blocks (glassy, quiet) ---------- */

function Row({ icon, title, hint, children }: {
  icon: React.ReactNode
  title: string
  hint?: string
  children: React.ReactNode
}) {
  return (
    <div className="rounded-2xl border border-white/8 bg-white/[0.03] p-4">
      <div className="mb-3 flex items-center gap-3">
        {icon}
        <div>
          <p className="text-sm font-medium text-white/85">{title}</p>
          {hint && <p className="text-xs text-white/35">{hint}</p>}
        </div>
      </div>
      {children}
    </div>
  )
}

function Segmented<T extends string | number>({ options, value, onChange, format }: {
  options: T[]
  value: T
  onChange: (v: T) => void
  format?: (v: T) => string
}) {
  return (
    <div className="flex gap-1.5">
      {options.map((q) => (
        <button
          key={String(q)}
          onClick={() => onChange(q)}
          className={`flex-1 rounded-xl border py-2 text-xs font-medium transition-all ${
            value === q
              ? 'border-violet-400/45 bg-violet-500/20 text-white shadow-[0_0_18px_rgba(124,58,237,0.22)]'
              : 'border-white/8 bg-white/[0.02] text-white/45 hover:text-white/80'
          }`}
        >
          {format ? format(q) : String(q)}
        </button>
      ))}
    </div>
  )
}

function SliderRow({ label, value, min, max, step, onChange, format }: {
  label: string
  value: number
  min: number
  max: number
  step: number
  onChange: (v: number) => void
  format: (v: number) => string
}) {
  return (
    <div className="mb-4 last:mb-0">
      <div className="mb-2 flex items-baseline justify-between">
        <span className="text-xs text-white/55">{label}</span>
        <span className="font-display text-xs font-semibold text-violet-200">{format(value)}</span>
      </div>
      <Slider
        value={[value]}
        min={min}
        max={max}
        step={step}
        onValueChange={(v) => onChange(v[0])}
        aria-label={label}
      />
    </div>
  )
}

function Toggle({ on, onClick, label }: { on: boolean; onClick: () => void; label: string }) {
  return (
    <button
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={onClick}
      className={`relative h-6.5 w-11 shrink-0 rounded-full border transition-colors ${
        on ? 'border-violet-400/40 bg-violet-500/50' : 'border-white/15 bg-white/10'
      }`}
    >
      <span
        className={`absolute top-1/2 h-4.5 w-4.5 -translate-y-1/2 rounded-full bg-white shadow transition-all ${
          on ? 'left-[calc(100%-1.375rem)]' : 'left-1'
        }`}
      />
    </button>
  )
}

function ToggleRow({ label, hint, on, onToggle }: {
  label: string
  hint?: string
  on: boolean
  onToggle: () => void
}) {
  return (
    <div className="flex items-center justify-between gap-4 py-1.5">
      <div>
        <p className="text-[13px] text-white/75">{label}</p>
        {hint && <p className="text-[11px] text-white/30">{hint}</p>}
      </div>
      <Toggle on={on} onClick={onToggle} label={label} />
    </div>
  )
}

/* ---------- the sphere style picker previews ---------- */

const SPHERE_STYLES: Array<{ id: SphereStyle; label: string; css: string }> = [
  { id: 'energy', label: 'Energy', css: 'bg-[radial-gradient(circle_at_32%_30%,#ede9fe,#8b5cf6_55%,#312e81)]' },
  { id: 'crystal', label: 'Crystal', css: 'bg-[conic-gradient(from_200deg,#e0f2fe,#a5b4fc_30%,#c4b5fd_55%,#67e8f9_80%,#e0f2fe)]' },
  { id: 'galaxy', label: 'Galaxy', css: 'bg-[radial-gradient(circle_at_50%_50%,#e2e8f0_4%,#312e81_28%,#0b1026_75%)]' },
  { id: 'liquid', label: 'Liquid', css: 'bg-[radial-gradient(circle_at_65%_20%,#a5f3fc,#06b6d4_60%,#1e3a8a)]' },
  { id: 'pixel', label: 'Pixel', css: 'bg-[repeating-conic-gradient(#a78bfa_0_25%,#7c3aed_0_50%)] [background-size:26%_33%] rounded-none' },
]

/* ---------- about · faq · privacy — quiet info, not navigation ---------- */

const VERSION_HISTORY: Array<[string, string, string[]]> = [
  ['1.3.0', 'Final Polish', [
    'A release pass over every screen — settings, menus, mobile and touch',
    'Effects and Clear All refined; the sphere always returns home to idle',
    'About, FAQ and Privacy finished inside Settings',
  ]],
  ['1.2.0', 'Living Sphere', [
    'The sphere never sleeps: idle breathing, moods, orbiting motes',
    'Physical combinations — fire + rain makes real steam',
    'Every core command re-choreographed by hand; zero placeholders',
    'Adaptive performance and a lighter mobile world',
  ]],
  ['1.1.0', 'The Actor', [
    'The sphere runs, walks, speaks, sleeps and booms in sequence',
    'Clear World, the settings drawer and Active Effects chips',
    'Five sphere styles, 3D / 2D, instant graphics settings',
  ]],
  ['1.0.0', 'First Light', [
    'One word, one world — the library, the studio, the surprises',
  ]],
]

const FAQ_ITEMS: Array<[string, string]> = [
  ['How do commands work?', 'Type any word and press Enter. If the world knows it, it happens — fly, fire, rain, boom, moon. Autocomplete chips suggest words as you type, and near-misses get a gentle “Hmm…” with ideas.'],
  ['What can I type?', `The registry holds ${COMMANDS.length} commands and ${TOTAL_WORDS}+ resolvable words, counting synonyms — “soar” flies just like “fly”. Colors, sizes and greetings are words too.`],
  ['Can I combine words?', 'Yes — cast them one after another. Fire then rain makes steam. Wind feeds fire. Rain plus freeze turns the rain itself to snow. Moon plus fly softens gravity. Some combinations are worth discovering.'],
  ['What is Spell Studio?', 'A small workbench for chaining commands into one castable spell. Build it, name it, cast it — the world performs each step in order.'],
  ['How do I remove a single effect?', 'Tap the × on its chip in the Active Effects row above the input. “Clear all” dismisses every effect softly; “Clear world” fades the whole scene to a fresh start.'],
  ['What does Clear world keep?', 'Your discoveries, spells, history and settings are untouched — only the current scene resets, with a short fade instead of a reload.'],
  ['Where do secrets live?', 'In Surprises — hints only, never the word. Some secrets are gold. One of them is the world saying its own name.'],
  ['Which settings should I lower if it stutters?', 'Try Quality → Medium, or Frame rate → 30 on older devices. Particle density and bloom lighten the load too. Everything applies instantly — experiment freely.'],
  ['Does WORDY work on phones?', 'Yes. The layout, the bottom tab bar and every drawer are built for small screens and touch, and the world lightens itself on slower devices. Type with the keyboard, tap chips to remove effects — it all works one-handed.'],
]

function InfoDialog({ open, onOpenChange, icon, title, children }: {
  open: boolean
  onOpenChange: (v: boolean) => void
  icon: React.ReactNode
  title: string
  children: React.ReactNode
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[82vh] overflow-y-auto border-white/10 bg-[#0B1026]/95 backdrop-blur-2xl sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2.5 font-display text-lg font-bold text-white">
            <span className="flex h-8 w-8 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-violet-300">{icon}</span>
            {title}
          </DialogTitle>
          <DialogDescription className="sr-only">{title}</DialogDescription>
        </DialogHeader>
        <div className="px-1 text-sm leading-relaxed text-white/65">{children}</div>
      </DialogContent>
    </Dialog>
  )
}

export function SettingsSheet() {
  const {
    graphics, setGraphics,
    audio, setAudio,
    sphere, setSphere,
    resetAll, discovered, discoveredSecrets, discoveredCombos, spells,
  } = useWordy()
  const [open, setOpen] = useState(false)
  const [info, setInfo] = useState<'about' | 'faq' | 'privacy' | null>(null)

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <button
          aria-label="Settings"
          className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/[0.04] text-white/55 backdrop-blur-xl transition-all hover:border-violet-400/35 hover:text-white active:scale-95"
        >
          <Settings2 size={16} />
        </button>
      </SheetTrigger>
      <SheetContent className="w-full border-l border-white/10 bg-[#0B1026]/95 backdrop-blur-2xl sm:max-w-sm">
        <SheetHeader className="pb-0">
          <SheetTitle className="font-display text-xl font-bold tracking-wide text-white">Settings</SheetTitle>
          <SheetDescription className="text-xs text-white/40">
            Everything applies instantly. Nothing here changes the magic.
          </SheetDescription>
        </SheetHeader>

        <div className="flex flex-1 flex-col gap-5 overflow-y-auto px-4 pb-10 pt-2">

          {/* ---------- graphics ---------- */}
          <Row icon={<Gauge size={16} className="text-blue-300" />} title="Graphics" hint="Performance & polish">
            <div className="flex flex-col gap-3.5">
              <div>
                <p className="mb-1.5 text-[11px] uppercase tracking-widest text-white/30">Quality</p>
                <Segmented
                  options={['low', 'medium', 'high', 'ultra'] as const}
                  value={graphics.quality}
                  onChange={(q) => setGraphics({ quality: q })}
                  format={(q) => q[0].toUpperCase() + q.slice(1)}
                />
              </div>
              <div>
                <p className="mb-1.5 text-[11px] uppercase tracking-widest text-white/30">Frame rate</p>
                <Segmented
                  options={[30, 60, 120] as const}
                  value={graphics.fps}
                  onChange={(f) => setGraphics({ fps: f })}
                  format={(f) => `${f} fps`}
                />
              </div>
              <SliderRow
                label="Particle density"
                value={graphics.density}
                min={0.25} max={2} step={0.05}
                onChange={(density) => setGraphics({ density })}
                format={(v) => `${Math.round(v * 100)}%`}
              />
              <SliderRow
                label="Bloom & glow"
                value={graphics.bloom}
                min={0.4} max={1.6} step={0.05}
                onChange={(bloom) => setGraphics({ bloom })}
                format={(v) => `${Math.round(v * 100)}%`}
              />
              <div className="mt-1 divide-y divide-white/5">
                <ToggleRow
                  label="Motion effects" hint="Camera shake & zoom pulses"
                  on={graphics.motion} onToggle={() => setGraphics({ motion: !graphics.motion })}
                />
                <ToggleRow
                  label="Background animation" hint="Drifting stars & nebula"
                  on={graphics.background} onToggle={() => setGraphics({ background: !graphics.background })}
                />
              </div>
            </div>
          </Row>

          {/* ---------- audio ---------- */}
          <Row icon={audio.master > 0 ? <Volume2 size={16} className="text-violet-300" /> : <VolumeX size={16} className="text-white/30" />} title="Audio" hint="Soft, synthesized, optional">
            <div className="flex flex-col gap-3.5">
              <SliderRow
                label="Master volume"
                value={audio.master}
                min={0} max={1} step={0.05}
                onChange={(master) => setAudio({ master })}
                format={(v) => (v === 0 ? 'muted' : `${Math.round(v * 100)}%`)}
              />
              <div className="divide-y divide-white/5">
                <ToggleRow
                  label="Command sounds" hint="Whooshes, booms, shimmers"
                  on={audio.commands} onToggle={() => setAudio({ commands: !audio.commands })}
                />
                <ToggleRow
                  label="Ambient sound" hint="Rain & the deep-space drone"
                  on={audio.ambient} onToggle={() => setAudio({ ambient: !audio.ambient })}
                />
                <ToggleRow
                  label="Voice" hint="The sphere reads what it speaks"
                  on={audio.voice} onToggle={() => setAudio({ voice: !audio.voice })}
                />
              </div>
            </div>
          </Row>

          {/* ---------- sphere appearance ---------- */}
          <Row icon={<Circle size={16} className="text-fuchsia-300" />} title="Sphere appearance" hint="The core, reimagined">
            <div className="flex flex-col gap-3.5">
              <div className="grid grid-cols-5 gap-2">
                {SPHERE_STYLES.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setSphere({ style: s.id })}
                    aria-label={`${s.label} style`}
                    className={`flex flex-col items-center gap-1.5 rounded-xl border p-2 transition-all ${
                      sphere.style === s.id
                        ? 'border-violet-400/50 bg-violet-500/15 shadow-[0_0_16px_rgba(124,58,237,0.25)]'
                        : 'border-white/8 bg-white/[0.02] hover:border-white/20'
                    }`}
                  >
                    <span className={`h-7 w-7 rounded-full ${s.css}`} />
                    <span className={`text-[9px] font-medium ${sphere.style === s.id ? 'text-white' : 'text-white/40'}`}>
                      {s.label}
                    </span>
                  </button>
                ))}
              </div>
              <div>
                <p className="mb-1.5 flex items-center gap-1.5 text-[11px] uppercase tracking-widest text-white/30">
                  <Monitor size={11} /> Dimension
                </p>
                <Segmented
                  options={['3d', '2d'] as const}
                  value={sphere.dimension}
                  onChange={(d) => setSphere({ dimension: d as SphereDimension })}
                  format={(d) => (d === '3d' ? '3D — full depth' : '2D — lightweight')}
                />
              </div>
            </div>
          </Row>

          {/* ---------- stats ---------- */}
          <Row icon={<Sparkles size={16} className="text-amber-300" />} title="Your journey">
            <div className="grid grid-cols-2 gap-2 text-center">
              {[
                ['words tried', discovered.length, COMMANDS.length],
                ['secrets found', discoveredSecrets.length, secretCommands.length],
                ['combos seen', discoveredCombos.length, COMBOS.length],
                ['spells saved', spells.length, '—'],
              ].map(([label, val, max]) => (
                <div key={label as string} className="rounded-xl bg-white/[0.03] px-2 py-3">
                  <p className="font-display text-lg font-bold text-white/90">
                    {val as number}
                    {max !== '—' && <span className="text-xs font-normal text-white/30"> / {max as number}</span>}
                  </p>
                  <p className="text-[10px] uppercase tracking-widest text-white/35">{label as string}</p>
                </div>
              ))}
            </div>
          </Row>

          {/* ---------- reset ---------- */}
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <button className="flex items-center justify-center gap-2 rounded-2xl border border-rose-400/20 bg-rose-500/8 py-3 text-sm font-medium text-rose-300/90 transition-all hover:border-rose-400/40 hover:bg-rose-500/15 active:scale-[0.98]">
                <RotateCcw size={14} />
                Reset everything
              </button>
            </AlertDialogTrigger>
            <AlertDialogContent className="border-white/10 bg-[#0B1026]/95 backdrop-blur-2xl">
              <AlertDialogHeader>
                <AlertDialogTitle className="font-display text-white">Start over?</AlertDialogTitle>
                <AlertDialogDescription className="text-white/50">
                  Discoveries, spells, settings and history will fade away. The words themselves will remember nothing.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel className="border-white/15 bg-transparent text-white/70 hover:bg-white/8 hover:text-white">Keep them</AlertDialogCancel>
                <AlertDialogAction onClick={resetAll} className="bg-rose-500/80 text-white hover:bg-rose-500">
                  Let them go
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          {/* ---------- about · faq · privacy — info, not navigation ---------- */}
          <div className="flex items-center justify-center gap-2 pt-1">
            <button
              onClick={() => setInfo('about')}
              className="flex items-center gap-1.5 rounded-full border border-white/8 bg-white/[0.02] px-3 py-1.5 text-[11px] text-white/45 transition-all hover:border-violet-300/30 hover:text-white/80 active:scale-95"
            >
              <Info size={11} /> About
            </button>
            <span className="text-white/15">·</span>
            <button
              onClick={() => setInfo('faq')}
              className="flex items-center gap-1.5 rounded-full border border-white/8 bg-white/[0.02] px-3 py-1.5 text-[11px] text-white/45 transition-all hover:border-violet-300/30 hover:text-white/80 active:scale-95"
            >
              <HelpCircle size={11} /> FAQ
            </button>
            <span className="text-white/15">·</span>
            <button
              onClick={() => setInfo('privacy')}
              className="flex items-center gap-1.5 rounded-full border border-white/8 bg-white/[0.02] px-3 py-1.5 text-[11px] text-white/45 transition-all hover:border-violet-300/30 hover:text-white/80 active:scale-95"
            >
              <ShieldCheck size={11} /> Privacy
            </button>
          </div>
        </div>
      </SheetContent>

      {/* ---------- the three quiet info dialogs ---------- */}
      <InfoDialog open={info === 'about'} onOpenChange={(v) => !v && setInfo(null)} icon={<Info size={14} />} title="About WORDY">
        <p className="mb-4">
          <span className="font-display text-base font-semibold text-white/90">Type a word. Change the world.</span>
          <br />
          <span className="text-[11px] uppercase tracking-widest text-violet-200/70">
            v{WORDY_VERSION} · “{WORDY_CODENAME}”
          </span>
        </p>
        <p className="mb-4">
          WORDY is a small living universe that answers language — one glowing sphere, {COMMANDS.length} commands,
          {' '}{TOTAL_WORDS}+ words, and a sky that pays attention.
        </p>
        <p className="mb-4 text-white/50">
          Built with Next.js, React and TypeScript. The world is a hand-tuned 2D canvas engine — no game
          framework — with particles, weather and light drawn frame by frame. Sound is synthesized live with WebAudio.
        </p>
        <p className="mb-2 text-[11px] uppercase tracking-widest text-white/35">Version history</p>
        <div className="flex flex-col gap-3">
          {VERSION_HISTORY.map(([v, name, notes]) => (
            <div key={v} className="rounded-2xl border border-white/8 bg-white/[0.02] p-3.5">
              <p className="mb-1.5 font-display text-sm font-semibold text-white/85">
                {v} — {name}
                {v === WORDY_VERSION && (
                  <span className="ml-2 rounded-full border border-violet-400/30 bg-violet-500/15 px-2 py-0.5 text-[9px] font-medium uppercase tracking-wider text-violet-200">
                    current
                  </span>
                )}
              </p>
              <ul className="ml-0.5 list-none space-y-1 text-[12px] text-white/50">
                {notes.map((n) => (
                  <li key={n} className="flex gap-2"><span className="mt-1.5 h-0.5 w-0.5 shrink-0 rounded-full bg-violet-300/50" />{n}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <p className="mt-4 text-[11px] text-white/35">
          Made with canvas, WebAudio and too much affection for words. The sphere thanks you for talking to it.
        </p>
      </InfoDialog>

      <InfoDialog open={info === 'faq'} onOpenChange={(v) => !v && setInfo(null)} icon={<HelpCircle size={14} />} title="Questions, answered">
        <div className="flex flex-col gap-2.5">
          {FAQ_ITEMS.map(([q, a]) => (
            <div key={q} className="rounded-2xl border border-white/8 bg-white/[0.02] p-3.5">
              <p className="mb-1 font-display text-[13px] font-semibold text-white/85">{q}</p>
              <p className="text-[12.5px] leading-relaxed text-white/55">{a}</p>
            </div>
          ))}
        </div>
      </InfoDialog>

      <InfoDialog open={info === 'privacy'} onOpenChange={(v) => !v && setInfo(null)} icon={<ShieldCheck size={14} />} title="Privacy Policy">
        <div className="flex flex-col gap-3.5">
          <p>
            WORDY runs entirely in your browser. Every discovery, spell, history entry and setting lives in this
            device’s local storage — never on a server, because there is no server.
          </p>
          <div className="grid grid-cols-3 gap-2 text-center">
            {[
              ['No accounts', 'nothing to sign'],
              ['No analytics', 'nothing counted'],
              ['No tracking', 'nothing followed'],
            ].map(([t, s]) => (
              <div key={t} className="rounded-xl bg-white/[0.03] px-2 py-3">
                <p className="font-display text-[11px] font-semibold text-white/80">{t}</p>
                <p className="text-[10px] text-white/35">{s}</p>
              </div>
            ))}
          </div>
          <p>
            Sound is synthesized locally with WebAudio, and the optional voice uses your browser’s own speech
            synthesis. Nothing is recorded, transmitted or shared.
          </p>
          <p>
            Want it all gone? <span className="text-white/80">Reset everything</span> in Settings wipes every byte
            WORDY has stored — instantly and completely.
          </p>
        </div>
      </InfoDialog>
    </Sheet>
  )
}
