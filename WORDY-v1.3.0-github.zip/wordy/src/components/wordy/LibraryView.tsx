'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { Sparkles, ArrowUpRight, Compass } from 'lucide-react'
import { COMMANDS } from '@/lib/wordy/commands'
import type { CommandDef, Category } from '@/lib/wordy/types'
import { CATEGORY_META } from '@/lib/wordy/types'
import { useWordy } from '@/lib/wordy/store'
import { useWordyUI } from './wordy-context'
import { MiniDemo } from './MiniDemo'
import { SoftSearch } from './CommandDeck'

const CATEGORIES: Array<Category | 'all'> = ['all', 'movement', 'physics', 'elements', 'nature', 'visual', 'environment', 'objects', 'special']

const CATEGORY_TAG: Record<Category, string> = {
  movement: 'bg-cyan-500/12 text-cyan-300 border-cyan-400/20',
  physics: 'bg-violet-500/12 text-violet-300 border-violet-400/20',
  elements: 'bg-orange-500/12 text-orange-300 border-orange-400/20',
  nature: 'bg-emerald-500/12 text-emerald-300 border-emerald-400/20',
  visual: 'bg-pink-500/12 text-pink-300 border-pink-400/20',
  environment: 'bg-blue-500/12 text-blue-300 border-blue-400/20',
  objects: 'bg-amber-500/12 text-amber-300 border-amber-400/20',
  special: 'bg-fuchsia-500/12 text-fuchsia-300 border-fuchsia-400/20',
}

function CommandCard({ cmd, index }: { cmd: CommandDef; index: number }) {
  const { tryCommandByName } = useWordyUI()
  const related = (cmd.related ?? []).filter((r) => r !== cmd.name).slice(0, 3)

  return (
    <motion.article
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '40px' }}
      transition={{ duration: 0.4, delay: (index % 6) * 0.04 }}
      className={`group relative flex flex-col overflow-hidden rounded-3xl transition-transform duration-300 hover:-translate-y-1 ${
        cmd.gold ? 'glass ring-1 ring-amber-400/25' : 'glass'
      }`}
    >
      {/* live preview */}
      <div className="relative h-[86px] overflow-hidden border-b border-white/6">
        <MiniDemo kind={cmd.demo ?? 'glow'} />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#080B1A]/50 to-transparent" />
        {cmd.gold && (
          <span className="absolute right-3 top-2.5 rounded-full border border-amber-400/30 bg-amber-400/15 px-2 py-0.5 text-[9px] font-semibold uppercase tracking-[0.2em] text-amber-300">
            rare
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-2.5 p-4">
        <div className="flex items-center justify-between gap-2">
          <h3 className="font-display text-lg font-semibold tracking-wide text-white">
            {cmd.name}
          </h3>
          <span className={`rounded-full border px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider ${CATEGORY_TAG[cmd.category]}`}>
            {CATEGORY_META[cmd.category].label}
          </span>
        </div>
        <p className="flex-1 text-[13px] leading-relaxed text-white/55">{cmd.description}</p>

        {related.length > 0 && (
          <div className="flex flex-wrap items-center gap-1">
            <span className="text-[10px] uppercase tracking-widest text-white/25">also</span>
            {related.map((r) => (
              <button
                key={r}
                onClick={() => tryCommandByName(r)}
                className="rounded-full border border-white/8 bg-white/[0.04] px-2 py-0.5 text-[11px] text-white/50 transition-colors hover:border-violet-400/30 hover:text-white/90"
              >
                {r}
              </button>
            ))}
          </div>
        )}

        <button
          onClick={() => tryCommandByName(cmd.name)}
          className={`mt-1 flex items-center justify-center gap-1.5 rounded-xl border py-2 text-xs font-semibold uppercase tracking-[0.15em] transition-all active:scale-[0.97] ${
            cmd.gold
              ? 'border-amber-400/30 bg-amber-400/10 text-amber-200 hover:bg-amber-400/20 hover:shadow-[0_0_24px_rgba(251,191,36,0.25)]'
              : 'border-violet-400/25 bg-violet-500/12 text-violet-200 hover:bg-violet-500/25 hover:shadow-[0_0_24px_rgba(124,58,237,0.3)]'
          }`}
        >
          Try it
          <ArrowUpRight size={13} />
        </button>
      </div>
    </motion.article>
  )
}

export function LibraryView() {
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState<Category | 'all'>('all')
  const [limit, setLimit] = useState(24)
  const discoveredSecrets = useWordy((s) => s.discoveredSecrets)
  const sentinelRef = useRef<HTMLDivElement | null>(null)
  const { setView } = useWordyUI()

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    return COMMANDS.filter((c) => {
      if (c.hidden && !discoveredSecrets.includes(c.name)) return false
      if (category !== 'all' && c.category !== category) return false
      if (!q) return true
      return (
        c.name.includes(q) ||
        c.description.toLowerCase().includes(q) ||
        c.aliases.some((a) => a.includes(q))
      )
    })
  }, [query, category, discoveredSecrets])

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: COMMANDS.filter((c) => !c.hidden || discoveredSecrets.includes(c.name)).length }
    for (const c of COMMANDS) {
      if (c.hidden && !discoveredSecrets.includes(c.name)) continue
      map[c.category] = (map[c.category] ?? 0) + 1
    }
    return map
  }, [discoveredSecrets])

  useEffect(() => {
    const el = sentinelRef.current
    if (!el) return
    const io = new IntersectionObserver((entries) => {
      if (entries[0]?.isIntersecting) {
        setLimit((l) => (l < filtered.length ? l + 24 : l))
      }
    }, { rootMargin: '600px' })
    io.observe(el)
    return () => io.disconnect()
  }, [filtered.length])

  const visible = filtered.slice(0, limit)

  return (
    <div className="mx-auto w-full max-w-6xl px-4 pb-24 pt-4 sm:px-6">
      {/* heading */}
      <header className="mb-6 flex flex-col gap-1">
        <h1 className="font-display text-3xl font-bold tracking-wide text-white sm:text-4xl">
          The <span className="wordy-gradient-text">Library</span>
        </h1>
        <p className="text-sm text-white/45">
          {counts.all} words the world understands — and a few it keeps to itself.
        </p>
      </header>

      {/* controls */}
      <div className="sticky top-16 z-20 -mx-4 mb-6 flex flex-col gap-3 bg-[#080B1A]/72 px-4 py-3 backdrop-blur-xl sm:-mx-6 sm:px-6">
        <SoftSearch value={query} onChange={setQuery} placeholder="Search the library — try “storm”" />
        <div className="scroll-thin -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-0.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {CATEGORIES.map((c) => {
            const active = category === c
            return (
              <button
                key={c}
                onClick={() => { setCategory(c); setLimit(24) }}
                className={`shrink-0 rounded-full border px-3.5 py-1.5 text-xs font-medium transition-all active:scale-95 ${
                  active
                    ? 'border-violet-400/45 bg-violet-500/20 text-white'
                    : 'border-white/8 bg-white/[0.03] text-white/50 hover:border-white/20 hover:text-white/80'
                }`}
              >
                {c === 'all' ? 'Everything' : CATEGORY_META[c].label}
                <span className={`ml-1.5 text-[10px] ${active ? 'text-white/60' : 'text-white/25'}`}>
                  {counts[c] ?? 0}
                </span>
              </button>
            )
          })}
        </div>
      </div>

      {/* grid */}
      {visible.length > 0 ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {visible.map((cmd, i) => (
            <CommandCard key={cmd.name} cmd={cmd} index={i} />
          ))}
        </div>
      ) : (
        <div className="glass mx-auto mt-10 flex max-w-md flex-col items-center gap-4 rounded-3xl px-8 py-14 text-center">
          <Compass className="h-8 w-8 text-violet-300/60" />
          <p className="text-sm text-white/60">
            Hmm… no words match <span className="text-white/95">“{query}”</span> {category !== 'all' && <>in <span className="text-white/90">{CATEGORY_META[category as Category].label}</span></>}.
          </p>
          <p className="text-xs text-white/35">Try “fl”, “ra”, or clear the filters.</p>
          <button
            onClick={() => { setQuery(''); setCategory('all') }}
            className="rounded-full border border-violet-400/30 bg-violet-500/15 px-4 py-1.5 text-xs font-medium text-violet-200 transition-colors hover:bg-violet-500/25"
          >
            Show everything
          </button>
        </div>
      )}

      {limit < filtered.length && <div ref={sentinelRef} className="h-4" />}

      {/* footer nudge */}
      <div className="mt-10 flex flex-col items-center gap-3 text-center">
        <p className="max-w-sm text-xs leading-relaxed text-white/30">
          Words marked <span className="text-amber-300/80">rare</span> were secrets once. Some still are —
          they only appear after you discover them.
        </p>
        <button
          onClick={() => setView('surprises')}
          className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-4 py-2 text-xs text-white/70 transition-colors hover:border-fuchsia-400/30 hover:text-white"
        >
          <Sparkles size={13} className="text-fuchsia-300" />
          What’s still hidden?
        </button>
      </div>
    </div>
  )
}
