'use client'

import { useEffect } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Gamepad2, Library, Wand2, Sparkles } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { getEngine } from '@/lib/wordy/engine/engine'
import { sound } from '@/lib/wordy/audio'
import { useWordy } from '@/lib/wordy/store'
import { useWordyUI, type ViewKind } from './wordy-context'
import { WorldCanvas } from './WorldCanvas'
import { CommandDeck } from './CommandDeck'
import { EffectsPanel } from './EffectsPanel'
import { LibraryView } from './LibraryView'
import { StudioView } from './StudioView'
import { SurprisesView } from './SurprisesView'
import { SettingsSheet } from './SettingsSheet'
import { secretCommands } from '@/lib/wordy/commands'

const NAV: Array<{ id: ViewKind; label: string; icon: LucideIcon }> = [
  { id: 'playground', label: 'Playground', icon: Gamepad2 },
  { id: 'library', label: 'Library', icon: Library },
  { id: 'studio', label: 'Spell Studio', icon: Wand2 },
  { id: 'surprises', label: 'Surprises', icon: Sparkles },
]

/* custom cosmic toasts (discoveries etc.) */
function Toasts() {
  const { toasts, dismissToast } = useWordyUI()
  return (
    <div className="pointer-events-none fixed bottom-24 right-4 z-50 flex w-[calc(100vw-2rem)] max-w-xs flex-col gap-2 sm:bottom-6 sm:right-6">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.button
            key={t.id}
            layout
            initial={{ opacity: 0, x: 40, filter: 'blur(4px)' }}
            animate={{ opacity: 1, x: 0, filter: 'blur(0px)' }}
            exit={{ opacity: 0, x: 24, filter: 'blur(4px)' }}
            onClick={() => dismissToast(t.id)}
            className={`pointer-events-auto overflow-hidden rounded-2xl border p-4 text-left backdrop-blur-2xl ${
              t.gold
                ? 'border-amber-400/30 bg-[#241a08]/85 shadow-[0_8px_40px_rgba(251,191,36,0.15)]'
                : 'border-violet-400/25 bg-[#141026]/85 shadow-[0_8px_40px_rgba(124,58,237,0.2)]'
            }`}
          >
            <p className={`font-display text-sm font-semibold ${t.gold ? 'wordy-gold-gradient-text' : 'wordy-gradient-text'}`}>
              {t.title}
            </p>
            {t.body && <p className="mt-1 text-xs leading-relaxed text-white/60">{t.body}</p>}
          </motion.button>
        ))}
      </AnimatePresence>
    </div>
  )
}

function Wordmark() {
  return (
    <div className="flex select-none items-center gap-2.5">
      <span className="relative flex h-8 w-8 items-center justify-center">
        <span className="absolute inset-0 rounded-full bg-gradient-to-br from-violet-500/60 to-blue-600/40 blur-[10px]" />
        <span className="relative h-5 w-5 rounded-full bg-gradient-to-br from-violet-300 via-violet-500 to-indigo-700 shadow-[0_0_16px_rgba(139,92,246,0.8)]" />
      </span>
      <span className="font-display text-lg font-bold tracking-[0.32em] text-white">
        WORDY
      </span>
    </div>
  )
}

export function AppShell() {
  const { view, setView } = useWordyUI()
  const discoveredSecrets = useWordy((s) => s.discoveredSecrets)
  const audio = useWordy((s) => s.audio)
  const secretsLeft = secretCommands.length - discoveredSecrets.length

  /* calm the world slightly when browsing other views */
  useEffect(() => {
    const engine = getEngine()
    engine?.setAmbience(view === 'playground' ? 'active' : 'background')
  }, [view])

  /* the deep-space drone follows the view + the ambient setting */
  useEffect(() => {
    sound.setSpaceAmbience(view === 'playground' && audio.master > 0 && audio.ambient)
  }, [view, audio])

  return (
    <div className="relative min-h-dvh">
      <WorldCanvas />

      {/* top scrim for header legibility */}
      <div className="pointer-events-none fixed inset-x-0 top-0 z-10 h-28 bg-gradient-to-b from-[#080B1A]/70 to-transparent" />

      {/* header */}
      <header className="fixed inset-x-0 top-0 z-40 px-4 pt-4 sm:px-6">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-4">
          <button onClick={() => setView('playground')} aria-label="WORDY home" className="shrink-0">
            <Wordmark />
          </button>

          {/* desktop nav */}
          <nav className="glass hidden items-center gap-1 rounded-full p-1 md:flex" aria-label="Main navigation">
            {NAV.map((n) => {
              const active = view === n.id
              return (
                <button
                  key={n.id}
                  onClick={() => setView(n.id)}
                  className={`relative rounded-full px-4 py-2 text-[13px] font-medium transition-colors ${
                    active ? 'text-white' : 'text-white/50 hover:text-white/85'
                  }`}
                >
                  {active && (
                    <motion.span
                      layoutId="nav-pill"
                      transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                      className="absolute inset-0 rounded-full border border-violet-400/30 bg-violet-500/20 shadow-[0_0_20px_rgba(124,58,237,0.25)]"
                    />
                  )}
                  <span className="relative flex items-center gap-1.5">
                    <n.icon size={13} />
                    {n.label}
                    {n.id === 'surprises' && secretsLeft > 0 && (
                      <span className="ml-0.5 h-1.5 w-1.5 rounded-full bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.9)]" />
                    )}
                  </span>
                </button>
              )
            })}
          </nav>

          <div className="flex shrink-0 items-center gap-2.5">
            <SettingsSheet />
          </div>
        </div>
      </header>

      {/* mobile bottom nav */}
      <nav
        aria-label="Main navigation"
        className="glass-deep fixed inset-x-4 bottom-4 z-40 flex items-center justify-around rounded-full px-2 py-2 md:hidden"
        style={{ paddingBottom: 'calc(0.5rem + env(safe-area-inset-bottom, 0px))' }}
      >
        {NAV.map((n) => {
          const active = view === n.id
          return (
            <button
              key={n.id}
              onClick={() => setView(n.id)}
              aria-label={n.label}
              className={`relative flex min-w-16 flex-col items-center gap-1 rounded-2xl px-2 py-1.5 text-[10px] font-medium transition-colors ${
                active ? 'text-violet-200' : 'text-white/45'
              }`}
            >
              {active && (
                <motion.span
                  layoutId="nav-pill-mobile"
                  className="absolute inset-0 rounded-2xl border border-violet-400/25 bg-violet-500/15"
                  transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                />
              )}
              <n.icon size={17} className="relative" />
              <span className="relative">{n.label.replace(' Spell Studio', ' Studio').replace(' Studio', ' Studio')}</span>
              {n.id === 'surprises' && secretsLeft > 0 && (
                <span className="absolute right-2 top-0.5 h-1.5 w-1.5 rounded-full bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.9)]" />
              )}
            </button>
          )
        })}
      </nav>

      {/* views */}
      <main className="relative z-20">
        <AnimatePresence mode="wait">
          <motion.div
            key={view}
            initial={{ opacity: 0, y: 16, filter: 'blur(6px)' }}
            animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
            exit={{ opacity: 0, y: -12, filter: 'blur(6px)' }}
            transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
          >
            {view === 'playground' && (
              <div className="flex min-h-dvh flex-col items-center justify-end px-4 pb-28 pt-24 sm:pb-24 md:pb-20">
                <EffectsPanel />
                <CommandDeck />
              </div>
            )}
            {view === 'library' && (
              <div className="min-h-dvh pt-20">
                <LibraryView />
              </div>
            )}
            {view === 'studio' && (
              <div className="min-h-dvh pt-20">
                <StudioView />
              </div>
            )}
            {view === 'surprises' && (
              <div className="min-h-dvh pt-20">
                <SurprisesView />
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      <Toasts />
    </div>
  )
}
