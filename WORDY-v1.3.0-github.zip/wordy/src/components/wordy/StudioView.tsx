'use client'

import { useMemo, useState } from 'react'
import { Reorder, motion, AnimatePresence } from 'framer-motion'
import { Play, Plus, Save, Trash2, X, Wand2, ScrollText, GripVertical } from 'lucide-react'
import { COMMANDS, findCommand } from '@/lib/wordy/commands'
import type { CommandDef } from '@/lib/wordy/types'
import { CATEGORY_META } from '@/lib/wordy/types'
import { useWordy, type Spell } from '@/lib/wordy/store'
import { useWordyUI } from './wordy-context'
import { MiniDemo } from './MiniDemo'
import { SoftSearch } from './CommandDeck'

const HUE_BY_CATEGORY: Record<string, string> = {
  movement: 'from-cyan-500/25 to-cyan-500/5 border-cyan-400/25 text-cyan-200',
  physics: 'from-violet-500/25 to-violet-500/5 border-violet-400/25 text-violet-200',
  elements: 'from-orange-500/25 to-orange-500/5 border-orange-400/25 text-orange-200',
  nature: 'from-emerald-500/25 to-emerald-500/5 border-emerald-400/25 text-emerald-200',
  visual: 'from-pink-500/25 to-pink-500/5 border-pink-400/25 text-pink-200',
  environment: 'from-blue-500/25 to-blue-500/5 border-blue-400/25 text-blue-200',
  objects: 'from-amber-500/25 to-amber-500/5 border-amber-400/25 text-amber-200',
  special: 'from-fuchsia-500/25 to-fuchsia-500/5 border-fuchsia-400/25 text-fuchsia-200',
}

/** one step in the spell */
function SpellCard({ name, onRemove }: { name: string; onRemove: () => void }) {
  const cmd = findCommand(name)
  const hue = cmd ? HUE_BY_CATEGORY[cmd.category] : HUE_BY_CATEGORY.special
  return (
    <div className={`group relative flex w-36 shrink-0 flex-col overflow-hidden rounded-2xl border bg-gradient-to-br ${hue} backdrop-blur-xl`}>
      <div className="relative h-14 border-b border-white/8">
        <MiniDemo kind={cmd?.demo ?? 'glow'} />
      </div>
      <div className="flex items-center justify-between gap-1 px-3 py-2.5">
        <div className="min-w-0">
          <p className="truncate font-display text-sm font-semibold tracking-wide">{name}</p>
          <p className="text-[10px] uppercase tracking-widest text-white/35">
            {cmd ? CATEGORY_META[cmd.category].label : 'word'}
          </p>
        </div>
        <button
          onClick={onRemove}
          aria-label={`Remove ${name}`}
          className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-white/10 bg-white/[0.04] text-white/40 opacity-0 transition-all hover:border-rose-400/40 hover:text-rose-300 group-hover:opacity-100"
        >
          <X size={12} />
        </button>
      </div>
      <div className="absolute left-2 top-2 text-white/20">
        <GripVertical size={13} className="opacity-60" />
      </div>
    </div>
  )
}

function AddCommandSheet({ open, onClose, onAdd }: { open: boolean; onClose: () => void; onAdd: (name: string) => void }) {
  const [query, setQuery] = useState('')
  const results = useMemo(() => {
    const q = query.trim().toLowerCase()
    const pool = COMMANDS.filter((c) => !c.hidden)
    if (!q) return pool.slice(0, 18)
    return pool.filter((c) => c.name.includes(q) || c.aliases.some((a) => a.includes(q))).slice(0, 18)
  }, [query])

  if (!open) return null

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 12 }}
      className="glass rounded-3xl p-5"
    >
      <SoftSearch value={query} onChange={setQuery} placeholder="Find a word to add…" />
      <div className="scroll-thin mt-4 grid max-h-72 grid-cols-2 gap-2 overflow-y-auto pr-1 sm:grid-cols-3">
        {results.map((c) => (
          <button
            key={c.name}
            onClick={() => { onAdd(c.name); setQuery('') }}
            className="flex items-center justify-between gap-2 rounded-xl border border-white/8 bg-white/[0.03] px-3 py-2 text-left text-xs text-white/75 transition-all hover:border-violet-400/35 hover:bg-violet-500/15 hover:text-white active:scale-[0.97]"
          >
            <span className="truncate font-medium">{c.name}</span>
            <Plus size={12} className="shrink-0 text-white/30" />
          </button>
        ))}
        {results.length === 0 && (
          <p className="col-span-full py-6 text-center text-xs text-white/35">
            Nothing matches “{query}” — the library might know it though.
          </p>
        )}
      </div>
    </motion.div>
  )
}

export function StudioView() {
  const [steps, setSteps] = useState<string[]>([])
  const [name, setName] = useState('')
  const [adding, setAdding] = useState(false)
  const [savedFlash, setSavedFlash] = useState(false)
  const { spells, saveSpell, deleteSpell } = useWordy()
  const { castSpell, casting } = useWordyUI()

  const canCast = steps.length > 0 && !casting
  const canSave = steps.length > 0 && name.trim().length > 0

  const handleSave = () => {
    if (!canSave) return
    const spell: Spell = {
      id: `spell-${Date.now()}`,
      name: name.trim(),
      steps: [...steps],
      createdAt: Date.now(),
    }
    saveSpell(spell)
    setSavedFlash(true)
    setTimeout(() => setSavedFlash(false), 1800)
  }

  return (
    <div className="mx-auto w-full max-w-4xl px-4 pb-24 pt-4 sm:px-6">
      <header className="mb-6">
        <h1 className="font-display text-3xl font-bold tracking-wide text-white sm:text-4xl">
          Spell <span className="wordy-gradient-text">Studio</span>
        </h1>
        <p className="text-sm text-white/45">Assemble words into a little story the world will perform.</p>
      </header>

      {/* name */}
      <div className="focus-glow mb-5 flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3 backdrop-blur-xl">
        <Wand2 size={16} className="shrink-0 text-fuchsia-300" />
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Name your experiment — “Night Flight”, “Storm Dance”…"
          maxLength={42}
          className="min-w-0 flex-1 bg-transparent text-sm text-white placeholder:text-white/30 focus:outline-none"
        />
      </div>

      {/* the sequence */}
      <div className="glass mb-5 rounded-3xl p-5">
        {steps.length === 0 ? (
          <button
            onClick={() => setAdding(true)}
            className="flex w-full flex-col items-center gap-3 rounded-2xl border border-dashed border-white/12 py-12 text-center transition-colors hover:border-violet-400/35"
          >
            <span className="flex h-11 w-11 items-center justify-center rounded-full bg-violet-500/15 text-violet-300">
              <Plus size={18} />
            </span>
            <div>
              <p className="text-sm font-medium text-white/75">Begin with a word</p>
              <p className="mt-1 text-xs text-white/35">Each card plays in order — FLY → SPIN → RAINBOW → BOOM</p>
            </div>
          </button>
        ) : (
          <>
            <Reorder.Group
              axis="x"
              values={steps}
              onReorder={setSteps}
              className="scroll-thin flex gap-3 overflow-x-auto pb-2 [scrollbar-width:thin]"
            >
              {steps.map((s, i) => (
                <Reorder.Item key={`${s}-${i}`} value={s} className="cursor-grab active:cursor-grabbing">
                  <div className="relative">
                    <SpellCard name={s} onRemove={() => setSteps((st) => st.filter((_, idx) => idx !== i))} />
                    {i < steps.length - 1 && (
                      <span className="pointer-events-none absolute -right-3 top-1/2 -translate-y-1/2 font-display text-xs text-white/30">→</span>
                    )}
                  </div>
                </Reorder.Item>
              ))}
              <button
                onClick={() => setAdding(true)}
                aria-label="Add a word"
                className="flex h-[126px] w-14 shrink-0 items-center justify-center rounded-2xl border border-dashed border-white/12 text-white/30 transition-colors hover:border-violet-400/40 hover:text-violet-300"
              >
                <Plus size={18} />
              </button>
            </Reorder.Group>

            {/* sequence preview line */}
            <p className="mt-2 truncate font-display text-sm tracking-[0.2em] text-white/40">
              {steps.map((s) => s.toUpperCase()).join(' → ')}
            </p>
          </>
        )}
      </div>

      <AnimatePresence>
        {adding && (
          <div className="mb-5">
            <AddCommandSheet
              open={adding}
              onClose={() => setAdding(false)}
              onAdd={(n) => {
                setSteps((st) => [...st, n])
                setAdding(false)
              }}
            />
          </div>
        )}
      </AnimatePresence>

      {/* actions */}
      <div className="mb-10 flex flex-wrap items-center gap-3">
        <button
          onClick={() => castSpell(steps)}
          disabled={!canCast}
          className="flex items-center gap-2 rounded-full bg-gradient-to-r from-violet-500 to-blue-600 px-6 py-3 text-sm font-semibold text-white shadow-[0_0_32px_rgba(124,58,237,0.4)] transition-all hover:scale-[1.03] active:scale-95 disabled:cursor-not-allowed disabled:opacity-30 disabled:shadow-none disabled:hover:scale-100"
        >
          <Play size={15} />
          {casting ? 'Casting…' : 'Cast Spell'}
        </button>
        <button
          onClick={handleSave}
          disabled={!canSave}
          className="flex items-center gap-2 rounded-full border border-white/12 bg-white/[0.05] px-5 py-3 text-sm font-medium text-white/80 transition-all hover:border-violet-400/35 hover:text-white active:scale-95 disabled:cursor-not-allowed disabled:opacity-30"
        >
          <Save size={15} />
          {savedFlash ? 'Saved ✓' : 'Save'}
        </button>
        {steps.length > 0 && (
          <button
            onClick={() => setSteps([])}
            className="rounded-full border border-white/8 px-4 py-3 text-xs text-white/40 transition-colors hover:border-rose-400/30 hover:text-rose-300"
          >
            Clear
          </button>
        )}
      </div>

      {/* saved spells */}
      <section>
        <h2 className="mb-3 flex items-center gap-2 font-display text-lg font-semibold text-white/85">
          <ScrollText size={16} className="text-violet-300" />
          Saved experiments
        </h2>
        {spells.length === 0 ? (
          <div className="glass flex flex-col items-center gap-2 rounded-3xl px-6 py-10 text-center">
            <p className="text-sm text-white/50">Nothing saved yet.</p>
            <p className="max-w-xs text-xs text-white/30">
              Cast something you love, name it, and it will wait for you here.
            </p>
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">
            {spells.map((s) => (
              <motion.div
                key={s.id}
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="glass group flex items-center gap-3 rounded-2xl p-4"
              >
                <div className="min-w-0 flex-1">
                  <p className="truncate font-display text-sm font-semibold text-white/90">{s.name}</p>
                  <p className="mt-0.5 truncate text-xs text-white/40">{s.steps.map((x) => x.toUpperCase()).join(' → ')}</p>
                </div>
                <button
                  onClick={() => castSpell(s.steps)}
                  aria-label={`Cast ${s.name}`}
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-violet-500/15 text-violet-200 transition-all hover:bg-violet-500/30 active:scale-90"
                >
                  <Play size={14} />
                </button>
                <button
                  onClick={() => deleteSpell(s.id)}
                  aria-label={`Delete ${s.name}`}
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-white/8 text-white/30 transition-all hover:border-rose-400/35 hover:text-rose-300 active:scale-90"
                >
                  <Trash2 size={13} />
                </button>
              </motion.div>
            ))}
          </div>
        )}
      </section>
    </div>
  )
}
