'use client'

import { createContext, useCallback, useContext, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import type { Category } from '@/lib/wordy/types'
import { parse } from '@/lib/wordy/parser'
import { findCommand } from '@/lib/wordy/commands'
import { getEngine } from '@/lib/wordy/engine/engine'
import { sound } from '@/lib/wordy/audio'
import { useWordy } from '@/lib/wordy/store'
import type { Suggestion } from '@/lib/wordy/types'
import { COMBOS } from '@/lib/wordy/commands'

export type ViewKind = 'playground' | 'library' | 'studio' | 'surprises'

export interface Confirmation {
  id: number
  word: string
  category: Category | 'secret'
  gold: boolean
  secret: boolean
}

export interface GentleNotice {
  id: number
  word: string
  suggestions: Suggestion[]
}

export interface WordyToast {
  id: number
  title: string
  body?: string
  gold?: boolean
}

interface WordyUI {
  view: ViewKind
  setView: (v: ViewKind) => void
  execute: (raw: string) => boolean
  tryCommandByName: (name: string) => void
  castSpell: (steps: string[]) => void
  casting: boolean
  confirmations: Confirmation[]
  notice: GentleNotice | null
  toasts: WordyToast[]
  dismissToast: (id: number) => void
}

const Ctx = createContext<WordyUI | null>(null)

export function useWordyUI(): WordyUI {
  const c = useContext(Ctx)
  if (!c) throw new Error('useWordyUI must be used inside WordyProvider')
  return c
}

let uid = 1
const nextId = () => uid++

export function WordyProvider({ children }: { children: ReactNode }) {
  const [view, setView] = useState<ViewKind>('playground')
  const [confirmations, setConfirmations] = useState<Confirmation[]>([])
  const [notice, setNotice] = useState<GentleNotice | null>(null)
  const [toasts, setToasts] = useState<WordyToast[]>([])
  const [casting, setCasting] = useState(false)
  const castTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const {
    discoveredSecrets,
    recordCommand,
    recordCombo,
    pushHistory,
    audio,
  } = useWordy()

  const pushToast = useCallback((t: Omit<WordyToast, 'id'>) => {
    const id = nextId()
    setToasts((ts) => [...ts.slice(-3), { ...t, id }])
    setTimeout(() => setToasts((ts) => ts.filter((x) => x.id !== id)), 4200)
  }, [])

  const dismissToast = useCallback((id: number) => {
    setToasts((ts) => ts.filter((x) => x.id !== id))
  }, [])

  const showConfirmation = useCallback((word: string, category: Category, gold: boolean, secret: boolean) => {
    const id = nextId()
    setConfirmations((cs) => [...cs.slice(-2), { id, word, category, gold, secret }])
    setTimeout(() => setConfirmations((cs) => cs.filter((c) => c.id !== id)), secret ? 3200 : 2200)
  }, [])

  const handleCombo = useCallback((comboId: string) => {
    const combo = COMBOS.find((c) => c.id === comboId)
    if (!combo) return
    recordCombo(comboId)
    pushToast({ title: `Combination discovered — ${combo.name}`, body: `${combo.recipe}: ${combo.description}`, gold: true })
  }, [recordCombo, pushToast])

  const applySoundAmbience = useCallback(() => {
    const engine = getEngine()
    const w = engine?.currentWeather()
    sound.setRainAmbience(audio.master > 0 && audio.ambient && (w === 'rain' || w === 'storm'))
  }, [audio])

  const execute = useCallback((raw: string): boolean => {
    const input = raw.trim()
    if (!input) return false
    const result = parse(input, discoveredSecrets)
    const engine = getEngine()

    if (result.command) {
      const cmd = result.command
      const effect = result.text ? { ...cmd.effect, text: result.text } : cmd.effect
      engine?.apply(effect)
      const family = cmd.effect.sound
        ?? (cmd.category === 'movement' ? 'whoosh'
          : cmd.category === 'nature' ? 'magic'
            : cmd.category === 'elements' ? 'magic'
              : 'shimmer')
      if (audio.master > 0 && audio.commands) sound.play(family)
      // the sphere says it out loud, if voices are welcome
      if (result.text && audio.master > 0 && audio.voice) sound.speak(result.text)
      recordCommand(cmd.name, cmd.hidden)
      pushHistory(cmd.name)
      showConfirmation(cmd.name, cmd.category, !!cmd.gold, !!cmd.hidden)
      if (result.isSecretReveal) {
        pushToast({ title: 'Secret discovered', body: `“${cmd.name}” joined your collection.`, gold: true })
      }
      // elements that affect ambience
      applySoundAmbience()
      setNotice(null)
      return true
    }

    // unknown word — respond softly
    setNotice({ id: nextId(), word: input, suggestions: result.unknown?.suggestions ?? [] })
    setTimeout(() => {
      setNotice((n) => (n && n.word === input ? null : n))
    }, 5200)
    return false
  }, [discoveredSecrets, recordCommand, pushHistory, showConfirmation, pushToast, applySoundAmbience, audio])

  const tryCommandByName = useCallback((name: string) => {
    const cmd = findCommand(name)
    if (cmd) {
      setView('playground')
      // small delay so the view transition breathes
      setTimeout(() => execute(cmd.name), 240)
    }
  }, [execute])

  const executeWithComboWatch = useCallback((raw: string) => {
    const engine = getEngine()
    if (!engine) return execute(raw)
    const prevOnCombo = engine.onCombo
    engine.onCombo = handleCombo
    const ok = execute(raw)
    engine.onCombo = prevOnCombo ?? handleCombo
    return ok
  }, [execute, handleCombo])

  const castSpell = useCallback((steps: string[]) => {
    if (!steps.length || casting) return
    setView('playground')
    setCasting(true)
    let i = 0
    const step = () => {
      if (i >= steps.length) {
        setCasting(false)
        return
      }
      executeWithComboWatch(steps[i])
      i += 1
      castTimer.current = setTimeout(step, 1500)
    }
    castTimer.current = setTimeout(step, 420)
  }, [casting, executeWithComboWatch])

  // wire engine combo callbacks permanently once engine exists
  const engine = getEngine()
  if (engine && engine.onCombo !== handleCombo) {
    engine.onCombo = handleCombo
  }

  const value: WordyUI = {
    view,
    setView,
    execute: executeWithComboWatch,
    tryCommandByName,
    castSpell,
    casting,
    confirmations,
    notice,
    toasts,
    dismissToast,
  }

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}
