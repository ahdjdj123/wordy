# WORDY

> **Type a word. Change the world.**

WORDY is an interactive, word-controlled playground — a small living universe that answers language. Type any word — *fly*, *fire*, *rain*, *boom*, *moon* — and the world around a glowing sphere reacts instantly. Discover secrets, combine elements, and cast spells.

---

## What's inside

| Section | What it does |
| --- | --- |
| **Playground** | The living world. One input, one word, one reaction — the sphere runs, burns, freezes, speaks and explodes. |
| **Library** | Every command as a card with a **live animated preview** — search, filter by category, and "Try it" straight in the Playground. |
| **Spell Studio** | Chain commands into one castable spell. Build it, name it, cast it — the world performs each step in order. |
| **Surprises** | 14 hidden secret words (hints only, never the answer) and 16 combinations to discover. Some secrets are gold. |
| **Active Effects** | Floating chips for everything currently happening — dismiss one with ×, dismiss all softly, or fade the whole world and begin again. |
| **Settings** | Graphics, audio and sphere appearance — everything applies instantly, no reload — plus About, FAQ and Privacy. |

## Highlights

- **261 commands, 989 resolvable words** — every core word is fully choreographed; zero placeholder animations
- **Physical combinations** — `fire` + `rain` makes real steam, `rain` + `freeze` turns the rain to snow, `wind` feeds the flames, `moon` + `fly` softens gravity, `freeze` + `boom` shatters into an ice explosion
- **A living sphere** — it breathes at rest, reacts to your cursor, takes moods from your commands, and always returns home to idle
- **Voice-grade `speak`** — `speak hello world` produces waveform rings, rhythmic glow and floating quoted text, with optional browser speech synthesis
- **Hand-tuned canvas engine** — a custom 2D engine with pooled particles, weather systems, environment crossfades and choreographed sequences; no game framework
- **Synthesized audio** — every sound is generated live with WebAudio; nothing is downloaded, nothing is recorded
- **Fully local** — discoveries, spells and settings live in your browser's local storage; no accounts, no analytics, no tracking, no server

## Getting started

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) and type your first word.

> Works with npm, pnpm, yarn or bun.

## Scripts

| Command | Description |
| --- | --- |
| `npm run dev` | Start the development server |
| `npm run build` | Build for production |
| `npm start` | Start the production server |
| `npm run lint` | Run ESLint |

## Tech stack

- **Next.js 16** (App Router) + **React 19** + **TypeScript**
- **Tailwind CSS 4** + **shadcn/ui** (New York) + **Framer Motion**
- **Zustand** with local-storage persistence
- **Canvas 2D** custom world engine (particles, weather, themes, orb, sequences)
- **WebAudio** synthesized sound + Speech Synthesis

## Project structure

```
src/
├── app/                    # Next.js app — layout, page, global styles
├── components/
│   ├── ui/                 # shadcn/ui primitives in use
│   └── wordy/              # the app — shell, command deck, views, settings
└── lib/
    └── wordy/
        ├── types.ts        # declarative EffectSpec — the vocabulary of change
        ├── parser.ts       # exact + alias + phrase lookup, suggestions
        ├── commands/       # the command registry (261 entries, 0 collisions)
        ├── engine/         # world engine — orb, particles, effects, themes
        ├── audio.ts        # synthesized WebAudio
        └── store.ts        # zustand + persistence + safe migrations
```

**Adding a word never touches the engine or the UI** — one registry entry with a declarative effect spec is enough.

## How it works

1. You type a word. The **parser** resolves it exactly, through an alias, or as a phrase — and offers scored suggestions for near-misses.
2. The **registry** maps the word to an `EffectSpec` — a declarative bundle of motion, elements, weather, environment, glow, trails and choreographed actions.
3. The **engine** applies the spec to the world: the sphere becomes an actor, the weather changes, the environment crossfades, sequences fire on timers.
4. The engine **reconciles** elements physically every frame — fire meeting rain dies into steam, ice meeting fire thaws into mist — and combinations are discovered, not scripted.

## Version history

- **1.3.0 — Final Polish** · release pass over every screen, mobile and touch refinement, About / FAQ / Privacy finished
- **1.2.0 — Living Sphere** · the sphere never sleeps; physical combinations; every core command re-choreographed
- **1.1.0 — The Actor** · the sphere runs, walks, speaks and booms; Clear World, Settings drawer, Active Effects
- **1.0.0 — First Light** · one word, one world

---

Made with canvas, WebAudio and too much affection for words.
