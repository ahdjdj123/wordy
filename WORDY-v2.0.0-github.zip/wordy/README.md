# WORDY

> **Type a word. Change the world.**

WORDY is an interactive learning universe that answers language. Type any word — *volcano*, *butterfly*, *gravity*, *photosynthesis* — and a living concept world builds itself around it: erupting mountains, four-stage life cycles, spinning solar systems. Then explore it, experiment with it, challenge yourself, and remember what you learned.

The classic playground lives on inside every world — *fly*, *fire*, *rain*, *boom* still answer, and the world reacts to them.

---

## What's inside

| Section | What it does |
| --- | --- |
| **Playground** | The living world. Type a word — a concept world opens with four learning modes, or a classic command answers instantly. |
| **Explore** | Tap the world itself: hotspots reveal facts, contextual buttons trigger eruptions, stage changes, breaches and roars. |
| **Experiment** | Turn real dials — chamber pressure, sunlight, star mass, wind shear — and watch cause and effect, live. |
| **Challenge** | Three knowledge checks per world. Get all three right and the world is mastered. |
| **Remember** | A quick recall game, the facts for keeps, and a save button — worlds go to your Library with their dials. |
| **Library** | All 34 concept worlds with learning progress, plus your saved worlds, your creations, and every one of the 261 classic commands as a card with a live animated preview. |
| **Spell Studio** | The **Word Blender** — combine two worlds into a creative interpretation (some pairs have secret names) — plus the classic spell sequencer. |
| **Surprises** | Today's discovery, a random-world shuffle, a daily learning challenge, 14 hidden secret words and 16 combinations. |
| **Settings** | Graphics, audio and sphere appearance — everything applies instantly — plus About, FAQ and Privacy. |

## Highlights

- **34 concept worlds across 8 learning categories** — objects, living things, natural phenomena, science, processes, big ideas, emotions and history
- **Category-aware visualisation** — a volcano erupts, a butterfly metamorphoses through four stages, planets orbit a Kepler-scaled sun, a plant photosynthesizes with visible CO₂ / O₂ / sugar flows
- **261 classic commands, 989 resolvable words** — every core word fully choreographed, zero placeholder animations
- **Contextual controls** — fire inside the volcano world feeds the chamber's pressure; rain cools it; the sphere steps aside as a small guide while a world is open
- **Physical combinations** — `fire` + `rain` makes real steam, `rain` + `freeze` turns the rain to snow, `moon` + `fly` softens gravity, `freeze` + `boom` shatters into ice
- **Learning progress** — visited, explored, experimented, challenged, remembered; mastered worlds earn a gold badge; everything persists locally
- **Honest labelling** — curated worlds teach textbook-safe facts; Word Blender creations are always labelled *creative interpretations*, never lessons
- **Hand-tuned canvas engine** — a custom 2D engine with pooled particles, weather, environment crossfades and a scene system for concept worlds; no game framework
- **Synthesized audio** — every sound generated live with WebAudio; nothing downloaded, nothing recorded
- **Fully local** — progress, worlds, creations, spells and settings live in your browser's local storage; no accounts, no analytics, no tracking, no server

## Getting started

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) and type your first word.

> Works with npm, pnpm, yarn or bun.

## Scripts

| Command | Description |
| --- | --- |
| `npm run dev` | Start the development server |
| `npm run build` | Build for production |
| `npm start` | Start the production server |
| `npm run lint` | Run ESLint |

## Tech stack

- **Next.js 16** (App Router) + **React 19** + **TypeScript**
- **Tailwind CSS 4** + **shadcn/ui** (New York) + **Framer Motion**
- **Zustand** with local-storage persistence and safe migrations
- **Canvas 2D** custom world engine (particles, weather, themes, orb, scenes, sequences)
- **WebAudio** synthesized sound + Speech Synthesis

## Project structure

```
src/
├── app/                    # Next.js app — layout, page, global styles
├── components/
│   ├── ui/                 # shadcn/ui primitives in use
│   └── wordy/              # the app — shell, hero, world stage, views, settings
└── lib/
    └── wordy/
        ├── types.ts        # declarative EffectSpec — the vocabulary of change
        ├── parser.ts       # word → command or concept world, with suggestions
        ├── commands/       # the classic command registry (261 entries)
        ├── knowledge/      # v2.0 — the 34 concept worlds: facts, quizzes,
        │                   #   experiments, actions, blend rules
        ├── engine/         # world engine — orb, particles, effects, themes,
        │   └── scenes/     #   and the category-aware scene renderers
        ├── audio.ts        # synthesized WebAudio
        └── store.ts        # zustand + persistence + safe migrations
```

**Adding a classic word never touches the engine or the UI** — one registry entry with a declarative effect spec is enough. **Adding a concept world** is one entry in `knowledge/` — facts, quiz, dials and actions — the scene templates do the rest.

## How it works

1. You type a word. The **parser** resolves it to a concept world (for the 34 curated words and their aliases) or to a classic command — with scored suggestions for near-misses.
2. A concept world enters through the **knowledge registry**: its entry spec preserves any classic behaviour, its scene template takes the stage, and the sphere becomes a small guide in the corner.
3. Classic commands still flow through the **command registry** into the engine — and scenes read the live element/weather state every frame, so *fire* genuinely feeds a volcano's pressure.
4. The engine **reconciles** elements physically every frame — fire meeting rain dies into steam, ice meeting fire thaws into mist — and combinations are discovered, not scripted.

## Version history

- **2.0.0 — The Learning Universe** · 34 concept worlds, four learning modes, the Word Blender, daily discoveries, learning progress and saved worlds
- **1.3.0 — Final Polish** · release pass over every screen, mobile and touch refinement, About / FAQ / Privacy finished
- **1.2.0 — Living Sphere** · the sphere never sleeps; physical combinations; every core command re-choreographed
- **1.1.0 — The Actor** · the sphere runs, walks, speaks and booms; Clear World, Settings drawer, Active Effects
- **1.0.0 — First Light** · one word, one world

---

Made with canvas, WebAudio and too much affection for words.
