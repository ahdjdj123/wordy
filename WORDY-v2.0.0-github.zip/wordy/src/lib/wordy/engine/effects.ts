import type { ParticleSystem } from './particles'

/* ==========================================================================
   WORDY effects — transient spectacles.
   Shockwaves, lightning, portals, black holes, fireworks, visitors.
   ========================================================================== */

export interface Shockwave { x: number; y: number; r: number; maxR: number; width: number; hue: number; sat: number; light: number; alpha: number; flat: boolean }
export interface RippleFX { x: number; y: number; r: number; maxR: number; alpha: number }
export interface BoltFX { pts: Array<{ x: number; y: number }>; life: number; maxLife: number; hue: number }
export interface PortalFX { x: number; y: number; open: number; rot: number; hue: number; closing: boolean }
export interface BlackHoleFX { x: number; y: number; life: number; maxLife: number; strength: number }
export interface MeteorFX { x: number; y: number; vx: number; vy: number; life: number; hue: number; size: number }
export interface Orbiter { ang: number; dist: number; size: number; hue: number; sat: number; light: number; kind: 'rock' | 'satellite' | 'moon'; vang: number }
export interface UfoFX { x: number; y: number; vx: number; phase: number; life: number }
export interface FloatText { text: string; x: number; y: number; life: number; maxLife: number; hue: number; size: number }
export interface FireworkShell { x: number; y: number; targetY: number; hue: number; life: number }
export interface TreeFX { x: number; groundY: number; life: number; maxLife: number; seed: number; hue: number; scale: number }
export interface BirdFX { x: number; y: number; vx: number; flap: number; flapSp: number; size: number; bobSeed: number; hue: number }

function rnd(a: number, b: number) {
  return a + Math.random() * (b - a)
}

function roundRectPath(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rr = Math.min(r, w / 2, h / 2)
  ctx.beginPath()
  ctx.moveTo(x + rr, y)
  ctx.arcTo(x + w, y, x + w, y + h, rr)
  ctx.arcTo(x + w, y + h, x, y + h, rr)
  ctx.arcTo(x, y + h, x, y, rr)
  ctx.arcTo(x, y, x + w, y, rr)
  ctx.closePath()
}

export class EffectsSystem {
  shockwaves: Shockwave[] = []
  ripples: RippleFX[] = []
  bolts: BoltFX[] = []
  portals: PortalFX[] = []
  blackholes: BlackHoleFX[] = []
  meteors: MeteorFX[] = []
  orbiters: Orbiter[] = []
  ufos: UfoFX[] = []
  texts: FloatText[] = []
  shells: FireworkShell[] = []
  trees: TreeFX[] = []
  birds: BirdFX[] = []
  flashA = 0
  flashHue = 220
  flashSat = 30
  invertA = 0
  shake = 0
  zoom = 1
  private zoomTarget = 1
  private w = 0
  private h = 0
  private t = 0
  private boltTimer = 0

  resize(w: number, h: number) {
    this.w = w
    this.h = h
  }

  addShockwave(x: number, y: number, maxR = 260, hue = 265, light = 72, width = 5, flat = false, sat = 90) {
    this.shockwaves.push({ x, y, r: 0, maxR, width, hue, sat, light, alpha: 1, flat })
  }

  addRipple(x: number, y: number, maxR = 180) {
    this.ripples.push({ x, y, r: 0, maxR, alpha: 1 })
  }

  addBolt(targetX?: number, targetY?: number, hue = 250) {
    const tx = targetX ?? rnd(this.w * 0.15, this.w * 0.85)
    const ty = targetY ?? rnd(this.h * 0.3, this.h * 0.75)
    const pts: Array<{ x: number; y: number }> = []
    let x = tx + rnd(-60, 60)
    let y = -10
    const steps = 7
    for (let i = 0; i <= steps; i++) {
      const p = i / steps
      pts.push({ x: x + (tx - x) * p + (i > 0 && i < steps ? rnd(-34, 34) : 0), y: -10 + (ty + 10) * p })
    }
    this.bolts.push({ pts, life: 0, maxLife: 0.5, hue })
    // v1.2 — a small fork branches off the main stroke
    const forkAt = 2 + Math.floor(rnd(0, 3))
    if (pts[forkAt]) {
      const fork: Array<{ x: number; y: number }> = [pts[forkAt]]
      let fx = pts[forkAt].x
      let fy = pts[forkAt].y
      const dir = Math.random() < 0.5 ? -1 : 1
      for (let i = 0; i < 3; i++) {
        fx += dir * rnd(18, 52)
        fy += rnd(14, 44)
        fork.push({ x: fx, y: fy })
      }
      this.bolts.push({ pts: fork, life: 0, maxLife: 0.34, hue: hue + 18 })
    }
    this.flashA = Math.max(this.flashA, 0.32)
    this.shake = Math.max(this.shake, 8)
  }

  addPortal(x: number, y: number, hue = 265) {
    this.portals.push({ x, y, open: 0, rot: 0, hue, closing: false })
    // energy gathering particles
  }

  addBlackhole(x: number, y: number, life = 6) {
    this.blackholes.push({ x, y, life: 0, maxLife: life, strength: 0 })
    this.shake = Math.max(this.shake, 6)
  }

  addMeteor() {
    const fromLeft = Math.random() < 0.5
    this.meteors.push({
      x: fromLeft ? -30 : this.w + 30,
      y: rnd(this.h * 0.05, this.h * 0.35),
      vx: (fromLeft ? 1 : -1) * rnd(280, 520),
      vy: rnd(60, 160),
      life: 0,
      hue: rnd(190, 280),
      size: rnd(2.4, 4.6),
    })
  }

  addOrbiters(n: number, kind: 'rock' | 'satellite' | 'moon' = 'rock') {
    for (let i = 0; i < n; i++) {
      this.orbiters.push({
        ang: (i / n) * Math.PI * 2 + rnd(0, 1),
        dist: rnd(80, 150),
        size: kind === 'satellite' ? 7 : rnd(4, 9),
        hue: kind === 'satellite' ? 210 : 28,
        sat: kind === 'satellite' ? 12 : 22,
        light: kind === 'satellite' ? 82 : 48,
        kind,
        vang: rnd(1.1, 2) * (Math.random() < 0.5 ? -1 : 1),
      })
    }
  }

  clearOrbiters() {
    this.orbiters.length = 0
  }

  addUfo() {
    this.ufos.push({ x: -80, y: this.h * rnd(0.12, 0.3), vx: rnd(110, 170), phase: 0, life: 0 })
  }

  addText(text: string, x: number, y: number, hue = 260, size = 26, life = 2.4) {
    this.texts.push({ text, x, y, life: 0, maxLife: life, hue, size })
  }

  /** a tree grows, steady and slow, then gently fades */
  addTree(x: number, groundY: number) {
    // keep at most 4 trees — the oldest fades out
    if (this.trees.length >= 4) this.trees.shift()
    this.trees.push({
      x, groundY,
      life: 0, maxLife: 11,
      seed: rnd(0, 10),
      hue: rnd(96, 140),
      scale: rnd(0.85, 1.25),
    })
  }

  /** a small flock sweeps across the sky */
  addFlock(n = 6) {
    const fromLeft = Math.random() < 0.5
    const baseY = rnd(this.h * 0.14, this.h * 0.38)
    const dir = fromLeft ? 1 : -1
    for (let i = 0; i < n; i++) {
      this.birds.push({
        x: fromLeft ? -50 - i * rnd(28, 48) : this.w + 50 + i * rnd(28, 48),
        y: baseY + (i % 2 ? 1 : -1) * (i * rnd(7, 16)),
        vx: dir * rnd(115, 168),
        flap: rnd(0, Math.PI * 2),
        flapSp: rnd(7.5, 10.5),
        size: rnd(5, 8.5),
        bobSeed: rnd(0, 10),
        hue: 222 + rnd(-16, 34),
      })
    }
  }

  /** clear all transient spectacles — used by clearWorld */
  reset() {
    this.shockwaves.length = 0
    this.ripples.length = 0
    this.bolts.length = 0
    this.portals.length = 0
    this.blackholes.length = 0
    this.meteors.length = 0
    this.orbiters.length = 0
    this.ufos.length = 0
    this.texts.length = 0
    this.shells.length = 0
    this.trees.length = 0
    this.birds.length = 0
    this.flashA = 0
    this.invertA = 0
    this.shake = 0
    this.zoom = 1
    this.zoomTarget = 1
  }

  fireworkShow(n = 6) {
    for (let i = 0; i < n; i++) {
      this.shells.push({
        x: rnd(this.w * 0.15, this.w * 0.85),
        y: this.h + 10,
        targetY: rnd(this.h * 0.12, this.h * 0.45),
        hue: [265, 200, 330, 45, 150][Math.floor(Math.random() * 5)],
        life: i * rnd(0.35, 0.6),
      })
    }
  }

  flash(strength = 0.65, hue = 220, sat = 30) {
    this.flashA = Math.max(this.flashA, strength)
    this.flashHue = hue
    this.flashSat = sat
  }

  kick(shake = 10) {
    this.shake = Math.max(this.shake, shake)
  }

  pulse(zoom = 1.14) {
    this.zoomTarget = zoom
  }

  update(dt: number, ps: ParticleSystem) {
    this.t += dt

    // decay global fx
    this.flashA = Math.max(0, this.flashA - dt * 1.6)
    this.invertA = Math.max(0, this.invertA - dt * 1.2)
    this.shake = Math.max(0, this.shake - dt * 22)
    this.zoom += (this.zoomTarget - this.zoom) * Math.min(1, dt * 7)
    if (Math.abs(this.zoom - this.zoomTarget) < 0.004) this.zoomTarget = 1

    // shockwaves
    for (let i = this.shockwaves.length - 1; i >= 0; i--) {
      const s = this.shockwaves[i]
      s.r += (s.maxR - s.r) * Math.min(1, dt * 4.2) + dt * 40
      s.alpha -= dt * 1.25
      if (s.alpha <= 0) this.shockwaves.splice(i, 1)
    }

    // ripples
    for (let i = this.ripples.length - 1; i >= 0; i--) {
      const r = this.ripples[i]
      r.r += (r.maxR - r.r) * Math.min(1, dt * 3.4) + dt * 26
      r.alpha -= dt * 0.9
      if (r.alpha <= 0) this.ripples.splice(i, 1)
    }

    // bolts
    for (let i = this.bolts.length - 1; i >= 0; i--) {
      const b = this.bolts[i]
      b.life += dt
      if (b.life >= b.maxLife) this.bolts.splice(i, 1)
    }

    // portals
    for (let i = this.portals.length - 1; i >= 0; i--) {
      const p = this.portals[i]
      p.rot += dt * 2.4
      if (p.closing) {
        p.open -= dt * 1.8
        if (p.open <= 0) {
          this.portals.splice(i, 1)
          continue
        }
      } else {
        p.open = Math.min(1, p.open + dt * 1.5)
        // suck particles in
        if (Math.random() < 0.5) {
          const a = Math.random() * Math.PI * 2
          const d = rnd(80, 170)
          ps.spawn('spark', {
            x: p.x + Math.cos(a) * d, y: p.y + Math.sin(a) * d,
            vx: -Math.cos(a) * d * 1.8, vy: -Math.sin(a) * d * 1.8,
            maxLife: 0.55, size: rnd(1.5, 3.4), hue: p.hue + rnd(-24, 24), light: 72,
          })
        }
      }
    }

    // black holes
    for (let i = this.blackholes.length - 1; i >= 0; i--) {
      const b = this.blackholes[i]
      b.life += dt
      b.strength = Math.min(1, b.strength + dt * 1.2)
      if (b.life > b.maxLife) b.strength -= dt * 1.6
      if (b.strength <= 0 && b.life > b.maxLife) {
        this.blackholes.splice(i, 1)
        continue
      }
      if (Math.random() < 0.7) {
        const a = Math.random() * Math.PI * 2
        const d = rnd(110, 240)
        ps.spawn('spark', {
          x: b.x + Math.cos(a) * d, y: b.y + Math.sin(a) * d * 0.8,
          vx: -Math.cos(a + 0.9) * d * 1.4, vy: -Math.sin(a + 0.9) * d * 1.1,
          maxLife: 0.6, size: rnd(1.4, 3), hue: 262, light: 66,
        })
      }
    }

    // meteors
    for (let i = this.meteors.length - 1; i >= 0; i--) {
      const m = this.meteors[i]
      m.life += dt
      m.x += m.vx * dt
      m.y += m.vy * dt
      if (Math.random() < 0.8) {
        ps.spawn('spark', {
          x: m.x, y: m.y, vx: rnd(-16, 16) - m.vx * 0.06, vy: rnd(-16, 16) - m.vy * 0.06,
          maxLife: rnd(0.3, 0.7), size: rnd(1.2, 2.6), hue: m.hue, light: 84,
        })
      }
      if (m.x < -60 || m.x > this.w + 60 || m.y > this.h + 60) this.meteors.splice(i, 1)
    }

    // orbiters
    for (const o of this.orbiters) {
      o.ang += o.vang * dt
      o.dist = Math.max(56, o.dist - dt * 2)
    }

    // ufos
    for (let i = this.ufos.length - 1; i >= 0; i--) {
      const u = this.ufos[i]
      u.life += dt
      u.phase += dt * 3
      u.x += u.vx * dt
      u.y += Math.sin(u.phase * 0.8) * 16 * dt
      if (Math.random() < 0.4) {
        ps.spawn('spark', {
          x: u.x + rnd(-6, 6), y: u.y + 8, vx: rnd(-6, 6), vy: rnd(30, 80),
          maxLife: rnd(0.4, 0.8), size: rnd(1.4, 2.6), hue: 140, light: 70,
        })
      }
      if (u.x > this.w + 120) this.ufos.splice(i, 1)
    }

    // texts
    for (let i = this.texts.length - 1; i >= 0; i--) {
      const tx = this.texts[i]
      tx.life += dt
      tx.y -= dt * (tx.maxLife > 3 ? 14 : 26)   // speech drifts slower
      if (tx.life >= tx.maxLife) this.texts.splice(i, 1)
    }

    // trees
    for (let i = this.trees.length - 1; i >= 0; i--) {
      const tr = this.trees[i]
      tr.life += dt
      if (tr.life > tr.maxLife) this.trees.splice(i, 1)
    }

    // birds
    for (let i = this.birds.length - 1; i >= 0; i--) {
      const b = this.birds[i]
      b.x += b.vx * dt
      b.flap += dt * b.flapSp
      b.y += Math.sin(this.t * 1.7 + b.bobSeed) * 14 * dt
      if (b.x < -90 || b.x > this.w + 90) this.birds.splice(i, 1)
    }

    // firework shells
    for (let i = this.shells.length - 1; i >= 0; i--) {
      const s = this.shells[i]
      s.life -= dt
      if (s.life <= 0) {
        const p = s.y - s.targetY
        s.y = Math.min(s.y, s.targetY)
        if (s.y < s.targetY) s.y = s.targetY
        if (s.y >= s.targetY || p >= 0) {
          // boom
          for (let j = 0; j < 34; j++) {
            const a = Math.random() * Math.PI * 2
            const sp = rnd(60, 240)
            ps.spawn('spark', {
              x: s.x, y: s.targetY, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp,
              maxLife: rnd(0.8, 1.7), size: rnd(1.6, 3.6),
              hue: s.hue + rnd(-18, 18), light: 72, gf: 0.32, wf: 0.6,
            })
          }
          this.shells.splice(i, 1)
          continue
        }
      }
      // rising trail
      ps.spawn('spark', {
        x: s.x + rnd(-3, 3), y: s.y, vx: 0, vy: -260,
        maxLife: 0.4, size: rnd(1, 2.4), hue: 40, light: 80,
      })
      s.y -= 260 * dt
    }

    // ambient storm bolts (when weather storm is active the engine calls addBolt via timer)
  }

  stormTick(dt: number, stormActive: boolean, boosted = false) {
    if (!stormActive) return
    this.boltTimer -= dt
    if (this.boltTimer <= 0) {
      // a charged storm answers twice as often
      this.boltTimer = boosted ? rnd(0.5, 1.4) : rnd(1.6, 4.2)
      this.addBolt()
    }
  }

  draw(ctx: CanvasRenderingContext2D) {
    // portals
    for (const p of this.portals) {
      const R = 54 * p.open
      if (R < 1) continue
      ctx.save()
      ctx.translate(p.x, p.y)
      ctx.rotate(p.rot)
      ctx.globalCompositeOperation = 'lighter'
      for (let ring = 0; ring < 3; ring++) {
        const rr = R * (1 - ring * 0.22)
        const g = ctx.createRadialGradient(0, 0, rr * 0.5, 0, 0, rr)
        g.addColorStop(0, `hsla(${p.hue + ring * 18},90%,66%,0)`)
        g.addColorStop(0.72, `hsla(${p.hue + ring * 18},90%,66%,${0.34 * p.open})`)
        g.addColorStop(1, `hsla(${p.hue + ring * 18},90%,66%,0)`)
        ctx.strokeStyle = g
        ctx.lineWidth = 2.4
        ctx.setLineDash([rr * 0.4, rr * 0.26])
        ctx.lineDashOffset = -this.t * 60 * (ring % 2 === 0 ? 1 : -1)
        ctx.beginPath()
        ctx.ellipse(0, 0, rr, rr * (0.42 + ring * 0.12), 0, 0, Math.PI * 2)
        ctx.stroke()
      }
      // core
      const g2 = ctx.createRadialGradient(0, 0, 0, 0, 0, R * 0.5)
      g2.addColorStop(0, `hsla(${p.hue},95%,80%,${0.5 * p.open})`)
      g2.addColorStop(0.5, `hsla(${p.hue + 30},90%,60%,${0.28 * p.open})`)
      g2.addColorStop(1, 'rgba(0,0,0,0)')
      ctx.fillStyle = g2
      ctx.beginPath()
      ctx.ellipse(0, 0, R * 0.5, R * 0.24, 0, 0, Math.PI * 2)
      ctx.fill()
      ctx.restore()
    }
    ctx.setLineDash([])

    // black holes
    for (const b of this.blackholes) {
      const s = b.strength
      ctx.save()
      ctx.translate(b.x, b.y)
      ctx.rotate(this.t * 0.7)
      ctx.globalCompositeOperation = 'source-over'
      const g = ctx.createRadialGradient(0, 0, 0, 0, 0, 64 * s)
      g.addColorStop(0, `rgba(2,2,8,${0.98 * s})`)
      g.addColorStop(0.55, `rgba(12,6,28,${0.9 * s})`)
      g.addColorStop(0.75, `rgba(76,29,149,${0.4 * s})`)
      g.addColorStop(1, 'rgba(76,29,149,0)')
      ctx.fillStyle = g
      ctx.beginPath()
      ctx.arc(0, 0, 64 * s, 0, Math.PI * 2)
      ctx.fill()
      ctx.globalCompositeOperation = 'lighter'
      ctx.strokeStyle = `rgba(167,139,250,${0.5 * s})`
      ctx.lineWidth = 1.6
      for (let i = 0; i < 3; i++) {
        ctx.beginPath()
        ctx.ellipse(0, 0, (46 + i * 12) * s, (14 + i * 5) * s, i * 1.1, 0, Math.PI * 2)
        ctx.stroke()
      }
      ctx.restore()
    }

    // meteors
    ctx.save()
    ctx.globalCompositeOperation = 'lighter'
    for (const m of this.meteors) {
      const g = ctx.createLinearGradient(m.x - m.vx * 0.14, m.y - m.vy * 0.14, m.x, m.y)
      g.addColorStop(0, `hsla(${m.hue},90%,80%,0)`)
      g.addColorStop(1, `hsla(${m.hue},90%,86%,0.9)`)
      ctx.strokeStyle = g
      ctx.lineWidth = m.size
      ctx.lineCap = 'round'
      ctx.beginPath()
      ctx.moveTo(m.x - m.vx * 0.14, m.y - m.vy * 0.14)
      ctx.lineTo(m.x, m.y)
      ctx.stroke()
    }
    ctx.restore()

    // ufos
    for (const u of this.ufos) {
      ctx.save()
      ctx.translate(u.x, u.y)
      // beam
      const bg = ctx.createLinearGradient(0, 10, 0, 120)
      bg.addColorStop(0, 'rgba(103,232,249,0.22)')
      bg.addColorStop(1, 'rgba(103,232,249,0)')
      ctx.fillStyle = bg
      ctx.beginPath()
      ctx.moveTo(-7, 10)
      ctx.lineTo(7, 10)
      ctx.lineTo(38, 120)
      ctx.lineTo(-38, 120)
      ctx.closePath()
      ctx.fill()
      // body
      ctx.fillStyle = '#1f2937'
      ctx.beginPath()
      ctx.ellipse(0, 6, 30, 9, 0, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = '#e2e8f0'
      ctx.beginPath()
      ctx.ellipse(0, 2, 13, 10, 0, Math.PI, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = `rgba(103,232,249,${0.6 + Math.sin(u.phase) * 0.4})`
      ctx.beginPath()
      ctx.arc(-16, 8, 2.4, 0, Math.PI * 2)
      ctx.arc(0, 9, 2.4, 0, Math.PI * 2)
      ctx.arc(16, 8, 2.4, 0, Math.PI * 2)
      ctx.fill()
      ctx.restore()
    }

    // orbiters are drawn by the engine (need orb position)

    // bolts
    for (const b of this.bolts) {
      const k = 1 - b.life / b.maxLife
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      ctx.lineCap = 'round'
      ctx.strokeStyle = `hsla(${b.hue},90%,72%,${0.28 * k})`
      ctx.lineWidth = 9
      ctx.beginPath()
      ctx.moveTo(b.pts[0].x, b.pts[0].y)
      for (const p of b.pts) ctx.lineTo(p.x, p.y)
      ctx.stroke()
      ctx.strokeStyle = `hsla(${b.hue},95%,86%,${0.9 * k})`
      ctx.lineWidth = 2.2
      ctx.stroke()
      ctx.restore()
    }

    // shockwaves
    for (const s of this.shockwaves) {
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      const g = ctx.createRadialGradient(s.x, s.y, Math.max(0, s.r - s.width * 3), s.x, s.y, s.r)
      g.addColorStop(0, `hsla(${s.hue},${s.sat}%,${s.light}%,0)`)
      g.addColorStop(0.82, `hsla(${s.hue},${s.sat}%,${s.light}%,${0.4 * s.alpha})`)
      g.addColorStop(1, `hsla(${s.hue},${s.sat}%,${s.light}%,0)`)
      ctx.strokeStyle = g
      ctx.lineWidth = s.width
      ctx.beginPath()
      if (s.flat) ctx.ellipse(s.x, s.y, s.r, s.r * 0.32, 0, 0, Math.PI * 2)
      else ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2)
      ctx.stroke()
      ctx.restore()
    }

    // ripples
    for (const r of this.ripples) {
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      ctx.strokeStyle = `rgba(103,232,249,${0.32 * r.alpha})`
      ctx.lineWidth = 1.6
      ctx.beginPath()
      ctx.ellipse(r.x, r.y, r.r, r.r * 0.36, 0, 0, Math.PI * 2)
      ctx.stroke()
      ctx.strokeStyle = `rgba(147,197,253,${0.18 * r.alpha})`
      ctx.beginPath()
      ctx.ellipse(r.x, r.y, r.r * 0.7, r.r * 0.25, 0, 0, Math.PI * 2)
      ctx.stroke()
      ctx.restore()
    }

    // floating texts — a gentle fade-in, a slow rise, an unhurried exit
    for (const tx of this.texts) {
      const k = 1 - tx.life / tx.maxLife
      const fadeIn = Math.min(1, tx.life / 0.3)
      const fadeOut = k > 0.75 ? (1 - k) / 0.25 : 1
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      ctx.font = `600 ${tx.size}px "Space Grotesk", sans-serif`
      ctx.textAlign = 'center'
      // a quiet glassy backdrop makes speech readable over any world
      if (tx.maxLife > 3) {
        const tw = ctx.measureText(tx.text).width
        ctx.globalCompositeOperation = 'source-over'
        ctx.fillStyle = `rgba(11,16,38,${0.42 * fadeIn * fadeOut})`
        roundRectPath(ctx, tx.x - tw / 2 - 12, tx.y - tx.size * 0.85, tw + 24, tx.size * 1.5, 999)
        ctx.fill()
        ctx.globalCompositeOperation = 'lighter'
      }
      ctx.fillStyle = `hsla(${tx.hue},90%,84%,${0.9 * k * fadeIn * fadeOut})`
      ctx.shadowColor = `hsla(${tx.hue},90%,70%,${0.8 * k * fadeIn})`
      ctx.shadowBlur = 18
      ctx.fillText(tx.text, tx.x, tx.y)
      ctx.restore()
    }

    // trees — procedural growth
    for (const tr of this.trees) {
      const k = Math.min(1, tr.life / 2.6)
      const fade = tr.life > tr.maxLife - 1.6 ? Math.max(0, (tr.maxLife - tr.life) / 1.6) : 1
      const trunkH = this.h * 0.17 * k * tr.scale
      if (trunkH < 2) continue
      ctx.save()
      ctx.globalAlpha = fade
      ctx.strokeStyle = 'hsla(25,42%,30%,0.95)'
      ctx.lineWidth = Math.max(2, 6.5 * k * tr.scale)
      ctx.lineCap = 'round'
      ctx.beginPath()
      ctx.moveTo(tr.x, tr.groundY)
      ctx.quadraticCurveTo(tr.x + Math.sin(tr.seed) * 7, tr.groundY - trunkH * 0.55, tr.x, tr.groundY - trunkH)
      ctx.stroke()
      if (k > 0.35) {
        const bk = (k - 0.35) / 0.65
        for (let b = 0; b < 5; b++) {
          const a = -Math.PI / 2 + (b - 2) * 0.46 + Math.sin(tr.seed + b) * 0.12
          const bl = (30 + ((b * 37) % 18)) * bk * tr.scale
          ctx.strokeStyle = 'hsla(28,36%,36%,0.9)'
          ctx.lineWidth = Math.max(1.4, 2.4 * bk * tr.scale)
          ctx.beginPath()
          ctx.moveTo(tr.x, tr.groundY - trunkH * 0.86)
          ctx.lineTo(tr.x + Math.cos(a) * bl, tr.groundY - trunkH * 0.86 + Math.sin(a) * bl)
          ctx.stroke()
        }
      }
      if (k > 0.55) {
        const ck = (k - 0.55) / 0.45
        for (let c = 0; c < 7; c++) {
          const ca = (c / 7) * Math.PI * 2 + tr.seed
          const cr = (21 + ((c * 29) % 16)) * ck * tr.scale
          ctx.fillStyle = `hsla(${tr.hue + ((c * 13) % 20) - 10},46%,${33 + (c % 3) * 6}%,0.86)`
          ctx.beginPath()
          ctx.arc(tr.x + Math.cos(ca) * cr * 0.8, tr.groundY - trunkH - 9 * ck + Math.sin(ca) * cr * 0.4, 13 * ck * tr.scale, 0, Math.PI * 2)
          ctx.fill()
        }
      }
      ctx.restore()
    }

    // birds — flapping silhouettes
    for (const b of this.birds) {
      const flap = Math.sin(b.flap)
      ctx.save()
      ctx.translate(b.x, b.y)
      ctx.strokeStyle = `hsla(${b.hue},22%,84%,0.92)`
      ctx.lineWidth = 1.8
      ctx.lineCap = 'round'
      ctx.beginPath()
      ctx.moveTo(-b.size, -flap * b.size * 0.72)
      ctx.quadraticCurveTo(-b.size * 0.32, -flap * b.size * 0.42, 0, 0)
      ctx.quadraticCurveTo(b.size * 0.32, -flap * b.size * 0.42, b.size, -flap * b.size * 0.72)
      ctx.stroke()
      ctx.restore()
    }
  }

  drawOrbiters(ctx: CanvasRenderingContext2D, orbX: number, orbY: number, orbScale: number) {
    ctx.save()
    for (const o of this.orbiters) {
      const x = orbX + Math.cos(o.ang) * o.dist * orbScale
      const y = orbY + Math.sin(o.ang) * o.dist * 0.45 * orbScale
      if (o.kind === 'satellite') {
        ctx.fillStyle = '#cbd5e1'
        ctx.fillRect(x - o.size / 2, y - o.size / 3, o.size, o.size * 0.66)
        ctx.strokeStyle = '#94a3b8'
        ctx.lineWidth = 1
        ctx.strokeRect(x - o.size / 2, y - o.size / 3, o.size, o.size * 0.66)
        // solar panels
        ctx.fillStyle = '#3b82f6'
        ctx.fillRect(x - o.size * 1.5, y - o.size / 5, o.size * 0.8, o.size * 0.3)
        ctx.fillRect(x + o.size * 0.7, y - o.size / 5, o.size * 0.8, o.size * 0.3)
        const blink = Math.sin(this.t * 6 + o.ang * 4) > 0.6
        if (blink) {
          ctx.fillStyle = '#f87171'
          ctx.beginPath()
          ctx.arc(x, y - o.size * 0.5, 1.6, 0, Math.PI * 2)
          ctx.fill()
        }
      } else {
        ctx.save()
        ctx.translate(x, y)
        ctx.rotate(o.ang * 2)
        ctx.fillStyle = `hsla(${o.hue},${o.sat}%,${o.light}%,0.95)`
        ctx.beginPath()
        ctx.moveTo(-o.size, o.size * 0.4)
        ctx.lineTo(-o.size * 0.3, -o.size)
        ctx.lineTo(o.size * 0.5, -o.size * 0.6)
        ctx.lineTo(o.size, o.size * 0.5)
        ctx.closePath()
        ctx.fill()
        ctx.restore()
      }
    }
    ctx.restore()
  }

  drawFlash(ctx: CanvasRenderingContext2D, w: number, h: number) {
    if (this.flashA > 0.005) {
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      ctx.fillStyle = `hsla(${this.flashHue},${this.flashSat}%,88%,${this.flashA})`
      ctx.fillRect(0, 0, w, h)
      ctx.restore()
    }
  }
}
