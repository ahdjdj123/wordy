import type { EnvironmentKind } from '../types'

/* ==========================================================================
   WORDY environment themes — 18 procedural worlds.
   Every theme = gradient + nebula + stars + scenery drawing.
   Themes crossfade: colors lerp, scenery fades.
   ========================================================================== */

export interface ThemeDef {
  bg: [string, string, string]
  nebula: string[]
  nebulaAlpha: number
  starCount: number
  starTint: string
  tint: string | null
  scenery: 'none' | 'moon' | 'crescent' | 'sunhigh' | 'sunset' | 'dawn' |
    'waves' | 'forest' | 'dunes' | 'snowground' | 'auroraBands' | 'stormclouds' |
    'void' | 'dreamblobs' | 'volcanoGlow' | 'jungleLeaves' | 'skyline' | 'galaxyBand'
}

export const THEMES: Record<EnvironmentKind, ThemeDef> = {
  space: {
    bg: ['#080B1A', '#0B1026', '#101736'],
    nebula: ['#7C3AED', '#3B82F6', '#06B6D4'],
    nebulaAlpha: 0.16,
    starCount: 220,
    starTint: '#dbeafe',
    tint: null,
    scenery: 'none',
  },
  galaxy: {
    bg: ['#070A18', '#0D1030', '#1A0F38'],
    nebula: ['#7C3AED', '#F472B6', '#3B82F6', '#06B6D4'],
    nebulaAlpha: 0.24,
    starCount: 420,
    starTint: '#f3e8ff',
    tint: null,
    scenery: 'galaxyBand',
  },
  night: {
    bg: ['#060916', '#0A1228', '#101B3C'],
    nebula: ['#1e3a8a', '#312e81'],
    nebulaAlpha: 0.12,
    starCount: 160,
    starTint: '#e0e7ff',
    tint: null,
    scenery: 'moon',
  },
  midnight: {
    bg: ['#03040C', '#050817', '#0A0F24'],
    nebula: ['#1e1b4b'],
    nebulaAlpha: 0.10,
    starCount: 300,
    starTint: '#c7d2fe',
    tint: null,
    scenery: 'crescent',
  },
  sunset: {
    bg: ['#150A1E', '#3B1A3E', '#7C2D4A'],
    nebula: ['#F472B6', '#FBBF24', '#7C3AED'],
    nebulaAlpha: 0.20,
    starCount: 40,
    starTint: '#fde68a',
    tint: 'rgba(251,146,60,0.05)',
    scenery: 'sunset',
  },
  dawn: {
    bg: ['#0E1430', '#233158', '#4A5D8C'],
    nebula: ['#FBBF24', '#F472B6', '#3B82F6'],
    nebulaAlpha: 0.18,
    starCount: 60,
    starTint: '#fef3c7',
    tint: 'rgba(251,191,36,0.04)',
    scenery: 'dawn',
  },
  ocean: {
    bg: ['#041225', '#062A44', '#0A4258'],
    nebula: ['#06B6D4', '#3B82F6'],
    nebulaAlpha: 0.20,
    starCount: 0,
    starTint: '#e0f2fe',
    tint: 'rgba(6,182,212,0.06)',
    scenery: 'waves',
  },
  forest: {
    bg: ['#04120C', '#0A231A', '#123326'],
    nebula: ['#10b981', '#065f46'],
    nebulaAlpha: 0.16,
    starCount: 50,
    starTint: '#d1fae5',
    tint: 'rgba(16,185,129,0.05)',
    scenery: 'forest',
  },
  desert: {
    bg: ['#1A0F0A', '#3B2214', '#6B3F1D'],
    nebula: ['#FBBF24', '#F97316'],
    nebulaAlpha: 0.15,
    starCount: 30,
    starTint: '#fde68a',
    tint: 'rgba(251,191,36,0.06)',
    scenery: 'dunes',
  },
  winter: {
    bg: ['#0A1220', '#14243D', '#1F3A5C'],
    nebula: ['#93c5fd', '#c4b5fd'],
    nebulaAlpha: 0.14,
    starCount: 90,
    starTint: '#e0f2fe',
    tint: 'rgba(191,219,254,0.07)',
    scenery: 'snowground',
  },
  arctic: {
    bg: ['#060D1A', '#0E1E36', '#16324F'],
    nebula: ['#06B6D4', '#7C3AED'],
    nebulaAlpha: 0.16,
    starCount: 140,
    starTint: '#e0f2fe',
    tint: 'rgba(103,232,249,0.05)',
    scenery: 'auroraBands',
  },
  storm: {
    bg: ['#07070F', '#14101F', '#231A33'],
    nebula: ['#4c1d95', '#312e81'],
    nebulaAlpha: 0.18,
    starCount: 20,
    starTint: '#cbd5e1',
    tint: 'rgba(30,27,75,0.10)',
    scenery: 'stormclouds',
  },
  void: {
    bg: ['#020208', '#04040C', '#070712'],
    nebula: [],
    nebulaAlpha: 0,
    starCount: 14,
    starTint: '#64748b',
    tint: null,
    scenery: 'void',
  },
  dream: {
    bg: ['#120A24', '#241245', '#3D1B5E'],
    nebula: ['#F472B6', '#a78bfa', '#67e8f9'],
    nebulaAlpha: 0.22,
    starCount: 80,
    starTint: '#f5d0fe',
    tint: 'rgba(244,114,182,0.05)',
    scenery: 'dreamblobs',
  },
  volcano: {
    bg: ['#0C0505', '#1F0A0A', '#3A1010'],
    nebula: ['#ef4444', '#f97316'],
    nebulaAlpha: 0.20,
    starCount: 20,
    starTint: '#fca5a5',
    tint: 'rgba(239,68,68,0.06)',
    scenery: 'volcanoGlow',
  },
  jungle: {
    bg: ['#04140C', '#0A2B16', '#11401F'],
    nebula: ['#34d399', '#0d9488'],
    nebulaAlpha: 0.18,
    starCount: 40,
    starTint: '#a7f3d0',
    tint: 'rgba(52,211,153,0.05)',
    scenery: 'jungleLeaves',
  },
  neon: {
    bg: ['#08040F', '#12082A', '#1D0E3E'],
    nebula: ['#7C3AED', '#F472B6', '#06B6D4'],
    nebulaAlpha: 0.20,
    starCount: 70,
    starTint: '#e9d5ff',
    tint: 'rgba(124,58,237,0.06)',
    scenery: 'skyline',
  },
  aurora: {
    bg: ['#040814', '#081226', '#0D1E3E'],
    nebula: ['#06B6D4', '#34d399', '#7C3AED'],
    nebulaAlpha: 0.15,
    starCount: 200,
    starTint: '#e0f2fe',
    tint: null,
    scenery: 'auroraBands',
  },
}

/* ---------- color helpers ---------- */

export function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace('#', '')
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16)
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255]
}

export function lerpColor(a: string, b: string, t: number): string {
  const [ar, ag, ab] = hexToRgb(a)
  const [br, bg, bb] = hexToRgb(b)
  const r = Math.round(ar + (br - ar) * t)
  const g = Math.round(ag + (bg - ag) * t)
  const bl = Math.round(ab + (bb - ab) * t)
  return `rgb(${r},${g},${bl})`
}

export interface RenderTheme {
  bg: [string, string, string]
  nebula: string[]
  nebulaAlpha: number
  starCount: number
  starTint: string
  tint: string | null
}

export function lerpTheme(a: ThemeDef, b: ThemeDef, t: number): RenderTheme {
  return {
    bg: [lerpColor(a.bg[0], b.bg[0], t), lerpColor(a.bg[1], b.bg[1], t), lerpColor(a.bg[2], b.bg[2], t)],
    nebula: b.nebula,
    nebulaAlpha: a.nebulaAlpha + (b.nebulaAlpha - a.nebulaAlpha) * t,
    starCount: Math.round(a.starCount + (b.starCount - a.starCount) * t),
    starTint: t > 0.5 ? b.starTint : a.starTint,
    tint: t > 0.5 ? b.tint : a.tint,
  }
}

/* ---------- procedural scenery ---------- */

function moon(ctx: CanvasRenderingContext2D, w: number, h: number, t: number, alpha: number, crescent: boolean) {
  const x = w * 0.78
  const y = h * 0.2
  const r = Math.min(w, h) * 0.07
  ctx.save()
  ctx.globalAlpha = alpha
  const g = ctx.createRadialGradient(x, y, r * 0.4, x, y, r * 2.6)
  g.addColorStop(0, 'rgba(226,232,240,0.28)')
  g.addColorStop(1, 'rgba(226,232,240,0)')
  ctx.fillStyle = g
  ctx.beginPath()
  ctx.arc(x, y, r * 2.6, 0, Math.PI * 2)
  ctx.fill()
  ctx.fillStyle = '#e2e8f0'
  ctx.beginPath()
  ctx.arc(x, y, r, 0, Math.PI * 2)
  ctx.fill()
  if (crescent) {
    ctx.fillStyle = 'rgba(6,9,22,0.92)'
    ctx.beginPath()
    ctx.arc(x - r * 0.42, y - r * 0.1, r * 0.92, 0, Math.PI * 2)
    ctx.fill()
  } else {
    ctx.fillStyle = 'rgba(148,163,184,0.35)'
    const craters = [[0.3, -0.2, 0.16], [-0.25, 0.3, 0.12], [0.1, 0.42, 0.1], [-0.4, -0.32, 0.09]]
    for (const [dx, dy, dr] of craters) {
      ctx.beginPath()
      ctx.arc(x + dx * r, y + dy * r, dr * r, 0, Math.PI * 2)
      ctx.fill()
    }
  }
  ctx.restore()
}

function sunDisc(ctx: CanvasRenderingContext2D, w: number, h: number, t: number, alpha: number, mode: 'sunset' | 'dawn' | 'high') {
  const x = w * 0.5
  const y = mode === 'high' ? h * 0.16 : h * 0.62
  const r = Math.min(w, h) * (mode === 'sunset' ? 0.09 : 0.07)
  ctx.save()
  ctx.globalAlpha = alpha
  const gg = ctx.createRadialGradient(x, y, r * 0.3, x, y, r * 3.4)
  const warm = mode === 'dawn' ? '251,191,36' : '251,146,60'
  gg.addColorStop(0, `rgba(${warm},0.5)`)
  gg.addColorStop(1, `rgba(${warm},0)`)
  ctx.fillStyle = gg
  ctx.beginPath()
  ctx.arc(x, y, r * 3.4, 0, Math.PI * 2)
  ctx.fill()
  ctx.fillStyle = mode === 'dawn' ? '#fde68a' : '#fbbf24'
  ctx.beginPath()
  ctx.arc(x, y, r, 0, Math.PI * 2)
  ctx.fill()
  if (mode === 'sunset') {
    // rays on horizon
    ctx.strokeStyle = `rgba(251,146,60,${0.12 * alpha})`
    for (let i = 0; i < 7; i++) {
      const a = (i / 7) * Math.PI * 2 + t * 0.05
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.moveTo(x + Math.cos(a) * r * 1.2, y + Math.sin(a) * r * 1.2)
      ctx.lineTo(x + Math.cos(a) * r * 4.2, y + Math.sin(a) * r * 4.2)
      ctx.stroke()
    }
  }
  ctx.restore()
}

function waveBand(ctx: CanvasRenderingContext2D, w: number, h: number, t: number, yBase: number, amp: number, color: string, alpha: number, speed: number) {
  ctx.save()
  ctx.globalAlpha = alpha
  ctx.fillStyle = color
  ctx.beginPath()
  ctx.moveTo(0, h)
  ctx.lineTo(0, yBase)
  for (let x = 0; x <= w; x += 14) {
    const y = yBase + Math.sin(x * 0.008 + t * speed) * amp + Math.sin(x * 0.02 + t * speed * 1.6) * amp * 0.3
    ctx.lineTo(x, y)
  }
  ctx.lineTo(w, h)
  ctx.closePath()
  ctx.fill()
  ctx.restore()
}

function pine(ctx: CanvasRenderingContext2D, x: number, baseY: number, s: number, color: string) {
  ctx.fillStyle = color
  ctx.beginPath()
  ctx.moveTo(x, baseY - s * 1.9)
  ctx.lineTo(x - s * 0.55, baseY)
  ctx.lineTo(x + s * 0.55, baseY)
  ctx.closePath()
  ctx.fill()
  ctx.beginPath()
  ctx.moveTo(x, baseY - s * 2.6)
  ctx.lineTo(x - s * 0.42, baseY - s * 0.9)
  ctx.lineTo(x + s * 0.42, baseY - s * 0.9)
  ctx.closePath()
  ctx.fill()
}

export function drawScenery(
  ctx: CanvasRenderingContext2D,
  env: EnvironmentKind,
  w: number,
  h: number,
  t: number,
  alpha: number,
) {
  if (alpha <= 0.005) return
  const theme = THEMES[env]
  switch (theme.scenery) {
    case 'moon':
      moon(ctx, w, h, t, alpha, false)
      break
    case 'crescent':
      moon(ctx, w, h, t, alpha, true)
      break
    case 'sunset':
      sunDisc(ctx, w, h, t, alpha, 'sunset')
      break
    case 'dawn':
      sunDisc(ctx, w, h, t, alpha, 'dawn')
      break
    case 'sunhigh':
      sunDisc(ctx, w, h, t, alpha, 'high')
      break
    case 'waves': {
      waveBand(ctx, w, h, t, h * 0.78, 10, '#0E5A72', 0.5 * alpha, 1.1)
      waveBand(ctx, w, h, t, h * 0.85, 14, '#0A4860', 0.7 * alpha, 0.8)
      waveBand(ctx, w, h, t, h * 0.92, 12, '#07364C', 0.9 * alpha, 0.55)
      // light shafts
      ctx.save()
      ctx.globalAlpha = 0.06 * alpha
      ctx.fillStyle = '#67e8f9'
      for (let i = 0; i < 4; i++) {
        const x = w * (0.2 + i * 0.2)
        ctx.beginPath()
        ctx.moveTo(x, 0)
        ctx.lineTo(x + w * 0.06, 0)
        ctx.lineTo(x + w * 0.12, h * 0.8)
        ctx.lineTo(x + w * 0.02, h * 0.8)
        ctx.closePath()
        ctx.fill()
      }
      ctx.restore()
      break
    }
    case 'forest': {
      ctx.save()
      ctx.globalAlpha = alpha
      const fy = h * 0.97
      // ground mist
      const mist = ctx.createLinearGradient(0, h * 0.72, 0, h)
      mist.addColorStop(0, 'rgba(6,95,70,0)')
      mist.addColorStop(1, 'rgba(6,95,70,0.35)')
      ctx.fillStyle = mist
      ctx.fillRect(0, h * 0.72, w, h * 0.28)
      for (let i = 0; i < 9; i++) {
        const x = w * (0.04 + (i * 0.115))
        const s = Math.min(w, h) * (0.05 + ((i * 37) % 13) / 90)
        pine(ctx, x, fy, s, 'rgba(4,20,14,0.9)')
      }
      ctx.restore()
      break
    }
    case 'dunes': {
      ctx.save()
      ctx.globalAlpha = alpha
      const dune = (yb: number, amp: number, c: string, a: number, phase: number) => {
        ctx.fillStyle = c
        ctx.globalAlpha = a * alpha
        ctx.beginPath()
        ctx.moveTo(0, h)
        ctx.lineTo(0, yb)
        for (let x = 0; x <= w; x += 20) {
          ctx.quadraticCurveTo(x + 10, yb + Math.sin(x * 0.005 + phase) * amp, x + 20, yb)
        }
        ctx.lineTo(w, h)
        ctx.closePath()
        ctx.fill()
      }
      dune(h * 0.8, 26, '#8A5A2B', 0.35, 1)
      dune(h * 0.88, 34, '#6B3F1D', 0.55, 3)
      dune(h * 0.95, 22, '#4A2A11', 0.8, 5)
      ctx.globalAlpha = alpha
      // cacti silhouettes
      ctx.fillStyle = 'rgba(30,20,10,0.9)'
      const cx = w * 0.18
      ctx.fillRect(cx, h * 0.86, 6, h * 0.06)
      ctx.fillRect(cx - 8, h * 0.88, 8, 4)
      ctx.fillRect(cx - 8, h * 0.84, 4, 8)
      ctx.fillRect(cx + 6, h * 0.9, 9, 4)
      ctx.fillRect(cx + 11, h * 0.86, 4, 9)
      ctx.restore()
      sunDisc(ctx, w, h, t, alpha, 'high')
      break
    }
    case 'snowground': {
      ctx.save()
      ctx.globalAlpha = alpha
      const g = ctx.createLinearGradient(0, h * 0.82, 0, h)
      g.addColorStop(0, 'rgba(224,242,254,0.25)')
      g.addColorStop(1, 'rgba(224,242,254,0.45)')
      ctx.fillStyle = g
      ctx.beginPath()
      ctx.moveTo(0, h * 0.9)
      for (let x = 0; x <= w; x += 24) {
        ctx.lineTo(x, h * 0.9 + Math.sin(x * 0.01) * 8)
      }
      ctx.lineTo(w, h)
      ctx.lineTo(0, h)
      ctx.closePath()
      ctx.fill()
      for (let i = 0; i < 7; i++) {
        const x = w * (0.06 + i * 0.145)
        pine(ctx, x, h * 0.92, Math.min(w, h) * 0.045, 'rgba(12,24,40,0.9)')
      }
      ctx.restore()
      break
    }
    case 'auroraBands': {
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      const bands = [
        { hue: 'rgba(52,211,153,', y: 0.24, amp: 0.05, sp: 0.5 },
        { hue: 'rgba(103,232,249,', y: 0.2, amp: 0.07, sp: 0.32 },
        { hue: 'rgba(124,58,237,', y: 0.3, amp: 0.04, sp: 0.7 },
      ]
      for (const b of bands) {
        for (let layer = 0; layer < 3; layer++) {
          const grad = ctx.createLinearGradient(0, h * (b.y - 0.1), 0, h * (b.y + 0.22))
          grad.addColorStop(0, b.hue + '0)')
          grad.addColorStop(0.5, b.hue + (0.10 * alpha * (1 - layer * 0.25)).toFixed(3) + ')')
          grad.addColorStop(1, b.hue + '0)')
          ctx.fillStyle = grad
          ctx.beginPath()
          ctx.moveTo(0, h * b.y)
          for (let x = 0; x <= w; x += 18) {
            const y = h * b.y + Math.sin(x * 0.006 + t * b.sp + layer * 2) * h * b.amp
              + Math.sin(x * 0.017 + t * b.sp * 1.7 + layer) * h * b.amp * 0.4
            ctx.lineTo(x, y)
          }
          ctx.lineTo(w, h * (b.y + 0.24))
          ctx.lineTo(0, h * (b.y + 0.24))
          ctx.closePath()
          ctx.globalAlpha = 1
          ctx.fill()
        }
      }
      ctx.restore()
      moon(ctx, w, h, t, alpha * 0.8, false)
      break
    }
    case 'stormclouds': {
      ctx.save()
      ctx.globalAlpha = alpha
      const clouds = [[0.16, 0.16, 0.16], [0.4, 0.12, 0.13], [0.66, 0.15, 0.12], [0.88, 0.18, 0.15]]
      for (const [cx, cy, cr] of clouds) {
        const x = w * cx + Math.sin(t * 0.1 + cx * 10) * 20
        const y = h * cy
        const r = Math.min(w, h) * cr
        const g = ctx.createRadialGradient(x, y, 0, x, y, r)
        g.addColorStop(0, 'rgba(49,46,81,0.55)')
        g.addColorStop(1, 'rgba(49,46,81,0)')
        ctx.fillStyle = g
        ctx.beginPath()
        ctx.ellipse(x, y, r, r * 0.55, 0, 0, Math.PI * 2)
        ctx.fill()
      }
      ctx.restore()
      break
    }
    case 'void': {
      ctx.save()
      ctx.globalAlpha = alpha
      const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.1, w / 2, h / 2, Math.max(w, h) * 0.7)
      g.addColorStop(0, 'rgba(30,27,75,0.12)')
      g.addColorStop(1, 'rgba(0,0,0,0.4)')
      ctx.fillStyle = g
      ctx.fillRect(0, 0, w, h)
      ctx.restore()
      break
    }
    case 'dreamblobs': {
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      const blobs = [
        { c: 'rgba(244,114,182,', x: 0.24, y: 0.3, r: 0.16, sp: 0.2 },
        { c: 'rgba(167,139,250,', x: 0.7, y: 0.24, r: 0.13, sp: 0.14 },
        { c: 'rgba(103,232,249,', x: 0.55, y: 0.6, r: 0.18, sp: 0.11 },
        { c: 'rgba(244,114,182,', x: 0.15, y: 0.7, r: 0.1, sp: 0.26 },
      ]
      for (const b of blobs) {
        const x = w * b.x + Math.sin(t * b.sp * 3) * 26
        const y = h * b.y + Math.cos(t * b.sp * 2.2) * 20
        const r = Math.min(w, h) * b.r * (1 + Math.sin(t * b.sp * 4) * 0.06)
        const g = ctx.createRadialGradient(x, y, 0, x, y, r)
        g.addColorStop(0, b.c + (0.12 * alpha).toFixed(3) + ')')
        g.addColorStop(1, b.c + '0)')
        ctx.fillStyle = g
        ctx.beginPath()
        ctx.arc(x, y, r, 0, Math.PI * 2)
        ctx.fill()
      }
      ctx.restore()
      break
    }
    case 'volcanoGlow': {
      ctx.save()
      ctx.globalAlpha = alpha
      // cone
      ctx.fillStyle = 'rgba(20,8,8,0.95)'
      ctx.beginPath()
      ctx.moveTo(w * 0.5, h * 0.66)
      ctx.lineTo(w * 0.32, h)
      ctx.lineTo(w * 0.68, h)
      ctx.closePath()
      ctx.fill()
      // crater glow
      const g = ctx.createRadialGradient(w * 0.5, h * 0.67, 0, w * 0.5, h * 0.67, Math.min(w, h) * 0.3)
      const pulse = 0.5 + Math.sin(t * 1.4) * 0.18
      g.addColorStop(0, `rgba(251,146,60,${0.5 * pulse * alpha})`)
      g.addColorStop(0.4, `rgba(239,68,68,${0.25 * pulse * alpha})`)
      g.addColorStop(1, 'rgba(239,68,68,0)')
      ctx.fillStyle = g
      ctx.beginPath()
      ctx.arc(w * 0.5, h * 0.67, Math.min(w, h) * 0.3, 0, Math.PI * 2)
      ctx.fill()
      // ground glow
      const g2 = ctx.createLinearGradient(0, h * 0.8, 0, h)
      g2.addColorStop(0, 'rgba(239,68,68,0)')
      g2.addColorStop(1, `rgba(239,68,68,${0.3 * alpha})`)
      ctx.fillStyle = g2
      ctx.fillRect(0, h * 0.8, w, h * 0.2)
      ctx.restore()
      break
    }
    case 'jungleLeaves': {
      ctx.save()
      ctx.globalAlpha = alpha
      const leaf = (x: number, y: number, s: number, rot: number, c: string) => {
        ctx.save()
        ctx.translate(x, y)
        ctx.rotate(rot)
        ctx.fillStyle = c
        ctx.beginPath()
        ctx.moveTo(0, 0)
        ctx.quadraticCurveTo(s * 0.5, -s * 0.38, s, 0)
        ctx.quadraticCurveTo(s * 0.5, s * 0.38, 0, 0)
        ctx.fill()
        ctx.restore()
      }
      const m = Math.min(w, h)
      for (let i = 0; i < 6; i++) {
        leaf(w * (0.02 + i * 0.19), h * 0.99, m * (0.24 + (i % 3) * 0.05), -0.5 - Math.sin(i) * 0.2, 'rgba(6,40,22,0.88)')
      }
      for (let i = 0; i < 5; i++) {
        leaf(w * (0.1 + i * 0.21), h * 1.02, m * (0.3 + (i % 2) * 0.06), -1.9 + Math.sin(i * 2) * 0.15, 'rgba(4,30,16,0.8)')
      }
      ctx.restore()
      break
    }
    case 'skyline': {
      ctx.save()
      ctx.globalAlpha = alpha
      const m = Math.min(w, h)
      // far layer
      ctx.fillStyle = 'rgba(23,12,48,0.85)'
      for (let i = 0; i < 10; i++) {
        const bw = w * 0.075
        const bh = m * (0.12 + ((i * 53) % 17) / 95)
        ctx.fillRect(w * 0.02 + i * bw, h * 0.88 - bh, bw * 0.94, bh + m * 0.12)
      }
      // near layer with windows
      for (let i = 0; i < 8; i++) {
        const bw = w * 0.1
        const bh = m * (0.18 + ((i * 71) % 23) / 80)
        const bx = w * 0.06 + i * bw
        const by = h * 0.88 - bh
        ctx.fillStyle = 'rgba(13,7,30,0.95)'
        ctx.fillRect(bx, by, bw * 0.92, bh + m * 0.14)
        // windows
        for (let wx = 0; wx < 3; wx++) {
          for (let wy = 0; wy < Math.floor(bh / (m * 0.035)); wy++) {
            if ((i * 7 + wx * 3 + wy * 5) % 4 < 2) {
              ctx.fillStyle = (i + wx + wy) % 5 === 0 ? 'rgba(244,114,182,0.5)' : 'rgba(103,232,249,0.32)'
              ctx.fillRect(bx + bw * 0.12 + wx * bw * 0.26, by + m * 0.02 + wy * m * 0.035, bw * 0.14, m * 0.016)
            }
          }
        }
      }
      ctx.restore()
      break
    }
    case 'galaxyBand': {
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      ctx.translate(w / 2, h / 2)
      ctx.rotate(-0.5)
      const bw = Math.max(w, h) * 1.15
      const g = ctx.createLinearGradient(0, -h * 0.22, 0, h * 0.22)
      g.addColorStop(0, 'rgba(124,58,237,0)')
      g.addColorStop(0.42, `rgba(124,58,237,${0.10 * alpha})`)
      g.addColorStop(0.5, `rgba(244,114,182,${0.12 * alpha})`)
      g.addColorStop(0.58, `rgba(59,130,246,${0.10 * alpha})`)
      g.addColorStop(1, 'rgba(59,130,246,0)')
      ctx.fillStyle = g
      ctx.fillRect(-bw / 2, -h * 0.22, bw, h * 0.44)
      ctx.restore()
      break
    }
    default:
      break
  }
}
