import type { WeatherKind, ElementKind } from '../types'

/* ==========================================================================
   WORDY particle system — one pool, many souls.
   Weather, element output, celebration bursts… all live here.
   ========================================================================== */

export type PKind =
  | 'spark' | 'ember' | 'raindrop' | 'snow' | 'leaf' | 'petal' | 'bubble'
  | 'starmote' | 'confetti' | 'firefly' | 'heart' | 'smoke' | 'steam'
  | 'droplet' | 'iceshard' | 'dust' | 'cloud' | 'glyph' | 'note'
  | 'streak' | 'feather' | 'rock' | 'shard' | 'flowerp' | 'butterfly'

export interface Particle {
  kind: PKind
  x: number
  y: number
  vx: number
  vy: number
  life: number
  maxLife: number
  size: number
  hue: number
  sat: number
  light: number
  rot: number
  vrot: number
  gf: number     // gravity factor
  wf: number     // wind factor
  sway: number   // horizontal sway amount
  swaySp: number
  seed: number
  fading: boolean
}

function rnd(a: number, b: number) {
  return a + Math.random() * (b - a)
}

export class ParticleSystem {
  particles: Particle[] = []
  cap = 520
  private w = 0
  private h = 0
  private t = 0

  resize(w: number, h: number) {
    this.w = w
    this.h = h
  }

  setCap(n: number) {
    this.cap = n
    if (this.particles.length > n) this.particles.length = n
  }

  spawn(kind: PKind, opts: Partial<Particle> & { x: number; y: number }): Particle | null {
    if (this.particles.length >= this.cap) {
      // recycle the oldest weather-free particle instead of dropping
      const idx = this.particles.findIndex((p) => p.life > p.maxLife * 0.5)
      if (idx === -1) return null
      this.particles.splice(idx, 1)
    }
    const p: Particle = {
      kind,
      x: opts.x,
      y: opts.y,
      vx: opts.vx ?? 0,
      vy: opts.vy ?? 0,
      life: 0,
      maxLife: opts.maxLife ?? 2,
      size: opts.size ?? 3,
      hue: opts.hue ?? 260,
      sat: opts.sat ?? 90,
      light: opts.light ?? 65,
      rot: opts.rot ?? 0,
      vrot: opts.vrot ?? 0,
      gf: opts.gf ?? 0,
      wf: opts.wf ?? 0,
      sway: opts.sway ?? 0,
      swaySp: opts.swaySp ?? 1,
      seed: Math.random() * 1000,
      fading: false,
    }
    this.particles.push(p)
    return p
  }

  /* ------------ bursts (reusable animation building blocks) ------------ */

  sparkBurst(x: number, y: number, n: number, hue = 48, speed = 240) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2
      const s = speed * rnd(0.25, 1)
      this.spawn('spark', {
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
        maxLife: rnd(0.4, 1.0), size: rnd(1.5, 4),
        hue: hue + rnd(-20, 20), light: rnd(60, 78),
        gf: 0.35, wf: 1,
      })
    }
  }

  emberBurst(x: number, y: number, n: number) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2
      const s = rnd(20, 130)
      this.spawn('ember', {
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 60,
        maxLife: rnd(0.8, 1.8), size: rnd(2, 5), hue: rnd(18, 40), gf: -0.25, wf: 1,
      })
    }
  }

  heartBurst(x: number, y: number, n: number) {
    for (let i = 0; i < n; i++) {
      this.spawn('heart', {
        x: x + rnd(-30, 30), y: y + rnd(-20, 20),
        vx: rnd(-40, 40), vy: rnd(-160, -60),
        maxLife: rnd(1.2, 2.2), size: rnd(6, 13),
        hue: 340 + rnd(-12, 10), gf: -0.12, sway: rnd(6, 18), swaySp: rnd(1, 2),
      })
    }
  }

  starBurst(x: number, y: number, n: number) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2
      const s = rnd(60, 320)
      this.spawn('spark', {
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
        maxLife: rnd(0.6, 1.4), size: rnd(1.5, 3.5), hue: rnd(200, 260), light: rnd(70, 92),
        gf: 0.1, wf: 0.4, vrot: 6,
      })
    }
    for (let i = 0; i < Math.floor(n / 3); i++) {
      this.spawn('starmote', {
        x: x + rnd(-10, 10), y: y + rnd(-10, 10),
        vx: rnd(-50, 50), vy: rnd(-50, 50),
        maxLife: rnd(1.5, 3), size: rnd(2, 5), hue: rnd(190, 280), gf: -0.02, sway: 4, swaySp: 0.7,
      })
    }
  }

  galaxyBurst(x: number, y: number, n: number) {
    const arms = 3
    for (let i = 0; i < n; i++) {
      const arm = i % arms
      const along = (i / n) * Math.PI * 2.2 + (arm / arms) * Math.PI * 2
      const r = rnd(30, 190)
      const s = rnd(40, 130)
      this.spawn('spark', {
        x: x + Math.cos(along) * r * 0.2, y: y + Math.sin(along) * r * 0.2,
        vx: Math.cos(along) * s * 1.5, vy: Math.sin(along) * s * 1.5,
        maxLife: rnd(1, 2.2), size: rnd(1.5, 3.8),
        hue: [265, 200, 330, 45][arm % 4] + rnd(-16, 16),
        light: rnd(62, 88), gf: 0, wf: 0.2,
      })
    }
  }

  confettiBurst(x: number, y: number, n: number) {
    const hues = [265, 200, 330, 45, 150]
    for (let i = 0; i < n; i++) {
      const a = -Math.PI / 2 + rnd(-1.1, 1.1)
      const s = rnd(150, 420)
      this.spawn('confetti', {
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
        maxLife: rnd(1.6, 3), size: rnd(4, 8),
        hue: hues[i % hues.length] + rnd(-10, 10),
        gf: 0.55, wf: 1.2, vrot: rnd(-8, 8), sway: rnd(3, 10), swaySp: rnd(1.5, 3.5),
      })
    }
  }

  shatterBurst(x: number, y: number) {
    for (let i = 0; i < 22; i++) {
      const a = Math.random() * Math.PI * 2
      const s = rnd(80, 300)
      this.spawn('shard', {
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
        maxLife: rnd(0.7, 1.4), size: rnd(3, 9), hue: 195, sat: 30, light: 88,
        gf: 0.45, wf: 0.6, vrot: rnd(-10, 10),
      })
    }
  }

  frostBurst(x: number, y: number) {
    for (let i = 0; i < 26; i++) {
      const a = Math.random() * Math.PI * 2
      const s = rnd(40, 200)
      this.spawn('iceshard', {
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 20,
        maxLife: rnd(0.8, 1.6), size: rnd(3, 7), hue: 200, sat: 60, light: 86,
        gf: 0.25, wf: 0.8, vrot: rnd(-6, 6),
      })
    }
    for (let i = 0; i < 16; i++) {
      const a = Math.random() * Math.PI * 2
      this.spawn('spark', {
        x, y, vx: Math.cos(a) * rnd(20, 90), vy: Math.sin(a) * rnd(20, 90),
        maxLife: rnd(0.8, 1.8), size: rnd(1.5, 3), hue: 190, light: 88,
      })
    }
  }

  splashBurst(x: number, y: number, n = 26) {
    for (let i = 0; i < n; i++) {
      const a = -Math.PI / 2 + rnd(-1.2, 1.2)
      const s = rnd(80, 300)
      this.spawn('droplet', {
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
        maxLife: rnd(0.5, 1.1), size: rnd(2, 4.5), hue: 200, sat: 80, light: 70,
        gf: 0.9, wf: 0.5,
      })
    }
  }

  featherBurst(n: number, w: number) {
    for (let i = 0; i < n; i++) {
      this.spawn('feather', {
        x: rnd(w * 0.15, w * 0.85), y: -20 - rnd(0, 60),
        vx: rnd(-14, 14), vy: rnd(18, 44),
        maxLife: rnd(6, 10), size: rnd(7, 13), hue: 45, sat: 25, light: 94,
        sway: rnd(16, 36), swaySp: rnd(0.5, 1), vrot: rnd(-1, 1),
      })
    }
  }

  bloomBurst(x: number, y: number, n = 18) {
    for (let i = 0; i < n; i++) {
      const a = -Math.PI / 2 + rnd(-1.4, 1.4)
      const s = rnd(30, 140)
      this.spawn('flowerp', {
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
        maxLife: rnd(1.6, 3), size: rnd(4, 9),
        hue: [330, 300, 150, 45][i % 4] + rnd(-14, 14),
        gf: 0.28, wf: 1, vrot: rnd(-3, 3), sway: rnd(4, 12), swaySp: rnd(1, 2),
      })
    }
  }

  noteBurst(x: number, y: number, n: number) {
    for (let i = 0; i < n; i++) {
      this.spawn('note', {
        x: x + rnd(-40, 40), y: y + rnd(-24, 24),
        vx: rnd(-30, 30), vy: rnd(-90, -40),
        maxLife: rnd(1.4, 2.4), size: rnd(10, 16),
        hue: [265, 330, 200, 45][i % 4], gf: -0.1, sway: rnd(8, 20), swaySp: rnd(1, 2),
      })
    }
  }

  bigbangBurst(x: number, y: number) {
    for (let i = 0; i < 90; i++) {
      const a = Math.random() * Math.PI * 2
      const s = rnd(120, 560)
      this.spawn('spark', {
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
        maxLife: rnd(1, 2.6), size: rnd(2, 5),
        hue: [265, 200, 330, 45, 150][i % 5] + rnd(-20, 20), light: rnd(66, 92),
        gf: 0.02, wf: 0.1,
      })
    }
    for (let i = 0; i < 40; i++) {
      const a = Math.random() * Math.PI * 2
      const s = rnd(20, 80)
      this.spawn('starmote', {
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
        maxLife: rnd(3, 6), size: rnd(2, 5), hue: rnd(200, 280), gf: -0.005, sway: 6, swaySp: 0.5,
      })
    }
  }

  supernovaBurst(x: number, y: number) {
    for (let i = 0; i < 70; i++) {
      const a = Math.random() * Math.PI * 2
      const s = rnd(160, 520)
      this.spawn('spark', {
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
        maxLife: rnd(0.8, 2), size: rnd(2, 5.5),
        hue: 30 + rnd(-14, 40), light: rnd(62, 90), gf: 0.06,
      })
    }
    for (let i = 0; i < 24; i++) {
      const a = Math.random() * Math.PI * 2
      this.spawn('starmote', {
        x, y, vx: Math.cos(a) * rnd(40, 130), vy: Math.sin(a) * rnd(40, 130),
        maxLife: rnd(2, 4), size: rnd(2, 6), hue: rnd(18, 50), gf: 0.02,
      })
    }
  }

  /* ------------ update ------------ */

  update(dt: number, opts: {
    w: number
    h: number
    gravity: number
    wind: number
    attract: 'attract' | 'repel' | null
    orbX: number
    orbY: number
    floorY: number
    elements: Set<ElementKind>
  }) {
    this.t += dt
    const { w, h, gravity, wind, attract, orbX, orbY } = opts
    const arr = this.particles
    // v1.2 — single pass with in-place compaction (no splices in the hot loop)
    let write = 0
    for (let i = 0; i < arr.length; i++) {
      const p = arr[i]
      p.life += dt
      let alive = p.life < p.maxLife
      if (alive) {
        const windF = wind * p.wf * 90
        p.vx += windF * dt
        if (p.gf !== 0) p.vy += gravity * 400 * p.gf * dt
        if (attract) {
          const dx = orbX - p.x
          const dy = orbY - p.y
          const d2 = dx * dx + dy * dy + 4000
          const f = (attract === 'attract' ? 52000 : -42000) / d2
          p.vx += dx * f * dt
          p.vy += dy * f * dt
        }
        p.x += p.vx * dt + Math.sin(this.t * p.swaySp + p.seed) * p.sway * dt
        p.y += p.vy * dt
        p.rot += p.vrot * dt
        // decay horizontal velocity slightly (air drag)
        p.vx *= 1 - 0.9 * dt * 0.35
        if (p.kind === 'firefly' || p.kind === 'starmote') {
          p.vy *= 1 - 1.2 * dt
        }
        // weather respawn kinds
        if (p.kind === 'raindrop' && p.y > h) {
          alive = false
        } else if (p.kind === 'snow' && p.y > h * 1.02) {
          alive = false
        } else if (p.x < -160 || p.x > w + 160 || p.y < -240 || (p.y > h + 140 && p.vy > 0)) {
          if (p.kind === 'glyph') {
            p.y = -20
            p.x = rnd(0, w)
            p.life = 0
          } else {
            alive = false
          }
        }
      }
      if (alive) arr[write++] = p
    }
    arr.length = write
  }

  /* ------------ draw ------------ */

  draw(ctx: CanvasRenderingContext2D) {
    const arr = this.particles
    ctx.save()
    for (const p of arr) {
      const k = 1 - p.life / p.maxLife
      switch (p.kind) {
        case 'spark': {
          ctx.globalCompositeOperation = 'lighter'
          ctx.fillStyle = `hsla(${p.hue},${p.sat}%,${p.light}%,${Math.min(1, k * 1.6)})`
          ctx.beginPath()
          ctx.arc(p.x, p.y, p.size * (0.5 + k * 0.5), 0, Math.PI * 2)
          ctx.fill()
          ctx.fillStyle = `hsla(${p.hue},${p.sat}%,${Math.min(96, p.light + 25)}%,${k * 0.5})`
          ctx.beginPath()
          ctx.arc(p.x, p.y, p.size * 1.7, 0, Math.PI * 2)
          ctx.fill()
          break
        }
        case 'ember': {
          ctx.globalCompositeOperation = 'lighter'
          const fl = 0.7 + Math.sin(p.seed + p.life * 14) * 0.3
          ctx.fillStyle = `hsla(${p.hue + Math.sin(p.life * 9) * 8},95%,${55 + k * 15}%,${k * fl})`
          ctx.beginPath()
          ctx.arc(p.x, p.y, p.size * (0.4 + k * 0.6), 0, Math.PI * 2)
          ctx.fill()
          break
        }
        case 'raindrop': {
          ctx.globalCompositeOperation = 'source-over'
          const g = ctx.createLinearGradient(p.x, p.y, p.x, p.y + p.size * 4)
          g.addColorStop(0, 'rgba(148,197,255,0)')
          g.addColorStop(0.4, `rgba(148,197,255,${0.28 + k * 0.3})`)
          g.addColorStop(1, 'rgba(148,197,255,0)')
          ctx.strokeStyle = g
          ctx.lineWidth = 1.1
          ctx.beginPath()
          ctx.moveTo(p.x, p.y)
          ctx.lineTo(p.x - p.vx * 0.016, p.y + p.size * 4)
          ctx.stroke()
          break
        }
        case 'snow': {
          ctx.globalCompositeOperation = 'lighter'
          ctx.fillStyle = `rgba(235,244,255,${0.5 + k * 0.4})`
          ctx.beginPath()
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
          ctx.fill()
          break
        }
        case 'leaf': {
          ctx.globalCompositeOperation = 'source-over'
          ctx.save()
          ctx.translate(p.x, p.y)
          ctx.rotate(p.rot)
          ctx.fillStyle = `hsla(${p.hue},${p.sat}%,${p.light}%,${Math.min(1, k * 2)})`
          ctx.beginPath()
          ctx.ellipse(0, 0, p.size, p.size * 0.45, 0, 0, Math.PI * 2)
          ctx.fill()
          ctx.restore()
          break
        }
        case 'petal':
        case 'flowerp': {
          ctx.globalCompositeOperation = 'source-over'
          ctx.save()
          ctx.translate(p.x, p.y)
          ctx.rotate(p.rot)
          ctx.fillStyle = `hsla(${p.hue},85%,${72 + Math.sin(p.life * 3) * 6}%,${Math.min(1, k * 1.8)})`
          ctx.beginPath()
          ctx.ellipse(0, 0, p.size, p.size * 0.6, 0, 0, Math.PI * 2)
          ctx.fill()
          ctx.restore()
          break
        }
        case 'bubble': {
          ctx.globalCompositeOperation = 'source-over'
          ctx.strokeStyle = `hsla(${p.hue},70%,85%,${k * 0.6})`
          ctx.lineWidth = 1
          ctx.beginPath()
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
          ctx.stroke()
          ctx.fillStyle = `hsla(${p.hue},70%,90%,${k * 0.12})`
          ctx.fill()
          break
        }
        case 'starmote': {
          ctx.globalCompositeOperation = 'lighter'
          const tw = 0.5 + Math.sin(p.seed + p.life * 5) * 0.5
          ctx.fillStyle = `hsla(${p.hue},80%,80%,${k * 0.65 * tw})`
          ctx.beginPath()
          ctx.arc(p.x, p.y, p.size * (0.6 + tw * 0.5), 0, Math.PI * 2)
          ctx.fill()
          break
        }
        case 'confetti': {
          ctx.globalCompositeOperation = 'source-over'
          ctx.save()
          ctx.translate(p.x, p.y)
          ctx.rotate(p.rot)
          const sq = Math.abs(Math.cos(p.life * p.swaySp + p.seed))
          ctx.fillStyle = `hsla(${p.hue},${p.sat}%,65%,${Math.min(1, k * 1.6)})`
          ctx.fillRect(-p.size / 2, -p.size * sq / 2, p.size, p.size * sq)
          ctx.restore()
          break
        }
        case 'firefly': {
          ctx.globalCompositeOperation = 'lighter'
          const blink = Math.max(0, Math.sin(p.seed + p.life * 2.4))
          ctx.fillStyle = `rgba(253,230,138,${k * blink})`
          ctx.beginPath()
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
          ctx.fill()
          ctx.fillStyle = `rgba(253,230,138,${k * blink * 0.3})`
          ctx.beginPath()
          ctx.arc(p.x, p.y, p.size * 2.6, 0, Math.PI * 2)
          ctx.fill()
          break
        }
        case 'heart': {
          ctx.globalCompositeOperation = 'source-over'
          drawHeart(ctx, p.x, p.y, p.size, `hsla(${p.hue},90%,70%,${Math.min(1, k * 1.5)})`)
          break
        }
        case 'smoke':
        case 'steam': {
          ctx.globalCompositeOperation = 'source-over'
          const grow = 1 + p.life * 1.4
          ctx.fillStyle = p.kind === 'steam'
            ? `rgba(226,232,240,${k * 0.14})`
            : `rgba(148,163,184,${k * 0.12})`
          ctx.beginPath()
          ctx.arc(p.x, p.y, p.size * grow, 0, Math.PI * 2)
          ctx.fill()
          break
        }
        case 'droplet': {
          ctx.globalCompositeOperation = 'source-over'
          ctx.fillStyle = `hsla(${p.hue},80%,72%,${Math.min(1, k * 1.6)})`
          ctx.beginPath()
          ctx.ellipse(p.x, p.y, p.size * 0.6, p.size, 0, 0, Math.PI * 2)
          ctx.fill()
          break
        }
        case 'iceshard': {
          ctx.globalCompositeOperation = 'lighter'
          ctx.save()
          ctx.translate(p.x, p.y)
          ctx.rotate(p.rot)
          ctx.fillStyle = `hsla(200,80%,88%,${k * 0.8})`
          ctx.beginPath()
          ctx.moveTo(0, -p.size)
          ctx.lineTo(p.size * 0.5, 0)
          ctx.lineTo(0, p.size)
          ctx.lineTo(-p.size * 0.5, 0)
          ctx.closePath()
          ctx.fill()
          ctx.restore()
          break
        }
        case 'dust': {
          ctx.globalCompositeOperation = 'lighter'
          ctx.fillStyle = `hsla(${p.hue},30%,80%,${k * 0.25})`
          ctx.beginPath()
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
          ctx.fill()
          break
        }
        case 'cloud': {
          ctx.globalCompositeOperation = 'source-over'
          ctx.fillStyle = `hsla(${p.hue},25%,88%,${k * 0.08})`
          ctx.beginPath()
          ctx.ellipse(p.x, p.y, p.size * 3, p.size * 1.2, 0, 0, Math.PI * 2)
          ctx.fill()
          break
        }
        case 'glyph': {
          ctx.globalCompositeOperation = 'source-over'
          ctx.fillStyle = `hsla(140,60%,62%,${k * 0.55})`
          ctx.font = `${p.size * 2.6}px "Space Grotesk", monospace`
          ctx.fillText(String.fromCharCode(0x30a0 + (p.seed * 7) % 90 || 65), p.x, p.y)
          break
        }
        case 'note': {
          ctx.globalCompositeOperation = 'source-over'
          ctx.fillStyle = `hsla(${p.hue},85%,75%,${Math.min(1, k * 1.4)})`
          ctx.font = `${p.size}px serif`
          ctx.fillText('♪', p.x, p.y)
          break
        }
        case 'streak': {
          ctx.globalCompositeOperation = 'lighter'
          const a = k * 0.35
          const g = ctx.createLinearGradient(p.x - p.vx * 0.05, p.y - p.vy * 0.05, p.x, p.y)
          g.addColorStop(0, `hsla(${p.hue},90%,80%,0)`)
          g.addColorStop(1, `hsla(${p.hue},90%,80%,${a})`)
          ctx.strokeStyle = g
          ctx.lineWidth = p.size * 0.4
          ctx.beginPath()
          ctx.moveTo(p.x - p.vx * 0.05, p.y - p.vy * 0.05)
          ctx.lineTo(p.x, p.y)
          ctx.stroke()
          break
        }
        case 'feather': {
          ctx.globalCompositeOperation = 'source-over'
          ctx.save()
          ctx.translate(p.x, p.y)
          ctx.rotate(p.rot + Math.sin(p.life * p.swaySp + p.seed) * 0.5)
          ctx.fillStyle = `rgba(248,250,252,${Math.min(1, k * 1.3)})`
          ctx.beginPath()
          ctx.ellipse(0, 0, p.size, p.size * 0.3, 0, 0, Math.PI * 2)
          ctx.fill()
          ctx.strokeStyle = `rgba(203,213,225,${k * 0.5})`
          ctx.lineWidth = 0.8
          ctx.beginPath()
          ctx.moveTo(-p.size, 0)
          ctx.lineTo(p.size, 0)
          ctx.stroke()
          ctx.restore()
          break
        }
        case 'rock': {
          ctx.globalCompositeOperation = 'source-over'
          ctx.save()
          ctx.translate(p.x, p.y)
          ctx.rotate(p.rot)
          ctx.fillStyle = `hsla(28,22%,${p.light}%,${Math.min(1, k * 1.5)})`
          ctx.beginPath()
          ctx.moveTo(-p.size, p.size * 0.5)
          ctx.lineTo(-p.size * 0.4, -p.size)
          ctx.lineTo(p.size * 0.6, -p.size * 0.7)
          ctx.lineTo(p.size, p.size * 0.4)
          ctx.closePath()
          ctx.fill()
          ctx.restore()
          break
        }
        case 'shard': {
          ctx.globalCompositeOperation = 'lighter'
          ctx.save()
          ctx.translate(p.x, p.y)
          ctx.rotate(p.rot)
          ctx.fillStyle = `hsla(${p.hue},${p.sat}%,${p.light}%,${k * 0.85})`
          ctx.beginPath()
          ctx.moveTo(0, -p.size)
          ctx.lineTo(p.size * 0.45, -p.size * 0.2)
          ctx.lineTo(p.size * 0.1, p.size)
          ctx.closePath()
          ctx.fill()
          ctx.restore()
          break
        }
        case 'butterfly': {
          ctx.globalCompositeOperation = 'source-over'
          ctx.save()
          ctx.translate(p.x, p.y)
          const face = p.vx >= 0 ? 1 : -1
          ctx.scale(face, 1)
          const flap = 0.35 + 0.65 * Math.abs(Math.sin(p.life * 10 + p.seed))
          ctx.fillStyle = `hsla(${p.hue},85%,68%,${Math.min(1, k * 1.7)})`
          // upper wings
          ctx.beginPath()
          ctx.moveTo(0, 0)
          ctx.quadraticCurveTo(-p.size * 0.9 * flap, -p.size * 0.9, -p.size * 0.2 * flap, -p.size * 0.98)
          ctx.quadraticCurveTo(-p.size * 0.5 * flap, -p.size * 0.25, 0, 0)
          ctx.fill()
          ctx.beginPath()
          ctx.moveTo(0, 0)
          ctx.quadraticCurveTo(p.size * 0.9 * flap, -p.size * 0.9, p.size * 0.2 * flap, -p.size * 0.98)
          ctx.quadraticCurveTo(p.size * 0.5 * flap, -p.size * 0.25, 0, 0)
          ctx.fill()
          // lower wings
          ctx.fillStyle = `hsla(${p.hue + 14},80%,62%,${Math.min(1, k * 1.5)})`
          ctx.beginPath()
          ctx.moveTo(0, 0)
          ctx.quadraticCurveTo(-p.size * 0.62 * flap, p.size * 0.5, -p.size * 0.14 * flap, p.size * 0.72)
          ctx.quadraticCurveTo(-p.size * 0.3 * flap, p.size * 0.2, 0, 0)
          ctx.fill()
          ctx.beginPath()
          ctx.moveTo(0, 0)
          ctx.quadraticCurveTo(p.size * 0.62 * flap, p.size * 0.5, p.size * 0.14 * flap, p.size * 0.72)
          ctx.quadraticCurveTo(p.size * 0.3 * flap, p.size * 0.2, 0, 0)
          ctx.fill()
          // body
          ctx.fillStyle = 'rgba(30,27,75,0.85)'
          ctx.beginPath()
          ctx.ellipse(0, 0, p.size * 0.08, p.size * 0.42, 0, 0, Math.PI * 2)
          ctx.fill()
          ctx.restore()
          break
        }
      }
    }
    ctx.restore()
    ctx.globalCompositeOperation = 'source-over'
  }
}

export function drawHeart(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, color: string) {
  ctx.save()
  ctx.translate(x, y)
  ctx.scale(s / 10, s / 10)
  ctx.fillStyle = color
  ctx.beginPath()
  ctx.moveTo(0, 3.2)
  ctx.bezierCurveTo(-5.6, -1.6, -3.4, -6, 0, -3)
  ctx.bezierCurveTo(3.4, -6, 5.6, -1.6, 0, 3.2)
  ctx.fill()
  ctx.restore()
}

/* ==========================================================================
   Weather — a thin manager that keeps spawning the right particles.
   Intensity eases in and out so weather never pops.
   ========================================================================== */

export class WeatherSystem {
  kind: WeatherKind = null
  private nextKind: WeatherKind = null
  intensity = 0
  private t = 0
  private isDaylight = false

  set(kind: WeatherKind) {
    if (kind === this.kind) return
    this.nextKind = kind
    if (this.kind === null) {
      this.kind = kind
      this.intensity = 0
    }
  }

  clear() {
    this.nextKind = null
  }

  setDaylight(v: boolean) {
    this.isDaylight = v
  }

  /** instant reset — used by clearWorld */
  reset() {
    this.kind = null
    this.nextKind = null
    this.intensity = 0
  }

  active(): WeatherKind {
    return this.kind
  }

  update(dt: number, w: number, h: number, ps: ParticleSystem, cap: number, wind: number) {
    this.t += dt
    // transitions
    if (this.nextKind !== this.kind) {
      this.intensity -= dt * 0.55
      if (this.intensity <= 0) {
        this.intensity = 0
        this.kind = this.nextKind
      }
    } else if (this.kind !== null) {
      this.intensity = Math.min(1, this.intensity + dt * 0.45)
    }
    if (!this.kind || this.intensity <= 0) return

    const k = this.kind
    const inten = this.intensity
    const budget = Math.floor(cap * inten)

    // spawn rates per kind (particles per second)
    let rate = 0
    let spawnOne: () => void = () => {}
    const R = (a: number, b: number) => a + Math.random() * (b - a)

    switch (k) {
      case 'rain':
        rate = 160
        spawnOne = () => ps.spawn('raindrop', {
          x: R(-60, w + 60), y: R(-80, -10),
          vx: wind * 60 + R(-8, 8), vy: R(620, 860),
          maxLife: 3, size: R(3, 7),
        })
        break
      case 'snow':
        rate = 60
        spawnOne = () => ps.spawn('snow', {
          x: R(-40, w + 40), y: -12,
          vx: wind * 30 + R(-16, 16), vy: R(36, 84),
          maxLife: 14, size: R(1.2, 3.4),
          sway: R(14, 42), swaySp: R(0.4, 1.2), wf: 1,
        })
        break
      case 'storm':
        rate = 200
        spawnOne = () => ps.spawn('raindrop', {
          x: R(-80, w + 80), y: R(-80, -10),
          vx: wind * 120 + R(10, 50), vy: R(760, 980),
          maxLife: 3, size: R(4, 8),
        })
        break
      case 'fog':
        rate = 2.2
        spawnOne = () => ps.spawn('cloud', {
          x: R(-100, w + 100), y: R(h * 0.45, h * 1.05),
          vx: wind * 26 + R(4, 14), vy: R(-3, 2),
          maxLife: R(9, 16), size: R(26, 60),
        })
        break
      case 'leaves':
        rate = 9
        spawnOne = () => ps.spawn('leaf', {
          x: R(-40, w + 40), y: -12,
          vx: wind * 40 + R(-20, 20), vy: R(30, 70),
          maxLife: 16, size: R(3, 7),
          hue: R(16, 42), sat: 70, light: 55,
          sway: R(20, 46), swaySp: R(0.5, 1.4),
          vrot: R(-2, 2), wf: 1, gf: -0.04,
        })
        break
      case 'petals':
        rate = 10
        spawnOne = () => ps.spawn('petal', {
          x: R(-40, w + 40), y: -12,
          vx: wind * 34 + R(-14, 14), vy: R(26, 62),
          maxLife: 18, size: R(3.4, 7),
          hue: R(328, 348), sat: 80, light: 80,
          sway: R(18, 40), swaySp: R(0.5, 1.2),
          vrot: R(-2.4, 2.4), wf: 1, gf: -0.05,
        })
        break
      case 'bubbles':
        rate = 8
        spawnOne = () => ps.spawn('bubble', {
          x: R(0, w), y: h + 14,
          vx: R(-14, 14), vy: R(-70, -26),
          maxLife: 14, size: R(2.6, 8),
          hue: 195, sway: R(10, 26), swaySp: R(0.6, 1.6), gf: -0.06,
        })
        break
      case 'embers':
        rate = 14
        spawnOne = () => ps.spawn('ember', {
          x: R(0, w), y: h + 8,
          vx: R(-20, 20), vy: R(-90, -40),
          maxLife: R(2.5, 5), size: R(1.6, 3.6),
          hue: R(14, 38), gf: -0.1, wf: 1, sway: R(8, 22), swaySp: R(0.6, 1.6),
        })
        break
      case 'starfall':
        rate = 5
        spawnOne = () => {
          const x = R(w * 0.05, w * 0.95)
          ps.spawn('streak', {
            x, y: R(-30, h * 0.3),
            vx: R(-120, -60) * (Math.random() < 0.5 ? 1 : -1), vy: R(140, 260),
            maxLife: 1.1, size: R(6, 13), hue: R(190, 280),
          })
          ps.spawn('spark', {
            x, y: R(-30, h * 0.3),
            vx: R(-90, 90), vy: R(110, 220),
            maxLife: R(0.8, 1.4), size: R(1.6, 3.4), hue: R(200, 280), light: 88,
          })
        }
        break
      case 'confetti':
        rate = 26
        spawnOne = () => ps.spawn('confetti', {
          x: R(0, w), y: -10,
          vx: R(-30, 30), vy: R(60, 140),
          maxLife: 12, size: R(3.4, 6.4),
          hue: [265, 200, 330, 45, 150][Math.floor(Math.random() * 5)] + R(-8, 8),
          gf: 0.05, wf: 1.2, vrot: R(-7, 7), sway: R(6, 16), swaySp: R(1.5, 3),
        })
        break
      case 'fireflies':
        rate = 3
        spawnOne = () => ps.spawn('firefly', {
          x: R(0, w), y: R(h * 0.35, h * 0.95),
          vx: R(-24, 24), vy: R(-18, 10),
          maxLife: R(7, 13), size: R(1.6, 3),
        })
        break
      case 'hearts':
        rate = 6
        spawnOne = () => ps.spawn('heart', {
          x: R(w * 0.1, w * 0.9), y: h + 16,
          vx: R(-16, 16), vy: R(-64, -30),
          maxLife: 12, size: R(5, 11), hue: R(335, 350),
          gf: -0.04, sway: R(10, 26), swaySp: R(0.6, 1.4),
        })
        break
      case 'sparks':
        rate = 22
        spawnOne = () => ps.spawn('spark', {
          x: R(0, w), y: R(0, h),
          vx: R(-160, 160), vy: R(-160, 160),
          maxLife: R(0.5, 1.1), size: R(1.4, 3),
          hue: [265, 200, 45, 330][Math.floor(Math.random() * 4)], light: 78,
        })
        break
      case 'dust':
        rate = 18
        spawnOne = () => ps.spawn('dust', {
          x: wind >= 0 ? -14 : w + 14, y: R(h * 0.2, h * 0.98),
          vx: wind * 220 + R(60, 160) * (wind >= 0 ? 1 : -1), vy: R(-8, 22),
          maxLife: 6, size: R(1.2, 3),
        })
        break
      case 'clouds':
        rate = 1.4
        spawnOne = () => ps.spawn('cloud', {
          x: -120, y: R(h * 0.08, h * 0.4),
          vx: R(16, 34) + wind * 20, vy: 0,
          maxLife: R(30, 50), size: R(30, 64), hue: this.isDaylight ? 40 : 240,
        })
        break
      case 'butterflies':
        rate = 2.4
        spawnOne = () => ps.spawn('butterfly', {
          x: R(0, w), y: R(h * 0.25, h * 0.85),
          vx: R(-30, 30) + wind * 20, vy: R(-26, -8),
          maxLife: R(8, 14), size: R(5, 9),
          hue: [340, 265, 200, 32][Math.floor(Math.random() * 4)],
          sway: R(12, 28), swaySp: R(0.6, 1.2), gf: -0.015,
        })
        break
      case 'matrix':
        rate = 12
        spawnOne = () => ps.spawn('glyph', {
          x: Math.floor(R(0, w / 22)) * 22, y: -20,
          vx: 0, vy: R(70, 170),
          maxLife: R(4, 8), size: R(6, 10),
        })
        break
    }

    const target = rate * dt
    const n = Math.min(budget * 0.02, target)
    const count = Math.floor(n) + (Math.random() < n % 1 ? 1 : 0)
    for (let i = 0; i < count; i++) spawnOne()
  }
}
