import {
  type SceneRenderer, type SceneFrameState,
  clamp01, lerp, easeOut, srand, glowCircle, labelChip, roundRectPath,
} from './types'

/* ==========================================================================
   Lifecycle — four stage pods: egg → larva → chrysalis → adult.
   butterfly | frog variants.
   ========================================================================== */

const STAGE_NAMES: Record<string, string[]> = {
  butterfly: ['egg', 'caterpillar', 'chrysalis', 'butterfly'],
  frog: ['eggs', 'tadpole', 'froglet', 'frog'],
}

export class LifecycleScene implements SceneRenderer {
  private variant: string
  private stage = 0          // 0..3
  private stageT = 0
  private t = 0
  private fliers: Array<{ x: number; y: number; a: number; sp: number; hue: number; size: number }> = []
  private hopers: Array<{ x: number; y: number; vy: number; phase: number }> = []

  constructor(variant: string) {
    this.variant = variant === 'frog' ? 'frog' : 'butterfly'
  }

  enter() {
    this.stage = 0
    this.stageT = 0
    this.fliers = []
    this.hopers = []
  }

  private advance() {
    this.stage = (this.stage + 1) % 4
    this.stageT = 0
    if (this.stage === 3) {
      this.fliers = []
      this.hopers = []
      for (let i = 0; i < 5; i++) {
        this.fliers.push({
          x: Math.random(), y: 0.3 + Math.random() * 0.3,
          a: Math.random() * Math.PI * 2, sp: lerp(0.35, 0.7, Math.random()),
          hue: this.variant === 'frog' ? 100 : lerp(260, 320, Math.random()), size: lerp(0.7, 1.2, Math.random()),
        })
      }
      this.hopers.push({ x: 0.5, y: 0, vy: 0, phase: 0 })
    }
  }

  update(s: SceneFrameState) {
    this.t += s.dt
    this.stageT += s.dt * (s.params.speed ?? 1)
    if (this.stageT > 7) this.advance()
    for (const f of this.fliers) {
      f.a += s.dt * f.sp
      f.x = clamp01(f.x + Math.cos(f.a) * s.dt * 0.05)
      f.y = Math.max(0.15, Math.min(0.72, 0.45 + Math.sin(f.a * 1.3 + f.hue * 0.01) * 0.18))
    }
    for (const hp of this.hopers) {
      hp.phase += s.dt
      hp.vy += 560 * s.dt
      hp.y += hp.vy * s.dt
      if (hp.y > 0) { hp.y = 0; hp.vy = this.variant === 'frog' ? -320 : -240 }
    }
    void s
  }

  /** the four pods' centres */
  private pods(w: number, h: number) {
    const y = h * 0.5
    const inset = Math.min(w * 0.16, 130)
    const gap = (w - inset * 2) / 3
    return [0, 1, 2, 3].map((i) => ({ x: inset + gap * i, y }))
  }

  draw(ctx: CanvasRenderingContext2D, s: SceneFrameState) {
    const { w, h } = s
    const names = STAGE_NAMES[this.variant]
    const pods = this.pods(w, h)
    const R = Math.min(gapPod(w) * 0.42, h * 0.2)

    // connecting line
    ctx.save()
    ctx.strokeStyle = 'rgba(255,255,255,0.08)'
    ctx.lineWidth = 2
    ctx.setLineDash([2, 8])
    ctx.beginPath()
    ctx.moveTo(pods[0].x + R, pods[0].y)
    ctx.lineTo(pods[3].x - R, pods[3].y)
    ctx.stroke()
    ctx.setLineDash([])
    ctx.restore()

    pods.forEach((p, i) => {
      const active = i === this.stage
      const done = i < this.stage
      const k = active ? easeOut(Math.min(1, this.stageT / 0.6)) : 1

      // pod glow
      if (active) {
        glowCircle(ctx, p.x, p.y, R * 1.9, 'rgba(139,92,246,0.14)', 'rgba(139,92,246,0)')
      }

      // stage disc
      ctx.save()
      ctx.globalAlpha = active ? 1 : done ? 0.75 : 0.38
      ctx.beginPath()
      ctx.arc(p.x, p.y, R, 0, Math.PI * 2)
      ctx.fillStyle = active ? 'rgba(30,26,52,0.9)' : 'rgba(18,16,34,0.72)'
      ctx.fill()
      ctx.strokeStyle = active ? 'rgba(167,139,250,0.6)' : done ? 'rgba(94,234,212,0.4)' : 'rgba(255,255,255,0.1)'
      ctx.lineWidth = active ? 2 : 1.2
      ctx.stroke()
      ctx.restore()

      // stage content
      ctx.save()
      ctx.translate(p.x, p.y)
      this.drawStageContent(ctx, i, k, active)
      ctx.restore()

      // labels
      labelChip(ctx, p.x, p.y + R + 24, names[i], active ? 'rgba(221,214,254,0.98)' : 'rgba(255,255,255,0.4)')
      if (done) {
        ctx.fillStyle = 'rgba(94,234,212,0.9)'
        ctx.font = '700 13px Inter, system-ui'
        ctx.textAlign = 'center'
        ctx.fillText('✓', p.x + R * 0.78, p.y - R * 0.72)
      }
    })

    if (this.stage === 3) {
      labelChip(ctx, w * 0.5, h * 0.16, 'the adult — the cycle begins again with new eggs', 'rgba(167,243,208,0.95)')
    }
  }

  private drawStageContent(ctx: CanvasRenderingContext2D, stage: number, k: number, active: boolean) {
    const t = this.t
    if (this.variant === 'butterfly') {
      if (stage === 0) {
        // leaf with egg cluster
        ctx.fillStyle = 'rgba(74,160,110,0.9)'
        ctx.beginPath()
        ctx.ellipse(0, 16, 26, 11, -0.4, 0, Math.PI * 2)
        ctx.fill()
        ctx.strokeStyle = 'rgba(30,90,60,0.8)'
        ctx.lineWidth = 1
        ctx.beginPath()
        ctx.moveTo(-22, 20)
        ctx.lineTo(22, 12)
        ctx.stroke()
        for (let i = 0; i < 5; i++) {
          const a = i * 1.4 - 2.8
          const ex = Math.cos(a) * 9
          const ey = 8 + Math.sin(a) * 5
          const pulse = active ? 1 + Math.sin(t * 3 + i) * 0.08 : 1
          ctx.fillStyle = 'rgba(240,230,200,0.95)'
          ctx.beginPath()
          ctx.ellipse(ex, ey, 3.4 * pulse, 4.4 * pulse, 0.3, 0, Math.PI * 2)
          ctx.fill()
        }
      } else if (stage === 1) {
        // caterpillar with segments
        const crawl = Math.sin(t * 2.4) * 3
        const segs = 6
        for (let i = 0; i < segs; i++) {
          const sx = -18 + i * 7 + crawl * (i / segs)
          const sy = 6 + Math.sin(t * 4 + i * 0.9) * 2.4
          const r = lerp(5.5, 3.4, i / segs)
          ctx.fillStyle = `hsla(${95 + i * 6}, 55%, ${52 - i * 2}%, 0.95)`
          ctx.beginPath()
          ctx.arc(sx, sy, r, 0, Math.PI * 2)
          ctx.fill()
        }
        // head
        ctx.fillStyle = 'hsla(88, 60%, 42%, 0.95)'
        ctx.beginPath()
        ctx.arc(-22 + crawl * 0.2, 5, 6, 0, Math.PI * 2)
        ctx.fill()
        ctx.fillStyle = '#1a1a26'
        ctx.beginPath()
        ctx.arc(-25 + crawl * 0.2, 3, 1.2, 0, Math.PI * 2)
        ctx.fill()
        // munching a leaf edge
        ctx.fillStyle = 'rgba(74,160,110,0.75)'
        ctx.beginPath()
        ctx.ellipse(26, 12, 12, 5, -0.3, 0, Math.PI * 2)
        ctx.fill()
      } else if (stage === 2) {
        // chrysalis hanging
        ctx.strokeStyle = 'rgba(120,100,90,0.7)'
        ctx.lineWidth = 1.4
        ctx.beginPath()
        ctx.moveTo(0, -26)
        ctx.lineTo(0, -14)
        ctx.stroke()
        const wig = Math.sin(t * 1.8) * 2.4
        const wingK = clamp01((this.stageT - 2.5) / 3)
        ctx.save()
        ctx.translate(wig, 0)
        const g = ctx.createLinearGradient(0, -14, 0, 18)
        g.addColorStop(0, 'rgba(96,200,150,0.9)')
        g.addColorStop(1, 'rgba(40,110,90,0.9)')
        ctx.fillStyle = g
        ctx.beginPath()
        ctx.ellipse(0, 2, 8.5, 15, 0, 0, Math.PI * 2)
        ctx.fill()
        // wing pattern fading in inside
        if (wingK > 0) {
          ctx.globalAlpha = wingK * 0.85
          ctx.fillStyle = 'rgba(196,132,252,0.9)'
          ctx.beginPath()
          ctx.ellipse(-2.5, 0, 4, 7, 0.4, 0, Math.PI * 2)
          ctx.fill()
          ctx.beginPath()
          ctx.ellipse(2.5, 4, 3.4, 6, -0.4, 0, Math.PI * 2)
          ctx.fill()
          ctx.globalAlpha = 1
        }
        // gold dots — real chrysalids have them!
        ctx.fillStyle = 'rgba(250,204,21,0.95)'
        for (let i = 0; i < 3; i++) {
          ctx.beginPath()
          ctx.arc(-6 + i * 6, -8 + Math.abs(i - 1) * 3, 1.1, 0, Math.PI * 2)
          ctx.fill()
        }
        ctx.restore()
      } else {
        // adult butterfly — flapping
        this.drawButterfly(ctx, 0, 0, 1.4, t, 300)
      }
    } else {
      // frog
      if (stage === 0) {
        // spawn mass in water
        ctx.fillStyle = 'rgba(60,120,150,0.35)'
        ctx.beginPath()
        ctx.ellipse(0, 10, 30, 12, 0, 0, Math.PI * 2)
        ctx.fill()
        for (let i = 0; i < 8; i++) {
          const a = i * 0.9 - 3.4
          const ex = Math.cos(a) * 16
          const ey = 10 + Math.sin(a) * 6
          const pulse = active ? 1 + Math.sin(t * 2.4 + i) * 0.1 : 1
          ctx.fillStyle = 'rgba(30,50,60,0.85)'
          ctx.beginPath()
          ctx.arc(ex, ey, 2.6 * pulse, 0, Math.PI * 2)
          ctx.fill()
          // pale core
          ctx.fillStyle = 'rgba(200,230,235,0.5)'
          ctx.beginPath()
          ctx.arc(ex, ey, 1 * pulse, 0, Math.PI * 2)
          ctx.fill()
        }
      } else if (stage === 1) {
        // tadpole — wiggling tail
        const swim = Math.sin(t * 3.4) * 5
        ctx.save()
        ctx.translate(swim, 0)
        ctx.fillStyle = 'rgba(40,70,72,0.92)'
        ctx.beginPath()
        ctx.ellipse(6, 0, 8, 5.4, 0, 0, Math.PI * 2)
        ctx.fill()
        ctx.strokeStyle = 'rgba(40,70,72,0.85)'
        ctx.lineWidth = 3
        ctx.lineCap = 'round'
        ctx.beginPath()
        ctx.moveTo(0, 0)
        ctx.quadraticCurveTo(-10, Math.sin(t * 7) * 6, -20, Math.sin(t * 7 + 1) * 4)
        ctx.stroke()
        ctx.fillStyle = 'rgba(220,240,240,0.7)'
        ctx.beginPath()
        ctx.arc(9, -1.4, 1.2, 0, Math.PI * 2)
        ctx.fill()
        ctx.restore()
      } else if (stage === 2) {
        // froglet — legs budding, tail shrinking
        const tailK = clamp01(1 - (this.stageT - 1.5) / 4)
        ctx.fillStyle = 'rgba(66,124,84,0.95)'
        ctx.beginPath()
        ctx.ellipse(0, 4, 9, 7, 0, 0, Math.PI * 2)
        ctx.fill()
        // legs
        const kick = Math.sin(t * 4) * 0.3
        ctx.strokeStyle = 'rgba(56,108,74,0.95)'
        ctx.lineWidth = 3.4
        ctx.lineCap = 'round'
        for (const side of [-1, 1]) {
          ctx.beginPath()
          ctx.moveTo(-3, 7)
          ctx.lineTo(-9 + kick * 3, 12 * side * 0 + 13 + kick * 2)
          ctx.stroke()
          void side
        }
        if (tailK > 0.05) {
          ctx.lineWidth = 3 * tailK
          ctx.beginPath()
          ctx.moveTo(-8, 5)
          ctx.quadraticCurveTo(-14, 5 + Math.sin(t * 6) * 4 * tailK, -18, 5)
          ctx.stroke()
        }
        ctx.fillStyle = '#fff'
        for (const ex of [-3, 3]) {
          ctx.beginPath()
          ctx.arc(ex, 0, 2.4, 0, Math.PI * 2)
          ctx.fill()
          ctx.fillStyle = '#141a20'
          ctx.beginPath()
          ctx.arc(ex, 0, 1.1, 0, Math.PI * 2)
          ctx.fill()
          ctx.fillStyle = '#fff'
        }
      } else {
        // adult frog — periodic hop handled by hopers overlay; pod shows sitting frog
        ctx.fillStyle = 'rgba(74,138,92,0.96)'
        ctx.beginPath()
        ctx.ellipse(0, 8, 12, 9, 0, 0, Math.PI * 2)
        ctx.fill()
        // legs folded
        ctx.strokeStyle = 'rgba(60,116,78,0.96)'
        ctx.lineWidth = 4.4
        ctx.lineCap = 'round'
        for (const side of [-1, 1]) {
          ctx.beginPath()
          ctx.moveTo(side * 5, 12)
          ctx.lineTo(side * 11, 17)
          ctx.stroke()
        }
        // eyes
        for (const ex of [-5, 5]) {
          ctx.fillStyle = '#f4f8f4'
          ctx.beginPath()
          ctx.arc(ex, -1, 3.4, 0, Math.PI * 2)
          ctx.fill()
          ctx.fillStyle = '#141a20'
          ctx.beginPath()
          ctx.arc(ex * 1.08, -1, 1.5, 0, Math.PI * 2)
          ctx.fill()
        }
        // mouth
        ctx.strokeStyle = 'rgba(30,60,40,0.6)'
        ctx.lineWidth = 1.4
        ctx.beginPath()
        ctx.arc(0, 6, 7, 0.25, Math.PI - 0.25)
        ctx.stroke()
      }
    }
    void k
  }

  private drawButterfly(ctx: CanvasRenderingContext2D, x: number, y: number, scale: number, t: number, hue: number) {
    const flap = Math.sin(t * 6)
    ctx.save()
    ctx.translate(x, y)
    ctx.scale(scale, scale)
    // wings (two pairs)
    for (const side of [-1, 1]) {
      ctx.save()
      ctx.scale(1, 1)
      ctx.rotate(side * flap * 0.25)
      ctx.fillStyle = `hsla(${hue}, 70%, 66%, 0.92)`
      ctx.beginPath()
      ctx.moveTo(0, 0)
      ctx.quadraticCurveTo(side * 14, -14, side * 17, -2)
      ctx.quadraticCurveTo(side * 13, 2, 0, 3)
      ctx.closePath()
      ctx.fill()
      ctx.fillStyle = `hsla(${hue + 25}, 70%, 60%, 0.9)`
      ctx.beginPath()
      ctx.moveTo(0, 3)
      ctx.quadraticCurveTo(side * 12, 4, side * 10, 12)
      ctx.quadraticCurveTo(side * 5, 10, 0, 6)
      ctx.closePath()
      ctx.fill()
      ctx.restore()
    }
    // body
    ctx.fillStyle = 'rgba(40,34,50,0.95)'
    ctx.beginPath()
    ctx.ellipse(0, 2, 1.8, 7, 0, 0, Math.PI * 2)
    ctx.fill()
    // antennae
    ctx.strokeStyle = 'rgba(40,34,50,0.8)'
    ctx.lineWidth = 1
    for (const side of [-1, 1]) {
      ctx.beginPath()
      ctx.moveTo(0, -4)
      ctx.quadraticCurveTo(side * 4, -10, side * 6, -12)
      ctx.stroke()
    }
    ctx.restore()
  }

  pointerDown(s: SceneFrameState) {
    const pods = this.pods(s.w, s.h)
    const R = Math.min(gapPod(s.w) * 0.42, s.h * 0.2)
    for (let i = 0; i < 4; i++) {
      if (Math.hypot(s.pointer.x - pods[i].x, s.pointer.y - pods[i].y) < R + 18) {
        this.stage = i
        this.stageT = 0
        if (i === 3 && this.fliers.length === 0) this.advance()
        return i
      }
    }
    return null
  }

  trigger(id: string, s: SceneFrameState) {
    if (id === 'next') { this.advance(); return true }
    if (id === 'restart') { this.stage = 0; this.stageT = 0; this.fliers = []; this.hopers = []; return true }
    void s
    return false
  }
}

function gapPod(w: number) {
  const inset = Math.min(w * 0.16, 130)
  return (w - inset * 2) / 3
}

/* ==========================================================================
   Plant — seed → root → shoot → leaves → flower, with photosynthesis flows.
   photosynthesis | germination variants.
   ========================================================================== */

interface Mote { p: number; lane: number; speed: number; dir: 1 | -1 }

export class PlantScene implements SceneRenderer {
  private variant: string
  private growth = 0        // 0 seed … 1 full bloom
  private t = 0
  private co2: Mote[] = []
  private o2: Mote[] = []
  private sugar: Mote[] = []
  private waterUp: Mote[] = []
  private bloomT = -1

  constructor(variant: string) {
    this.variant = variant === 'germination' ? 'germination' : 'photosynthesis'
  }

  enter() {
    this.growth = this.variant === 'germination' ? 0 : 0.25
    this.co2 = []
    this.o2 = []
    this.sugar = []
    this.waterUp = []
    this.bloomT = -1
  }

  private get maxGrowth() {
    return this.variant === 'germination' ? 0.62 : 1
  }

  update(s: SceneFrameState) {
    this.t += s.dt
    const sun = (s.params.sunlight ?? 1) * (s.fire ? 1.5 : 1)
    const water = s.params.water ?? 1
    const rate = 0.012 + sun * water * 0.02
    const droop = sun <= 0.05 ? 0.15 : 0
    this.growth = Math.min(this.maxGrowth, this.growth + s.dt * rate * (1 - droop))

    // photosynthesis traffic only when there are leaves and light
    const leafK = clamp01((this.growth - 0.25) / 0.3)
    if (this.variant === 'photosynthesis' && leafK > 0.2 && sun > 0.1) {
      const n = sun * leafK
      if (Math.random() < s.dt * 2.4 * n * s.quality) this.co2.push({ p: 0, lane: Math.random(), speed: lerp(0.3, 0.5, Math.random()), dir: 1 })
      if (Math.random() < s.dt * 2.2 * n * s.quality) this.o2.push({ p: 0, lane: Math.random(), speed: lerp(0.35, 0.55, Math.random()), dir: -1 })
      if (Math.random() < s.dt * 1.8 * n * s.quality) this.sugar.push({ p: 0, lane: Math.random(), speed: lerp(0.22, 0.4, Math.random()), dir: -1 })
    }
    if (water > 0.1 && Math.random() < s.dt * 2 * water * s.quality) {
      this.waterUp.push({ p: 0, lane: Math.random(), speed: lerp(0.25, 0.45, Math.random()), dir: 1 })
    }
    const step = (arr: Mote[]) => {
      for (let i = arr.length - 1; i >= 0; i--) {
        arr[i].p += s.dt * arr[i].speed * (0.6 + sun * 0.4)
        if (arr[i].p >= 1) arr.splice(i, 1)
      }
    }
    step(this.co2); step(this.o2); step(this.sugar); step(this.waterUp)

    if (this.bloomT >= 0) this.bloomT += s.dt
  }

  /** plant anchor points */
  private plantGeom(s: SceneFrameState) {
    const baseX = s.w * 0.5
    const soilY = s.h * 0.74
    const h = (s.h * 0.34) * easeOut(this.growth / this.maxGrowth) * 1.0
    return { baseX, soilY, h }
  }

  draw(ctx: CanvasRenderingContext2D, s: SceneFrameState) {
    const { w, h } = s
    const sun = (s.params.sunlight ?? 1) * (s.fire ? 1.5 : 1)
    const water = s.params.water ?? 1
    const { baseX, soilY, h: plantH } = this.plantGeom(s)
    const sunX = w * 0.14
    const sunY = h * 0.16

    // sun
    const sunA = 0.25 + sun * 0.32
    glowCircle(ctx, sunX, sunY, 54 + sun * 26, `rgba(255,214,120,${sunA})`, 'rgba(255,160,60,0)')
    if (sun > 0.05) {
      ctx.fillStyle = '#ffd98a'
      ctx.beginPath()
      ctx.arc(sunX, sunY, 16, 0, Math.PI * 2)
      ctx.fill()
    } else {
      // clouded sun
      ctx.fillStyle = 'rgba(160,160,180,0.5)'
      ctx.beginPath()
      ctx.arc(sunX, sunY, 15, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = 'rgba(120,124,150,0.8)'
      ctx.beginPath()
      ctx.ellipse(sunX + 10, sunY + 2, 22, 10, 0, 0, Math.PI * 2)
      ctx.fill()
    }
    labelChip(ctx, sunX, sunY - 40, sun <= 0.05 ? 'no light — the plant waits' : 'light in', 'rgba(253,224,130,0.95)')

    // soil
    const sg = ctx.createLinearGradient(0, soilY, 0, h)
    sg.addColorStop(0, 'rgba(66,50,44,0.95)')
    sg.addColorStop(1, 'rgba(26,20,20,0.98)')
    ctx.fillStyle = sg
    ctx.beginPath()
    ctx.moveTo(0, soilY)
    for (let x = 0; x <= w; x += 20) ctx.lineTo(x, soilY + Math.sin(x * 0.03) * 3)
    ctx.lineTo(w, h)
    ctx.lineTo(0, h)
    ctx.closePath()
    ctx.fill()
    // moisture hint
    labelChip(ctx, w * 0.82, soilY + 30, water < 0.15 ? 'dry soil' : `soil water ${(water * 100).toFixed(0)}%`, 'rgba(147,197,253,0.9)')

    const stemTop = soilY - plantH
    const droopK = sun <= 0.05 ? 0.5 : 0
    const wiltK = water < 0.15 ? 0.6 : 0
    const lean = droopK * 0.5 + wiltK * 0.3

    // root system (visible in cross-section)
    ctx.save()
    ctx.globalAlpha = 0.5
    ctx.strokeStyle = 'rgba(214,196,180,0.7)'
    ctx.lineWidth = 1.4
    const rootH = 24 + easeOut(this.growth) * 30
    for (let i = -2; i <= 2; i++) {
      ctx.beginPath()
      ctx.moveTo(baseX, soilY + 2)
      ctx.quadraticCurveTo(baseX + i * 9, soilY + rootH * 0.5, baseX + i * 15, soilY + rootH * (1 - Math.abs(i) * 0.14))
      ctx.stroke()
    }
    ctx.restore()

    // seed / stem / leaves
    if (this.growth < 0.14) {
      // swollen seed
      const sw = 1 + this.growth * 2.4
      ctx.fillStyle = 'rgba(164,124,84,0.96)'
      ctx.beginPath()
      ctx.ellipse(baseX, soilY - 6, 8 * sw, 11 * sw, 0.2, 0, Math.PI * 2)
      ctx.fill()
      ctx.strokeStyle = 'rgba(120,86,56,0.8)'
      ctx.lineWidth = 1
      ctx.beginPath()
      ctx.ellipse(baseX, soilY - 6, 8 * sw, 11 * sw, 0.2, 0, Math.PI * 2)
      ctx.stroke()
    } else {
      // stem
      ctx.strokeStyle = '#4a8f5c'
      ctx.lineWidth = 4 + this.growth * 3
      ctx.lineCap = 'round'
      ctx.beginPath()
      ctx.moveTo(baseX, soilY)
      ctx.quadraticCurveTo(baseX + lean * 26, soilY - plantH * 0.55, baseX + lean * 40, stemTop)
      ctx.stroke()
      // leaves appear with growth
      const leafCount = Math.floor(clamp01((this.growth - 0.18) / 0.12)) + (this.variant === 'photosynthesis' ? 1 : 0)
      for (let i = 0; i < Math.min(4, leafCount); i++) {
        const lk = clamp01((this.growth - 0.18 - i * 0.12) / 0.1)
        if (lk <= 0) continue
        const side = i % 2 === 0 ? -1 : 1
        const ly = soilY - plantH * (0.32 + i * 0.16)
        const lx = baseX + lean * 26 * ((ly - stemTop) / plantH) * 0.8
        const ll = (16 + i * 4) * easeOut(lk)
        ctx.save()
        ctx.translate(lx, ly)
        ctx.rotate(side * (0.5 + droopK * 0.7))
        const lg = ctx.createLinearGradient(0, 0, ll, 0)
        const dry = wiltK > 0.3 || sun <= 0.05
        lg.addColorStop(0, dry ? 'rgba(150,150,90,0.95)' : 'rgba(88,178,108,0.96)')
        lg.addColorStop(1, dry ? 'rgba(120,130,70,0.9)' : 'rgba(56,140,84,0.95)')
        ctx.fillStyle = lg
        ctx.beginPath()
        ctx.moveTo(0, 0)
        ctx.quadraticCurveTo(ll * 0.5, -ll * 0.42, ll, 0)
        ctx.quadraticCurveTo(ll * 0.5, ll * 0.42, 0, 0)
        ctx.fill()
        ctx.strokeStyle = 'rgba(30,90,52,0.5)'
        ctx.lineWidth = 0.8
        ctx.beginPath()
        ctx.moveTo(0, 0)
        ctx.lineTo(ll * 0.92, 0)
        ctx.stroke()
        ctx.restore()
      }
      // flower at full growth (photosynthesis variant)
      if (this.variant === 'photosynthesis' && this.growth > 0.86) {
        const fk = clamp01((this.growth - 0.86) / 0.14)
        const fx = baseX + lean * 40
        const petals = 6
        for (let i = 0; i < petals; i++) {
          const a = (i / petals) * Math.PI * 2 + this.t * 0.1
          ctx.fillStyle = `rgba(244,${Math.floor(140 + fk * 60)},190,${0.85 * fk})`
          ctx.save()
          ctx.translate(fx, stemTop)
          ctx.rotate(a)
          ctx.beginPath()
          ctx.ellipse(0, -9 * fk, 4.4 * fk, 9 * fk, 0, 0, Math.PI * 2)
          ctx.fill()
          ctx.restore()
        }
        ctx.fillStyle = '#fde68a'
        ctx.beginPath()
        ctx.arc(fx, stemTop, 4.4 * fk, 0, Math.PI * 2)
        ctx.fill()
      }
    }

    // CO₂ motes drifting in
    ctx.save()
    for (const m of this.co2) {
      const x = lerp(w * 0.86, baseX + 14, m.p) + Math.sin(m.p * 7 + m.lane * 9) * 8
      const y = lerp(h * 0.3, stemTop + 26, m.p)
      ctx.fillStyle = 'rgba(160,170,185,0.75)'
      ctx.beginPath()
      ctx.arc(x, y, 3, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = 'rgba(200,210,225,0.4)'
      ctx.font = '700 7px Inter'
      ctx.fillText('CO₂', x - 7, y - 6)
    }
    // O₂ released
    for (const m of this.o2) {
      const x = baseX - 14 + Math.sin(m.p * 8 + m.lane * 7) * 10
      const y = lerp(stemTop + 20, h * 0.12, m.p)
      ctx.fillStyle = 'rgba(150,220,250,0.8)'
      ctx.beginPath()
      ctx.arc(x, y, 2.4, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = 'rgba(190,235,255,0.5)'
      ctx.font = '700 7px Inter'
      ctx.fillText('O₂', x - 6, y - 5)
    }
    // sugar flowing down
    for (const m of this.sugar) {
      const x = baseX + 6 + Math.sin(m.p * 6 + m.lane * 5) * 3
      const y = lerp(stemTop + 16, soilY - 8, m.p)
      ctx.fillStyle = 'rgba(250,204,21,0.9)'
      ctx.beginPath()
      ctx.arc(x, y, 1.8, 0, Math.PI * 2)
      ctx.fill()
    }
    // water rising
    for (const m of this.waterUp) {
      const x = baseX - 5 + Math.sin(m.p * 9 + m.lane * 4) * 2.6
      const y = lerp(soilY + 6, stemTop + 30, m.p)
      ctx.fillStyle = 'rgba(110,180,240,0.8)'
      ctx.beginPath()
      ctx.arc(x, y, 1.7, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.restore()

    // labels for the flows
    if (this.variant === 'photosynthesis' && this.growth > 0.4) {
      labelChip(ctx, w * 0.8, h * 0.24, 'CO₂ in', 'rgba(203,213,225,0.9)', 'right')
      labelChip(ctx, baseX - 60, h * 0.16, 'O₂ out', 'rgba(147,197,253,0.9)', 'right')
      labelChip(ctx, baseX + 66, h * 0.52, 'sugar down', 'rgba(253,224,130,0.9)')
      labelChip(ctx, baseX - 60, soilY - 20, 'water up', 'rgba(147,197,253,0.9)', 'right')
    }
  }

  pointerDown(s: SceneFrameState) {
    const { baseX, soilY } = this.plantGeom(s)
    // sun
    if (Math.hypot(s.pointer.x - s.w * 0.14, s.pointer.y - s.h * 0.16) < 58) return 0
    // leaves / stem
    if (Math.abs(s.pointer.x - baseX) < 90 && s.pointer.y > s.h * 0.3 && s.pointer.y < soilY) return 1
    // soil / roots
    if (s.pointer.y >= soilY) return 2
    return null
  }

  trigger(id: string, s: SceneFrameState) {
    if (id === 'bloom') {
      this.growth = Math.min(this.maxGrowth, this.growth + 0.3)
      this.bloomT = 0
      return true
    }
    if (id === 'cloud') {
      // temporary cloud pass — handled by params from UI; here we pulse
      void s
      return true
    }
    if (id === 'water') return true // UI adjusts param
    if (id === 'restart') {
      this.enter()
      return true
    }
    return false
  }
}

/* ==========================================================================
   Creature — bird | whale | dinosaur, with perform actions.
   ========================================================================== */

export class CreatureScene implements SceneRenderer {
  private variant: string
  private t = 0
  private cxP = 0.5
  private cyP = 0.4
  private performT = -1
  private flock: Array<{ ox: number; oy: number; phase: number; scale: number }> = []
  private walkPhase = 0
  private dustT = 0
  private singT = -1

  constructor(variant: string) {
    this.variant = variant === 'whale' ? 'whale' : variant === 'dinosaur' ? 'dinosaur' : 'bird'
  }

  enter() {
    this.t = 0
    this.performT = -1
    this.flock = []
    for (let i = 0; i < 5; i++) {
      this.flock.push({ ox: (i - 2) * 0.075, oy: Math.abs(i - 2) * 0.035, phase: i * 1.3, scale: 0.7 + (1 - Math.abs(i - 2) / 3) * 0.4 })
    }
  }

  update(s: SceneFrameState) {
    this.t += s.dt
    const energy = (s.params.energy ?? 1) * (s.wind ? 1.25 : 1)
    this.walkPhase += s.dt * (this.variant === 'dinosaur' ? 1.6 * energy : 0)

    // the creature patrols gently
    this.cxP = 0.5 + Math.sin(this.t * 0.16 * energy) * 0.18
    this.cyP =
      this.variant === 'bird' ? 0.34 + Math.sin(this.t * 0.4 * energy) * 0.05
        : this.variant === 'whale' ? 0.52 + Math.sin(this.t * 0.22 * energy) * 0.08
          : 0.62

    if (this.performT >= 0) {
      this.performT += s.dt
      if (this.performT > 2.4) this.performT = -1
    }
    if (this.singT >= 0) {
      this.singT += s.dt
      if (this.singT > 3) this.singT = -1
    }

    // dinosaur footfall dust
    if (this.variant === 'dinosaur') {
      this.dustT -= s.dt
      if (this.dustT <= 0 && this.performT < 0) {
        this.dustT = 0.85 / Math.max(0.2, energy)
        s.emit('dust', {
          x: this.cxP * s.w + (Math.sin(this.walkPhase * 3) > 0 ? -18 : 20),
          y: s.h * 0.78,
          vx: (Math.random() - 0.5) * 40, vy: -Math.random() * 26,
          maxLife: 0.9, size: lerp(2, 4.5, Math.random()), hue: 30,
        })
      }
    }
  }

  draw(ctx: CanvasRenderingContext2D, s: SceneFrameState) {
    const { w, h } = s
    const energy = s.params.energy ?? 1

    if (this.variant === 'bird') this.drawBirdWorld(ctx, s, energy)
    else if (this.variant === 'whale') this.drawWhaleWorld(ctx, s, energy)
    else this.drawDinosaurWorld(ctx, s, energy)
  }

  private drawBirdWorld(ctx: CanvasRenderingContext2D, s: SceneFrameState, energy: number) {
    const { w, h } = s
    // distant ridges
    ctx.fillStyle = 'rgba(30,30,54,0.55)'
    ctx.beginPath()
    ctx.moveTo(0, h * 0.66)
    for (let x = 0; x <= w; x += 30) ctx.lineTo(x, h * 0.66 - Math.sin(x * 0.006) * 30 - srand(Math.floor(x / 30)) * 18)
    ctx.lineTo(w, h)
    ctx.lineTo(0, h)
    ctx.fill()

    // flock companions
    this.flock.forEach((f, i) => {
      if (i === 2) return // centre slot is the hero
      const fx = (this.cxP + f.ox) * w
      const fy = (this.cyP + f.oy) * h + Math.sin(this.t * 1.4 + f.phase) * 8
      this.drawBird(ctx, fx, fy, 13 * f.scale, this.t * (5 + energy * 3) + f.phase, '#b9c8e8')
    })
    // hero bird
    const bx = this.cxP * w
    const by = this.cyP * h + (this.performT >= 0 ? -Math.sin(clamp01(this.performT / 2.4) * Math.PI) * h * 0.16 : 0)
    this.drawBird(ctx, bx, by, 20, this.t * (6 + energy * 3), '#e8eefc')
    glowCircle(ctx, bx, by, 44, 'rgba(147,197,253,0.12)', 'rgba(147,197,253,0)')

    labelChip(ctx, w * 0.5, h * 0.14, this.performT >= 0 ? 'a dive!' : 'hollow bones, feathered wings', 'rgba(221,214,254,0.95)')
  }

  private drawBird(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, t: number, color: string) {
    const flap = Math.sin(t)
    ctx.save()
    ctx.translate(x, y)
    ctx.fillStyle = color
    // body
    ctx.beginPath()
    ctx.ellipse(0, 0, size, size * 0.34, 0.06, 0, Math.PI * 2)
    ctx.fill()
    // wings
    for (const side of [-1, 1]) {
      ctx.save()
      ctx.rotate(side * flap * 0.6)
      ctx.beginPath()
      ctx.moveTo(0, -2)
      ctx.quadraticCurveTo(side * size * 0.4, -size * 0.9, side * size * 1.25, -size * 0.45)
      ctx.quadraticCurveTo(side * size * 0.65, -size * 0.05, 0, 2)
      ctx.closePath()
      ctx.fill()
      ctx.restore()
    }
    // tail
    ctx.beginPath()
    ctx.moveTo(-size * 0.85, 0)
    ctx.lineTo(-size * 1.5, -size * 0.22)
    ctx.lineTo(-size * 1.5, size * 0.22)
    ctx.closePath()
    ctx.fill()
    // beak
    ctx.fillStyle = 'rgba(250,200,110,0.95)'
    ctx.beginPath()
    ctx.moveTo(size * 0.9, -1)
    ctx.lineTo(size * 1.4, 1.4)
    ctx.lineTo(size * 0.9, 3)
    ctx.closePath()
    ctx.fill()
    // eye
    ctx.fillStyle = '#10131f'
    ctx.beginPath()
    ctx.arc(size * 0.5, -size * 0.08, size * 0.07, 0, Math.PI * 2)
    ctx.fill()
    ctx.restore()
  }

  private drawWhaleWorld(ctx: CanvasRenderingContext2D, s: SceneFrameState, energy: number) {
    const { w, h } = s
    // water body
    const wg = ctx.createLinearGradient(0, h * 0.2, 0, h)
    wg.addColorStop(0, 'rgba(18,52,88,0.55)')
    wg.addColorStop(1, 'rgba(6,20,44,0.9)')
    ctx.fillStyle = wg
    ctx.fillRect(0, h * 0.2, w, h * 0.8)
    // light shafts
    ctx.save()
    ctx.globalCompositeOperation = 'lighter'
    for (let i = 0; i < 4; i++) {
      const rx = w * (0.2 + i * 0.22) + Math.sin(this.t * 0.3 + i) * 20
      const g = ctx.createLinearGradient(rx, h * 0.2, rx + 50, h * 0.85)
      g.addColorStop(0, 'rgba(110,180,225,0.07)')
      g.addColorStop(1, 'rgba(110,180,225,0)')
      ctx.fillStyle = g
      ctx.beginPath()
      ctx.moveTo(rx - 10, h * 0.2)
      ctx.lineTo(rx + 16, h * 0.2)
      ctx.lineTo(rx + 70, h * 0.85)
      ctx.lineTo(rx - 40, h * 0.85)
      ctx.closePath()
      ctx.fill()
    }
    ctx.restore()

    // whale
    const wx = this.cxP * w
    const wy = this.cyP * h
    const breachK = this.performT >= 0 ? Math.sin(clamp01(this.performT / 2.4) * Math.PI) : 0
    const wyEff = wy - breachK * h * 0.3
    ctx.save()
    ctx.translate(wx, wyEff)
    ctx.rotate(Math.sin(this.t * 0.5) * 0.05 - breachK * 0.5)
    const S = 1 + breachK * 0.1
    ctx.scale(S, S)
    // body
    const bg = ctx.createLinearGradient(0, -34, 0, 34)
    bg.addColorStop(0, 'rgba(70,96,130,0.98)')
    bg.addColorStop(0.55, 'rgba(48,68,100,0.98)')
    bg.addColorStop(1, 'rgba(180,200,220,0.9)')
    ctx.fillStyle = bg
    ctx.beginPath()
    ctx.moveTo(-110, 4)
    ctx.quadraticCurveTo(-40, -40, 60, -26)
    ctx.quadraticCurveTo(112, -12, 118, 0)
    ctx.quadraticCurveTo(96, 18, 40, 26)
    ctx.quadraticCurveTo(-60, 34, -110, 4)
    ctx.closePath()
    ctx.fill()
    // tail fluke (oscillates)
    const fl = Math.sin(this.t * (1.4 + energy * 1.2))
    ctx.save()
    ctx.translate(-108, 2)
    ctx.rotate(fl * 0.28)
    ctx.fillStyle = 'rgba(58,80,114,0.98)'
    ctx.beginPath()
    ctx.moveTo(0, 0)
    ctx.quadraticCurveTo(-34, -26, -56, -30)
    ctx.quadraticCurveTo(-38, -8, -40, 0)
    ctx.quadraticCurveTo(-38, 8, -56, 30)
    ctx.quadraticCurveTo(-34, 26, 0, 0)
    ctx.closePath()
    ctx.fill()
    ctx.restore()
    // fin
    ctx.fillStyle = 'rgba(52,74,108,0.95)'
    ctx.beginPath()
    ctx.moveTo(10, 18)
    ctx.quadraticCurveTo(-4, 48, -26, 52)
    ctx.quadraticCurveTo(-8, 28, 4, 20)
    ctx.closePath()
    ctx.fill()
    // eye + mouth line
    ctx.fillStyle = '#0c1220'
    ctx.beginPath()
    ctx.arc(88, -4, 2.6, 0, Math.PI * 2)
    ctx.fill()
    ctx.strokeStyle = 'rgba(20,30,50,0.5)'
    ctx.lineWidth = 1.6
    ctx.beginPath()
    ctx.moveTo(100, 4)
    ctx.quadraticCurveTo(70, 12, 44, 10)
    ctx.stroke()
    ctx.restore()

    // bubbles
    if (Math.random() < 0.12) {
      s.emit('splash', { x: wx + 90, y: wyEff - 10, vx: 10, vy: -40, maxLife: 1.6, size: 2.4, hue: 195 })
    }
    // breach splash
    if (this.performT >= 0 && this.performT < 0.5) {
      for (let i = 0; i < 8; i++) {
        s.emit('splash', {
          x: wx + (Math.random() - 0.5) * 120, y: h * 0.42,
          vx: (Math.random() - 0.5) * 160, vy: -Math.random() * 220,
          maxLife: 0.9, size: lerp(2, 4, Math.random()), hue: 200,
        })
      }
    }
    // song rings
    if (this.singT >= 0) {
      const k = (this.singT % 1)
      ctx.save()
      ctx.strokeStyle = `rgba(140,200,240,${0.4 * (1 - k)})`
      ctx.lineWidth = 1.6
      ctx.beginPath()
      ctx.arc(wx, wyEff, 60 + k * 190, 0, Math.PI * 2)
      ctx.stroke()
      ctx.restore()
      labelChip(ctx, w * 0.5, h * 0.12, 'song — carrying for hundreds of kilometres', 'rgba(186,230,253,0.95)')
    } else {
      labelChip(ctx, w * 0.5, h * 0.12, breachK > 0.1 ? 'breach!' : 'a mammal, breathing air', 'rgba(186,230,253,0.95)')
    }
  }

  private drawDinosaurWorld(ctx: CanvasRenderingContext2D, s: SceneFrameState, energy: number) {
    const { w, h } = s
    const groundY = h * 0.78
    // prehistoric ridges
    for (const layer of [0, 1]) {
      ctx.fillStyle = layer === 0 ? 'rgba(38,42,60,0.7)' : 'rgba(26,30,46,0.85)'
      ctx.beginPath()
      ctx.moveTo(0, h * (0.55 + layer * 0.1))
      for (let x = 0; x <= w; x += 40) {
        ctx.lineTo(x, h * (0.5 + layer * 0.12) - Math.sin(x * 0.004 + layer * 2) * 40 - srand(Math.floor(x / 40) + layer * 9) * 26)
      }
      ctx.lineTo(w, h)
      ctx.lineTo(0, h)
      ctx.fill()
    }
    // ground
    const gg = ctx.createLinearGradient(0, groundY, 0, h)
    gg.addColorStop(0, 'rgba(60,56,52,0.95)')
    gg.addColorStop(1, 'rgba(24,22,24,0.98)')
    ctx.fillStyle = gg
    ctx.fillRect(0, groundY, w, h - groundY)

    // the dinosaur — a striding theropod
    const dx = this.cxP * w
    const roarK = this.performT >= 0 ? Math.sin(clamp01(this.performT / 2.4) * Math.PI) : 0
    const bob = Math.sin(this.walkPhase * 3) * 4
    ctx.save()
    ctx.translate(dx, groundY - 78 + bob)
    ctx.rotate(Math.sin(this.walkPhase * 1.5) * 0.02)
    const bodyG = ctx.createLinearGradient(0, -40, 0, 40)
    bodyG.addColorStop(0, 'rgba(94,110,84,0.98)')
    bodyG.addColorStop(1, 'rgba(52,66,52,0.98)')
    ctx.fillStyle = bodyG
    // body
    ctx.beginPath()
    ctx.ellipse(0, 0, 46, 30, -0.08, 0, Math.PI * 2)
    ctx.fill()
    // tail
    ctx.beginPath()
    ctx.moveTo(-36, -6)
    ctx.quadraticCurveTo(-86, -18 + Math.sin(this.t * 1.8) * 8, -124, -26 + Math.sin(this.t * 1.8) * 10)
    ctx.quadraticCurveTo(-84, 4, -34, 16)
    ctx.closePath()
    ctx.fill()
    // neck + head
    ctx.save()
    ctx.translate(34, -18)
    ctx.rotate(-0.5 + roarK * 0.5)
    ctx.beginPath()
    ctx.moveTo(-6, 10)
    ctx.quadraticCurveTo(16, -26, 34, -40)
    ctx.lineTo(46, -32)
    ctx.quadraticCurveTo(28, -14, 16, 14)
    ctx.closePath()
    ctx.fill()
    // jaw opens on roar
    ctx.fillStyle = 'rgba(44,56,44,0.98)'
    ctx.save()
    ctx.translate(40, -36)
    ctx.rotate(roarK * 0.5)
    ctx.beginPath()
    ctx.moveTo(0, 0)
    ctx.lineTo(22, 6)
    ctx.lineTo(2, 8)
    ctx.closePath()
    ctx.fill()
    ctx.restore()
    // eye
    ctx.fillStyle = '#f8e8a0'
    ctx.beginPath()
    ctx.arc(30, -34, 3.2, 0, Math.PI * 2)
    ctx.fill()
    ctx.fillStyle = '#181c14'
    ctx.beginPath()
    ctx.arc(31, -34, 1.5, 0, Math.PI * 2)
    ctx.fill()
    ctx.restore()
    // legs — striding
    ctx.strokeStyle = 'rgba(56,70,56,0.98)'
    ctx.lineWidth = 11
    ctx.lineCap = 'round'
    for (const side of [-1, 1]) {
      const phase = this.walkPhase * 3 + (side > 0 ? Math.PI : 0)
      const swing = Math.sin(phase)
      const lift = Math.max(0, Math.cos(phase))
      ctx.beginPath()
      ctx.moveTo(side * 14, 14)
      ctx.lineTo(side * 14 + swing * 22, 48)
      ctx.lineTo(side * 14 + swing * 30, 78 - lift * 12)
      ctx.stroke()
      // foot
      ctx.lineWidth = 7
      ctx.beginPath()
      ctx.moveTo(side * 14 + swing * 30, 78 - lift * 12)
      ctx.lineTo(side * 14 + swing * 30 + 14, 80 - lift * 12)
      ctx.stroke()
      ctx.lineWidth = 11
    }
    // little arms
    ctx.lineWidth = 6
    ctx.beginPath()
    ctx.moveTo(24, -2)
    ctx.lineTo(36, 8 + Math.sin(this.t * 2) * 2)
    ctx.stroke()
    ctx.restore()

    // roar shockwave
    if (roarK > 0.1) {
      ctx.save()
      ctx.strokeStyle = `rgba(250,204,120,${roarK * 0.5})`
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.arc(dx + 70, groundY - 128, 20 + roarK * 60, 0, Math.PI * 2)
      ctx.stroke()
      ctx.restore()
    }

    labelChip(ctx, w * 0.5, h * 0.12, roarK > 0.2 ? 'ROAR' : '165 million years of walking', 'rgba(221,214,254,0.95)')
  }

  pointerDown(s: SceneFrameState) {
    const cx = this.cxP * s.w
    const cy =
      this.variant === 'bird' ? this.cyP * s.h
        : this.variant === 'whale' ? this.cyP * s.h
          : s.h * 0.72
    if (Math.hypot(s.pointer.x - cx, s.pointer.y - cy) < 130) {
      this.performT = 0
      if (this.variant === 'whale') this.singT = 0
      return this.variant === 'bird' ? 2 : 0
    }
    return 3 // habitat fact
  }

  trigger(id: string, s: SceneFrameState) {
    if (id === 'perform') { this.performT = 0; return true }
    if (id === 'dive') { this.performT = 0; return true }
    if (id === 'song') { this.singT = 0; return true }
    if (id === 'stampede') {
      for (let i = 0; i < Math.floor(10 * s.quality); i++) {
        s.emit('dust', {
          x: Math.random() * s.w, y: s.h * 0.79,
          vx: (Math.random() - 0.5) * 120, vy: -Math.random() * 60,
          maxLife: lerp(0.8, 1.6, Math.random()), size: lerp(2.5, 5, Math.random()), hue: 30,
        })
      }
      this.walkPhase += 2
      return true
    }
    return false
  }
}
