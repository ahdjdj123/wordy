import type { SceneKind } from '../../knowledge/types'
import type { SceneRenderer, SceneFrameState } from './types'
import { VolcanoScene, WaterCycleScene, WeatherScene, OceanScene } from './physical'
import { LifecycleScene, PlantScene, CreatureScene } from './life'
import { OrbitalScene, AtomScene, FieldScene, TimelineScene, GearsScene } from './minds'

/* ==========================================================================
   The scene system — owns the active world renderer, its parameters and
   its enter/exit fades. The engine drives it once per frame.
   ========================================================================== */

export type { SceneRenderer, SceneFrameState } from './types'

export interface ActiveScene {
  kind: SceneKind
  variant: string
  renderer: SceneRenderer
}

export function createRenderer(kind: SceneKind, config: Record<string, unknown> = {}): SceneRenderer {
  const variant = typeof config.variant === 'string' ? config.variant : ''
  switch (kind) {
    case 'volcano': return new VolcanoScene()
    case 'watercycle': return new WaterCycleScene()
    case 'weather': return new WeatherScene(variant)
    case 'ocean': return new OceanScene(variant)
    case 'lifecycle': return new LifecycleScene(variant)
    case 'plant': return new PlantScene(variant)
    case 'creature': return new CreatureScene(variant)
    case 'orbital': return new OrbitalScene(variant)
    case 'atom': return new AtomScene(variant)
    case 'field': return new FieldScene(variant)
    case 'timeline': return new TimelineScene(variant)
    case 'gears': return new GearsScene(variant)
    default: return new FieldScene('calm')
  }
}

export class SceneSystem {
  active: ActiveScene | null = null
  params: Record<string, number> = {}
  /** 0 → 1 enter fade; -1 → 0 exit fade */
  fade = 0
  fadingOut = false
  private t = 0
  /** fired when the UI should surface a fact (hotspot tap) */
  onFact: ((factIndex: number) => void) | null = null

  set(kind: SceneKind, config: Record<string, unknown> = {}, params: Record<string, number> = {}, w = 800, h = 600) {
    if (this.active && this.active.kind === kind && this.variantOf(this.active) === String(config.variant ?? '')) {
      // same world re-entered — just refresh params
      this.params = { ...params }
      this.fadingOut = false
      return
    }
    this.dispose()
    const renderer = createRenderer(kind, config)
    try {
      renderer.enter(w, h)
    } catch {
      /* a scene must never take the world down */
    }
    this.active = { kind, variant: String(config.variant ?? ''), renderer }
    this.params = { ...params }
    this.fade = 0
    this.fadingOut = false
    this.t = 0
  }

  private variantOf(a: ActiveScene) {
    return a.variant
  }

  clear() {
    if (!this.active) return
    this.fadingOut = true
    this.fade = 1
  }

  private dispose() {
    if (this.active?.renderer.dispose) {
      try { this.active.renderer.dispose() } catch { /* ignore */ }
    }
    this.active = null
    this.fade = 0
    this.fadingOut = false
  }

  setParams(params: Record<string, number>) {
    this.params = { ...params }
  }

  setParam(key: string, value: number) {
    this.params = { ...this.params, [key]: value }
  }

  trigger(id: string, s: Omit<SceneFrameState, 't' | 'dt' | 'params'>): boolean {
    if (!this.active) return false
    try {
      return this.active.renderer.trigger(id, { ...s, t: this.t, dt: 1 / 60, params: this.params } as SceneFrameState)
    } catch {
      return false
    }
  }

  pointerDown(s: Omit<SceneFrameState, 't' | 'dt' | 'params'>): number | null {
    if (!this.active) return null
    try {
      return this.active.renderer.pointerDown({ ...s, t: this.t, dt: 1 / 60, params: this.params } as SceneFrameState)
    } catch {
      return null
    }
  }

  update(base: Omit<SceneFrameState, 't' | 'dt' | 'params'>, dt: number) {
    if (!this.active) return
    this.t += dt
    if (this.fadingOut) {
      this.fade -= dt * 2.4
      if (this.fade <= 0) this.dispose()
      return
    }
    if (this.fade < 1) this.fade = Math.min(1, this.fade + dt * 2.2)
    try {
      this.active.renderer.update({ ...base, t: this.t, dt, params: this.params } as SceneFrameState)
    } catch {
      /* keep the world alive even if a scene hiccups */
    }
  }

  draw(ctx: CanvasRenderingContext2D, base: Omit<SceneFrameState, 't' | 'dt' | 'params'>, dt: number) {
    if (!this.active || this.fade <= 0.01) return
    ctx.save()
    ctx.globalAlpha = Math.max(0, Math.min(1, this.fade))
    try {
      this.active.renderer.draw(ctx, { ...base, t: this.t, dt, params: this.params } as SceneFrameState)
    } catch {
      /* drawing must never kill the loop */
    }
    ctx.restore()
  }
}
