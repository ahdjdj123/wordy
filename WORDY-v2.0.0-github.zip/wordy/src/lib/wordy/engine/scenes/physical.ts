import {
  type SceneRenderer, type SceneFrameState,
  clamp01, lerp, easeOut, srand, glowCircle, labelChip, flowArrow,
} from './types'

/* ==========================================================================
   Volcano — mountain, magma chamber, pressure, eruption.
   ========================================================================== */

interface LavaBomb { x: number; y: number; vx: number; vy: number; life: number; size: number; seed: number }
interface FlowBlob { p: number; lane: number; size: number; alpha: number }

export class VolcanoScene implements SceneRenderer {
  private pressure = 0.45
  private tremor = 0
  private erupting = 0        // 0..1 eruption progress envelope
  private eruptT = -1
  private bombs: LavaBomb[] = []
  private flows: FlowBlob[] = []
  private t = 0
  private mountainSeed = Math.random() * 100

  enter() {
    this.pressure = 0.45
    this.tremor = 0
    this.erupting = 0
    this.eruptT = -1
    this.bombs = []
    this.flows = []
  }

  private eruptionBurst(s: SceneFrameState) {
    const cx = s.w * 0.5
    const craterY = s.h * 0.46
    const n = Math.floor((46 + this.pressure * 60) * s.quality)
    for (let i = 0; i < n; i++) {
      const a = -Math.PI / 2 + (Math.random() - 0.5) * 1.5
      const v = lerp(220, 620, Math.random()) * (0.5 + this.pressure * 0.7)
      this.bombs.push({
        x: cx + (Math.random() - 0.5) * 26,
        y: craterY,
        vx: Math.cos(a) * v,
        vy: Math.sin(a) * v,
        life: 0,
        size: lerp(2, 6.5, Math.random()),
        seed: Math.random(),
      })
    }
    for (let i = 0; i < Math.floor(16 * s.quality); i++) {
      s.emit('cloud', {
        x: cx + (Math.random() - 0.5) * 60,
        y: craterY - Math.random() * 30,
        vx: (Math.random() - 0.5) * 40,
        vy: -lerp(50, 130, Math.random()),
        maxLife: lerp(3.5, 6.5, Math.random()),
        size: lerp(22, 52, Math.random()),
        hue: 20,
      })
    }
    for (let i = 0; i < Math.floor(20 * s.quality); i++) {
      s.emit('spark', {
        x: cx + (Math.random() - 0.5) * 30,
        y: craterY,
        vx: (Math.random() - 0.5) * 380,
        vy: -Math.random() * 480,
        maxLife: lerp(0.5, 1.2, Math.random()),
        size: lerp(1.6, 3.4, Math.random()),
        hue: 24,
        light: 80,
      })
    }
  }

  update(s: SceneFrameState) {
    this.t += s.dt
    // user pressure + fire element feeds the chamber; rain cools it
    const target = clamp01(s.params.pressure ?? 0.45)
    if (s.fire) this.pressure = clamp01(this.pressure + s.dt * 0.22)
    if (s.weather === 'rain' || s.weather === 'storm' || s.water) {
      this.pressure = clamp01(this.pressure - s.dt * 0.05)
    }
    this.pressure += (target - this.pressure) * Math.min(1, s.dt * 1.4)

    if (this.pressure >= 0.985 && this.eruptT < 0) this.eruptT = 0

    // tremor ramps as pressure climbs
    const wantTremor = this.pressure > 0.75 ? (this.pressure - 0.75) / 0.25 : 0
    this.tremor += (wantTremor - this.tremor) * Math.min(1, s.dt * 2)

    if (this.eruptT >= 0) {
      this.eruptT += s.dt
      this.erupting = Math.min(1, this.erupting + s.dt * 6)
      if (this.eruptT < 0.25 && this.bombs.length === 0) this.eruptionBurst(s)
      if (this.eruptT > 0.3 && this.eruptT < 2.2 && Math.random() < s.dt * 14 * s.quality) {
        // sustained column
        const cx = s.w * 0.5
        s.emit('spark', {
          x: cx + (Math.random() - 0.5) * 34,
          y: s.h * 0.46,
          vx: (Math.random() - 0.5) * 90,
          vy: -lerp(300, 560, Math.random()),
          maxLife: lerp(0.5, 1.1, Math.random()),
          size: lerp(1.6, 3.6, Math.random()),
          hue: 22, light: 70,
        })
      }
      if (this.eruptT > 1.1) {
        // start lava flows
        if (this.flows.length === 0) {
          this.flows.push({ p: 0, lane: 0.5 + Math.random() * 0.2, size: 9, alpha: 1 })
          this.flows.push({ p: 0, lane: -0.5 - Math.random() * 0.2, size: 7, alpha: 1 })
        }
        this.flows.forEach((f) => { f.p = Math.min(1, f.p + s.dt * 0.16) })
      }
      if (this.eruptT > 6.5) {
        this.eruptT = -1
        this.erupting = 0
        this.pressure = 0.25
      }
    }

    // bombs physics
    const ground = s.h * 0.8
    for (let i = this.bombs.length - 1; i >= 0; i--) {
      const b = this.bombs[i]
      b.vy += 900 * s.dt
      b.x += b.vx * s.dt
      b.y += b.vy * s.dt
      b.life += s.dt
      if (b.y > ground) {
        if (b.size > 4.5 && Math.random() < 0.6) {
          s.emit('spark', { x: b.x, y: ground, vx: (Math.random() - 0.5) * 120, vy: -Math.random() * 140, maxLife: 0.5, size: 2, hue: 20, light: 60 })
        }
        this.bombs.splice(i, 1)
      } else if (b.life > 4) this.bombs.splice(i, 1)
    }

    // idle embers from crater
    if (this.pressure > 0.35 && Math.random() < s.dt * 3 * this.pressure * s.quality) {
      s.emit('ember', {
        x: s.w * 0.5 + (Math.random() - 0.5) * 22,
        y: s.h * 0.47,
        vx: (Math.random() - 0.5) * 30,
        vy: -lerp(40, 90, Math.random()),
        maxLife: lerp(1.2, 2.2, Math.random()),
        size: lerp(1.4, 2.8, Math.random()),
        hue: lerp(16, 32, Math.random()),
        gf: -0.25,
      })
    }
  }

  private mountainPath(ctx: CanvasRenderingContext2D, w: number, h: number) {
    const cx = w * 0.5
    const peak = h * 0.45
    const base = h * 0.82
    const halfW = Math.min(w * 0.34, 330)
    ctx.beginPath()
    ctx.moveTo(cx - halfW, base)
    // jagged left ridge
    const pts = 7
    for (let i = 1; i <= pts; i++) {
      const k = i / (pts + 1)
      const x = cx - halfW + k * halfW * (i === pts ? 0.62 : 1) * (i <= pts ? 1 : 0)
      const ridge = peak + (base - peak) * Math.pow(k, 1.6) * (i === pts ? 0.18 : 0.55)
      const jag = (srand(this.mountainSeed + i) - 0.5) * 26
      ctx.lineTo(i === pts ? cx - 26 : x, ridge + jag)
    }
    // crater mouth
    ctx.lineTo(cx - 22, peak + 6)
    ctx.lineTo(cx - 12, peak - 4)
    ctx.lineTo(cx + 12, peak - 4)
    ctx.lineTo(cx + 22, peak + 6)
    // jagged right ridge (mirror-ish)
    for (let i = pts; i >= 1; i--) {
      const k = i / (pts + 1)
      const x = cx + halfW - k * halfW * 0.55
      const ridge = peak + (base - peak) * Math.pow(k, 1.8) * 0.5
      const jag = (srand(this.mountainSeed + 40 + i) - 0.5) * 24
      ctx.lineTo(x, ridge + jag)
    }
    ctx.lineTo(cx + halfW, base)
    ctx.closePath()
  }

  draw(ctx: CanvasRenderingContext2D, s: SceneFrameState) {
    const { w, h } = s
    const cx = w * 0.5
    const peak = h * 0.45
    const shakeX = this.tremor > 0 ? (Math.random() - 0.5) * this.tremor * 5 : 0
    const shakeY = this.tremor > 0 ? (Math.random() - 0.5) * this.tremor * 3 : 0

    // crater glow on the sky
    const glowK = 0.25 + this.pressure * 0.55 + this.erupting * 0.5
    ctx.save()
    ctx.globalCompositeOperation = 'lighter'
    glowCircle(ctx, cx + shakeX, peak - 30, 120 + glowK * 150,
      `rgba(255,120,40,${0.1 + glowK * 0.16})`, 'rgba(255,60,20,0)')
    ctx.restore()

    // mountain body
    ctx.save()
    ctx.translate(shakeX, shakeY)
    const g = ctx.createLinearGradient(cx, peak, cx, h * 0.82)
    g.addColorStop(0, '#2a2230')
    g.addColorStop(0.5, '#1c1826')
    g.addColorStop(1, '#12101c')
    this.mountainPath(ctx, w, h)
    ctx.fillStyle = g
    ctx.fill()
    ctx.strokeStyle = 'rgba(148,120,160,0.18)'
    ctx.lineWidth = 1.5
    ctx.stroke()

    // magma veins — brightness follows pressure
    const veinK = 0.25 + this.pressure * 0.75
    ctx.save()
    ctx.globalCompositeOperation = 'lighter'
    for (let v = 0; v < 3; v++) {
      const side = v === 0 ? 0 : v === 1 ? -1 : 1
      ctx.beginPath()
      ctx.moveTo(cx + side * 6, peak + 8)
      const segs = 5
      for (let i = 1; i <= segs; i++) {
        const k = i / segs
        const vx = cx + side * (18 + k * (60 + v * 34)) + (srand(this.mountainSeed + v * 9 + i) - 0.5) * 18
        const vy = peak + 8 + k * (h * 0.3)
        ctx.lineTo(vx, vy)
      }
      ctx.strokeStyle = `rgba(255,${Math.floor(90 + veinK * 60)},30,${0.14 + veinK * 0.4})`
      ctx.lineWidth = 1.6 + veinK * 2.6
      ctx.stroke()
    }
    ctx.restore()

    // crater mouth: lava lake
    const lakeGlow = 0.5 + this.pressure * 0.5
    ctx.save()
    ctx.globalCompositeOperation = 'lighter'
    glowCircle(ctx, cx, peak - 2, 26 + lakeGlow * 20,
      `rgba(255,${Math.floor(150 + lakeGlow * 70)},60,${0.55 * lakeGlow + 0.2})`, 'rgba(255,80,20,0)')
    ctx.restore()
    ctx.fillStyle = `rgba(255,${Math.floor(130 + Math.sin(this.t * 6) * 30)},50,${0.75})`
    ctx.beginPath()
    ctx.ellipse(cx, peak - 2, 13, 5.5, 0, 0, Math.PI * 2)
    ctx.fill()

    // lava flows down the slope
    if (this.flows.length > 0) {
      ctx.save()
      for (const f of this.flows) {
        const flowEase = easeOut(f.p)
        const fx0 = cx + f.lane * 18
        const fx1 = cx + f.lane * (150 + Math.abs(f.lane) * 130)
        const fy0 = peak + 6
        const fy1 = h * 0.8
        const grad = ctx.createLinearGradient(fx0, fy0, fx1, fy1)
        const hot = `rgba(255,${Math.floor(120 + 60 * (1 - flowEase))},40,${0.9 * f.alpha})`
        const cooled = `rgba(60,30,45,${0.8 * f.alpha})`
        grad.addColorStop(0, hot)
        grad.addColorStop(clamp01(flowEase * 0.6 + 0.1), hot)
        grad.addColorStop(1, cooled)
        ctx.strokeStyle = grad
        ctx.lineCap = 'round'
        ctx.lineWidth = f.size
        ctx.beginPath()
        ctx.moveTo(fx0, fy0)
        const midX = cx + f.lane * 90 + Math.sin(f.lane * 3 + this.t * 0.4) * 6
        ctx.quadraticCurveTo(midX, lerp(fy0, fy1, 0.5), lerp(fx0, fx1, flowEase), lerp(fy0, fy1, flowEase))
        ctx.stroke()
        // cooling crust at the leading edge
        if (flowEase > 0.2) {
          ctx.fillStyle = 'rgba(40,24,36,0.7)'
          ctx.beginPath()
          ctx.arc(lerp(fx0, fx1, flowEase), lerp(fy0, fy1, flowEase), f.size * 0.55, 0, Math.PI * 2)
          ctx.fill()
        }
      }
      ctx.restore()
    }

    // bombs
    for (const b of this.bombs) {
      const flick = 0.7 + Math.sin(b.life * 20 + b.seed * 9) * 0.3
      glowCircle(ctx, b.x, b.y, b.size * 3,
        `rgba(255,150,60,${0.25 * flick})`, 'rgba(255,80,20,0)')
      ctx.fillStyle = `rgba(255,${Math.floor(170 + flick * 50)},70,0.95)`
      ctx.beginPath()
      ctx.arc(b.x, b.y, b.size, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.restore()

    // ground
    const gg = ctx.createLinearGradient(0, h * 0.78, 0, h)
    gg.addColorStop(0, 'rgba(24,20,34,0.9)')
    gg.addColorStop(1, 'rgba(10,9,18,0.95)')
    ctx.fillStyle = gg
    ctx.fillRect(0, h * 0.78, w, h * 0.22)

    // annotations
    labelChip(ctx, cx, peak - 74, this.eruptT >= 0 ? 'eruption!' : `pressure ${(this.pressure * 100).toFixed(0)}%`,
      this.pressure > 0.75 ? 'rgba(252,165,165,0.95)' : 'rgba(196,181,253,0.9)')
    if (s.weather === 'rain' || s.weather === 'storm') {
      labelChip(ctx, cx + Math.min(w * 0.3, 210), peak + 30, 'rain cools the lava — steam', 'rgba(165,243,252,0.9)', 'center')
    }
  }

  pointerDown(s: SceneFrameState) {
    const cx = s.w * 0.5
    const peak = s.h * 0.45
    if (Math.hypot(s.pointer.x - cx, s.pointer.y - (peak - 10)) < 64) {
      this.eruptT = 0
      this.erupting = 0
      this.bombs = []
      this.flows = []
      this.pressure = 1
      return 0
    }
    // slope
    if (Math.abs(s.pointer.x - cx) < s.w * 0.3 && s.pointer.y > peak && s.pointer.y < s.h * 0.82) {
      return 1
    }
    return null
  }

  trigger(id: string, s: SceneFrameState) {
    if (id === 'erupt') {
      this.eruptT = 0
      this.erupting = 0
      this.bombs = []
      this.flows = []
      this.pressure = 1
      return true
    }
    if (id === 'ease') {
      this.pressure = Math.max(0.15, this.pressure - 0.3)
      this.eruptT = -1
      this.erupting = 0
      this.flows = []
      return true
    }
    return false
  }
}

/* ==========================================================================
   Water cycle — sun, sea, cloud, rain, river. A visible loop.
   ========================================================================== */

interface EvapDot { p: number; lane: number; speed: number }

export class WaterCycleScene implements SceneRenderer {
  private phase: 'evaporate' | 'condense' | 'rain' | 'collect' = 'evaporate'
  private phaseT = 0
  private cloudMass = 0.15
  private seaLevel = 0
  private drops: EvapDot[] = []
  private t = 0

  enter() {
    this.phase = 'evaporate'
    this.phaseT = 0
    this.cloudMass = 0.15
    this.seaLevel = 0
    this.drops = []
  }

  private nextPhase(s: SceneFrameState) {
    this.phaseT = 0
    if (this.phase === 'evaporate') this.phase = 'condense'
    else if (this.phase === 'condense') this.phase = 'rain'
    else if (this.phase === 'rain') this.phase = 'collect'
    else this.phase = 'evaporate'
    if (this.phase === 'evaporate') this.seaLevel = Math.max(-14, this.seaLevel - 5)
    void s
  }

  update(s: SceneFrameState) {
    this.t += s.dt
    const heat = s.params.heat ?? 1
    const hot = s.fire ? heat + 0.8 : heat
    this.phaseT += s.dt * (0.55 + hot * 0.5)

    if (this.phase === 'evaporate') {
      this.cloudMass = Math.min(1, this.cloudMass + s.dt * 0.12 * hot)
      // rising vapour dots
      if (Math.random() < s.dt * 5 * hot * s.quality) {
        this.drops.push({ p: 0, lane: Math.random(), speed: lerp(0.25, 0.42, Math.random()) })
      }
      if (this.cloudMass >= 1 && this.phaseT > 4) this.nextPhase(s)
    } else if (this.phase === 'condense') {
      this.cloudMass = Math.min(1.12, this.cloudMass + s.dt * 0.06)
      if (this.phaseT > 2.2) this.nextPhase(s)
    } else if (this.phase === 'rain') {
      this.cloudMass = Math.max(0.1, this.cloudMass - s.dt * 0.22)
      if (Math.random() < s.dt * 26 * s.quality) {
        const rx = s.w * 0.36 + Math.random() * s.w * 0.3
        s.emit('splash', {
          x: rx, y: s.h * 0.34 + Math.random() * 20,
          vx: (Math.random() - 0.5) * 20, vy: lerp(260, 380, Math.random()),
          maxLife: 0.7, size: lerp(1.4, 2.6, Math.random()), hue: 205,
        })
      }
      this.seaLevel = Math.min(18, this.seaLevel + s.dt * 1.4)
      if (this.cloudMass <= 0.14) this.nextPhase(s)
    } else {
      if (this.phaseT > 2.4) this.nextPhase(s)
    }

    for (let i = this.drops.length - 1; i >= 0; i--) {
      const d = this.drops[i]
      d.p += s.dt * d.speed * (0.6 + hot * 0.4)
      if (d.p >= 1) this.drops.splice(i, 1)
    }
  }

  draw(ctx: CanvasRenderingContext2D, s: SceneFrameState) {
    const { w, h } = s
    const seaTop = h * 0.74 + this.seaLevel * -1 * 0.4
    const sunX = w * 0.16
    const sunY = h * 0.2
    const cloudX = w * 0.5
    const cloudY = h * 0.3

    // sun (heat-intent)
    const heat = (s.params.heat ?? 1) * (s.fire ? 1.6 : 1)
    glowCircle(ctx, sunX, sunY, 46 + heat * 22, `rgba(255,214,120,${0.5 + heat * 0.2})`, 'rgba(255,160,60,0)')
    ctx.fillStyle = '#ffd98a'
    ctx.beginPath()
    ctx.arc(sunX, sunY, 17, 0, Math.PI * 2)
    ctx.fill()
    // rays
    ctx.save()
    ctx.strokeStyle = `rgba(255,206,120,${0.28 + heat * 0.2})`
    ctx.lineWidth = 2
    for (let i = 0; i < 10; i++) {
      const a = (i / 10) * Math.PI * 2 + this.t * 0.14
      ctx.beginPath()
      ctx.moveTo(sunX + Math.cos(a) * 24, sunY + Math.sin(a) * 24)
      ctx.lineTo(sunX + Math.cos(a) * (32 + heat * 8), sunY + Math.sin(a) * (32 + heat * 8))
      ctx.stroke()
    }
    ctx.restore()
    labelChip(ctx, sunX, sunY - 44, 'the sun powers it all', 'rgba(253,224,130,0.95)')

    // vapour rising
    ctx.save()
    for (const d of this.drops) {
      const x = w * 0.42 + d.lane * w * 0.2 + Math.sin(d.p * 9 + d.lane * 8) * 10
      const y = lerp(seaTop - 10, cloudY + 26, d.p)
      ctx.fillStyle = `rgba(190,225,245,${0.5 * (1 - d.p * 0.5)})`
      ctx.beginPath()
      ctx.arc(x, y, 2.2, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.restore()

    // cloud — grows with mass
    const m = this.cloudMass
    ctx.save()
    ctx.globalCompositeOperation = 'source-over'
    const cloudW = 60 + m * 90
    const puffs = 6
    for (let i = 0; i < puffs; i++) {
      const px = cloudX + (i / (puffs - 1) - 0.5) * cloudW
      const pr = lerp(16, 40, m) * (0.7 + srand(i * 3) * 0.5)
      const py = cloudY + Math.sin(this.t * 0.8 + i) * 4 + (i === 0 || i === puffs - 1 ? 8 : 0)
      const shade = this.phase === 'rain' ? 90 : 200
      const g = ctx.createRadialGradient(px, py - pr * 0.3, 0, px, py, pr)
      g.addColorStop(0, `rgba(${shade + 30},${shade + 34},${shade + 44},0.95)`)
      g.addColorStop(1, `rgba(${shade - 40},${shade - 34},${shade - 24},0.85)`)
      ctx.fillStyle = g
      ctx.beginPath()
      ctx.arc(px, py, pr, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.restore()
    const phaseLabel =
      this.phase === 'evaporate' ? 'evaporation'
        : this.phase === 'condense' ? 'condensation'
          : this.phase === 'rain' ? 'precipitation'
            : 'collection'
    labelChip(ctx, cloudX, cloudY - 56, phaseLabel, 'rgba(186,230,253,0.95)')

    // sea with animated waves
    const seaH = h - seaTop
    const sg = ctx.createLinearGradient(0, seaTop, 0, h)
    sg.addColorStop(0, 'rgba(30,84,130,0.92)')
    sg.addColorStop(1, 'rgba(10,28,54,0.96)')
    ctx.fillStyle = sg
    ctx.beginPath()
    ctx.moveTo(0, seaTop + 4)
    for (let x = 0; x <= w; x += 16) {
      const yv = seaTop + Math.sin(x * 0.02 + this.t * 1.4) * 4 + Math.sin(x * 0.008 - this.t * 0.8) * 3
      ctx.lineTo(x, yv)
    }
    ctx.lineTo(w, h)
    ctx.lineTo(0, h)
    ctx.closePath()
    ctx.fill()
    // glitter path under sun
    ctx.save()
    ctx.globalCompositeOperation = 'lighter'
    for (let i = 0; i < 12; i++) {
      const gy = seaTop + 8 + i * 5
      const gx = sunX + Math.sin(this.t * 1.8 + i * 1.7) * (10 + i * 3)
      ctx.fillStyle = `rgba(255,220,140,${0.24 - i * 0.016})`
      ctx.beginPath()
      ctx.ellipse(gx, gy, 14 - i * 0.7, 1.6, 0, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.restore()

    // river flowing back to sea during rain phase
    if (this.phase === 'rain' || this.phase === 'collect') {
      ctx.save()
      ctx.strokeStyle = 'rgba(120,180,225,0.5)'
      ctx.lineWidth = 6
      ctx.lineCap = 'round'
      ctx.beginPath()
      const rvX = w * 0.78
      ctx.moveTo(rvX, seaTop - 2)
      ctx.quadraticCurveTo(rvX - 26, seaTop - 40, rvX - 8, seaTop - 78)
      ctx.stroke()
      ctx.restore()
      flowArrow(ctx, w * 0.78 - 6, seaTop - 44, -Math.PI / 2.2, 16, 'rgba(186,230,253,0.6)')
    }

    // loop arrow annotation
    labelChip(ctx, w * 0.5, seaTop + 26, this.seaLevel > 4 ? 'the sea rises, then gives it back' : 'the same water, forever looping', 'rgba(147,197,253,0.9)')
  }

  pointerDown(s: SceneFrameState) {
    // sun
    if (Math.hypot(s.pointer.x - s.w * 0.16, s.pointer.y - s.h * 0.2) < 56) return 0
    // cloud
    if (Math.hypot(s.pointer.x - s.w * 0.5, s.pointer.y - s.h * 0.3) < 80) return 1
    // sea
    if (s.pointer.y > s.h * 0.7) return 2
    return null
  }

  trigger(id: string, s: SceneFrameState) {
    if (id === 'rain') {
      if (this.phase !== 'rain') { this.phase = 'rain'; this.phaseT = 0; this.cloudMass = 1; return true }
      return false
    }
    if (id === 'relax') {
      this.phase = 'collect'
      this.phaseT = 0
      return true
    }
    void s
    return false
  }
}

/* ==========================================================================
   Weather — tornado funnel / earthquake fault.
   ========================================================================== */

interface Debris { a: number; r: number; hgt: number; speed: number; size: number; hue: number }

export class WeatherScene implements SceneRenderer {
  private variant: string
  private funnelReach = 0      // 0 cloud-only, 1 touching ground
  private funnelTarget = 0
  private funnelSway = 0
  private debris: Debris[] = []
  private quakeEnergy = 0
  private quakeAmp = 0
  private t = 0
  private cracks: Array<{ x: number; seed: number; p: number }> = []

  constructor(variant: string) {
    this.variant = variant === 'earthquake' ? 'earthquake' : 'tornado'
  }

  enter() {
    this.funnelReach = this.variant === 'tornado' ? 0.35 : 0
    this.funnelTarget = this.variant === 'tornado' ? 0.35 : 0
    this.debris = []
    this.quakeEnergy = 0.3
    this.quakeAmp = 0
    this.cracks = []
  }

  update(s: SceneFrameState) {
    this.t += s.dt
    if (this.variant === 'tornado') {
      const shear = s.params.shear ?? 1
      // wind tightens the funnel
      const goal = clamp01(this.funnelTarget * (0.55 + shear * 0.3 + (s.wind ? 0.12 : 0)))
      this.funnelReach += (goal - this.funnelReach) * Math.min(1, s.dt * 1.6)
      this.funnelSway += s.dt * (0.6 + shear * 0.9)

      // debris at the base when touching ground
      if (this.funnelReach > 0.75 && this.debris.length < 26 * s.quality) {
        this.debris.push({
          a: Math.random() * Math.PI * 2,
          r: lerp(30, 70, Math.random()),
          hgt: Math.random() * 0.2,
          speed: lerp(2.4, 4.4, Math.random()) * (0.6 + shear * 0.5),
          size: lerp(1.6, 4.4, Math.random()),
          hue: lerp(28, 42, Math.random()),
        })
      }
      for (let i = this.debris.length - 1; i >= 0; i--) {
        const d = this.debris[i]
        d.a += s.dt * d.speed
        d.hgt += s.dt * 0.24
        d.r *= 1 - s.dt * 0.12
        if (d.hgt > 1 || d.r < 6) this.debris.splice(i, 1)
      }
    } else {
      // earthquake
      const stress = s.params.stress ?? 0.4
      this.quakeEnergy = clamp01(stress + (s.weather === 'storm' ? 0.1 : 0))
      const wantAmp = this.quakeActive ? 0.5 + this.quakeEnergy * 0.5 : this.quakeEnergy * 0.04
      this.quakeAmp += (wantAmp - this.quakeAmp) * Math.min(1, s.dt * 3)
      if (this.quakeActive) {
        this.quakeLeft -= s.dt
        if (Math.random() < s.dt * 8 * s.quality) {
          s.emit('dust', {
            x: this.faultX(s) + (Math.random() - 0.5) * 220,
            y: s.h * 0.74,
            vx: (Math.random() - 0.5) * 90, vy: -Math.random() * 70,
            maxLife: lerp(0.7, 1.4, Math.random()), size: lerp(1.8, 4, Math.random()), hue: 28,
          })
        }
        if (this.quakeLeft <= 0) this.quakeActive = false
      }
    }
  }

  private quakeActive = false
  private quakeLeft = 0
  private faultX(s: SceneFrameState) { return s.w * 0.5 }

  draw(ctx: CanvasRenderingContext2D, s: SceneFrameState) {
    const { w, h } = s
    if (this.variant === 'tornado') this.drawTornado(ctx, s)
    else this.drawEarthquake(ctx, s)
    void w
    void h
  }

  private drawTornado(ctx: CanvasRenderingContext2D, s: SceneFrameState) {
    const { w, h } = s
    const shear = s.params.shear ?? 1
    const humid = s.params.humidity ?? 1
    const cloudY = h * 0.16
    const groundY = h * 0.8

    // storm cloud deck
    ctx.save()
    const deckW = w * (0.5 + humid * 0.28)
    for (let i = 0; i < 10; i++) {
      const cx = w * 0.5 + (i / 9 - 0.5) * deckW
      const r = lerp(30, 62, humid) * (0.6 + srand(i * 7) * 0.6)
      const g = ctx.createRadialGradient(cx, cloudY - r * 0.2, 0, cx, cloudY, r)
      g.addColorStop(0, 'rgba(84,84,104,0.95)')
      g.addColorStop(1, 'rgba(38,38,54,0.85)')
      ctx.fillStyle = g
      ctx.beginPath()
      ctx.arc(cx, cloudY + Math.sin(i * 2.3) * 8, r, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.restore()

    // funnel — stacked rotating ellipses
    const funnelH = (groundY - cloudY - 30) * this.funnelReach
    const sway = Math.sin(this.funnelSway) * (26 + shear * 18)
    ctx.save()
    const segs = 16
    for (let i = 0; i <= segs; i++) {
      const k = i / segs
      const y = cloudY + 26 + k * funnelH
      // radius grows toward the ground
      const rBase = lerp(10, 64, Math.pow(k, 1.5)) * (0.7 + shear * 0.25)
      const x = w * 0.5 + sway * k * k
      const spin = Math.sin(this.t * (6 - k * 2) + k * 9) * rBase * 0.14
      const alpha = 0.24 + k * 0.3
      const g = ctx.createRadialGradient(x + spin, y, 0, x + spin, y, rBase * 1.7)
      g.addColorStop(0, `rgba(120,116,140,${alpha})`)
      g.addColorStop(0.6, `rgba(80,78,100,${alpha * 0.7})`)
      g.addColorStop(1, 'rgba(60,58,80,0)')
      ctx.fillStyle = g
      ctx.beginPath()
      ctx.ellipse(x + spin, y, rBase * 1.7, rBase * 0.42, 0, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.restore()

    // debris orbiting the base
    const baseY = cloudY + 26 + funnelH
    for (const d of this.debris) {
      const dy = baseY - d.hgt * (funnelH * 0.5)
      const dx = w * 0.5 + sway + Math.cos(d.a) * d.r
      ctx.fillStyle = `rgba(180,${Math.floor(150 - d.hue * 0.8)},110,${0.7 - d.hgt * 0.4})`
      ctx.fillRect(dx, dy, d.size, d.size * 0.7)
    }

    // ground
    const gg = ctx.createLinearGradient(0, groundY - 6, 0, h)
    gg.addColorStop(0, 'rgba(52,48,64,0.9)')
    gg.addColorStop(1, 'rgba(16,14,26,0.95)')
    ctx.fillStyle = gg
    ctx.fillRect(0, groundY - 6, w, h - groundY + 6)

    labelChip(ctx, w * 0.5, cloudY - 66, this.funnelReach > 0.75 ? 'on the ground' : 'forming…', 'rgba(221,214,254,0.95)')
    labelChip(ctx, w * 0.5 + Math.min(150, w * 0.22), groundY + 26, `shear ${(shear * 100).toFixed(0)}%`, 'rgba(165,243,252,0.9)')
  }

  private drawEarthquake(ctx: CanvasRenderingContext2D, s: SceneFrameState) {
    const { w, h } = s
    const groundY = h * 0.72
    const amp = this.quakeAmp * 10
    const shake = this.quakeAmp > 0.05 ? (Math.random() - 0.5) * amp : 0
    const fx = this.faultX(s)

    // strata layers with seismic offset
    ctx.save()
    ctx.translate(shake, 0)
    const layers = [
      { top: groundY - 60, col: 'rgba(64,56,84,0.9)' },
      { top: groundY - 30, col: 'rgba(50,44,68,0.92)' },
      { top: groundY, col: 'rgba(38,34,52,0.95)' },
    ]
    layers.forEach((L, li) => {
      ctx.beginPath()
      ctx.moveTo(0, L.top + 60)
      for (let x = 0; x <= w; x += 14) {
        const wave = Math.sin(x * 0.045 - this.t * (2.2 + li * 0.7)) * this.quakeAmp * (5 + li * 3) * Math.exp(-Math.abs(x - fx) / (w * 0.4))
        ctx.lineTo(x, L.top + wave)
      }
      ctx.lineTo(w, L.top + 60)
      ctx.lineTo(w, h)
      ctx.lineTo(0, h)
      ctx.closePath()
      ctx.fillStyle = L.col
      ctx.fill()
    })

    // fault line
    ctx.strokeStyle = `rgba(255,140,140,${0.2 + this.quakeEnergy * 0.55})`
    ctx.lineWidth = 2
    ctx.setLineDash([10, 8])
    ctx.beginPath()
    ctx.moveTo(fx, groundY - 70)
    ctx.lineTo(fx + Math.sin(this.t * 0.4) * 4, h * 0.86)
    ctx.stroke()
    ctx.setLineDash([])

    // cracks radiating when quaking
    for (const c of this.cracks) {
      ctx.strokeStyle = `rgba(30,26,44,${0.8 * c.p})`
      ctx.lineWidth = 2
      ctx.beginPath()
      let x = c.x
      let y = groundY
      ctx.moveTo(x, y)
      const dir = c.seed > 0.5 ? 1 : -1
      for (let i = 0; i < 6; i++) {
        x += dir * lerp(14, 34, srand(c.seed + i))
        y += lerp(4, 16, srand(c.seed + i * 3))
        ctx.lineTo(x, y)
      }
      ctx.stroke()
    }
    ctx.restore()

    // stress meter
    const stress = s.params.stress ?? 0.4
    labelChip(ctx, w * 0.5, groundY - 96, this.quakeActive ? 'SLIP! seismic waves racing out' : `fault stress ${(this.quakeEnergy * 100).toFixed(0)}%`,
      this.quakeEnergy > 0.7 ? 'rgba(252,165,165,0.95)' : 'rgba(221,214,254,0.9)')
  }

  pointerDown(s: SceneFrameState) {
    if (this.variant === 'tornado') {
      // cloud deck
      if (s.pointer.y < s.h * 0.32) {
        this.funnelTarget = this.funnelTarget > 0.5 ? 0.3 : 1
        return 1
      }
      // ground
      if (s.pointer.y > s.h * 0.72) return 3
      return null
    }
    // earthquake — tap the fault
    if (Math.abs(s.pointer.x - this.faultX(s)) < 90 && s.pointer.y > s.h * 0.5) {
      this.quakeActive = true
      this.quakeLeft = 1.6
      const n = Math.floor(3 + (s.params.stress ?? 0.4) * 4)
      for (let i = 0; i < n; i++) {
        this.cracks.push({ x: this.faultX(s) + (Math.random() - 0.5) * 160, seed: Math.random(), p: 1 })
      }
      if (this.cracks.length > 14) this.cracks.splice(0, this.cracks.length - 14)
      return 0
    }
    return null
  }

  trigger(id: string, s: SceneFrameState) {
    if (this.variant === 'tornado') {
      if (id === 'spinup') { this.funnelTarget = 1; return true }
      if (id === 'settle') { this.funnelTarget = 0.3; this.debris = []; return true }
    } else {
      if (id === 'quake') {
        this.quakeActive = true
        this.quakeLeft = 1.6 + (s.params.stress ?? 0.4) * 2
        const n = Math.floor(3 + (s.params.stress ?? 0.4) * 5)
        for (let i = 0; i < n; i++) {
          this.cracks.push({ x: this.faultX(s) + (Math.random() - 0.5) * 180, seed: Math.random(), p: 1 })
        }
        if (this.cracks.length > 14) this.cracks.splice(0, this.cracks.length - 14)
        return true
      }
      if (id === 'relax') {
        this.quakeActive = false
        this.quakeAmp = 0.05
        this.cracks = []
        return true
      }
    }
    return false
  }
}

/* ==========================================================================
   Ocean — layered waves, fish, optional reef. (waves / reef variants)
   ========================================================================== */

interface Fish { x: number; y: number; dir: number; speed: number; size: number; hue: number; phase: number }

export class OceanScene implements SceneRenderer {
  private variant: string
  private fish: Fish[] = []
  private swells: Array<{ x: number; amp: number; life: number }> = []
  private t = 0
  private school = 0

  constructor(variant: string) {
    this.variant = variant === 'reef' ? 'reef' : 'waves'
  }

  enter(w: number, h: number) {
    this.fish = []
    this.swells = []
    const want = this.variant === 'reef' ? 8 : 5
    for (let i = 0; i < want; i++) this.spawnFish(w, h)
  }

  private spawnFish(w: number, h: number) {
    const dir = Math.random() < 0.5 ? 1 : -1
    this.fish.push({
      x: Math.random() * w,
      y: h * (this.variant === 'reef' ? lerp(0.35, 0.68, Math.random()) : lerp(0.45, 0.72, Math.random())),
      dir,
      speed: lerp(18, 55, Math.random()),
      size: lerp(5, 11, Math.random()) * (this.variant === 'reef' ? 0.8 : 1),
      hue: this.variant === 'reef' ? lerp(0, 60, Math.random()) : lerp(180, 220, Math.random()),
      phase: Math.random() * 9,
    })
  }

  update(s: SceneFrameState) {
    this.t += s.dt
    const wantFish = Math.round(s.params.fish ?? 6)
    while (this.fish.length < wantFish) this.spawnFish(s.w, s.h)
    while (this.fish.length > wantFish) this.fish.pop()
    const waveBoost = s.wind ? 1.5 : 1
    for (const f of this.fish) {
      const sp = f.speed * (1 + this.school * 2.2) * (0.7 + (s.params.waves ?? 1) * 0.3)
      f.x += f.dir * sp * s.dt
      f.y += Math.sin(this.t * 1.6 + f.phase) * 6 * s.dt
      if (f.x < -60) f.x = s.w + 50
      if (f.x > s.w + 60) f.x = -50
    }
    if (this.school > 0) this.school = Math.max(0, this.school - s.dt * 0.5)
    for (let i = this.swells.length - 1; i >= 0; i--) {
      const sw = this.swells[i]
      sw.x += 130 * s.dt
      sw.life -= s.dt
      if (sw.life <= 0) this.swells.splice(i, 1)
    }
    void waveBoost
    // reef bubbles
    if (this.variant === 'reef' && Math.random() < s.dt * 2.2 * s.quality) {
      s.emit('splash', {
        x: lerp(s.w * 0.1, s.w * 0.9, Math.random()),
        y: s.h * 0.78,
        vx: (Math.random() - 0.5) * 10,
        vy: -lerp(30, 60, Math.random()),
        maxLife: lerp(2, 3.6, Math.random()),
        size: lerp(1.4, 3, Math.random()), hue: 190,
      })
    }
  }

  private waveY(x: number, t: number, h: number, layer: number, ampK: number, swells: Array<{ x: number; amp: number }>) {
    const base = h * (0.42 + layer * 0.16)
    let y = base
      + Math.sin(x * 0.012 + t * (1.1 + layer * 0.2)) * (8 + layer * 3) * ampK
      + Math.sin(x * 0.03 - t * 1.6) * 4 * ampK
    for (const sw of swells) {
      const d = Math.abs(x - sw.x)
      y -= Math.exp(-(d * d) / 8000) * sw.amp
    }
    return y
  }

  draw(ctx: CanvasRenderingContext2D, s: SceneFrameState) {
    const { w, h } = s
    const ampK = (s.params.waves ?? 1) * (s.wind ? 1.3 : 1)
    const reef = this.variant === 'reef'

    // sun glow above water
    if (!reef) {
      glowCircle(ctx, w * 0.72, h * 0.16, 70, 'rgba(255,214,140,0.35)', 'rgba(255,160,60,0)')
    } else {
      // caustic light rays
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      for (let i = 0; i < 5; i++) {
        const rx = w * (0.15 + i * 0.18)
        const g = ctx.createLinearGradient(rx, h * 0.2, rx + 40, h * 0.75)
        g.addColorStop(0, 'rgba(120,200,235,0.09)')
        g.addColorStop(1, 'rgba(120,200,235,0)')
        ctx.fillStyle = g
        ctx.beginPath()
        ctx.moveTo(rx - 14, h * 0.2)
        ctx.lineTo(rx + 18, h * 0.2)
        ctx.lineTo(rx + 60, h * 0.78)
        ctx.lineTo(rx - 30, h * 0.78)
        ctx.closePath()
        ctx.fill()
      }
      ctx.restore()
    }

    // water layers
    const layers = 3
    for (let L = layers - 1; L >= 0; L--) {
      const top = this.waveY(0, this.t - L * 0.3, h, L, ampK, this.swells)
      const g = ctx.createLinearGradient(0, top, 0, h)
      const dk = 1 - L * 0.28
      g.addColorStop(0, `rgba(${Math.floor(24 * dk + 8)},${Math.floor(92 * dk + 22)},${Math.floor(140 * dk + 30)},0.88)`)
      g.addColorStop(1, `rgba(${Math.floor(8 * dk + 3)},${Math.floor(30 * dk + 10)},${Math.floor(62 * dk + 18)},0.96)`)
      ctx.fillStyle = g
      ctx.beginPath()
      ctx.moveTo(0, top)
      for (let x = 0; x <= w; x += 14) {
        ctx.lineTo(x, this.waveY(x, this.t - L * 0.3, h, L, ampK, this.swells))
      }
      ctx.lineTo(w, h)
      ctx.lineTo(0, h)
      ctx.closePath()
      ctx.fill()
      // crest highlight
      ctx.strokeStyle = `rgba(180,225,250,${0.14 + ampK * 0.08})`
      ctx.lineWidth = 1.4
      ctx.beginPath()
      for (let x = 0; x <= w; x += 14) {
        const y = this.waveY(x, this.t - L * 0.3, h, L, ampK, this.swells)
        if (x === 0) ctx.moveTo(x, y)
        else ctx.lineTo(x, y)
      }
      ctx.stroke()
    }

    // fish
    for (const f of this.fish) {
      const x = f.x
      const y = f.y + Math.sin(this.t * 2 + f.phase) * 3
      ctx.save()
      ctx.translate(x, y)
      ctx.scale(f.dir, 1)
      ctx.fillStyle = `hsla(${f.hue}, 62%, 62%, 0.85)`
      ctx.beginPath()
      ctx.ellipse(0, 0, f.size, f.size * 0.42, 0, 0, Math.PI * 2)
      ctx.fill()
      // tail
      const tw = Math.sin(this.t * 8 + f.phase) * 0.5
      ctx.beginPath()
      ctx.moveTo(-f.size * 0.85, 0)
      ctx.lineTo(-f.size * 1.55, -f.size * 0.5 + tw * 4)
      ctx.lineTo(-f.size * 1.55, f.size * 0.5 + tw * 4)
      ctx.closePath()
      ctx.fill()
      // eye
      ctx.fillStyle = 'rgba(10,12,24,0.8)'
      ctx.beginPath()
      ctx.arc(f.size * 0.45, -f.size * 0.08, 1.3, 0, Math.PI * 2)
      ctx.fill()
      ctx.restore()
    }

    // reef floor
    if (reef) {
      const fy = h * 0.8
      const fg = ctx.createLinearGradient(0, fy - 10, 0, h)
      fg.addColorStop(0, 'rgba(90,70,80,0.55)')
      fg.addColorStop(1, 'rgba(30,24,40,0.9)')
      ctx.fillStyle = fg
      ctx.beginPath()
      ctx.moveTo(0, fy)
      for (let x = 0; x <= w; x += 24) ctx.lineTo(x, fy + Math.sin(x * 0.02) * 8 + srand(x) * 6)
      ctx.lineTo(w, h)
      ctx.lineTo(0, h)
      ctx.closePath()
      ctx.fill()
      // corals
      for (let i = 0; i < 9; i++) {
        const cx = (i + 0.5) / 9 * w + srand(i * 5) * 30 - 15
        const kind = srand(i * 11)
        const swayK = Math.sin(this.t * 1.2 + i) * 3
        if (kind < 0.45) {
          // branching coral
          ctx.strokeStyle = `hsla(${srand(i * 3) * 40 + 10}, 55%, 58%, 0.85)`
          ctx.lineWidth = 3
          ctx.lineCap = 'round'
          for (let b = -1; b <= 1; b++) {
            ctx.beginPath()
            ctx.moveTo(cx, fy + 10)
            ctx.quadraticCurveTo(cx + b * 8 + swayK, fy - 16, cx + b * 16, fy - 30 - srand(i + b) * 14)
            ctx.stroke()
          }
        } else if (kind < 0.75) {
          // brain coral
          ctx.fillStyle = `hsla(${srand(i * 7) * 50 + 320}, 40%, 55%, 0.8)`
          ctx.beginPath()
          ctx.ellipse(cx, fy + 8, 16 + srand(i) * 8, 10, 0, 0, Math.PI * 2)
          ctx.fill()
          ctx.strokeStyle = 'rgba(20,16,30,0.3)'
          ctx.lineWidth = 1
          ctx.beginPath()
          ctx.ellipse(cx, fy + 8, 9, 5, 0.4, 0, Math.PI * 2)
          ctx.stroke()
        } else {
          // sea fan
          ctx.strokeStyle = `hsla(${srand(i * 13) * 60 + 150}, 50%, 55%, 0.75)`
          ctx.lineWidth = 1.6
          for (let b = 0; b < 4; b++) {
            ctx.beginPath()
            ctx.moveTo(cx, fy + 10)
            ctx.quadraticCurveTo(cx + (b - 1.5) * 7 + swayK, fy - 18, cx + (b - 1.5) * 13, fy - 34)
            ctx.stroke()
          }
        }
      }
      labelChip(ctx, w * 0.5, h * 0.24, 'a city built by animals the size of a fingernail', 'rgba(147,197,253,0.9)')
    } else {
      labelChip(ctx, w * 0.5, h * 0.16, 'waves move energy — the water mostly stays', 'rgba(147,197,253,0.9)')
    }
  }

  pointerDown(s: SceneFrameState) {
    if (s.pointer.y < s.h * 0.5) return 0 // sky/surface fact
    // scatter fish
    this.school = 1
    return 3
  }

  trigger(id: string, s: SceneFrameState) {
    if (id === 'bigwave') {
      this.swells.push({ x: -80, amp: 22 + (s.params.waves ?? 1) * 14, life: 8 })
      return true
    }
    if (id === 'school') {
      this.school = 1
      return true
    }
    return false
  }
}
