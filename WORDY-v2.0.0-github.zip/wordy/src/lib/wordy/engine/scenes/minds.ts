import {
  type SceneRenderer, type SceneFrameState,
  clamp01, lerp, easeOut, srand, glowCircle, labelChip, roundRectPath,
} from './types'

/* ==========================================================================
   Orbital — star + planets on Kepler-ish orbits. solar | gravity | blackhole.
   ========================================================================== */

interface Planet {
  r: number        // orbit radius
  size: number
  hue: number
  ang: number
  speed: number
  tilt: number     // ellipse squash
  moons: number
}

export class OrbitalScene implements SceneRenderer {
  private variant: string
  private planets: Planet[] = []
  private t = 0
  private flareT = -1
  private diskDust: Array<{ a: number; r: number; sp: number }[]> = []

  constructor(variant: string) {
    this.variant = variant === 'blackhole' ? 'blackhole' : variant === 'gravity' ? 'gravity' : 'solar'
  }

  enter(w: number, _h: number) {
    this.t = 0
    this.planets = []
    const base = this.variant === 'solar'
      ? [
        { r: 0.16, size: 5, hue: 210, moons: 0 },
        { r: 0.23, size: 8, hue: 30, moons: 0 },
        { r: 0.31, size: 7, hue: 150, moons: 1 },
        { r: 0.4, size: 14, hue: 28, moons: 2 },
      ]
      : [
        { r: 0.18, size: 7, hue: 200, moons: 0 },
        { r: 0.3, size: 10, hue: 280, moons: 1 },
        { r: 0.42, size: 6, hue: 120, moons: 0 },
      ]
    const minDim = Math.min(w, 900)
    for (const b of base) {
      this.planets.push({
        ...b,
        r: b.r * minDim,
        ang: Math.random() * Math.PI * 2,
        speed: lerp(0.5, 0.24, b.r / 0.42) * 1.4,
        tilt: 0.42 + srand(b.r * 99) * 0.16,
        moons: b.moons,
      })
    }
    void _h
  }

  update(s: SceneFrameState) {
    this.t += s.dt
    const mass = s.params.mass ?? 1
    const speed = s.params.speed ?? 1
    // Kepler's third law, simplified: T ∝ r^1.5 / sqrt(M)
    for (const p of this.planets) {
      const kepler = Math.pow(p.r / (Math.min(s.w, 900) * 0.42), 1.5)
      p.ang += s.dt * speed * (1.5 / Math.max(0.12, kepler)) * Math.sqrt(mass) * 0.5
    }
    if (this.flareT >= 0) {
      this.flareT += s.dt
      if (this.flareT > 1.6) this.flareT = -1
    }
    if (this.variant === 'blackhole' && s.fire && this.flareT < 0) this.flareT = 0
  }

  private center(s: SceneFrameState) {
    return { cx: s.w * 0.5, cy: s.h * 0.44 }
  }

  draw(ctx: CanvasRenderingContext2D, s: SceneFrameState) {
    const { w, h } = s
    const { cx, cy } = this.center(s)
    const mass = s.params.mass ?? 1
    const blackhole = this.variant === 'blackhole'

    // orbit ellipses
    ctx.save()
    ctx.strokeStyle = blackhole ? 'rgba(160,140,255,0.09)' : 'rgba(255,255,255,0.07)'
    ctx.lineWidth = 1
    for (const p of this.planets) {
      ctx.beginPath()
      ctx.ellipse(cx, cy, p.r, p.r * p.tilt, 0, 0, Math.PI * 2)
      ctx.stroke()
    }
    ctx.restore()

    if (blackhole) {
      // accretion disk (behind + front halves)
      const flare = this.flareT >= 0 ? Math.sin(clamp01(this.flareT / 1.6) * Math.PI) : 0
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      for (let i = 0; i < 3; i++) {
        const rr = 56 + i * 16 + mass * 12
        const g = ctx.createLinearGradient(cx - rr, cy, cx + rr, cy)
        g.addColorStop(0, `rgba(120,80,255,${0.02 + flare * 0.05})`)
        g.addColorStop(0.5, `rgba(255,${140 - i * 20},90,${0.34 + flare * 0.4 - i * 0.08})`)
        g.addColorStop(1, `rgba(120,80,255,${0.02 + flare * 0.05})`)
        ctx.strokeStyle = g
        ctx.lineWidth = 7 - i * 1.6
        ctx.beginPath()
        ctx.ellipse(cx, cy, rr, rr * 0.3, 0, 0, Math.PI * 2)
        ctx.stroke()
      }
      ctx.restore()
      // event horizon
      ctx.fillStyle = '#05030c'
      ctx.beginPath()
      ctx.arc(cx, cy, 24 + mass * 9, 0, Math.PI * 2)
      ctx.fill()
      // photon ring
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      const pr = 30 + mass * 9
      const pg = ctx.createRadialGradient(cx, cy, pr - 7, cx, cy, pr + 8)
      pg.addColorStop(0, 'rgba(255,190,120,0)')
      pg.addColorStop(0.5, `rgba(255,${200 + flare * 40},150,${0.55 + flare * 0.35})`)
      pg.addColorStop(1, 'rgba(255,190,120,0)')
      ctx.fillStyle = pg
      ctx.beginPath()
      ctx.arc(cx, cy, pr + 8, 0, Math.PI * 2)
      ctx.fill()
      ctx.restore()
      // lensing glow
      glowCircle(ctx, cx, cy, 90 + mass * 20, 'rgba(150,110,255,0.1)', 'rgba(150,110,255,0)')
      labelChip(ctx, cx, cy - 110 - mass * 10, 'the event horizon — no light returns', 'rgba(221,214,254,0.95)')
    } else {
      // star
      const flare = this.flareT >= 0 ? Math.sin(clamp01(this.flareT / 1.6) * Math.PI) : 0
      const starR = 22 + mass * 13
      glowCircle(ctx, cx, cy, starR * 3.4 + flare * 40, `rgba(255,190,90,${0.3 + flare * 0.2})`, 'rgba(255,120,40,0)')
      const sg = ctx.createRadialGradient(cx - starR * 0.3, cy - starR * 0.3, 0, cx, cy, starR)
      sg.addColorStop(0, '#fff3c4')
      sg.addColorStop(0.6, '#ffc258')
      sg.addColorStop(1, '#f09030')
      ctx.fillStyle = sg
      ctx.beginPath()
      ctx.arc(cx, cy, starR, 0, Math.PI * 2)
      ctx.fill()
      // corona flicker
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      for (let i = 0; i < 7; i++) {
        const a = (i / 7) * Math.PI * 2 + this.t * 0.2
        const len = starR * (1.25 + Math.sin(this.t * 3 + i * 2) * 0.18 + flare * 0.4)
        ctx.strokeStyle = `rgba(255,180,80,${0.16 + flare * 0.2})`
        ctx.lineWidth = 3
        ctx.beginPath()
        ctx.moveTo(cx + Math.cos(a) * starR * 0.9, cy + Math.sin(a) * starR * 0.9)
        ctx.lineTo(cx + Math.cos(a) * len, cy + Math.sin(a) * len)
        ctx.stroke()
      }
      ctx.restore()
      if (s.fire) {
        for (let i = 0; i < 2; i++) {
          s.emit('spark', {
            x: cx + (Math.random() - 0.5) * starR * 2, y: cy + (Math.random() - 0.5) * starR * 2,
            vx: (Math.random() - 0.5) * 120, vy: -Math.random() * 100,
            maxLife: 0.8, size: 2, hue: 32, light: 70,
          })
        }
      }
      labelChip(ctx, cx, cy - starR - 34, this.variant === 'solar' ? '99.8% of the system’s mass' : 'every object pulls on every other', 'rgba(253,224,130,0.95)')
    }

    // planets
    for (const p of this.planets) {
      const px = cx + Math.cos(p.ang) * p.r
      const py = cy + Math.sin(p.ang) * p.r * p.tilt
      // trail
      ctx.save()
      ctx.strokeStyle = `hsla(${p.hue}, 65%, 66%, 0.32)`
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.ellipse(cx, cy, p.r, p.r * p.tilt, 0, p.ang - 0.9, p.ang)
      ctx.stroke()
      ctx.restore()
      // body
      const pg = ctx.createRadialGradient(px - p.size * 0.35, py - p.size * 0.35, 0, px, py, p.size)
      pg.addColorStop(0, `hsla(${p.hue}, 70%, 74%, 1)`)
      pg.addColorStop(1, `hsla(${p.hue}, 62%, 40%, 1)`)
      ctx.fillStyle = pg
      ctx.beginPath()
      ctx.arc(px, py, p.size, 0, Math.PI * 2)
      ctx.fill()
      // moons
      for (let m = 0; m < p.moons; m++) {
        const ma = this.t * (1.2 + m * 0.5) + m * 2
        const mx = px + Math.cos(ma) * (p.size + 7 + m * 5)
        const my = py + Math.sin(ma) * (p.size + 7 + m * 5) * 0.5
        ctx.fillStyle = 'rgba(220,220,235,0.9)'
        ctx.beginPath()
        ctx.arc(mx, my, 2, 0, Math.PI * 2)
        ctx.fill()
      }
    }
  }

  pointerDown(s: SceneFrameState) {
    const { cx, cy } = this.center(s)
    const mass = s.params.mass ?? 1
    if (this.variant === 'blackhole') {
      if (Math.hypot(s.pointer.x - cx, s.pointer.y - cy) < 40 + mass * 9) {
        this.flareT = 0
        return 2
      }
    } else {
      const starR = 22 + mass * 13
      if (Math.hypot(s.pointer.x - cx, s.pointer.y - cy) < starR + 14) {
        this.flareT = 0
        return 0
      }
      for (const p of this.planets) {
        const px = cx + Math.cos(p.ang) * p.r
        const py = cy + Math.sin(p.ang) * p.r * p.tilt
        if (Math.hypot(s.pointer.x - px, s.pointer.y - py) < p.size + 18) return 3
      }
    }
    // empty space → add a planet
    this.addPlanet(s)
    return null
  }

  private addPlanet(s: SceneFrameState) {
    if (this.planets.length >= 7) return
    const minDim = Math.min(s.w, 900)
    const r = lerp(0.14, 0.46, Math.random()) * minDim
    if (this.planets.some((p) => Math.abs(p.r - r) < 34)) return
    this.planets.push({
      r,
      size: lerp(4.5, 11, Math.random()),
      hue: Math.random() * 360,
      ang: Math.random() * Math.PI * 2,
      speed: 1,
      tilt: 0.42 + Math.random() * 0.16,
      moons: Math.random() < 0.3 ? 1 : 0,
    })
  }

  trigger(id: string, s: SceneFrameState) {
    if (id === 'addplanet') { this.addPlanet(s); return true }
    if (id === 'clearplanets') {
      this.planets = []
      return true
    }
    if (id === 'feed') { this.flareT = 0; return true }
    return false
  }
}

/* ==========================================================================
   Atom — nucleus + electron shells. atom | circuit variants.
   ========================================================================== */

interface Electron { shell: number; ang: number; jump: number; jumpT: number }

export class AtomScene implements SceneRenderer {
  private variant: string
  private t = 0
  private electrons: Electron[] = []
  private shells = [0.16, 0.26, 0.36]
  private photonFlash = -1
  private switchOn = true
  private lampGlow = 0

  constructor(variant: string) {
    this.variant = variant === 'circuit' ? 'circuit' : 'atom'
  }

  enter() {
    this.t = 0
    this.electrons = []
    this.shells.forEach((_, si) => {
      const n = si === 0 ? 2 : si === 1 ? 3 : 2
      for (let i = 0; i < n; i++) {
        this.electrons.push({ shell: si, ang: (i / n) * Math.PI * 2 + si, jump: 0, jumpT: -1 })
      }
    })
    this.switchOn = true
    this.lampGlow = 0
  }

  update(s: SceneFrameState) {
    this.t += s.dt
    const energy = s.params.energy ?? 1
    if (this.variant === 'atom') {
      for (const e of this.electrons) {
        e.ang += s.dt * energy * lerp(2.6, 1.4, e.shell / 2)
        if (e.jumpT >= 0) {
          e.jumpT += s.dt * 2
          if (e.jumpT >= 1) {
            e.jumpT = -1
            e.shell = Math.max(0, e.shell - 1)
            e.jump = 0
            this.photonFlash = 0
          } else {
            e.jump = e.jumpT
          }
        }
      }
      if (s.electric && Math.random() < s.dt * 3) this.excite()
      if (this.photonFlash >= 0) {
        this.photonFlash += s.dt * 2.4
        if (this.photonFlash > 1) this.photonFlash = -1
      }
    } else {
      // circuit
      const current = (s.params.current ?? 1) * (this.switchOn ? 1 : 0)
      this.lampGlow += ((this.switchOn ? 0.4 + current * 0.6 : 0) - this.lampGlow) * Math.min(1, s.dt * 3)
      if (this.switchOn && s.electric && Math.random() < s.dt * 4) {
        s.emit('spark', {
          x: s.w * 0.5 + (Math.random() - 0.5) * 60, y: s.h * 0.3,
          vx: (Math.random() - 0.5) * 100, vy: -40,
          maxLife: 0.4, size: 1.8, hue: 48, light: 80,
        })
      }
    }
  }

  private excite() {
    const calm = this.electrons.filter((e) => e.jumpT < 0 && e.shell < 2)
    if (calm.length === 0) return
    const e = calm[Math.floor(Math.random() * calm.length)]
    e.jumpT = 0
    e.shell = e.shell // target set on completion
  }

  /** circuit wire path (rounded rectangle) */
  private circuitPath(s: SceneFrameState) {
    const padX = s.w * 0.22
    const top = s.h * 0.3
    const bot = s.h * 0.62
    const r = 26
    return { padX, top, bot, r, cx: s.w * 0.5 }
  }

  private wirePoint(s: SceneFrameState, k: number): { x: number; y: number } {
    // k 0..1 travels clockwise around the rounded rect
    const { padX, top, bot, r, cx } = this.circuitPath(s)
    const wRect = s.w - padX * 2
    const hRect = bot - top
    const straight = 2 * (wRect - 2 * r) + 2 * (hRect - 2 * r)
    const arc = 2 * Math.PI * r
    const total = straight + arc
    let d = k * total
    // start at top-left corner after arc, moving right
    const topY = top, botY = bot, leftX = padX, rightX = s.w - padX
    const segTop = wRect - 2 * r
    const segSide = hRect - 2 * r
    if (d < segTop) return { x: leftX + r + d, y: topY }
    d -= segTop
    if (d < Math.PI * r / 2) {
      const a = -Math.PI / 2 + d / r
      return { x: rightX - r + Math.cos(a) * r, y: topY + r + Math.sin(a) * r }
    }
    d -= Math.PI * r / 2
    if (d < segSide) return { x: rightX, y: topY + r + d }
    d -= segSide
    if (d < Math.PI * r / 2) {
      const a = 0 + d / r
      return { x: rightX - r + Math.cos(a) * r, y: botY - r + Math.sin(a) * r }
    }
    d -= Math.PI * r / 2
    if (d < segTop) return { x: rightX - r - d, y: botY }
    d -= segTop
    if (d < Math.PI * r / 2) {
      const a = Math.PI / 2 + d / r
      return { x: leftX + r + Math.cos(a) * r, y: botY - r + Math.sin(a) * r }
    }
    d -= Math.PI * r / 2
    if (d < segSide) return { x: leftX, y: botY - r - d }
    d -= segSide
    const a = Math.PI + d / r
    void cx
    return { x: leftX + r + Math.cos(a) * r, y: topY + r + Math.sin(a) * r }
  }

  draw(ctx: CanvasRenderingContext2D, s: SceneFrameState) {
    if (this.variant === 'atom') this.drawAtom(ctx, s)
    else this.drawCircuit(ctx, s)
  }

  private drawAtom(ctx: CanvasRenderingContext2D, s: SceneFrameState) {
    const { w, h } = s
    const cx = w * 0.5
    const cy = h * 0.46
    const energy = s.params.energy ?? 1
    const baseR = Math.min(w, h) * 0.26

    // nucleus — protons + neutrons jittering
    const nucR = 16 + energy * 2
    glowCircle(ctx, cx, cy, nucR * 2.4, 'rgba(244,114,182,0.14)', 'rgba(244,114,182,0)')
    for (let i = 0; i < 7; i++) {
      const a = (i / 7) * Math.PI * 2 + this.t * 0.3
      const rr = nucR * 0.5
      const nx = cx + Math.cos(a) * rr * Math.sin(this.t * 0.8 + i)
      const ny = cy + Math.sin(a) * rr * Math.cos(this.t * 0.7 + i * 2)
      const isProton = i % 2 === 0
      ctx.fillStyle = isProton ? 'rgba(244,114,182,0.95)' : 'rgba(96,165,250,0.9)'
      ctx.beginPath()
      ctx.arc(nx, ny, 6, 0, Math.PI * 2)
      ctx.fill()
    }

    // shells + electrons
    const angles = [0.5, -0.6, 0.15]
    this.shells.forEach((sh, si) => {
      const rx = baseR * (sh / 0.16) * 0.62
      const ry = rx * 0.38
      ctx.save()
      ctx.translate(cx, cy)
      ctx.rotate(angles[si])
      ctx.strokeStyle = 'rgba(255,255,255,0.1)'
      ctx.lineWidth = 1.2
      ctx.beginPath()
      ctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2)
      ctx.stroke()
      ctx.restore()
    })
    for (const e of this.electrons) {
      const si = e.jumpT >= 0 ? Math.min(2, e.shell + 1) : e.shell
      const rx = baseR * (this.shells[si] / 0.16) * 0.62
      const ry = rx * 0.38
      ctx.save()
      ctx.translate(cx, cy)
      ctx.rotate(angles[si])
      const ex = Math.cos(e.ang) * rx
      const ey = Math.sin(e.ang) * ry
      ctx.restore()
      // electron glow
      glowCircle(ctx, cx + Math.cos(angles[si]) * ex - Math.sin(angles[si]) * ey,
        cy + Math.sin(angles[si]) * ex + Math.cos(angles[si]) * ey, 10,
        'rgba(125,211,252,0.5)', 'rgba(125,211,252,0)')
      ctx.fillStyle = '#7dd3fc'
      ctx.beginPath()
      ctx.arc(cx + Math.cos(angles[si]) * ex - Math.sin(angles[si]) * ey,
        cy + Math.sin(angles[si]) * ex + Math.cos(angles[si]) * ey, 3.2, 0, Math.PI * 2)
      ctx.fill()
    }

    // photon flash on de-excitation
    if (this.photonFlash >= 0 && this.photonFlash < 1) {
      const k = this.photonFlash
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      ctx.strokeStyle = `rgba(250,240,140,${0.7 * (1 - k)})`
      ctx.lineWidth = 2
      const fx = cx + 90
      ctx.beginPath()
      ctx.moveTo(fx, cy - 30)
      ctx.lineTo(fx + 60 * (1 - k), cy - 30)
      ctx.moveTo(fx + 8, cy - 38)
      ctx.lineTo(fx + 8, cy - 22)
      ctx.stroke()
      ctx.restore()
      labelChip(ctx, w * 0.5 + 90, cy - 52, 'photon!', 'rgba(253,224,130,0.95)')
    }

    labelChip(ctx, w * 0.5, h * 0.14, 'mostly empty space — a stadium around a marble', 'rgba(221,214,254,0.95)')
  }

  private drawCircuit(ctx: CanvasRenderingContext2D, s: SceneFrameState) {
    const { w, h } = s
    const { padX, top, bot, r } = this.circuitPath(s)
    const current = (s.params.current ?? 1) * (this.switchOn ? 1 : 0)

    // wire
    ctx.save()
    ctx.strokeStyle = 'rgba(196,181,253,0.5)'
    ctx.lineWidth = 3
    roundRectPath(ctx, padX, top, w - padX * 2, bot - top, r)
    ctx.stroke()
    ctx.restore()

    // battery (left side)
    const batY = (top + bot) / 2
    ctx.fillStyle = 'rgba(30,26,52,0.95)'
    roundRectPath(ctx, padX - 10, batY - 26, 20, 52, 5)
    ctx.fill()
    ctx.strokeStyle = 'rgba(196,181,253,0.5)'
    ctx.lineWidth = 2
    ctx.stroke()
    ctx.fillStyle = '#fbbf24'
    ctx.fillRect(padX - 5, batY - 16, 10, 5)
    ctx.fillRect(padX - 5, batY + 11, 10, 5)
    labelChip(ctx, padX, batY + 52, 'battery — the push (volts)', 'rgba(253,224,130,0.9)')

    // lamp (right side)
    const lampX = w - padX
    const lampY = batY
    glowCircle(ctx, lampX, lampY, 26 + this.lampGlow * 34, `rgba(250,220,120,${0.12 + this.lampGlow * 0.4})`, 'rgba(250,220,120,0)')
    ctx.strokeStyle = `rgba(250,220,120,${0.4 + this.lampGlow * 0.6})`
    ctx.lineWidth = 2.4
    ctx.beginPath()
    ctx.arc(lampX, lampY, 13, 0, Math.PI * 2)
    ctx.stroke()
    ctx.beginPath()
    ctx.moveTo(lampX - 6, lampY + 15)
    ctx.lineTo(lampX + 6, lampY + 15)
    ctx.stroke()
    labelChip(ctx, lampX, lampY - 40, this.lampGlow > 0.1 ? 'glowing — work being done' : 'dark', 'rgba(253,224,130,0.9)')

    // switch (top side)
    const swX = w * 0.5
    const swY = top
    ctx.strokeStyle = 'rgba(221,214,254,0.85)'
    ctx.lineWidth = 3
    ctx.beginPath()
    ctx.moveTo(swX - 18, swY)
    ctx.lineTo(swX + (this.switchOn ? 18 : 8), swY + (this.switchOn ? 0 : -14))
    ctx.lineTo(swX + 18, swY)
    ctx.stroke()
    labelChip(ctx, swX, swY - 30, this.switchOn ? 'switch closed — loop complete' : 'switch open — the loop is broken', 'rgba(221,214,254,0.95)')

    // electrons flowing
    const n = Math.round(14 * s.quality)
    const flow = (this.t * 0.14 * (0.4 + current)) % 1
    for (let i = 0; i < n; i++) {
      const k = (flow + i / n) % 1
      const p = this.wirePoint(s, k)
      if (this.switchOn) {
        glowCircle(ctx, p.x, p.y, 6, 'rgba(125,211,252,0.4)', 'rgba(125,211,252,0)')
        ctx.fillStyle = '#7dd3fc'
        ctx.beginPath()
        ctx.arc(p.x, p.y, 2.4, 0, Math.PI * 2)
        ctx.fill()
      } else {
        ctx.fillStyle = 'rgba(125,211,252,0.22)'
        ctx.beginPath()
        ctx.arc(p.x, p.y, 2, 0, Math.PI * 2)
        ctx.fill()
      }
    }

    labelChip(ctx, w * 0.5, bot + 40, this.switchOn ? 'electrons drift round the loop' : 'a gap anywhere stops the flow', 'rgba(147,197,253,0.9)')
  }

  pointerDown(s: SceneFrameState) {
    if (this.variant === 'atom') {
      const cx = s.w * 0.5
      const cy = s.h * 0.46
      if (Math.hypot(s.pointer.x - cx, s.pointer.y - cy) < 60) {
        this.excite()
        return 0
      }
      return 1
    }
    // circuit — the switch
    const swX = s.w * 0.5
    const swY = this.circuitPath(s).top
    if (Math.abs(s.pointer.x - swX) < 50 && Math.abs(s.pointer.y - swY) < 44) {
      this.switchOn = !this.switchOn
      return 1
    }
    // lamp
    const lampX = s.w - this.circuitPath(s).padX
    const lampY = (this.circuitPath(s).top + this.circuitPath(s).bot) / 2
    if (Math.hypot(s.pointer.x - lampX, s.pointer.y - lampY) < 50) return 0
    return null
  }

  trigger(id: string, s: SceneFrameState) {
    if (this.variant === 'atom') {
      if (id === 'excite') { this.excite(); this.excite(); this.excite(); return true }
      if (id === 'cool') { this.electrons.forEach((e) => { e.jumpT = -1; e.shell = 0 }); return true }
    } else {
      if (id === 'toggle') { this.switchOn = !this.switchOn; return true }
      if (id === 'surge') {
        this.switchOn = true
        for (let i = 0; i < 10; i++) {
          s.emit('spark', {
            x: s.w * 0.5 + (Math.random() - 0.5) * 140, y: this.circuitPath(s).top + 4,
            vx: (Math.random() - 0.5) * 220, vy: -Math.random() * 130,
            maxLife: 0.55, size: lerp(1.6, 3, Math.random()), hue: 48, light: 80,
          })
        }
        return true
      }
    }
    return false
  }
}

/* ==========================================================================
   Field — emotions, prism, aurora, magnet, energy, chaos, time.
   ========================================================================== */

export class FieldScene implements SceneRenderer {
  private variant: string
  private t = 0
  private rings: Array<{ r: number; born: number }> = []
  private lorenz: Array<{ x: number; y: number }> = []
  private lx = 0.4
  private ly = 0.2
  private lzx = 10
  private lzy = 28
  private filings: Array<{ x: number; y: number; a: number }> = []
  private flipped = 1
  private pendA = 0
  private pendV = 0.6

  constructor(variant: string) {
    this.variant = variant
  }

  enter(w: number, h: number) {
    this.t = 0
    this.rings = []
    this.lorenz = []
    if (this.variant === 'magnet') {
      this.filings = []
      for (let i = 0; i < 90; i++) {
        this.filings.push({
          x: (i % 15) / 14, y: Math.floor(i / 15) / 5,
          a: 0,
        })
      }
      this.alignFilings(w, h)
    }
  }

  private alignFilings(w: number, h: number) {
    const cx = w * 0.5
    const cy = h * 0.46
    const mw = Math.min(w * 0.16, 150)
    for (const f of this.filings) {
      const x = 30 + f.x * (w - 60)
      const y = h * 0.16 + f.y * (h * 0.62)
      const dx = x - cx
      const dy = (y - cy) * 2.6
      const r = Math.hypot(dx, dy)
      const pull = clamp01(1 - r / (mw * 4.2))
      const along = Math.atan2(dy, dx)
      // filings near poles align radially; farther out they curve
      const curve = Math.sin(along) * 0.8
      f.a = along - curve * pull * this.flipped * (dx > 0 ? 1 : -1) * 0.9
    }
  }

  update(s: SceneFrameState) {
    this.t += s.dt
    const inten = s.params.intensity ?? 1

    if (this.variant === 'joy' || this.variant === 'calm' || this.variant === 'time') {
      const rate = this.variant === 'calm' ? 0.22 : this.variant === 'time' ? 1 / 6 : 0.5 * inten
      if (Math.random() < s.dt * rate * 3) {
        this.rings.push({ r: 0, born: this.t })
      }
      for (let i = this.rings.length - 1; i >= 0; i--) {
        const speed = this.variant === 'joy' ? 150 * inten : this.variant === 'time' ? 90 : 46
        this.rings[i].r += s.dt * speed
        if (this.rings[i].r > Math.max(s.w, s.h)) this.rings.splice(i, 1)
      }
    }

    if (this.variant === 'chaos') {
      // Lorenz attractor integration
      const dt = s.dt * 2.4 * inten
      for (let i = 0; i < 3; i++) {
        const dx = 10 * (this.ly - this.lx)
        const dy = this.lx * (28 - this.lzx) - this.ly
        const dz = this.lx * this.ly - (8 / 3) * this.lzx
        this.lx += dx * dt * 0.01
        this.ly += dy * dt * 0.01
        this.lzx += dz * dt * 0.01
        this.lzy = this.lzy // keep names simple
      }
      const px = s.w * 0.5 + this.lx / 30 * s.w * 0.4
      const py = s.h * 0.5 - (this.lzy + 25) / 50 * s.h * 0.7 + 0.12 * s.h
      this.lorenz.push({ x: px, y: py })
      if (this.lorenz.length > 240) this.lorenz.shift()
    }

    if (this.variant === 'time') {
      this.pendA += this.pendV * s.dt * inten
      this.pendV += -Math.sin(this.pendA) * s.dt * 2.2
      this.pendV *= 0.999
    }
    void this.filings
  }

  draw(ctx: CanvasRenderingContext2D, s: SceneFrameState) {
    const { w, h } = s
    const cx = w * 0.5
    const cy = h * 0.44
    const inten = s.params.intensity ?? 1

    switch (this.variant) {
      case 'joy': this.drawJoy(ctx, s, cx, cy, inten); break
      case 'sadness': this.drawSadness(ctx, s, cx, cy, inten); break
      case 'anger': this.drawAnger(ctx, s, cx, cy, inten); break
      case 'calm': this.drawCalm(ctx, s, cx, cy, inten); break
      case 'prism': this.drawPrism(ctx, s, cx, cy, inten); break
      case 'aurora': this.drawAurora(ctx, s, inten); break
      case 'magnet': this.drawMagnet(ctx, s, cx, cy, inten); break
      case 'energy': this.drawEnergy(ctx, s, cx, cy, inten); break
      case 'chaos': this.drawChaos(ctx, s, cx, cy, inten); break
      case 'time': this.drawTime(ctx, s, cx, cy, inten); break
      default: this.drawCalm(ctx, s, cx, cy, inten)
    }
  }

  private drawJoy(ctx: CanvasRenderingContext2D, s: SceneFrameState, cx: number, cy: number, inten: number) {
    // rising sparkle field
    ctx.save()
    ctx.globalCompositeOperation = 'lighter'
    for (let i = 0; i < 26 * s.quality; i++) {
      const seed = i * 7.3
      const y = ((this.t * (26 + srand(seed) * 40) * inten + srand(seed + 1) * s.h) % (s.h * 1.1))
      const x = cx + (srand(seed + 2) - 0.5) * s.w * 0.72 + Math.sin(this.t * 1.4 + i) * 16
      const yy = s.h * 1.05 - y
      const r = 1.4 + srand(seed + 3) * 2.4
      ctx.fillStyle = `hsla(${lerp(45, 330, srand(seed + 4))}, 85%, 72%, ${0.5 + Math.sin(this.t * 3 + i) * 0.3})`
      ctx.beginPath()
      ctx.arc(x, yy, r, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.restore()
    // rising rings
    for (const ring of this.rings) {
      ctx.save()
      ctx.strokeStyle = `rgba(250,204,21,${0.4 * (1 - ring.r / Math.max(s.w, s.h))})`
      ctx.lineWidth = 2.4
      ctx.beginPath()
      ctx.ellipse(cx, cy, ring.r, ring.r * 0.6, 0, 0, Math.PI * 2)
      ctx.stroke()
      ctx.restore()
    }
    labelChip(ctx, cx, s.h * 0.12, 'everything rises — light, wide, contagious', 'rgba(253,224,130,0.95)')
  }

  private drawSadness(ctx: CanvasRenderingContext2D, s: SceneFrameState, cx: number, cy: number, inten: number) {
    // gentle rain of heavy drops
    ctx.save()
    for (let i = 0; i < 34 * s.quality * inten; i++) {
      const seed = i * 5.1
      const x = (srand(seed) * 1.1 - 0.05) * s.w + Math.sin(this.t * 0.5 + i) * 10
      const y = ((this.t * (34 + srand(seed + 1) * 30) + srand(seed + 2) * s.h) % (s.h + 40)) - 20
      ctx.fillStyle = `rgba(120,150,210,${0.24 + srand(seed + 3) * 0.3})`
      ctx.beginPath()
      ctx.ellipse(x, y, 1.6, 5.5, 0, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.restore()
    // pooling at the bottom
    const pool = s.h * 0.82
    ctx.save()
    ctx.fillStyle = 'rgba(60,80,130,0.28)'
    ctx.beginPath()
    ctx.ellipse(cx, pool + 26, s.w * 0.3 + Math.sin(this.t * 0.4) * 8, 16, 0, 0, Math.PI * 2)
    ctx.fill()
    ctx.restore()
    labelChip(ctx, cx, s.h * 0.12, 'slow, heavy, part of the process', 'rgba(147,197,253,0.9)')
  }

  private drawAnger(ctx: CanvasRenderingContext2D, s: SceneFrameState, cx: number, cy: number, inten: number) {
    // sharp red spikes pulsing outward
    const pulse = 0.5 + Math.sin(this.t * 5 * inten) * 0.5
    ctx.save()
    ctx.globalCompositeOperation = 'lighter'
    for (let i = 0; i < 22; i++) {
      const a = (i / 22) * Math.PI * 2 + this.t * 0.3
      const len = 60 + pulse * 90 * inten + srand(i) * 40
      const g = ctx.createLinearGradient(cx, cy, cx + Math.cos(a) * len, cy + Math.sin(a) * len)
      g.addColorStop(0, `rgba(255,90,60,${0.5 + pulse * 0.3})`)
      g.addColorStop(1, 'rgba(255,40,20,0)')
      ctx.strokeStyle = g
      ctx.lineWidth = 2 + pulse * 2
      ctx.beginPath()
      ctx.moveTo(cx + Math.cos(a) * 26, cy + Math.sin(a) * 26)
      ctx.lineTo(cx + Math.cos(a) * len, cy + Math.sin(a) * len)
      ctx.stroke()
    }
    ctx.restore()
    labelChip(ctx, cx, s.h * 0.12, 'quick, hot — energy asking for a direction', 'rgba(252,165,165,0.95)')
  }

  private drawCalm(ctx: CanvasRenderingContext2D, s: SceneFrameState, cx: number, cy: number, inten: number) {
    // six-second breathing waves
    for (const ring of this.rings) {
      const k = ring.r / Math.max(s.w, s.h)
      ctx.save()
      ctx.strokeStyle = `rgba(94,234,212,${0.34 * (1 - k)})`
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.arc(cx, cy, ring.r, 0, Math.PI * 2)
      ctx.stroke()
      ctx.restore()
    }
    // drifting motes
    ctx.save()
    for (let i = 0; i < 16 * s.quality; i++) {
      const seed = i * 9.7
      const x = cx + Math.sin(this.t * 0.22 + seed) * s.w * 0.3
      const y = cy + Math.cos(this.t * 0.18 + seed * 1.3) * s.h * 0.26
      ctx.fillStyle = `rgba(160,230,220,${0.3 + Math.sin(this.t + i) * 0.15})`
      ctx.beginPath()
      ctx.arc(x, y, 1.8 + srand(seed) * 1.6, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.restore()
    labelChip(ctx, cx, s.h * 0.12, 'breathe with the rings — six seconds each', 'rgba(167,243,208,0.95)')
  }

  private drawPrism(ctx: CanvasRenderingContext2D, s: SceneFrameState, cx: number, cy: number, inten: number) {
    // incoming white beam
    const beamK = inten
    ctx.save()
    ctx.globalCompositeOperation = 'lighter'
    const from = { x: cx - s.w * 0.34, y: cy - s.h * 0.3 }
    ctx.strokeStyle = `rgba(255,255,255,${0.5 * beamK})`
    ctx.lineWidth = 3 + beamK * 2
    ctx.beginPath()
    ctx.moveTo(from.x, from.y)
    ctx.lineTo(cx - 26, cy - 12)
    ctx.stroke()
    ctx.restore()

    // prism triangle
    ctx.save()
    ctx.beginPath()
    ctx.moveTo(cx, cy - 42)
    ctx.lineTo(cx + 38, cy + 28)
    ctx.lineTo(cx - 38, cy + 28)
    ctx.closePath()
    const pg = ctx.createLinearGradient(cx - 38, cy - 42, cx + 38, cy + 28)
    pg.addColorStop(0, 'rgba(200,220,255,0.25)')
    pg.addColorStop(0.5, 'rgba(255,255,255,0.16)')
    pg.addColorStop(1, 'rgba(160,180,220,0.3)')
    ctx.fillStyle = pg
    ctx.fill()
    ctx.strokeStyle = 'rgba(220,230,255,0.6)'
    ctx.lineWidth = 1.6
    ctx.stroke()
    ctx.restore()

    // spectrum fan
    const colors = ['#ff5e5e', '#ff9d45', '#ffe066', '#7ef29b', '#5eb6ff', '#8b7bff', '#c77dff']
    ctx.save()
    ctx.globalCompositeOperation = 'lighter'
    colors.forEach((col, i) => {
      const spread = (i - 3) * 0.16
      const a = spread * beamK
      const len = s.w * 0.4
      ctx.strokeStyle = col
      ctx.globalAlpha = 0.55 * beamK
      ctx.lineWidth = 5
      ctx.beginPath()
      ctx.moveTo(cx + 22, cy + 2)
      ctx.lineTo(cx + 22 + Math.cos(a) * len, cy + 2 + Math.sin(a) * len * 0.8)
      ctx.stroke()
    })
    ctx.restore()

    // floating droplets that make it possible
    ctx.save()
    for (let i = 0; i < 14 * s.quality; i++) {
      const seed = i * 3.7
      const x = (srand(seed) * 0.9 + 0.05) * s.w
      const y = s.h * 0.24 + srand(seed + 1) * s.h * 0.6 + Math.sin(this.t + i) * 4
      ctx.strokeStyle = 'rgba(180,220,255,0.4)'
      ctx.lineWidth = 1
      ctx.beginPath()
      ctx.arc(x, y, 3.4, 0, Math.PI * 2)
      ctx.stroke()
      ctx.fillStyle = 'rgba(200,230,255,0.24)'
      ctx.beginPath()
      ctx.arc(x - 1, y - 1, 1.4, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.restore()

    labelChip(ctx, cx, s.h * 0.12, 'white light is all the colours, travelling together', 'rgba(221,214,254,0.95)')
  }

  private drawAurora(ctx: CanvasRenderingContext2D, s: SceneFrameState, inten: number) {
    const { w, h } = s
    // dancing curtains
    ctx.save()
    ctx.globalCompositeOperation = 'lighter'
    const curtains = [
      { hue: 140, yBase: 0.16, amp: 46, alpha: 0.34 },
      { hue: 168, yBase: 0.1, amp: 62, alpha: 0.26 },
      { hue: 280, yBase: 0.05, amp: 34, alpha: 0.18 },
    ]
    for (const c of curtains) {
      for (let band = 0; band < 3; band++) {
        ctx.beginPath()
        const x0 = 0
        const yAt = (x: number) =>
          h * c.yBase + Math.sin(x * 0.004 + this.t * (0.5 + band * 0.12) + c.hue) * c.amp
        ctx.moveTo(x0, yAt(x0))
        for (let x = 0; x <= w; x += 14) ctx.lineTo(x, yAt(x))
        for (let x = w; x >= 0; x -= 14) ctx.lineTo(x, yAt(x) + 120 + band * 34)
        ctx.closePath()
        const g = ctx.createLinearGradient(0, h * c.yBase - c.amp, 0, h * c.yBase + 170)
        g.addColorStop(0, `hsla(${c.hue}, 85%, 66%, 0)`)
        g.addColorStop(0.4, `hsla(${c.hue}, 85%, 66%, ${c.alpha * inten})`)
        g.addColorStop(1, `hsla(${c.hue}, 85%, 66%, 0)`)
        ctx.fillStyle = g
        ctx.fill()
      }
    }
    ctx.restore()
    labelChip(ctx, w * 0.5, h * 0.84, 'solar wind, caught by the magnetic field', 'rgba(167,243,208,0.95)')
  }

  private drawMagnet(ctx: CanvasRenderingContext2D, s: SceneFrameState, cx: number, cy: number, inten: number) {
    const mw = Math.min(s.w * 0.15, 150)
    const mh = mw * 0.42

    // field lines (dipole loops)
    ctx.save()
    ctx.strokeStyle = `rgba(147,197,253,${0.2 + inten * 0.18})`
    ctx.lineWidth = 1.4
    for (let L = 1; L <= 4; L++) {
      const rx = mw * (0.7 + L * 0.42)
      const ry = mh * (0.7 + L * 0.85)
      ctx.beginPath()
      ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2)
      ctx.stroke()
    }
    ctx.restore()

    // iron filings aligned
    ctx.save()
    ctx.strokeStyle = 'rgba(220,220,235,0.5)'
    ctx.lineWidth = 1.4
    for (const f of this.filings) {
      const x = 30 + f.x * (s.w - 60)
      const y = s.h * 0.16 + f.y * (s.h * 0.62)
      const dx = x - cx
      const dy = y - cy
      if (Math.hypot(dx, dy) < mw * 0.8) continue
      ctx.save()
      ctx.translate(x, y)
      ctx.rotate(f.a)
      ctx.beginPath()
      ctx.moveTo(-5, 0)
      ctx.lineTo(5, 0)
      ctx.stroke()
      ctx.restore()
    }
    ctx.restore()

    // bar magnet
    ctx.save()
    const half = mw / 2
    // north (red) / south (blue) — flips visually
    const nCol = this.flipped > 0 ? '#f87171' : '#60a5fa'
    const sCol = this.flipped > 0 ? '#60a5fa' : '#f87171'
    ctx.fillStyle = nCol
    ctx.fillRect(cx - half, cy - mh / 2, half, mh)
    ctx.fillStyle = sCol
    ctx.fillRect(cx, cy - mh / 2, half, mh)
    ctx.strokeStyle = 'rgba(20,20,40,0.5)'
    ctx.strokeRect(cx - half, cy - mh / 2, mw, mh)
    ctx.fillStyle = '#fff'
    ctx.font = '800 15px Inter, system-ui'
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.fillText(this.flipped > 0 ? 'N' : 'S', cx - half / 2, cy)
    ctx.fillText(this.flipped > 0 ? 'S' : 'N', cx + half / 2, cy)
    ctx.restore()

    labelChip(ctx, cx, s.h * 0.1, this.flipped > 0 ? 'like poles repel — opposites attract' : 'flipped! every filing swung around', 'rgba(221,214,254,0.95)')
  }

  private drawEnergy(ctx: CanvasRenderingContext2D, s: SceneFrameState, cx: number, cy: number, inten: number) {
    // golden circuit loop with flowing orbs
    ctx.save()
    const pts: Array<{ x: number; y: number }> = []
    const R = Math.min(s.w, s.h) * 0.24
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2 - Math.PI / 2
      pts.push({ x: cx + Math.cos(a) * R, y: cy + Math.sin(a) * R * 0.8 })
    }
    ctx.strokeStyle = 'rgba(250,204,21,0.3)'
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(pts[0].x, pts[0].y)
    for (let i = 1; i <= pts.length; i++) {
      const p = pts[i % pts.length]
      ctx.quadraticCurveTo(pts[(i - 1) % pts.length].x + 40, pts[(i - 1) % pts.length].y, p.x, p.y)
    }
    ctx.stroke()
    // nodes
    for (const p of pts) {
      glowCircle(ctx, p.x, p.y, 16, `rgba(250,204,21,${0.3 + inten * 0.2})`, 'rgba(250,204,21,0)')
      ctx.fillStyle = '#fde68a'
      ctx.beginPath()
      ctx.arc(p.x, p.y, 4, 0, Math.PI * 2)
      ctx.fill()
    }
    // flowing energy orbs
    for (let i = 0; i < 7; i++) {
      const k = (this.t * 0.16 * (0.4 + inten) + i / 7) % 1
      const seg = Math.floor(k * 5)
      const lk = (k * 5) % 1
      const p0 = pts[seg % 5]
      const p1 = pts[(seg + 1) % 5]
      const mx = (p0.x + p1.x) / 2 + 40
      const my = (p0.y + p1.y) / 2
      const bx = (1 - lk) * (1 - lk) * p0.x + 2 * (1 - lk) * lk * mx + lk * lk * p1.x
      const by = (1 - lk) * (1 - lk) * p0.y + 2 * (1 - lk) * lk * my + lk * lk * p1.y
      glowCircle(ctx, bx, by, 12, 'rgba(253,224,130,0.5)', 'rgba(253,224,130,0)')
      ctx.fillStyle = '#fef3c7'
      ctx.beginPath()
      ctx.arc(bx, by, 2.6, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.restore()
    labelChip(ctx, cx, s.h * 0.12, 'transformed, never lost', 'rgba(253,224,130,0.95)')
  }

  private drawChaos(ctx: CanvasRenderingContext2D, s: SceneFrameState, cx: number, cy: number, inten: number) {
    // Lorenz butterfly attractor trace
    ctx.save()
    ctx.globalCompositeOperation = 'lighter'
    for (let i = 1; i < this.lorenz.length; i++) {
      const k = i / this.lorenz.length
      const p0 = this.lorenz[i - 1]
      const p1 = this.lorenz[i]
      ctx.strokeStyle = `hsla(${lerp(262, 190, k)}, 80%, 68%, ${k * 0.7})`
      ctx.lineWidth = 1 + k * 1.6
      ctx.beginPath()
      ctx.moveTo(p0.x, p0.y)
      ctx.lineTo(p1.x, p1.y)
      ctx.stroke()
    }
    const head = this.lorenz[this.lorenz.length - 1]
    if (head) {
      glowCircle(ctx, head.x, head.y, 22, 'rgba(196,181,253,0.5)', 'rgba(196,181,253,0)')
      ctx.fillStyle = '#e9d5ff'
      ctx.beginPath()
      ctx.arc(head.x, head.y, 3.4, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.restore()
    labelChip(ctx, cx, s.h * 0.12, 'strict rules — yet never the same path twice', 'rgba(221,214,254,0.95)')
    void inten
  }

  private drawTime(ctx: CanvasRenderingContext2D, s: SceneFrameState, cx: number, cy: number, inten: number) {
    // second ripples + pendulum
    for (const ring of this.rings) {
      const k = ring.r / Math.max(s.w, s.h)
      ctx.save()
      ctx.strokeStyle = `rgba(196,181,253,${0.36 * (1 - k)})`
      ctx.lineWidth = 1.6
      ctx.beginPath()
      ctx.arc(cx, cy, ring.r, 0, Math.PI * 2)
      ctx.stroke()
      ctx.restore()
    }
    // pendulum
    const plen = Math.min(s.h * 0.3, 200)
    const bx = cx + Math.sin(this.pendA) * plen
    const by = cy - 60 + Math.cos(this.pendA) * plen
    ctx.save()
    ctx.strokeStyle = 'rgba(220,214,254,0.5)'
    ctx.lineWidth = 1.6
    ctx.beginPath()
    ctx.moveTo(cx, cy - 60)
    ctx.lineTo(bx, by)
    ctx.stroke()
    ctx.fillStyle = '#c4b5fd'
    ctx.beginPath()
    ctx.arc(bx, by, 10, 0, Math.PI * 2)
    ctx.fill()
    // pivot
    ctx.fillStyle = 'rgba(220,214,254,0.8)'
    ctx.beginPath()
    ctx.arc(cx, cy - 60, 4, 0, Math.PI * 2)
    ctx.fill()
    ctx.restore()
    // tick marks around
    ctx.save()
    ctx.strokeStyle = 'rgba(196,181,253,0.3)'
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2
      const r0 = Math.min(s.w, s.h) * 0.3
      ctx.beginPath()
      ctx.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0)
      ctx.lineTo(cx + Math.cos(a) * (r0 + 8), cy + Math.sin(a) * (r0 + 8))
      ctx.stroke()
    }
    ctx.restore()
    labelChip(ctx, cx, s.h * 0.88, 'a second: 9,192,631,770 caesium vibrations', 'rgba(196,181,253,0.95)')
  }

  pointerDown(s: SceneFrameState) {
    const cx = s.w * 0.5
    const cy = s.h * 0.44
    if (this.variant === 'magnet') {
      if (Math.abs(s.pointer.x - cx) < 110 && Math.abs(s.pointer.y - cy) < 70) {
        this.flipped *= -1
        this.alignFilings(s.w, s.h)
        return 3
      }
      return 1
    }
    if (Math.hypot(s.pointer.x - cx, s.pointer.y - cy) < 150) {
      // centre interactions per variant
      if (this.variant === 'joy' || this.variant === 'calm' || this.variant === 'time') {
        this.rings.push({ r: 0, born: this.t })
        return 0
      }
      if (this.variant === 'sadness') {
        s.emit('splash', { x: cx, y: cy + 40, vx: 0, vy: 30, maxLife: 1.2, size: 3, hue: 210 })
        return 1
      }
      if (this.variant === 'anger') return 0
      if (this.variant === 'prism') return 1
      if (this.variant === 'aurora') return 0
      if (this.variant === 'energy') { this.rings.push({ r: 0, born: this.t }); return 0 }
      if (this.variant === 'chaos') {
        this.lx += (Math.random() - 0.5) * 0.6
        this.ly += (Math.random() - 0.5) * 0.6
        return 0
      }
    }
    return null
  }

  trigger(id: string, s: SceneFrameState) {
    switch (id) {
      case 'burst': case 'pulse': case 'ripple':
        this.rings.push({ r: 0, born: this.t })
        return true
      case 'share':
        for (let i = 0; i < 3; i++) this.rings.push({ r: -i * 40, born: this.t })
        return true
      case 'drift': case 'clear':
        return true
      case 'flare':
        this.rings.push({ r: 0, born: this.t })
        return true
      case 'breathe':
        this.rings.push({ r: 0, born: this.t })
        return true
      case 'shine': case 'gust':
        this.rings.push({ r: 0, born: this.t })
        return true
      case 'mist':
        for (let i = 0; i < 12 * s.quality; i++) {
          s.emit('splash', {
            x: Math.random() * s.w, y: s.h * 0.2 + Math.random() * s.h * 0.3,
            vx: (Math.random() - 0.5) * 20, vy: lerp(40, 120, Math.random()),
            maxLife: 1.4, size: lerp(1.2, 2.4, Math.random()), hue: 200,
          })
        }
        return true
      case 'flip':
        this.flipped *= -1
        this.alignFilings(s.w, s.h)
        return true
      case 'shake':
        this.filings.forEach((f) => { f.a += (Math.random() - 0.5) * 0.4 })
        return true
      case 'nudge':
        this.lx += (Math.random() - 0.5) * 1.2
        this.ly += (Math.random() - 0.5) * 1.2
        return true
      case 'reset':
        this.lorenz = []
        this.lx = 0.4
        this.ly = 0.2
        return true
      case 'rewind':
        this.rings = []
        this.pendA = 0
        this.pendV = 0.6
        return true
      case 'transform':
        this.rings.push({ r: 0, born: this.t })
        this.rings.push({ r: -50, born: this.t })
        return true
      default:
        return false
    }
  }
}

/* ==========================================================================
   Timeline — history eras with event nodes + era silhouettes.
   ========================================================================== */

export class TimelineScene implements SceneRenderer {
  private variant: string
  private t = 0
  private node = 0
  private nodeT = 0
  private events: Array<{ year: string; label: string }> = []

  constructor(variant: string) {
    this.variant = variant
    switch (variant) {
      case 'egypt':
        this.events = [
          { year: '~3100 BC', label: 'Upper and Lower Egypt unite' },
          { year: '~2560 BC', label: 'Great Pyramid completed at Giza' },
          { year: '~1330 BC', label: 'Tutankhamun rules — his tomb survives' },
          { year: '1799', label: 'Rosetta Stone discovered' },
          { year: '1822', label: 'Hieroglyphs finally decoded' },
        ]
        break
      case 'rome':
        this.events = [
          { year: '27 BC', label: 'Augustus — the Empire begins' },
          { year: '~80 AD', label: 'The Colosseum opens' },
          { year: '~117 AD', label: 'Rome at its greatest extent' },
          { year: '476 AD', label: 'The western Empire falls' },
          { year: 'today', label: 'Latin lives on in five languages' },
        ]
        break
      case 'wall':
        this.events = [
          { year: '~220 BC', label: 'First walls linked under Qin' },
          { year: '~1368', label: 'Ming rebuilds the iconic wall' },
          { year: '1644', label: 'The Ming era ends' },
          { year: '1987', label: 'UNESCO World Heritage listing' },
          { year: '2012', label: 'Survey: 21,196 km of wall' },
        ]
        break
      default: // apollo
        this.events = [
          { year: '1961', label: 'Kennedy commits to the Moon' },
          { year: '1968', label: 'Apollo 8 orbits the Moon' },
          { year: '1969', label: 'Apollo 11 lands — one small step' },
          { year: '1972', label: 'Apollo 17 — the last walk (so far)' },
          { year: 'today', label: 'Footprints still fresh after 50+ years' },
        ]
    }
  }

  enter() {
    this.t = 0
    this.node = 0
    this.nodeT = 0
  }

  update(s: SceneFrameState) {
    this.t += s.dt
    this.nodeT += s.dt * (s.params.pace ?? 1)
    if (this.nodeT > 6) {
      this.nodeT = 0
      this.node = (this.node + 1) % this.events.length
    }
  }

  draw(ctx: CanvasRenderingContext2D, s: SceneFrameState) {
    const { w, h } = s
    const lineY = h * 0.62
    const inset = Math.min(w * 0.14, 120)
    const span = w - inset * 2

    // era backdrop
    this.drawEra(ctx, s, lineY)

    // timeline spine
    ctx.save()
    const g = ctx.createLinearGradient(inset, 0, w - inset, 0)
    g.addColorStop(0, 'rgba(251,191,36,0.15)')
    g.addColorStop(0.5, 'rgba(251,191,36,0.5)')
    g.addColorStop(1, 'rgba(251,191,36,0.15)')
    ctx.strokeStyle = g
    ctx.lineWidth = 2.4
    ctx.beginPath()
    ctx.moveTo(inset, lineY)
    ctx.lineTo(w - inset, lineY)
    ctx.stroke()
    ctx.restore()

    // nodes
    const n = this.events.length
    this.events.forEach((ev, i) => {
      const x = inset + (i / (n - 1)) * span
      const active = i === this.node
      const lit = i <= this.node
      const k = active ? easeOut(Math.min(1, this.nodeT / 0.5)) : 1
      // node dot
      if (active) glowCircle(ctx, x, lineY, 30 + k * 14, 'rgba(251,191,36,0.3)', 'rgba(251,191,36,0)')
      ctx.fillStyle = lit ? (active ? '#fde68a' : 'rgba(251,191,36,0.65)') : 'rgba(255,255,255,0.22)'
      ctx.beginPath()
      ctx.arc(x, lineY, active ? 7 : 5, 0, Math.PI * 2)
      ctx.fill()
      // year + label (alternate above/below)
      const above = i % 2 === 0
      const ty = above ? lineY - 58 : lineY + 52
      ctx.save()
      ctx.globalAlpha = lit ? 1 : 0.4
      ctx.textAlign = 'center'
      ctx.fillStyle = active ? '#fde68a' : 'rgba(255,255,255,0.65)'
      ctx.font = '700 13px Space Grotesk, Inter, sans-serif'
      ctx.fillText(ev.year, x, ty)
      ctx.font = '500 11px Inter, sans-serif'
      ctx.fillStyle = active ? 'rgba(255,255,255,0.92)' : 'rgba(255,255,255,0.45)'
      ctx.fillText(ev.label, x, ty + 17)
      // stem
      ctx.strokeStyle = lit ? 'rgba(251,191,36,0.4)' : 'rgba(255,255,255,0.12)'
      ctx.lineWidth = 1.2
      ctx.beginPath()
      ctx.moveTo(x, lineY + (above ? -8 : 8))
      ctx.lineTo(x, ty + (above ? 12 : -14))
      ctx.stroke()
      ctx.restore()
    })

    // active event chip
    const ev = this.events[this.node]
    labelChip(ctx, w * 0.5, h * 0.14, `${ev.year} — ${ev.label}`, 'rgba(253,224,130,0.95)')
  }

  private drawEra(ctx: CanvasRenderingContext2D, s: SceneFrameState, lineY: number) {
    const { w, h } = s
    const groundY = lineY + 110 > h ? h - 40 : lineY + 96
    switch (this.variant) {
      case 'egypt': {
        // dunes + pyramids + big sun
        glowCircle(ctx, w * 0.78, h * 0.2, 90, 'rgba(250,204,120,0.28)', 'rgba(250,204,120,0)')
        ctx.fillStyle = '#fcd34d'
        ctx.beginPath()
        ctx.arc(w * 0.78, h * 0.2, 30, 0, Math.PI * 2)
        ctx.fill()
        const pyramids = [
          { x: 0.2, size: 64 }, { x: 0.32, size: 44 }, { x: 0.44, size: 30 },
        ]
        for (const p of pyramids) {
          const px = w * p.x
          const pz = groundY
          ctx.fillStyle = 'rgba(214,164,96,0.85)'
          ctx.beginPath()
          ctx.moveTo(px, pz - p.size)
          ctx.lineTo(px + p.size * 0.85, pz)
          ctx.lineTo(px - p.size * 0.85, pz)
          ctx.closePath()
          ctx.fill()
          ctx.fillStyle = 'rgba(180,132,74,0.85)'
          ctx.beginPath()
          ctx.moveTo(px, pz - p.size)
          ctx.lineTo(px + p.size * 0.32, pz)
          ctx.lineTo(px - p.size * 0.32, pz)
          ctx.closePath()
          ctx.fill()
        }
        ctx.fillStyle = 'rgba(194,150,90,0.5)'
        ctx.beginPath()
        ctx.moveTo(0, groundY)
        for (let x = 0; x <= w; x += 30) ctx.lineTo(x, groundY + Math.sin(x * 0.01) * 6)
        ctx.lineTo(w, h)
        ctx.lineTo(0, h)
        ctx.fill()
        break
      }
      case 'rome': {
        // arches (aqueduct / colosseum)
        ctx.fillStyle = 'rgba(120,100,84,0.55)'
        const baseY = groundY
        const archW = 54
        for (let x = w * 0.08; x < w * 0.95; x += archW) {
          ctx.fillRect(x, baseY - 58, archW - 8, 58)
          ctx.save()
          ctx.globalCompositeOperation = 'destination-out'
          ctx.beginPath()
          ctx.arc(x + (archW - 8) / 2, baseY - 24, 15, 0, Math.PI * 2)
          ctx.fill()
          ctx.restore()
        }
        ctx.fillStyle = 'rgba(150,124,100,0.6)'
        ctx.fillRect(w * 0.08 - 6, baseY - 70, w * 0.87 + 12, 10)
        break
      }
      case 'wall': {
        // wall with towers on ridges
        ctx.fillStyle = 'rgba(90,74,66,0.75)'
        const baseY = groundY
        ctx.beginPath()
        ctx.moveTo(0, baseY)
        for (let x = 0; x <= w; x += 26) {
          ctx.lineTo(x, baseY - 16 - Math.sin(x * 0.008) * 22)
        }
        ctx.lineTo(w, baseY + 10)
        ctx.lineTo(w, h)
        ctx.lineTo(0, h)
        ctx.fill()
        // crenellations
        ctx.fillStyle = 'rgba(110,90,80,0.85)'
        for (let x = 0; x <= w; x += 52) {
          const wy = baseY - 16 - Math.sin(x * 0.008) * 22
          ctx.fillRect(x, wy - 10, 8, 10)
          ctx.fillRect(x + 16, wy - 10, 8, 10)
        }
        // towers
        for (let i = 0; i < 3; i++) {
          const tx = w * (0.2 + i * 0.3)
          const ty = baseY - 16 - Math.sin(tx * 0.008) * 22
          ctx.fillRect(tx - 14, ty - 44, 28, 44)
          for (let c = 0; c < 3; c++) ctx.fillRect(tx - 14 + c * 11, ty - 54, 7, 10)
          if (i === this.node) {
            // beacon fire
            glowCircle(ctx, tx, ty - 62, 26, 'rgba(250,160,60,0.5)', 'rgba(250,160,60,0)')
          }
        }
        break
      }
      default: {
        // apollo — moonscape + Earth in sky + lander
        ctx.fillStyle = 'rgba(120,124,140,0.8)'
        ctx.beginPath()
        ctx.arc(w * 0.82, h * 0.18, 26, 0, Math.PI * 2)
        ctx.fill()
        ctx.fillStyle = 'rgba(80,120,200,0.75)'
        ctx.beginPath()
        ctx.arc(w * 0.82 - 6, h * 0.18 - 4, 20, 0, Math.PI * 2)
        ctx.fill()
        ctx.fillStyle = 'rgba(90,150,120,0.7)'
        ctx.beginPath()
        ctx.arc(w * 0.82 - 10, h * 0.18 + 6, 8, 0, Math.PI * 2)
        ctx.fill()
        // ground
        ctx.fillStyle = 'rgba(70,70,84,0.9)'
        ctx.beginPath()
        ctx.moveTo(0, groundY)
        for (let x = 0; x <= w; x += 24) ctx.lineTo(x, groundY + Math.sin(x * 0.02) * 5 + srand(Math.floor(x / 24)) * 8)
        ctx.lineTo(w, h)
        ctx.lineTo(0, h)
        ctx.fill()
        // craters
        for (let i = 0; i < 6; i++) {
          const crx = srand(i * 13) * w
          const cry = groundY + 14 + srand(i * 7) * 26
          ctx.strokeStyle = 'rgba(40,40,54,0.5)'
          ctx.lineWidth = 2
          ctx.beginPath()
          ctx.ellipse(crx, cry, 12 + srand(i) * 10, 4, 0, 0, Math.PI * 2)
          ctx.stroke()
        }
        // lander
        const lx = w * 0.24
        const ly = groundY - 8
        ctx.fillStyle = 'rgba(200,200,214,0.9)'
        ctx.beginPath()
        ctx.moveTo(lx - 16, ly - 26)
        ctx.lineTo(lx + 16, ly - 26)
        ctx.lineTo(lx + 11, ly - 8)
        ctx.lineTo(lx - 11, ly - 8)
        ctx.closePath()
        ctx.fill()
        ctx.strokeStyle = 'rgba(200,200,214,0.8)'
        ctx.lineWidth = 2
        for (const side of [-1, 1]) {
          ctx.beginPath()
          ctx.moveTo(lx + side * 9, ly - 8)
          ctx.lineTo(lx + side * 20, ly)
          ctx.stroke()
        }
        ctx.fillStyle = '#fbbf24'
        ctx.fillRect(lx - 6, ly - 36, 3, 10)
        ctx.fillRect(lx + 3, ly - 36, 3, 10)
        break
      }
    }
  }

  pointerDown(s: SceneFrameState) {
    const { w, h } = s
    const lineY = h * 0.62
    const inset = Math.min(w * 0.14, 120)
    const span = w - inset * 2
    const n = this.events.length
    for (let i = 0; i < n; i++) {
      const x = inset + (i / (n - 1)) * span
      if (Math.abs(s.pointer.x - x) < 46 && Math.abs(s.pointer.y - lineY) < 70) {
        this.node = i
        this.nodeT = 0
        return i % 4
      }
    }
    return null
  }

  trigger(id: string, _s: SceneFrameState) {
    if (id === 'next') {
      this.node = (this.node + 1) % this.events.length
      this.nodeT = 0
      return true
    }
    if (id === 'replay') {
      this.node = 0
      this.nodeT = 0
      return true
    }
    void _s
    return false
  }
}

/* ==========================================================================
   Gears — clockwork | robot.
   ========================================================================== */

export class GearsScene implements SceneRenderer {
  private variant: string
  private t = 0
  private speedK = 1
  private windT = -1
  private eyeA = 0
  private scanT = -1
  private chimeT = -1

  constructor(variant: string) {
    this.variant = variant === 'robot' ? 'robot' : 'clock'
  }

  enter() {
    this.t = 0
    this.speedK = 1
    this.windT = -1
    this.scanT = -1
    this.chimeT = -1
  }

  update(s: SceneFrameState) {
    this.t += s.dt * (s.params.speed ?? s.params.activity ?? 1) * this.speedK
    if (this.windT >= 0) {
      this.windT += s.dt
      this.speedK = 1 + Math.sin(clamp01(this.windT / 2.5) * Math.PI) * 2.2
      if (this.windT > 2.5) { this.windT = -1; this.speedK = 1 }
    }
    if (this.scanT >= 0) {
      this.scanT += s.dt
      if (this.scanT > 1.4) this.scanT = -1
    }
    if (this.chimeT >= 0) {
      this.chimeT += s.dt
      if (this.chimeT > 2.2) this.chimeT = -1
    }
    // robot eye follows pointer
    if (this.variant === 'robot' && s.pointer.active) {
      const dx = s.pointer.x - s.w * 0.5
      this.eyeA = clamp01(dx / (s.w * 0.5)) * 0.6
    }
  }

  private gear(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, teeth: number, rot: number, col: string) {
    ctx.save()
    ctx.translate(x, y)
    ctx.rotate(rot)
    ctx.fillStyle = col
    ctx.beginPath()
    for (let i = 0; i < teeth; i++) {
      const a0 = (i / teeth) * Math.PI * 2
      const a1 = ((i + 0.38) / teeth) * Math.PI * 2
      const a2 = ((i + 0.62) / teeth) * Math.PI * 2
      const a3 = ((i + 1) / teeth) * Math.PI * 2
      ctx.arc(0, 0, r, a0, a1)
      ctx.arc(0, 0, r * 1.22, a1, a2)
      ctx.arc(0, 0, r, a2, a3)
    }
    ctx.closePath()
    ctx.fill()
    // hub
    ctx.fillStyle = 'rgba(12,12,26,0.85)'
    ctx.beginPath()
    ctx.arc(0, 0, r * 0.32, 0, Math.PI * 2)
    ctx.fill()
    ctx.strokeStyle = 'rgba(255,255,255,0.25)'
    ctx.lineWidth = 1.4
    ctx.beginPath()
    ctx.arc(0, 0, r, 0, Math.PI * 2)
    ctx.stroke()
    ctx.restore()
  }

  draw(ctx: CanvasRenderingContext2D, s: SceneFrameState) {
    if (this.variant === 'clock') this.drawClock(ctx, s)
    else this.drawRobot(ctx, s)
  }

  private drawClock(ctx: CanvasRenderingContext2D, s: SceneFrameState) {
    const { w, h } = s
    const cx = w * 0.5
    const cy = h * 0.42

    // faint clock face behind
    ctx.save()
    ctx.strokeStyle = 'rgba(196,181,253,0.16)'
    ctx.lineWidth = 1.4
    ctx.beginPath()
    ctx.arc(cx, cy, Math.min(w, h) * 0.27, 0, Math.PI * 2)
    ctx.stroke()
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2
      const r0 = Math.min(w, h) * 0.25
      ctx.beginPath()
      ctx.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0)
      ctx.lineTo(cx + Math.cos(a) * (r0 + 10), cy + Math.sin(a) * (r0 + 10))
      ctx.stroke()
    }
    ctx.restore()

    // gear train — ratios counter-rotate
    const gears = [
      { x: cx - 96, y: cy - 20, r: 34, teeth: 10, rate: 0.7 },
      { x: cx - 42, y: cy + 24, r: 24, teeth: 8, rate: -1.05 },
      { x: cx + 22, y: cy - 8, r: 40, teeth: 12, rate: 0.5 },
      { x: cx + 88, y: cy + 30, r: 18, teeth: 7, rate: -1.5 },
    ]
    gears.forEach((g, i) => {
      this.gear(ctx, g.x, g.y, g.r, g.teeth, this.t * g.rate + i, 'rgba(148,130,190,0.55)')
    })

    // pendulum below
    const plen = Math.min(h * 0.26, 170)
    const swing = Math.sin(this.t * 2.2) * 0.34
    const px = cx + Math.sin(swing) * plen
    const py = cy + 64 + Math.cos(swing) * plen
    ctx.save()
    ctx.strokeStyle = 'rgba(200,190,225,0.6)'
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(cx, cy + 64)
    ctx.lineTo(px, py)
    ctx.stroke()
    glowCircle(ctx, px, py, 24, 'rgba(196,181,253,0.3)', 'rgba(196,181,253,0)')
    ctx.fillStyle = '#c4b5fd'
    ctx.beginPath()
    ctx.arc(px, py, 12, 0, Math.PI * 2)
    ctx.fill()
    ctx.restore()

    // tick flash
    const tick = Math.sin(this.t * 2.2 * Math.PI)
    if (tick > 0.96) {
      glowCircle(ctx, cx, cy + 64, 18, 'rgba(253,224,130,0.4)', 'rgba(253,224,130,0)')
    }

    if (this.chimeT >= 0) {
      const k = (this.chimeT % 0.7) / 0.7
      ctx.save()
      ctx.strokeStyle = `rgba(253,224,130,${0.6 * (1 - k)})`
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.arc(cx, cy, 60 + k * 120, 0, Math.PI * 2)
      ctx.stroke()
      ctx.restore()
      labelChip(ctx, w * 0.5, h * 0.12, 'the hour rings', 'rgba(253,224,130,0.95)')
    } else {
      labelChip(ctx, w * 0.5, h * 0.12, 'neighbours always turn opposite ways', 'rgba(221,214,254,0.95)')
    }
  }

  private drawRobot(ctx: CanvasRenderingContext2D, s: SceneFrameState) {
    const { w, h } = s
    const cx = w * 0.5
    const cy = h * 0.46
    const activity = s.params.activity ?? 1
    const bob = Math.sin(this.t * 2) * 3 * activity

    ctx.save()
    ctx.translate(cx, cy + bob)

    // antenna
    ctx.strokeStyle = 'rgba(200,190,225,0.7)'
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(0, -66)
    ctx.lineTo(0, -92)
    ctx.stroke()
    const blink = Math.sin(this.t * 4) > 0.4 ? 0.9 : 0.3
    glowCircle(ctx, 0, -96, 14, `rgba(248,113,113,${blink})`, 'rgba(248,113,113,0)')
    ctx.fillStyle = `rgba(248,113,113,${blink})`
    ctx.beginPath()
    ctx.arc(0, -96, 4.4, 0, Math.PI * 2)
    ctx.fill()

    // head
    const hg = ctx.createLinearGradient(-50, -66, 50, -10)
    hg.addColorStop(0, 'rgba(120,124,160,0.95)')
    hg.addColorStop(1, 'rgba(74,80,110,0.95)')
    ctx.fillStyle = hg
    roundRectPath(ctx, -50, -66, 100, 56, 14)
    ctx.fill()
    ctx.strokeStyle = 'rgba(220,214,254,0.35)'
    ctx.lineWidth = 1.6
    ctx.stroke()

    // visor + scanning eye
    ctx.fillStyle = 'rgba(14,16,34,0.9)'
    roundRectPath(ctx, -38, -54, 76, 28, 10)
    ctx.fill()
    const eyeX = this.eyeA * 26
    const scan = this.scanT >= 0 ? Math.sin((this.scanT / 1.4) * Math.PI * 2) : 0
    glowCircle(ctx, eyeX, -40, 20 + Math.abs(scan) * 14, `rgba(110,231,255,${0.4 + Math.abs(scan) * 0.3})`, 'rgba(110,231,255,0)')
    ctx.fillStyle = '#7dd3fc'
    roundRectPath(ctx, eyeX - 11, -45, 22, 10, 5)
    ctx.fill()
    // scan line
    if (this.scanT >= 0) {
      const sy = -54 + ((this.scanT * 120) % 28)
      ctx.strokeStyle = 'rgba(110,231,255,0.5)'
      ctx.lineWidth = 1
      ctx.beginPath()
      ctx.moveTo(-38, sy)
      ctx.lineTo(38, sy)
      ctx.stroke()
    }

    // mouth grille
    ctx.strokeStyle = 'rgba(160,170,200,0.5)'
    ctx.lineWidth = 1.4
    for (let i = -2; i <= 2; i++) {
      ctx.beginPath()
      ctx.moveTo(i * 9, -20)
      ctx.lineTo(i * 9, -14)
      ctx.stroke()
    }

    // body with a gear inside
    ctx.fillStyle = 'rgba(60,64,96,0.92)'
    roundRectPath(ctx, -44, -10, 88, 64, 12)
    ctx.fill()
    ctx.strokeStyle = 'rgba(220,214,254,0.25)'
    ctx.stroke()
    // chest window with gear
    ctx.fillStyle = 'rgba(14,16,34,0.75)'
    roundRectPath(ctx, -26, -2, 52, 44, 8)
    ctx.fill()
    this.gear(ctx, 0, 20, 14, 8, this.t * 1.4, 'rgba(196,181,253,0.65)')
    // chest light
    const pulse = 0.5 + Math.sin(this.t * 3 * activity) * 0.5
    glowCircle(ctx, 28, 6, 10 + pulse * 6, `rgba(110,231,255,${0.3 + pulse * 0.3})`, 'rgba(110,231,255,0)')

    // arms — one follows pointer slightly
    ctx.strokeStyle = 'rgba(120,124,160,0.9)'
    ctx.lineWidth = 9
    ctx.lineCap = 'round'
    const armWave = Math.sin(this.t * 2 * activity) * 0.2
    // left arm
    ctx.beginPath()
    ctx.moveTo(-44, 2)
    ctx.lineTo(-64, 24 + armWave * 20)
    ctx.lineTo(-58, 48)
    ctx.stroke()
    // right arm
    ctx.beginPath()
    ctx.moveTo(44, 2)
    ctx.lineTo(64, 24 - armWave * 20)
    ctx.lineTo(58, 48)
    ctx.stroke()
    ctx.restore()

    labelChip(ctx, w * 0.5, h * 0.12, 'sense → decide → act', 'rgba(221,214,254,0.95)')
  }

  pointerDown(s: SceneFrameState) {
    if (this.variant === 'robot') {
      const cx = s.w * 0.5
      const cy = s.h * 0.46
      if (Math.abs(s.pointer.x - cx) < 90 && Math.abs(s.pointer.y - cy) < 90) {
        this.scanT = 0
        return 1
      }
      return 0
    }
    const cx = s.w * 0.5
    const cy = s.h * 0.42
    if (Math.hypot(s.pointer.x - (cx - 96), s.pointer.y - (cy - 20)) < 60) return 0
    if (Math.hypot(s.pointer.x - cx, s.pointer.y - (cy + 64 + 100)) < 60) return 1
    if (Math.hypot(s.pointer.x - cx, s.pointer.y - cy) < 130) return 2
    return null
  }

  trigger(id: string, _s: SceneFrameState) {
    if (id === 'wind') { this.windT = 0; return true }
    if (id === 'chime') { this.chimeT = 0; return true }
    if (id === 'scan') { this.scanT = 0; return true }
    if (id === 'salute') {
      this.windT = 0
      return true
    }
    void _s
    return false
  }
}
