import type { WeatherKind } from '../../types'

/* ==========================================================================
   Scene engine — category-aware worlds rendered on the main canvas.
   Each renderer is a small stateful machine: enter → update → draw,
   plus pointer hotspots and contextual triggers from the UI.
   ========================================================================== */

export type SceneVariant = string

/** everything a renderer needs each frame */
export interface SceneFrameState {
  w: number
  h: number
  t: number                                  // seconds since scene entered
  dt: number                                 // scaled frame delta
  params: Record<string, number>
  pointer: { x: number; y: number; active: boolean }
  fire: boolean
  water: boolean
  ice: boolean
  wind: boolean
  electric: boolean
  weather: WeatherKind
  quality: number                            // 0.5–1 particle budget scale
  /** fire a particle from the shared pool (kind: ember | spark | dust | cloud | splash…) */
  emit: (kind: string, opts: Record<string, number>) => void
}

export interface SceneRenderer {
  enter(w: number, h: number): void
  update(s: SceneFrameState): void
  draw(ctx: CanvasRenderingContext2D, s: SceneFrameState): void
  /** returns the fact index when a hotspot is hit, else null */
  pointerDown(s: SceneFrameState): number | null
  trigger(id: string, s: SceneFrameState): boolean
  resize?(w: number, h: number): void
  dispose?(): void
}

/* ---------- small shared helpers ---------- */

export const clamp01 = (v: number) => Math.max(0, Math.min(1, v))
export const lerp = (a: number, b: number, k: number) => a + (b - a) * k
export const easeOut = (k: number) => 1 - Math.pow(1 - clamp01(k), 3)
export const easeInOut = (k: number) =>
  k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2

/** deterministic pseudo-random from a seed */
export function srand(seed: number): number {
  const x = Math.sin(seed * 127.1 + 311.7) * 43758.5453
  return x - Math.floor(x)
}

export function glowCircle(
  ctx: CanvasRenderingContext2D,
  x: number, y: number, r: number,
  inner: string, outer: string,
) {
  const g = ctx.createRadialGradient(x, y, 0, x, y, r)
  g.addColorStop(0, inner)
  g.addColorStop(1, outer)
  ctx.fillStyle = g
  ctx.beginPath()
  ctx.arc(x, y, r, 0, Math.PI * 2)
  ctx.fill()
}

/** a small glassy label chip, used for explore-mode annotations */
export function labelChip(
  ctx: CanvasRenderingContext2D,
  x: number, y: number, text: string,
  accent = 'rgba(196,181,253,0.9)',
  align: CanvasTextAlign = 'center',
) {
  ctx.save()
  ctx.font = '600 11px Inter, system-ui, sans-serif'
  const tw = ctx.measureText(text).width
  const px = 9
  const wBox = tw + px * 2
  const hBox = 20
  let bx = x
  if (align === 'center') bx = x - wBox / 2
  else if (align === 'right') bx = x - wBox
  bx = Math.max(6, bx)
  ctx.fillStyle = 'rgba(10,13,32,0.66)'
  ctx.strokeStyle = 'rgba(255,255,255,0.12)'
  ctx.lineWidth = 1
  const r = 10
  ctx.beginPath()
  ctx.moveTo(bx + r, y - hBox / 2)
  ctx.arcTo(bx + wBox, y - hBox / 2, bx + wBox, y + hBox / 2, r)
  ctx.arcTo(bx + wBox, y + hBox / 2, bx, y + hBox / 2, r)
  ctx.arcTo(bx, y + hBox / 2, bx, y - hBox / 2, r)
  ctx.arcTo(bx, y - hBox / 2, bx + wBox, y - hBox / 2, r)
  ctx.fill()
  ctx.stroke()
  ctx.fillStyle = accent
  ctx.textAlign = 'left'
  ctx.textBaseline = 'middle'
  ctx.fillText(text, bx + px, y + 0.5)
  ctx.restore()
}

/** soft arrow used to annotate flows */
export function flowArrow(
  ctx: CanvasRenderingContext2D,
  x: number, y: number, angle: number, len: number,
  color = 'rgba(255,255,255,0.35)',
) {
  ctx.save()
  ctx.translate(x, y)
  ctx.rotate(angle)
  ctx.strokeStyle = color
  ctx.lineWidth = 1.5
  ctx.beginPath()
  ctx.moveTo(0, 0)
  ctx.lineTo(len, 0)
  ctx.stroke()
  ctx.beginPath()
  ctx.moveTo(len, 0)
  ctx.lineTo(len - 6, -3.5)
  ctx.lineTo(len - 6, 3.5)
  ctx.closePath()
  ctx.fillStyle = color
  ctx.fill()
  ctx.restore()
}

export function roundRectPath(
  ctx: CanvasRenderingContext2D,
  x: number, y: number, w: number, h: number, r: number,
) {
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.arcTo(x + w, y, x + w, y + h, r)
  ctx.arcTo(x + w, y + h, x, y + h, r)
  ctx.arcTo(x, y + h, x, y, r)
  ctx.arcTo(x, y, x + w, y, r)
  ctx.closePath()
}
