import { cmd } from './helpers'
import type { CommandDef } from '../types'

/* ELEMENTS — raw forces you can summon and combine */
export const elementCommands: CommandDef[] = [
  cmd('fire', 'elements', 'The core ignites — warm, alive, dancing.', {
    element: 'fire', glow: 1.3,
  }, { aliases: ['flame', 'burn', 'burning', 'blaze', 'inferno', 'ignite'], related: ['lava', 'smoke', 'steam'], demo: 'fire', sound: 'magic' }),

  cmd('water', 'elements', 'Cool ribbons of water coil around the core.', {
    element: 'water', trail: 'bubble',
  }, { aliases: ['aqua', 'liquid', 'hydro'], related: ['rain', 'ocean', 'ice'], demo: 'water', sound: 'water' }),

  cmd('ice', 'elements', 'A crown of frost, crisp and quiet.', {
    element: 'ice',
  }, { aliases: ['frost', 'icy', 'chill', 'glacier heart'], related: ['freeze', 'snow', 'winter'], demo: 'freeze', sound: 'freeze' }),

  cmd('wind', 'elements', 'An invisible current sweeps through everything.', {
    element: 'wind', wind: 0.55, weather: null,
  }, { aliases: ['breeze', 'gale', 'gust', 'air', 'airflow', 'draft'], related: ['storm', 'tornado', 'cloud'], demo: 'wind', sound: 'wind' }),

  cmd('earth', 'elements', 'Stones gather and hum around the core.', {
    element: 'earth', action: 'orbiters', gravity: 0.5,
  }, { aliases: ['stone', 'rock', 'terrain', 'dirt'], related: ['sand', 'metal', 'mountain'], demo: 'earth', sound: 'impact' }),

  cmd('smoke', 'elements', 'Soft grey shapes curl and fade.', {
    element: 'smoke',
  }, { aliases: ['fume', 'ash cloud', 'smolder'], related: ['fog', 'steam', 'fire'], demo: 'smoke' }),

  cmd('steam', 'elements', 'Heat meets water — a ghost of vapor rises.', {
    element: 'steam',
  }, { aliases: ['vapor', 'mist cloud'], related: ['smoke', 'water', 'fire'], demo: 'smoke' }),

  cmd('lightning', 'elements', 'A crooked line of light splits the sky.', {
    action: 'lightning', glow: 1.4,
  }, { aliases: ['bolt', 'thunderbolt', 'strike', 'shock'], related: ['electric', 'storm', 'thunder'], demo: 'lightning', sound: 'zap' }),

  cmd('electric', 'elements', 'The core crackles with living sparks.', {
    element: 'electric',
  }, { aliases: ['static', 'voltage', 'charge', 'zap'], related: ['lightning', 'plasma'], demo: 'lightning', sound: 'zap' }),

  cmd('lava', 'elements', 'Molten light oozes and glows.', {
    element: 'lava', gravity: 0.6, glow: 1.25,
  }, { aliases: ['magma', 'molten', 'volcano heart'], related: ['fire', 'volcano'], demo: 'fire' }),

  cmd('cloud', 'elements', 'Soft shapes drift across the sky.', {
    weather: 'clouds',
  }, { aliases: ['clouds', 'cloudy', 'cumulus'], related: ['rain', 'fog', 'wind'], demo: 'fog' }),

  cmd('plasma', 'elements', 'Neither fire nor light — something in between.', {
    element: 'electric', color: '#c084fc', glow: 1.45, action: 'sparkburst',
  }, { aliases: ['plasma field', 'ion'], related: ['electric', 'fire', 'neon'], demo: 'lightning', sound: 'zap' }),

  cmd('sand', 'elements', 'A warm wind of tiny grains.', {
    weather: 'dust', environment: 'desert',
  }, { aliases: ['sandy', 'grains', 'sandstorm'], related: ['desert', 'wind', 'earth'], demo: 'fog' }),

  cmd('metal', 'elements', 'A cool chrome sheen hardens the light.', {
    color: '#cbd5e1', chrome: true, spin: 1.5, action: 'sparkburst',
  }, { aliases: ['steel', 'iron', 'chrome'], related: ['magnet', 'silver'], demo: 'color' }),

  cmd('glass', 'elements', 'Transparent and delicate, catching every color.', {
    color: '#e0f2fe', glow: 1.35, alpha: 0.72, chrome: true, action: 'sparkburst',
  }, { aliases: ['crystal clear', 'fragile'], related: ['crystal', 'diamond', 'ice'], demo: 'color', sound: 'freeze' }),

  cmd('void', 'elements', 'An absence of everything, quietly pulling.', {
    element: 'void', dim: 0.35, glow: 0.7, color: '#6d28d9', wind: -0.2,
  }, { aliases: ['emptiness', 'null'], related: ['blackhole', 'space'], demo: 'portal', sound: 'portal' }),

  cmd('shadow', 'elements', 'A darker twin follows every move.', {
    action: 'clone', color: '#312e81', dim: 0.2,
  }, { aliases: ['shadows', 'darkness', 'umbra', 'silhouette'], related: ['night', 'ghost', 'mirror'], demo: 'shadow' }),

  cmd('light', 'elements', 'Everything brightens, gently.', {
    glow: 1.6, dim: 0, action: 'flash',
  }, { aliases: ['brightness', 'lumen', 'radiance'], related: ['glow', 'shine', 'sun'], demo: 'glow', sound: 'magic' }),

  cmd('tornado', 'elements', 'Everything spins into one hungry column.', {
    motion: 'spiral', spin: 8, weather: 'dust', action: 'shake',
  }, { aliases: ['twister', 'cyclone', 'whirlwind', 'vortex'], related: ['wind', 'storm', 'spin'], demo: 'chaos', sound: 'wind' }),
]
