import { cmd } from './helpers'
import type { CommandDef } from '../types'

/* NATURE — weather, seasons and living things */
export const natureCommands: CommandDef[] = [
  cmd('rain', 'nature', 'The air cools, then the rain arrives.', {
    weather: 'rain', dim: 0.15,
  }, { aliases: ['rainy', 'raining', 'downpour', 'drizzle', 'shower'], related: ['storm', 'water', 'thunder'], demo: 'rain', sound: 'rain' }),

  cmd('snow', 'nature', 'Soft flakes tumble down without a sound.', {
    weather: 'snow', dim: 0.1,
  }, { aliases: ['snowing', 'snowy', 'snowfall', 'flurry', 'blizzard'], related: ['winter', 'ice', 'freeze'], demo: 'rain' }),

  cmd('storm', 'nature', 'Clouds gather. Thunder follows.', {
    weather: 'storm', dim: 0.3, action: 'lightning',
  }, { aliases: ['thunderstorm', 'tempest', 'stormy'], related: ['lightning', 'thunder', 'rain'], demo: 'storm', sound: 'rain' }),

  cmd('fog', 'nature', 'The world wraps itself in soft grey.', {
    weather: 'fog', dim: 0.2,
  }, { aliases: ['mist', 'haze', 'foggy', 'cloudy ground'], related: ['smoke', 'cloud'], demo: 'fog' }),

  cmd('sun', 'nature', 'Warm light floods everything.', {
    environment: 'dawn', dim: 0, glow: 1.3,
  }, { aliases: ['sunny', 'sunshine', 'daylight', 'sunlight'], related: ['dawn', 'summer', 'shine'], demo: 'sun', sound: 'magic' }),

  cmd('moon', 'nature', 'The sky darkens; a moon rises.', {
    environment: 'night', dim: 0.15, glow: 1.1, color: '#e2e8f0',
    // note: no gravity here — the moon + fly combination is what unlocks low gravity
  }, { aliases: ['moonlight', 'moonlit', 'lunar', 'full moon'], related: ['night', 'star', 'space'], demo: 'moon' }),

  cmd('thunder', 'nature', 'A deep rumble rolls somewhere far away.', {
    action: ['shake', 'flash'], weather: 'storm',
  }, { aliases: ['rumble', 'thunder roll'], related: ['lightning', 'storm'], demo: 'lightning', sound: 'impact' }),

  cmd('forest', 'nature', 'Trees close in; the air turns green.', {
    environment: 'forest', weather: 'leaves',
  }, { aliases: ['woods', 'woodland', 'trees'], related: ['jungle', 'leaf', 'firefly'], demo: 'environment' }),

  cmd('ocean', 'nature', 'Waves breathe far below.', {
    environment: 'ocean', weather: 'bubbles',
  }, { aliases: ['sea', 'deep sea', 'seaside', 'underwater'], related: ['water', 'wave', 'island'], demo: 'environment' }),

  cmd('wave', 'nature', 'A swell rises and rolls through the world.', {
    action: ['ringwave', 'ripple', 'splash'], element: 'water',
  }, { aliases: ['waves', 'tide', 'surf'], related: ['ocean', 'water', 'tsunami'], demo: 'ripple', sound: 'water' }),

  cmd('flower', 'nature', 'Petals unfurl around the core.', {
    action: 'bloom', shape: 'flower', color: '#f9a8d4',
  }, { aliases: ['flowers', 'bloom', 'blossom', 'floral'], related: ['petal', 'spring', 'garden'], demo: 'petal', sound: 'magic' }),

  cmd('leaf', 'nature', 'Autumn leaves spiral through the air.', {
    weather: 'leaves',
  }, { aliases: ['leaves', 'falling leaves', 'foliage'], related: ['forest', 'wind', 'petal'], demo: 'rain' }),

  cmd('rainbow', 'nature', 'A ribbon of color follows the core.', {
    trail: 'rainbow', glow: 1.2,
  }, { aliases: ['rainbows', 'color trail', 'spectrum'], related: ['prism', 'color', 'unicorn'], demo: 'rainbow', sound: 'magic' }),

  cmd('aurora', 'nature', 'Rivers of light drift across the sky.', {
    environment: 'aurora',
  }, { aliases: ['northern lights', 'polar lights', 'borealis'], related: ['arctic', 'galaxy', 'rainbow'], demo: 'environment' }),

  cmd('comet', 'nature', 'A bright visitor streaks past.', {
    action: 'cometfly', trail: 'comet',
  }, { aliases: ['comets'], related: ['meteor', 'starfall'], demo: 'meteor' }),

  cmd('meteor', 'nature', 'Stars start falling — gently, beautifully.', {
    weather: 'starfall',
  }, { aliases: ['meteor shower', 'shooting star', 'shooting stars', 'starfall', 'falling stars'], related: ['comet', 'space'], demo: 'meteor' }),

  cmd('eclipse', 'nature', 'The sun goes dark behind the core.', {
    environment: 'midnight', dim: 0.4, action: 'flash', color: '#f59e0b',
  }, { aliases: ['solar eclipse', 'dark sun'], related: ['moon', 'midnight'], demo: 'moon', sound: 'magic' }),

  cmd('petal', 'nature', 'Soft pink petals drift and settle.', {
    weather: 'petals',
  }, { aliases: ['petals', 'sakura', 'cherry blossom', 'cherry blossoms', 'blossom snow'], related: ['flower', 'spring'], demo: 'petal' }),

  cmd('river', 'nature', 'A silver current winds across the floor.', {
    environment: 'forest', action: 'ripple', element: 'water',
  }, { aliases: ['stream', 'creek', 'brook'], related: ['waterfall', 'ocean'], demo: 'ripple', sound: 'water' }),

  cmd('mountain', 'nature', 'Distant peaks rise in silhouette.', {
    environment: 'arctic', action: 'ringwave',
  }, { aliases: ['mountains', 'peak', 'peaks', 'summit', 'alps'], related: ['winter', 'earth'], demo: 'environment' }),

  cmd('island', 'nature', 'A quiet shore appears in the void.', {
    environment: 'ocean', action: 'ripple',
  }, { aliases: ['isles', 'isle'], related: ['ocean', 'beach'], demo: 'environment' }),

  cmd('volcano', 'nature', 'The ground glows. Embers rise.', {
    environment: 'volcano', weather: 'embers',
  }, { aliases: ['volcanic', 'eruption', 'erupt', 'mountain of fire'], related: ['lava', 'fire'], demo: 'fire' }),

  cmd('oasis', 'nature', 'Water shimmers in the warm sand.', {
    environment: 'desert', action: ['ripple', 'splash'],
  }, { aliases: ['mirage', 'desert spring'], related: ['desert', 'water'], demo: 'ripple' }),

  cmd('waterfall', 'nature', 'A thread of falling light, endlessly pouring.', {
    environment: 'forest', weather: 'bubbles', element: 'water',
  }, { aliases: ['cascade', 'falls', 'niagara'], related: ['river', 'rain'], demo: 'ripple', sound: 'water' }),

  cmd('glacier', 'nature', 'Ancient ice, blue and patient.', {
    environment: 'arctic', element: 'ice',
  }, { aliases: ['iceberg', 'ice age', 'permafrost'], related: ['ice', 'arctic', 'freeze'], demo: 'freeze' }),

  cmd('grass', 'nature', 'A green hush spreads at the bottom of the world.', {
    environment: 'forest', weather: 'leaves', action: 'bloom',
  }, { aliases: ['meadow', 'grassland', 'field'], related: ['forest', 'spring'], demo: 'petal' }),

  cmd('tree', 'nature', 'One tree grows, steady and slow.', {
    action: 'growtree', environment: 'forest',
  }, { aliases: ['oak', 'sapling'], related: ['forest', 'seed', 'life'], demo: 'petal', sound: 'magic' }),

  cmd('seed', 'nature', 'Something small stirs, ready to become.', {
    action: 'growtree', weather: 'petals',
  }, { aliases: ['sprout', 'plant', 'grow seed'], related: ['tree', 'flower', 'life'], demo: 'petal', sound: 'magic' }),

  cmd('butterfly', 'nature', 'Winged companions flutter around the core.', {
    weather: 'butterflies', color: '#f472b6',
  }, { aliases: ['butterflies', 'moth'], related: ['petal', 'flower', 'spring'], demo: 'petal', sound: 'magic' }),

  cmd('firefly', 'nature', 'Tiny lights blink in the dark.', {
    weather: 'fireflies', dim: 0.25,
  }, { aliases: ['fireflies', 'glowworm', 'lightning bug', 'lightning bugs'], related: ['night', 'sparkle'], demo: 'fireflies' }),

  cmd('bird', 'nature', 'A small flock sweeps across the sky.', {
    action: 'flock', environment: 'dawn',
  }, { aliases: ['birds', 'flock', 'swallow', 'dove'], related: ['fly', 'feather'], demo: 'dash' }),

  cmd('fish', 'nature', 'Something silvery swims past below.', {
    environment: 'ocean', weather: 'bubbles',
  }, { aliases: ['fishes', 'koi', 'salmon'], related: ['ocean', 'water'], demo: 'water', sound: 'water' }),

  cmd('spring', 'nature', 'The season turns: petals and new green.', {
    environment: 'forest', weather: 'petals', action: 'bloom', color: '#86efac',
  }, { aliases: ['springtime', 'blossom season'], related: ['flower', 'summer'], demo: 'petal', sound: 'magic' }),

  cmd('summer', 'nature', 'Long golden light, everywhere at once.', {
    environment: 'sunset', glow: 1.3, color: '#fbbf24', dim: 0,
  }, { aliases: ['summertime', 'golden season'], related: ['sun', 'spring'], demo: 'sun', sound: 'magic' }),

  cmd('autumn', 'nature', 'Amber, rust and falling leaves.', {
    environment: 'forest', weather: 'leaves', color: '#fb923c', dim: 0.12,
  }, { aliases: ['fall season', 'harvest'], related: ['leaf', 'winter'], demo: 'rain' }),

  cmd('winter', 'nature', 'The world hushes under white.', {
    environment: 'winter', weather: 'snow', color: '#bae6fd', dim: 0.15,
  }, { aliases: ['wintertime', 'cold season', 'snowfall season'], related: ['snow', 'freeze'], demo: 'rain' }),

  cmd('beach', 'nature', 'Warm sand and a far-off tide.', {
    environment: 'sunset', action: 'ripple',
  }, { aliases: ['shore', 'coast', 'seaside walk'], related: ['ocean', 'desert'], demo: 'environment' }),

  cmd('hail', 'nature', 'Little beads of ice tick against everything.', {
    weather: 'snow', element: 'ice', sound: 'freeze',
  }, { aliases: ['hailstorm', 'ice pellets'], related: ['snow', 'ice'], demo: 'rain' }),

  cmd('tsunami', 'nature', 'A tall wave sweeps the whole world clean.', {
    action: ['splash', 'shockwave', 'ripple'], element: 'water',
  }, { aliases: ['tidal wave', 'big wave'], related: ['wave', 'ocean'], demo: 'ripple', sound: 'impact' }),

  cmd('feather', 'nature', 'Something soft falls slowly, slowly.', {
    action: 'featherfall', timeScale: 0.8,
  }, { aliases: ['feathers', 'down', 'plume'], related: ['bird', 'snow'], demo: 'petal', sound: 'magic' }),

  cmd('volcanic winter', 'nature', 'Ash dims the sun; the air tastes of iron.', {
    environment: 'volcano', weather: 'fog', dim: 0.35,
  }, { aliases: ['ashfall', 'ash'], related: ['volcano', 'fog'], demo: 'fog' }),
]
