import { cmd } from './helpers'
import type { CommandDef } from '../types'

/* ENVIRONMENT — whole worlds to shift into */
export const environmentCommands: CommandDef[] = [
  cmd('space', 'environment', 'Back to the deep, star-strewn quiet.', {
    environment: 'space', dim: 0,
  }, { aliases: ['deep space', 'cosmos', 'starfield', 'outer space'], related: ['galaxy', 'void'], demo: 'environment' }),

  cmd('galaxy', 'environment', 'Spiral arms of stars and dust unfold.', {
    environment: 'galaxy',
  }, { aliases: ['galaxies', 'milky way', 'nebula', 'universe', 'cosmic'], related: ['space', 'supernova'], demo: 'environment' }),

  cmd('night', 'environment', 'A deep blue hush, full of stars.', {
    environment: 'night', dim: 0.15,
  }, { aliases: ['nighttime', 'evening', 'starry night', 'night sky'], related: ['moon', 'midnight'], demo: 'environment' }),

  cmd('midnight', 'environment', 'The deepest dark before dawn.', {
    environment: 'midnight', dim: 0.3,
  }, { aliases: ['witching hour', 'dead of night', 'late night'], related: ['night', 'void'], demo: 'environment' }),

  cmd('sunset', 'environment', 'Amber light melts along the horizon.', {
    environment: 'sunset', dim: 0.08,
  }, { aliases: ['dusk', 'golden hour', 'sundown', 'evening glow'], related: ['dawn', 'summer'], demo: 'environment' }),

  cmd('dawn', 'environment', 'The first pale light climbs the sky.', {
    environment: 'dawn', dim: 0,
  }, { aliases: ['sunrise', 'daybreak', 'first light', 'morning'], related: ['sunset', 'sun'], demo: 'environment' }),

  cmd('ocean env', 'environment', 'Down where the light bends blue.', {
    environment: 'ocean',
  }, { aliases: ['underwater world', 'deep blue', 'aquarium'], related: ['ocean', 'fish'], demo: 'environment' }),

  cmd('desert', 'environment', 'Warm dunes under a wide pale sky.', {
    environment: 'desert', weather: 'dust',
  }, { aliases: ['dunes', 'sahara', 'wasteland', 'badlands'], related: ['oasis', 'sand'], demo: 'environment' }),

  cmd('winter env', 'environment', 'A still, white, waiting world.', {
    environment: 'winter',
  }, { aliases: ['snowscape', 'frost world', 'tundra'], related: ['winter', 'arctic'], demo: 'environment' }),

  cmd('arctic', 'environment', 'Ice-light and a hint of aurora.', {
    environment: 'arctic',
  }, { aliases: ['polar', 'antarctic', 'north pole', 'frozen north'], related: ['glacier', 'aurora'], demo: 'environment' }),

  cmd('void env', 'environment', 'Almost nothing. Almost everything.', {
    environment: 'void', dim: 0.4,
  }, { aliases: ['the void', 'abyss', 'nothing'], related: ['void', 'space'], demo: 'environment' }),

  cmd('dream', 'environment', 'Soft pastels, floating logic.', {
    environment: 'dream', timeScale: 0.85,
  }, { aliases: ['dreamscape', 'dreaming', 'slumber', 'reverie'], related: ['blur', 'cloud'], demo: 'environment' }),

  cmd('jungle', 'environment', 'Damp green light, everywhere growing.', {
    environment: 'jungle',
  }, { aliases: ['rainforest', 'tropics', 'tropical'], related: ['forest', 'river'], demo: 'environment' }),

  cmd('aurora sky', 'environment', 'Curtains of light sway overhead.', {
    environment: 'aurora',
  }, { aliases: ['aurora sky dance'], related: ['aurora', 'arctic'], demo: 'environment' }),

  cmd('city', 'environment', 'A far-off skyline hums below.', {
    environment: 'neon',
  }, { aliases: ['skyline', 'downtown', 'midnight city'], related: ['neon', 'night'], demo: 'environment' }),

  cmd('candy', 'environment', 'Everything turns pink and impossibly sweet.', {
    environment: 'dream', weather: 'petals', color: '#f9a8d4',
  }, { aliases: ['candyland', 'candy world', 'sweets'], related: ['dream', 'petal'], demo: 'environment' }),

  cmd('matrix world', 'environment', 'A quiet rain of soft green glyphs.', {
    weather: 'matrix', dim: 0.3, color: '#4ade80',
  }, { aliases: ['matrix'], related: ['glitch', 'rain'], demo: 'rain' }),
]

/* OBJECTS — transform the core into something new */
export const objectCommands: CommandDef[] = [
  cmd('cube', 'objects', 'The core folds itself into a perfect cube.', {
    shape: 'cube',
  }, { aliases: ['box', 'block', 'square'], related: ['sphere', 'crystal'], demo: 'shape', sound: 'magic' }),

  cmd('sphere', 'objects', 'Back to the simplest, purest form.', {
    shape: 'orb',
  }, { aliases: ['ball', 'orb', 'globe', 'bubble'], related: ['cube', 'planet'], demo: 'shape', sound: 'magic' }),

  cmd('ring', 'objects', 'A thin, endless circle of light.', {
    shape: 'ring',
  }, { aliases: ['donut', 'torus'], related: ['halo', 'planet'], demo: 'shape', sound: 'magic' }),

  cmd('star', 'objects', 'A small star is born, twinkling.', {
    shape: 'star', glow: 1.4, action: 'starburst',
  }, { aliases: ['little star', 'starlight', 'twinkle star'], related: ['starfall', 'sparkle'], demo: 'sparkle', sound: 'magic' }),

  cmd('planet', 'objects', 'The core grows a ringed world of its own.', {
    shape: 'planet',
  }, { aliases: ['saturn', 'ringed planet', 'world'], related: ['moon', 'galaxy'], demo: 'shape', sound: 'magic' }),

  cmd('rocket', 'objects', 'Countdown… liftoff… gone.', {
    shape: 'rocket', motion: 'fly', trail: 'comet', action: 'toss',
  }, { aliases: ['spaceship', 'ship', 'launch rocket'], related: ['launch', 'space'], demo: 'rise', sound: 'impact' }),

  cmd('portal', 'objects', 'Energy gathers — then a doorway opens.', {
    shape: 'portal', action: 'portalopen', glow: 1.35,
  }, { aliases: ['gateway', 'door', 'doorway'], related: ['wormhole', 'teleport', 'dimension'], demo: 'portal', sound: 'portal' }),

  cmd('crystal', 'objects', 'Facets catch every color in the room.', {
    shape: 'crystal', action: 'sparkburst',
  }, { aliases: ['gem', 'quartz', 'gemstone'], related: ['diamond', 'glass', 'ice'], demo: 'shape', sound: 'freeze' }),

  cmd('heart', 'objects', 'The core beats like something alive.', {
    shape: 'heart', color: '#fb7185', action: 'heartburst', spin: 0,
  }, { aliases: ['hearts', 'love heart'], related: ['love', 'pulse'], demo: 'hearts', sound: 'magic' }),

  cmd('diamond', 'objects', 'Hard light, brilliant edges.', {
    shape: 'diamond', color: '#e0f2fe',
  }, { aliases: ['jewel', 'brilliant', 'gemstone cut'], related: ['crystal', 'glass'], demo: 'shape', sound: 'freeze' }),

  cmd('moonstone', 'objects', 'A pale, patient little moon.', {
    shape: 'moon', color: '#e2e8f0', glow: 1.1, environment: 'night',
  }, { aliases: ['moon core', 'little moon'], related: ['moon', 'night'], demo: 'moon', sound: 'magic' }),

  cmd('asteroid', 'objects', 'A rough rock, tumbling happily.', {
    shape: 'asteroid', spin: 2.2, gravity: 0.4,
  }, { aliases: ['boulder', 'meteorite'], related: ['comet', 'earth'], demo: 'shape' }),

  cmd('flower core', 'objects', 'The core blooms, petal by petal.', {
    shape: 'flower', color: '#f9a8d4',
  }, { aliases: ['bloom core', 'blossom core'], related: ['flower', 'petal'], demo: 'petal', sound: 'magic' }),

  cmd('eye', 'objects', 'It watches. It blinks. It is patient.', {
    shape: 'eye', glow: 1.2,
  }, { aliases: ['the eye', 'iris', 'all seeing'], related: ['void', 'dream'], demo: 'shape', sound: 'magic' }),

  cmd('ghost', 'objects', 'Boo — sort of. Mostly friendly.', {
    shape: 'ghost', motion: 'float', glow: 0.85, alpha: 0.6,
  }, { aliases: ['spirit', 'phantom', 'specter'], related: ['fade', 'shadow'], demo: 'shadow', sound: 'magic' }),

  cmd('balloon', 'objects', 'One string, one slow rise.', {
    shape: 'balloon', motion: 'fly', gravity: -0.15, color: '#f472b6',
  }, { aliases: ['party balloon', 'red balloon'], related: ['float', 'fly'], demo: 'rise', sound: 'whoosh' }),

  cmd('comet core', 'objects', 'The core becomes a traveler with a tail.', {
    shape: 'comet', trail: 'comet', motion: 'spiral',
  }, { aliases: ['wandering star'], related: ['comet', 'star'], demo: 'meteor', sound: 'whoosh' }),

  cmd('ufo', 'objects', 'Something cruises by overhead…', {
    action: 'ufo',
  }, { aliases: ['alien', 'saucer', 'flying saucer'], related: ['space', 'teleport'], demo: 'meteor', sound: 'magic' }),

  cmd('satellite', 'objects', 'A tiny metal moon takes up orbit.', {
    action: 'satellite',
  }, { aliases: ['space station', 'probe'], related: ['orbit', 'planet'], demo: 'orbit', sound: 'magic' }),
]
