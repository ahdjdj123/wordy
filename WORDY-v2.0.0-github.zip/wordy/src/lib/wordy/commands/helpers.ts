import type { CommandDef, EffectSpec, Category, SoundFamily } from '../types'

/** terse builder so the registry stays readable and easy to extend */
export function cmd(
  name: string,
  category: Category,
  description: string,
  effect: EffectSpec,
  extra: {
    aliases?: string[]
    related?: string[]
    hidden?: boolean
    gold?: boolean
    demo?: string
    sound?: SoundFamily
    /** commands that accept free text after the word (speak, say…) */
    takesText?: boolean
  } = {},
): CommandDef {
  return {
    name,
    aliases: extra.aliases ?? [],
    category,
    description,
    effect: { sound: extra.sound, ...effect },
    related: extra.related,
    hidden: extra.hidden,
    gold: extra.gold,
    demo: extra.demo,
    takesText: extra.takesText,
  }
}
