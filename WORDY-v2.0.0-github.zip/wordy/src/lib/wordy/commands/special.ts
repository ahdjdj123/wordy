import { cmd } from './helpers'
import type { CommandDef } from '../types'

/* SPECIAL — experimental words, plus a few that shall not be named */

export const specialCommands: CommandDef[] = [
  cmd('boom', 'special', 'A full, satisfying detonation.', {
    action: 'boom',
  }, { aliases: ['boom boom', 'kaboom', 'bang', 'explosion'], related: ['explode', 'supernova', 'implode'], demo: 'explode', sound: 'impact' }),

  cmd('speak', 'special', 'Say something — the core repeats it in light.', {
    action: 'speak',
  }, { aliases: ['say', 'talk', 'tell'], related: ['hello', 'sing', 'wordy'], demo: 'sparkle', sound: 'magic', takesText: true }),

  cmd('sing', 'special', 'The core hums a little melody in colors.', {
    action: 'sing', trail: 'musical', glow: 1.2,
  }, { aliases: ['singing', 'song', 'hum', 'humming'], related: ['speak', 'disco', 'music'], demo: 'disco', sound: 'magic' }),

  cmd('dimension', 'special', 'A fold in space; a different elsewhere.', {
    action: ['portalopen', 'flash', 'ripple'], environment: 'void', glow: 1.3,
  }, { aliases: ['dimensions', 'other side', 'portal jump'], related: ['portal', 'wormhole', 'void'], demo: 'portal', sound: 'portal' }),

  cmd('wormhole', 'special', 'Two points in space become one.', {
    action: ['portalopen', 'teleport'], trail: 'sparkle',
  }, { aliases: ['worm hole', 'tunnel'], related: ['portal', 'teleport', 'dimension'], demo: 'portal', sound: 'portal' }),

  cmd('surprise', 'special', 'Let the world decide what happens next.', {
    action: 'summon',
  }, { aliases: ['random', 'anything', 'whatever', 'surprise me'], related: ['chaos', 'secret'], demo: 'sparkle', sound: 'magic' }),

  cmd('big bang', 'special', 'Everything, from one impossibly small point.', {
    action: ['bigbang', 'supernova'], environment: 'galaxy',
  }, { aliases: ['bigbang', 'beginning', 'genesis'], related: ['supernova', 'galaxy', 'universe'], demo: 'fireworks', sound: 'impact' }),

  cmd('supernova', 'special', 'A star spends everything, all at once.', {
    action: ['supernova', 'shockwave', 'flash'], trail: 'rainbow',
  }, { aliases: ['nova'], related: ['bigbang', 'explode', 'star'], demo: 'fireworks', sound: 'impact' }),

  cmd('blackhole', 'special', 'A patient darkness with perfect manners.', {
    action: 'blackhole', dim: 0.35, attract: 'attract',
  }, { aliases: ['black hole', 'event horizon'], related: ['void', 'implode', 'singularity'], demo: 'portal', sound: 'portal' }),

  cmd('singularity', 'special', 'Smaller than small. Heavier than heavy.', {
    action: ['blackhole', 'implode'], scale: 0.35,
  }, { aliases: ['point zero'], related: ['blackhole', 'implode'], demo: 'portal', sound: 'portal' }),

  cmd('time travel', 'special', 'The world remembers, then forgets again.', {
    action: ['ripple', 'flash'], timeScale: 0.5, environment: 'void',
  }, { aliases: ['timetravel', 'time machine', 'time machine'], related: ['time', 'reverse'], demo: 'time', sound: 'magic' }),
]

/* ---- hidden discoveries ---- */
export const secretCommands: CommandDef[] = [
  cmd('love', 'special', 'It beats. It glows. It overflows.', {
    action: 'heartburst', shape: 'heart', color: '#fb7185', trail: 'heart', glow: 1.5,
  }, { aliases: ['i love you', 'i love this', 'amour'], hidden: true, gold: true, demo: 'hearts', sound: 'magic' }),

  cmd('life', 'special', 'Something green insists on existing.', {
    action: ['bloom', 'featherfall'], environment: 'forest', color: '#86efac',
  }, { aliases: ['alive', 'living'], hidden: true, gold: true, demo: 'petal', sound: 'magic' }),

  cmd('magic', 'special', 'Proper magic. No explanation offered.', {
    action: ['galaxyburst', 'sparkburst'], trail: 'sparkle', glow: 1.5,
  }, { aliases: ['magical', 'spell'], hidden: true, gold: true, demo: 'sparkle', sound: 'magic' }),

  cmd('wonder', 'special', 'The feeling itself, rendered in light.', {
    action: ['starburst', 'galaxyburst'], weather: 'starfall', glow: 1.4,
  }, { aliases: ['wonderful', 'awe'], hidden: true, gold: true, demo: 'meteor', sound: 'magic' }),

  cmd('secret', 'special', 'You found it. That was the secret.', {
    action: ['flash', 'galaxyburst'], environment: 'dream',
  }, { aliases: ['secrets', 'hidden'], hidden: true, gold: true, demo: 'sparkle', sound: 'magic' }),

  cmd('wordy', 'special', 'The world says its own name, delighted.', {
    action: ['greet', 'confettiburst', 'galaxyburst'], glow: 1.5,
  }, { aliases: ['wordy wordy'], hidden: true, gold: true, demo: 'confetti', sound: 'magic' }),

  cmd('zen', 'special', 'Nothing happens. It is perfect.', {
    motion: 'float', spin: 0, timeScale: 0.6, clearWeather: true, trail: null, glow: 0.9, dim: 0.1,
  }, { aliases: ['zen mode', 'nothing at all'], hidden: true, gold: true, demo: 'drift', sound: 'magic' }),

  cmd('unicorn', 'special', 'Horn, rainbow, attitude.', {
    trail: 'rainbow', color: '#f9a8d4', action: ['starburst', 'featherfall'], motion: 'fly', glow: 1.4,
  }, { aliases: ['unicorn core'], hidden: true, gold: true, demo: 'rainbow', sound: 'magic' }),

  cmd('dragon', 'special', 'Fire, with ambition.', {
    element: 'fire', trail: 'fire', motion: 'spiral', spin: 3, scaleMul: 1.3, action: 'shockwave',
  }, { aliases: ['wyrm', 'draco'], hidden: true, gold: true, demo: 'fire', sound: 'impact' }),

  cmd('phoenix', 'special', 'Burn, then begin again.', {
    element: 'fire', action: ['explode', 'bloom'], trail: 'fire', color: '#fb923c', glow: 1.5, motion: 'fly',
  }, { aliases: ['rebirth', 'rise again'], hidden: true, gold: true, demo: 'fire', sound: 'impact' }),

  cmd('miracle', 'special', 'Light does something it shouldn’t.', {
    action: ['galaxyburst', 'starburst', 'featherfall'], environment: 'aurora', glow: 1.5,
  }, { aliases: ['miracles'], hidden: true, gold: true, demo: 'fireworks', sound: 'magic' }),

  cmd('infinity', 'special', 'The core traces forever.', {
    motion: 'figure8', trail: 'rainbow', spin: 1,
  }, { aliases: ['forever', 'eternal', 'lemniscate'], hidden: true, gold: true, demo: 'orbit', sound: 'magic' }),

  cmd('cosmic dance', 'special', 'The stars waltz with the core.', {
    motion: 'orbit', trail: 'rainbow', spin: 2, environment: 'galaxy', action: 'starburst',
  }, { aliases: ['stardance', 'star dance'], hidden: true, gold: true, demo: 'rainbow', sound: 'magic' }),

  cmd('fever dream', 'special', 'Everything, slightly too much, beautifully.', {
    environment: 'dream', action: ['confettiburst', 'wobble'], trail: 'rainbow', timeScale: 1.5, spin: 4,
  }, { aliases: ['dreamcore', 'surreal'], hidden: true, gold: true, demo: 'disco', sound: 'magic' }),
]
