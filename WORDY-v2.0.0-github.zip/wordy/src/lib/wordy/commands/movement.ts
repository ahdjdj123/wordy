import { cmd } from './helpers'
import type { CommandDef } from '../types'

/* MOVEMENT — how the core travels through the world */
export const movementCommands: CommandDef[] = [
  cmd('fly', 'movement', 'The core rises and drifts through the upper air.', {
    motion: 'fly', glow: 1.2,
  }, { aliases: ['flying', 'soar', 'soaring', 'levitate', 'up'], related: ['float', 'glide', 'rise', 'hover'], demo: 'rise', sound: 'whoosh' }),

  cmd('run', 'movement', 'The core takes off across the world, kicking up stardust.', {
    motion: 'run', trail: 'echo',
  }, { aliases: ['running', 'jog', 'jogging'], related: ['walk', 'go', 'dash', 'stop'], demo: 'dash', sound: 'whoosh' }),

  cmd('walk', 'movement', 'A gentle stroll from one end of everywhere to the other.', {
    motion: 'walk',
  }, { aliases: ['walking', 'stroll', 'strolling', 'amble'], related: ['run', 'go', 'march', 'stop'], demo: 'dash', sound: 'whoosh' }),

  cmd('go', 'movement', 'Forward — steadily, cheerfully, going.', {
    motion: 'go', trail: 'sparkle',
  }, { aliases: ['going', 'travel', 'head out'], related: ['run', 'walk', 'move'], demo: 'dash', sound: 'whoosh' }),

  cmd('stop', 'movement', 'Everything settles. The core catches its breath.', {
    motion: 'stop', spin: 0,
  }, { aliases: ['halt', 'stand still', 'hold still', 'stay'], related: ['calm', 'sleep', 'equilibrium'], demo: 'drift', sound: 'magic' }),

  cmd('sleep', 'movement', 'The core drifts off, breathing slow little z’s.', {
    action: 'sleep', motion: 'stop', glow: 0.8,
  }, { aliases: ['nap', 'doze', 'rest', 'asleep'], related: ['dream', 'wake', 'night'], demo: 'drift', sound: 'magic' }),

  cmd('wake', 'movement', 'Eyes open. A stretch. Ready again.', {
    action: 'wake', glow: 1.2,
  }, { aliases: ['awake', 'wake up', 'awaken', 'rise and shine'], related: ['sleep', 'sun', 'good morning'], demo: 'sparkle', sound: 'magic' }),

  cmd('jump', 'movement', 'A quick hop — and a soft landing.', {
    action: 'jump',
  }, { aliases: ['hop', 'leap', 'skip'], related: ['bounce', 'fly', 'spring'], demo: 'hop', sound: 'whoosh' }),

  cmd('fall', 'movement', 'The core lets go and tumbles downward.', {
    motion: 'floor', gravity: 1, spin: 2,
  }, { aliases: ['falling'], related: ['drop', 'gravity', 'heavy'], demo: 'fall' }),

  cmd('drop', 'movement', 'A sudden plunge toward the ground.', {
    motion: 'floor', gravity: 1.8,
  }, { aliases: ['plummet', 'fall down', 'sink'], related: ['fall', 'gravity'], demo: 'fall' }),

  cmd('float', 'movement', 'Weightless, drifting like a thought.', {
    motion: 'float', gravity: 0, glow: 1.1,
  }, { aliases: ['floating', 'weightless drift'], related: ['hover', 'fly', 'antigravity'], demo: 'drift', sound: 'whoosh' }),

  cmd('glide', 'movement', 'A smooth sideways current carries the core.', {
    motion: 'drift', trail: 'comet', gravity: 0.1,
  }, { aliases: ['gliding', 'sail', 'skate'], related: ['float', 'drift', 'fly'], demo: 'drift', sound: 'whoosh' }),

  cmd('spin', 'movement', 'Round and round, faster and faster.', {
    spin: 5,
  }, { aliases: ['spinning', 'rotate', 'rotation', 'twirl', 'whirl'], related: ['orbit', 'flip', 'tornado'], demo: 'spin', sound: 'whoosh' }),

  cmd('orbit', 'movement', 'The core circles the heart of the world.', {
    motion: 'orbit',
  }, { aliases: ['orbiting', 'circle', 'revolve', 'loop'], related: ['spin', 'moon', 'satellite'], demo: 'orbit', sound: 'whoosh' }),

  cmd('bounce', 'movement', 'Up, down, up, down — never tired.', {
    motion: 'bounce', gravity: 1,
  }, { aliases: ['bouncing', 'boing', 'pogo'], related: ['jump', 'elastic', 'ball'], demo: 'bounce', sound: 'impact' }),

  cmd('dash', 'movement', 'A lightning-fast sideways burst.', {
    action: 'dash', trail: 'sparkle',
  }, { aliases: ['sprint', 'zoom', 'dart'], related: ['fast', 'sonic', 'flash'], demo: 'dash', sound: 'whoosh' }),

  cmd('slide', 'movement', 'A smooth glide along the ground.', {
    motion: 'floor', gravity: 1, trail: 'echo',
  }, { aliases: ['sliding', 'skid'], related: ['roll', 'glide'], demo: 'slide' }),

  cmd('roll', 'movement', 'Tumbling over like a wheel.', {
    motion: 'floor', spin: 7, gravity: 1,
  }, { aliases: ['rolling', 'tumble'], related: ['spin', 'slide'], demo: 'spin' }),

  cmd('flip', 'movement', 'A full mid-air somersault.', {
    action: 'flip',
  }, { aliases: ['flipping', 'somersault', 'backflip'], related: ['spin', 'jump'], demo: 'spin', sound: 'whoosh' }),

  cmd('drift', 'movement', 'Wandering wherever the current goes.', {
    motion: 'drift',
  }, { aliases: ['drifting', 'wander', 'roam'], related: ['float', 'glide'], demo: 'drift' }),

  cmd('hover', 'movement', 'Perfect stillness, barely breathing.', {
    motion: 'float', glow: 1.15,
  }, { aliases: ['hovering', 'hang', 'suspense'], related: ['float', 'levitate'], demo: 'drift' }),

  cmd('rise', 'movement', 'A slow, steady ascent.', {
    motion: 'fly', glow: 1.1,
  }, { aliases: ['rising', 'ascend', 'upward', 'lift'], related: ['fly', 'launch', 'float'], demo: 'rise', sound: 'whoosh' }),

  cmd('launch', 'movement', 'Ignition — the core blasts upward.', {
    motion: 'fly', action: ['toss', 'shockwave'], trail: 'comet',
  }, { aliases: ['blastoff', 'liftoff', 'takeoff'], related: ['rocket', 'fly', 'dash'], demo: 'rise', sound: 'impact' }),

  cmd('land', 'movement', 'A gentle touchdown after all that flying.', {
    motion: 'floor', gravity: 1, action: 'squish', trail: null,
  }, { aliases: ['landing', 'touchdown'], related: ['fall', 'drop'], demo: 'fall' }),

  cmd('dive', 'movement', 'A swoop down low — then back up again.', {
    action: 'dive',
  }, { aliases: ['swan dive', 'swoop', 'plunge'], related: ['drop', 'bird'], demo: 'fall', sound: 'whoosh' }),

  cmd('swing', 'movement', 'Swaying like a lantern on a branch.', {
    motion: 'sway',
  }, { aliases: ['swinging', 'pendulum'], related: ['sway', 'float'], demo: 'swing' }),

  cmd('sway', 'movement', 'A gentle pendulum lull.', {
    motion: 'sway',
  }, { aliases: ['swaying', 'rocking'], related: ['swing', 'wobble'], demo: 'swing' }),

  cmd('zigzag', 'movement', 'Sharp turns, impossible angles.', {
    motion: 'zigzag',
  }, { aliases: ['zig', 'zigzagging', 'weave'], related: ['chaos', 'drift'], demo: 'zigzag' }),

  cmd('spiral', 'movement', 'Curling outward like a galaxy arm.', {
    motion: 'spiral', trail: 'sparkle',
  }, { aliases: ['spiraling', 'coil', 'corkscrew'], related: ['orbit', 'spin', 'galaxy'], demo: 'orbit' }),

  cmd('shake', 'movement', 'Everything trembles for a moment.', {
    action: ['shake', 'wobble'],
  }, { aliases: ['shaking', 'tremble', 'quake'], related: ['wobble', 'earthquake'], demo: 'wobble', sound: 'impact' }),

  cmd('wobble', 'movement', 'Wobbly like jelly, delightfully so.', {
    action: ['wobble', 'squish'],
  }, { aliases: ['wobbly', 'jiggle', 'jelly', 'wibble'], related: ['shake', 'squish'], demo: 'wobble' }),

  cmd('teleport', 'movement', 'Now you see it — now you don’t.', {
    action: ['teleport', 'ripple', 'flash'],
  }, { aliases: ['blink', 'disappear', 'apparate', 'warp'], related: ['portal', 'wormhole'], demo: 'portal', sound: 'magic' }),

  cmd('boomerang', 'movement', 'It flies away… and always comes back.', {
    action: 'boomerang',
  }, { aliases: ['return', 'comeback'], related: ['dash', 'fly'], demo: 'dash', sound: 'whoosh' }),

  cmd('figure8', 'movement', 'An endless figure-eight path.', {
    motion: 'figure8', trail: 'echo',
  }, { aliases: ['figure eight', 'eight', 'loop de loop'], related: ['orbit', 'infinity'], demo: 'orbit' }),

  cmd('move', 'movement', 'A little nudge in a random direction.', {
    action: ['toss', 'ripple'],
  }, { aliases: ['nudge', 'wiggle'], related: ['dash', 'drift'], demo: 'dash' }),

  cmd('march', 'movement', 'Left, right, left — a tiny parade.', {
    motion: 'walk', action: 'wobble',
  }, { aliases: ['marching', 'parade', 'stomp'], related: ['walk', 'slide'], demo: 'bounce' }),

  cmd('climb', 'movement', 'Up the invisible wall it goes — hand over hand.', {
    motion: 'climb',
  }, { aliases: ['climbing', 'scale', 'ascend the wall'], related: ['rise', 'fly', 'jump'], demo: 'rise', sound: 'whoosh' }),

  cmd('swim', 'movement', 'Gliding through thick imaginary water.', {
    motion: 'drift', element: 'water', trail: 'bubble',
  }, { aliases: ['swimming', 'breaststroke'], related: ['ocean', 'water', 'fish'], demo: 'drift', sound: 'water' }),

  cmd('flyback', 'movement', 'Home — a slow return to the center.', {
    motion: 'idle', spin: 0, trail: null,
  }, { aliases: ['return home', 'center', 'come back'], related: ['calm', 'reset'], demo: 'drift' }),

  cmd('creep', 'movement', 'Slow, slow, slower.', {
    motion: 'drift', timeScale: 0.55,
  }, { aliases: ['sneak', 'tiptoe'], related: ['slow', 'crawl'], demo: 'drift' }),

  cmd('stampede', 'movement', 'The whole world surges sideways.', {
    action: ['dash', 'shake'], weather: 'dust',
  }, { aliases: ['trample', 'surge'], related: ['dash', 'earthquake'], demo: 'dash', sound: 'impact' }),
]
