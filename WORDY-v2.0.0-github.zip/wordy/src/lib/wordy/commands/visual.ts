import { cmd } from './helpers'
import type { CommandDef } from '../types'

/* VISUAL — light, color and afterimages */
export const visualCommands: CommandDef[] = [
  cmd('glow', 'visual', 'The core brightens from within.', {
    glow: 1.6,
  }, { aliases: ['glowing', 'bright', 'brighten', 'luminous'], related: ['shine', 'light', 'dim'], demo: 'glow', sound: 'magic' }),

  cmd('dim', 'visual', 'The lights soften to a murmur.', {
    glow: 0.55, dim: 0.25,
  }, { aliases: ['dimmed', 'darken', 'faint'], related: ['glow', 'shadow'], demo: 'glow' }),

  cmd('flash', 'visual', 'One clean burst of white light.', {
    action: 'flash',
  }, { aliases: ['flash of light', 'camera flash'], related: ['strobe', 'lightning'], demo: 'flash', sound: 'zap' }),

  cmd('spark', 'visual', 'A handful of bright sparks escapes.', {
    action: 'sparkburst',
  }, { aliases: ['sparks', 'ember'], related: ['sparkle', 'electric'], demo: 'sparkle', sound: 'zap' }),

  cmd('sparkle', 'visual', 'Tiny stars cling to the core.', {
    trail: 'sparkle', glow: 1.25,
  }, { aliases: ['glitter', 'twinkle', 'shimmer', 'dazzle'], related: ['spark', 'star'], demo: 'sparkle', sound: 'magic' }),

  cmd('blur', 'visual', 'Edges soften; everything turns dreamy.', {
    trail: 'echo', timeScale: 0.85, glow: 0.9,
  }, { aliases: ['soft focus', 'dreamy'], related: ['dream', 'fade'], demo: 'drift' }),

  cmd('shine', 'visual', 'Rays of light radiate from the core.', {
    glow: 1.5, action: 'starburst',
  }, { aliases: ['radiant', 'gleam', 'glisten', 'beaming'], related: ['glow', 'sun'], demo: 'glow', sound: 'magic' }),

  cmd('pulse', 'visual', 'A slow heartbeat of light.', {
    heartbeat: true, glow: 1.4,
  }, { aliases: ['heartbeat', 'throb', 'beat', 'pulsing'], related: ['glow', 'wobble'], demo: 'glow', sound: 'magic' }),

  cmd('invert', 'visual', 'Every color turns inside out.', {
    invert: true, action: 'flash',
  }, { aliases: ['negative', 'opposite colors'], related: ['mirror', 'monochrome'], demo: 'mirror', sound: 'magic' }),

  cmd('mirror', 'visual', 'The world reflects itself.', {
    action: ['mirrorworld', 'clone'], mirror: true,
  }, { aliases: ['reflect', 'reflection'], related: ['reverse', 'clone'], demo: 'mirror', sound: 'magic' }),

  cmd('fade', 'visual', 'The core thins into a ghost of itself.', {
    action: 'clone', glow: 0.6, alpha: 0.45,
  }, { aliases: ['fading', 'dissolve', 'ghost mode'], related: ['ghost', 'blur'], demo: 'shadow' }),

  cmd('explode', 'visual', 'A bloom of light and pieces.', {
    action: 'explode',
  }, { aliases: ['burst', 'blast', 'pop', 'detonate'], related: ['boom', 'supernova', 'implode'], demo: 'explode', sound: 'impact' }),

  cmd('ripple', 'visual', 'The world is water; touch it.', {
    action: 'ripple',
  }, { aliases: ['ripples', 'waves ring', 'echo ring'], related: ['wave', 'water'], demo: 'ripple', sound: 'water' }),

  cmd('echo', 'visual', 'The core leaves copies of itself behind.', {
    trail: 'echo',
  }, { aliases: ['afterimage', 'ghost trail', 'replay'], related: ['clone', 'blur'], demo: 'drift' }),

  cmd('glitch', 'visual', 'Reality stutters for a second.', {
    action: ['shake', 'flash'], invert: true,
  }, { aliases: ['glitchy', 'bug', 'static field'], related: ['chaos', 'matrix'], demo: 'flash', sound: 'zap' }),

  cmd('prism', 'visual', 'White light splits into six colors.', {
    action: 'galaxyburst', trail: 'rainbow',
  }, { aliases: ['prismatic', 'refract', 'light split'], related: ['rainbow', 'sparkle'], demo: 'rainbow', sound: 'magic' }),

  cmd('neon', 'visual', 'The world switches on after dark.', {
    environment: 'neon', glow: 1.4,
  }, { aliases: ['neon lights', 'synthwave', 'vaporwave'], related: ['disco', 'night'], demo: 'environment' }),

  cmd('disco', 'visual', 'A mirror ball turns, and the colors dance.', {
    action: ['wobble', 'confettiburst'], trail: 'rainbow', spin: 3, chrome: true,
  }, { aliases: ['party', 'dance', 'rave', 'celebrate'], related: ['confetti', 'rainbow', 'metal'], demo: 'disco', sound: 'magic' }),

  cmd('strobe', 'visual', 'Quick flashes — hold on tight.', {
    action: 'strobe',
  }, { aliases: ['strobe light', 'flicker'], related: ['flash', 'disco'], demo: 'flash', sound: 'zap' }),

  cmd('color', 'visual', 'The core picks a new favorite color.', {
    action: 'sparkburst', color: 'random',
  }, { aliases: ['colors', 'colorful', 'recolor'], related: ['rainbow', 'prism'], demo: 'color' }),

  cmd('monochrome', 'visual', 'All color drains away, elegantly.', {
    color: '#94a3b8', trail: null, glow: 0.9, dim: 0.12,
  }, { aliases: ['grayscale', 'grey', 'gray', 'black and white'], related: ['silver', 'metal'], demo: 'color' }),

  cmd('halo', 'visual', 'A quiet ring of light settles above.', {
    halo: true, color: '#fde68a', glow: 1.3,
  }, { aliases: ['aura', 'nimbus', 'ring of light'], related: ['angel', 'glow'], demo: 'glow', sound: 'magic' }),

  cmd('trail', 'visual', 'The core remembers where it has been.', {
    trail: 'comet',
  }, { aliases: ['trails', 'light trail', 'comet trail'], related: ['echo', 'rainbow'], demo: 'drift' }),

  cmd('confetti', 'visual', 'A small celebration rains down.', {
    weather: 'confetti',
  }, { aliases: ['confetti fall', 'celebration'], related: ['disco', 'fireworks'], demo: 'confetti', sound: 'magic' }),

  cmd('fireworks', 'visual', 'Quiet fireworks bloom far above.', {
    action: 'fireworks',
  }, { aliases: ['firework', 'firework show', 'pyrotechnics'], related: ['explode', 'confetti'], demo: 'fireworks', sound: 'impact' }),

  cmd('angel', 'visual', 'Feathers, a halo, a calm and gentle light.', {
    action: ['featherfall', 'ringwave'], color: '#fef3c7', glow: 1.4, weather: null,
  }, { aliases: ['seraph', 'heavenly'], related: ['halo', 'feather'], demo: 'petal', sound: 'magic' }),

  cmd('shadowclone', 'visual', 'Three dark copies, one step behind.', {
    action: 'clone',
  }, { aliases: ['clones', 'afterimages', 'multiplicity'], related: ['shadow', 'echo'], demo: 'shadow' }),
]
