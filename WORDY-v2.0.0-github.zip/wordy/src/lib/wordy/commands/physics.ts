import { cmd } from './helpers'
import type { CommandDef } from '../types'

/* PHYSICS — bend the rules that hold everything together */
export const physicsCommands: CommandDef[] = [
  cmd('gravity', 'physics', 'Everything remembers which way is down.', {
    gravity: 1, motion: 'bounce',
  }, { aliases: ['gravitation', 'grav'], related: ['heavy', 'fall', 'antigravity'], demo: 'gravity', sound: 'impact' }),

  cmd('antigravity', 'physics', 'Down is a rumor now. Everything rises.', {
    gravity: -0.6, motion: 'float',
  }, { aliases: ['zero gravity', 'zerog', 'weightless'], related: ['float', 'gravity', 'fly'], demo: 'drift', sound: 'whoosh' }),

  cmd('freeze', 'physics', 'Ice creeps over the core, patient and bright.', {
    element: 'ice', action: 'frostburst',
  }, { aliases: ['frozen', 'freezing', 'ice over'], related: ['ice', 'melt', 'winter'], demo: 'freeze', sound: 'freeze' }),

  cmd('melt', 'physics', 'The ice loosens and streams away.', {
    action: 'melt', weather: null,
  }, { aliases: ['thaw', 'melting', 'unfreeze'], related: ['freeze', 'fire', 'steam'], demo: 'freeze' }),

  cmd('heavy', 'physics', 'Dense as a dying star. It sinks.', {
    gravity: 1.6, scaleMul: 1.12, timeScale: 0.8, motion: 'floor',
  }, { aliases: ['heavy core', 'dense', 'anchor'], related: ['gravity', 'collapse'], demo: 'fall', sound: 'impact' }),

  cmd('lighten', 'physics', 'Lighter than a whisper.', {
    gravity: 0, motion: 'float', scaleMul: 0.94, glow: 1.2,
  }, { aliases: ['featherweight', 'airy'], related: ['float', 'antigravity'], demo: 'drift' }),

  cmd('slow', 'physics', 'Time thickens like honey.', {
    timeScale: 0.45,
  }, { aliases: ['slow motion', 'slowmo', 'slow down'], related: ['crawl', 'fast', 'time'], demo: 'time' }),

  cmd('fast', 'physics', 'Everything quickens.', {
    timeScale: 1.65,
  }, { aliases: ['quick', 'speed', 'quicken', 'hurry'], related: ['slow', 'turbo', 'sonic'], demo: 'time' }),

  cmd('hyper', 'physics', 'Beyond fast — the world blurs.', {
    timeScale: 2.3, trail: 'echo',
  }, { aliases: ['hyperspeed', 'turbo', 'overdrive'], related: ['fast', 'sonic'], demo: 'time' }),

  cmd('crawl', 'physics', 'Barely moving at all.', {
    timeScale: 0.28,
  }, { aliases: ['snail', 'turtle', 'sloth'], related: ['slow', 'calm'], demo: 'time' }),

  cmd('sonic', 'physics', 'A crack of speed, a ring of sound.', {
    timeScale: 2.6, action: ['ringwave', 'dash'], trail: 'comet',
  }, { aliases: ['supersonic', 'cheetah', 'speed of sound'], related: ['fast', 'dash'], demo: 'dash', sound: 'impact' }),

  cmd('reverse', 'physics', 'The world flips inside out.', {
    action: 'mirrorworld', mirror: true,
  }, { aliases: ['rewind', 'backwards', 'flip world'], related: ['mirror', 'invert'], demo: 'mirror', sound: 'magic' }),

  cmd('attract', 'physics', 'Everything leans toward the core.', {
    attract: 'attract', action: 'ringwave',
  }, { aliases: ['attract mode', 'gravity well'], related: ['repel', 'magnet'], demo: 'gravity', sound: 'magic' }),

  cmd('repel', 'physics', 'Everything scatters away.', {
    attract: 'repel', action: 'shockwave',
  }, { aliases: ['push', 'scatter', 'deflect'], related: ['attract', 'boom'], demo: 'gravity', sound: 'impact' }),

  cmd('implode', 'physics', 'All of it, crushed into one bright point.', {
    action: ['implode', 'flash'],
  }, { aliases: ['collapse', 'crush'], related: ['blackhole', 'explode'], demo: 'explode', sound: 'impact' }),

  cmd('expand', 'physics', 'The core swells like a rising sun.', {
    action: 'ringwave', scaleMul: 1.35, glow: 1.2,
  }, { aliases: ['inflate', 'grow big'], related: ['big', 'grow', 'shrink'], demo: 'size' }),

  cmd('shrink', 'physics', 'Small, smaller, smallest.', {
    scaleMul: 0.7,
  }, { aliases: ['shrink down', 'deflate'], related: ['tiny', 'small', 'expand'], demo: 'size' }),

  cmd('elastic', 'physics', 'Stretchy landings every time.', {
    motion: 'bounce', gravity: 1, action: 'squish',
  }, { aliases: ['rubber', 'bouncy', 'jelly physics'], related: ['bounce', 'wobble'], demo: 'bounce' }),

  cmd('friction', 'physics', 'The world grinds to a halt.', {
    timeScale: 0.6, motion: 'floor', gravity: 1, weather: 'dust',
  }, { aliases: ['brake', 'grind'], related: ['slow', 'stop'], demo: 'time' }),

  cmd('inertia', 'physics', 'Once moving, always moving.', {
    motion: 'drift', spin: 2.5,
  }, { aliases: ['momentum', 'drift on'], related: ['drift', 'glide'], demo: 'drift' }),

  cmd('equilibrium', 'physics', 'All forces balanced. Peace restored.', {
    gravity: 0, timeScale: 1, motion: 'idle', spin: 0, attract: null, mirror: false,
  }, { aliases: ['balance', 'stability', 'harmony'], related: ['calm', 'reset'], demo: 'drift', sound: 'magic' }),

  cmd('magnet', 'physics', 'Iron dust dances to the core’s tune.', {
    attract: 'attract', action: 'sparkburst', color: '#94a3b8',
  }, { aliases: ['magnetic', 'lodestone'], related: ['attract', 'metal'], demo: 'gravity', sound: 'magic' }),

  cmd('time', 'physics', 'Time itself ripples and bends.', {
    action: 'ripple', timeScale: 0.7,
  }, { aliases: ['clock', 'hourglass', 'tempo'], related: ['slow', 'fast', 'chaos'], demo: 'time', sound: 'magic' }),

  cmd('reset', 'physics', 'A fresh world, as if nothing happened.', {
    motion: 'idle', spin: 0, gravity: 0, timeScale: 1, scale: 1, shape: 'orb',
    trail: null, clearElements: true, clearWeather: true, environment: 'space',
    attract: null, mirror: false, invert: false, dim: 0, color: '#a78bfa', glow: 1,
  }, { aliases: ['restart', 'clear', 'fresh start', 'new world'], related: ['calm', 'equilibrium'], demo: 'environment', sound: 'magic' }),

  cmd('calm', 'physics', 'The world exhales and settles.', {
    motion: 'idle', spin: 0, timeScale: 1, clearWeather: true, trail: null, glow: 1,
  }, { aliases: ['peace', 'still', 'serenity'], related: ['reset', 'equilibrium'], demo: 'drift', sound: 'magic' }),

  cmd('chaos', 'physics', 'Rules? Never heard of them.', {
    action: ['shake', 'sparkburst'], spin: 6, motion: 'zigzag', timeScale: 1.4, weather: 'sparks',
  }, { aliases: ['mayhem', 'havoc', 'wild'], related: ['random', 'storm', 'disco'], demo: 'chaos', sound: 'impact' }),
]
