import type { CommandDef, ComboDef, SecretHint, Category } from '../types'
import { movementCommands } from './movement'
import { physicsCommands } from './physics'
import { elementCommands } from './elements'
import { natureCommands } from './nature'
import { visualCommands } from './visual'
import { environmentCommands, objectCommands } from './environments'
import { specialCommands, secretCommands } from './special'
import { colorCommands, sizeCommands, phraseCommands } from './words'

/* ==========================================================================
   The WORDY registry — every command the world knows.
   To add a command: add one entry in any file above. Nothing else changes.
   ========================================================================== */

export const COMMANDS: CommandDef[] = [
  ...movementCommands,
  ...physicsCommands,
  ...elementCommands,
  ...natureCommands,
  ...visualCommands,
  ...environmentCommands,
  ...objectCommands,
  ...specialCommands,
  ...phraseCommands,
  ...colorCommands,
  ...sizeCommands,
  ...secretCommands,
]

/** every word (names + aliases) that resolves to a command */
export const COMMAND_MAP: Map<string, CommandDef> = (() => {
  const map = new Map<string, CommandDef>()
  for (const c of COMMANDS) {
    map.set(c.name, c)
    for (const a of c.aliases) map.set(a, c)
  }
  return map
})()

export const TOTAL_WORDS = COMMAND_MAP.size
export const TOTAL_COMMANDS = COMMANDS.length
export const TOTAL_SECRETS = secretCommands.length
export { secretCommands, specialCommands }

export function findCommand(raw: string): CommandDef | undefined {
  const key = raw.trim().toLowerCase().replace(/\s+/g, ' ')
  if (!key) return undefined
  return (
    COMMAND_MAP.get(key) ??
    COMMAND_MAP.get(key.replace(/\s+/g, '')) ??
    COMMAND_MAP.get(key.replace(/\s+/g, ''))
  )
}

export function commandsByCategory(cat: Category): CommandDef[] {
  return COMMANDS.filter((c) => c.category === cat && !c.hidden)
}

export function randomVisibleCommand(): CommandDef {
  const pool = COMMANDS.filter((c) => !c.hidden)
  return pool[Math.floor(Math.random() * pool.length)]
}

/** curated starters shown before the user types anything — worlds first */
export const STARTER_WORDS = ['volcano', 'butterfly', 'gravity', 'photosynthesis', 'fly', 'boom', 'rainbow', 'ocean', 'tornado', 'moon', 'storm', 'black hole']

/* ---- emergent combinations the engine can discover ---- */
export const COMBOS: ComboDef[] = [
  { id: 'steam', name: 'Steam', recipe: 'fire + rain', description: 'Fire and water meet — and turn into something soft.' },
  { id: 'mist', name: 'Mist', recipe: 'fire + ice', description: 'Opposites cancel into a pale fog.' },
  { id: 'firestorm', name: 'Firestorm', recipe: 'fire + wind', description: 'Wind feeds the flame until it roars.' },
  { id: 'glacier', name: 'Glacier', recipe: 'water + ice', description: 'Water remembers how to be solid.' },
  { id: 'thunderstorm', name: 'Thunderstorm', recipe: 'lightning + storm', description: 'The sky commits to the bit.' },
  { id: 'rainbowbirth', name: 'Rainbow Born', recipe: 'sun + rain', description: 'After sun and rain, color itself appears.' },
  { id: 'obsidian', name: 'Obsidian', recipe: 'fire + earth', description: 'Flame bakes the stone into black glass.' },
  { id: 'geyser', name: 'Geyser', recipe: 'lava + water', description: 'Deep heat meets deep water. Stand back.' },
  { id: 'snowflake', name: 'Perfect Snow', recipe: 'ice + wind', description: 'Wind carves the frost into patterns.' },
  { id: 'thundercloud', name: 'Thundercloud', recipe: 'electric + cloud', description: 'A cloud with opinions.' },
  { id: 'stardust', name: 'Stardust', recipe: 'star + boom', description: 'A star, gently taken apart.' },
  { id: 'popsicle', name: 'Popsicle', recipe: 'freeze + bounce', description: 'Some things should not be that cold.' },
  { id: 'iceburst', name: 'Iceburst', recipe: 'freeze + boom', description: 'A frozen core does not burn — it shatters, beautifully.' },
  { id: 'blizzard', name: 'Blizzard', recipe: 'rain + freeze', description: 'The rain itself forgets how to fall as water.' },
  { id: 'moonflight', name: 'Moon Flight', recipe: 'moon + fly', description: 'Up here, gravity is only a suggestion.' },
  { id: 'ragingstorm', name: 'Raging Tempest', recipe: 'storm + lightning', description: 'The sky takes the lightning personally, and answers twice as often.' },
]

/* ---- hints for the secrets (never the word itself) ---- */
export const SECRET_HINTS: SecretHint[] = secretCommands.map((c) => ({ name: c.name, hint: '' }))

const HINTS: Record<string, string> = {
  love: 'Four letters. Endless output. Try saying it to the world.',
  life: 'It starts with a seed and refuses to stop.',
  magic: 'You already know the word. You have always known it.',
  wonder: 'The feeling you are pretending not to have.',
  secret: 'The word is the hint. That is the whole puzzle.',
  wordy: 'Say the world’s name and it will answer.',
  zen: 'Less. Then less again.',
  unicorn: 'Horn. Rainbow. Attitude.',
  dragon: 'Fire, with ambition.',
  phoenix: 'It burns, and calls that a fresh start.',
  miracle: 'Light does something it should not be able to.',
  infinity: 'The core traces a shape with no end.',
  'cosmic dance': 'The stars waltz, if you ask correctly.',
  'fever dream': 'Everything at once, slightly too much, beautifully.',
}

export function hintFor(name: string): string {
  return HINTS[name] ?? 'Somewhere between a word and a wish.'
}
