import { cmd } from './helpers'
import type { CommandDef } from '../types'

/* WORDS — generated families: colors, sizes, greetings */

const COLOR_WORDS: Array<[string, string, string[]]> = [
  ['red', '#f87171', ['crimson red', 'scarlet core']],
  ['orange', '#fb923c', ['tangerine', 'citrus']],
  ['yellow', '#fde047', ['lemon', 'sunny yellow']],
  ['green', '#4ade80', ['emerald light', 'leaf green']],
  ['blue', '#60a5fa', ['true blue', 'azure']],
  ['purple', '#a78bfa', ['violet core', 'amethyst']],
  ['pink', '#f472b6', ['rose', 'blush']],
  ['gold', '#fbbf24', ['golden', 'aurum']],
  ['silver', '#e2e8f0', ['platinum', 'moon silver']],
  ['white', '#f8fafc', ['pure white', 'snow white']],
  ['black', '#312e81', ['obsidian', 'onyx']],
  ['teal', '#2dd4bf', ['teal glow']],
  ['cyan', '#22d3ee', ['aqua blue', 'electric cyan']],
  ['magenta', '#e879f9', ['fuchsia', 'hot pink']],
  ['violet', '#8b5cf6', ['ultraviolet', 'deep violet']],
  ['crimson', '#ef4444', ['blood red', 'ruby red']],
  ['amber', '#f59e0b', ['honey', 'golden amber']],
  ['emerald', '#34d399', ['jade', 'emerald green']],
  ['sapphire', '#3b82f6', ['deep sapphire']],
  ['ruby', '#f43f5e', ['ruby core']],
  ['lavender', '#c4b5fd', ['lilac', 'soft violet']],
  ['turquoise', '#5eead4', ['aqua green']],
  ['peach', '#fdba74', ['apricot', 'sunset peach']],
  ['mint', '#a7f3d0', ['minty', 'seafoam']],
]

const TINT_DESCRIPTIONS = [
  'The core settles into a {name} glow.',
  'A wash of {name} light.',
  'Everything it touches turns a little {name}.',
  '{Name}, quietly radiating.',
]

export const colorCommands: CommandDef[] = COLOR_WORDS.map(([name, hex, aliases], i) =>
  cmd(name, 'visual', TINT_DESCRIPTIONS[i % TINT_DESCRIPTIONS.length].replace('{name}', name).replace('{Name}', name[0].toUpperCase() + name.slice(1)), {
    color: hex, action: 'sparkburst', glow: 1.25,
  }, { aliases, related: ['color', 'rainbow', 'glow'], demo: 'color', gold: name === 'gold' }),
)

/* ---- sizes ---- */
const SIZE_WORDS: Array<[string, number, number, string[]]> = [
  ['tiny', 0.45, 1, ['tininess', 'itty bitty', 'smol']],
  ['small', 0.72, 1, ['little', 'petite']],
  ['big', 1.45, 1, ['big core', 'grown']],
  ['large', 1.75, 1, ['grand']],
  ['huge', 2.15, 1, ['very big', 'large and in charge']],
  ['giant', 2.6, 1, ['enormous', 'gigantic']],
  ['massive', 3.1, 1, ['colossal core', 'immense']],
  ['colossal', 3.8, 1, ['titanic', 'planetary']],
  ['grow', 0, 1.32, ['growing', 'enlarge', 'bigger']],
  ['swell', 0, 1.2, ['swelling', 'puff up']],
  ['microscopic', 0.25, 1, ['quantum dot', 'speck']],
]

const SIZE_DESCRIPTIONS: Record<string, string> = {
  tiny: 'So small you could almost miss it.',
  small: 'Modest, tidy, pocket-sized.',
  big: 'Noticeably more core than before.',
  large: 'The core takes up real presence.',
  huge: 'Big enough to worry the neighbors.',
  giant: 'It blocks out reasonable amounts of sky.',
  massive: 'Gently unreasonable in scale.',
  colossal: 'The horizon is nervous.',
  grow: 'A little bigger, every moment.',
  swell: 'It breathes outward.',
  microscopic: 'Blink and it is gone.',
}

export const sizeCommands: CommandDef[] = SIZE_WORDS.map(([name, scale, mul, aliases]) =>
  cmd(name, 'physics', SIZE_DESCRIPTIONS[name] ?? 'A different scale of core.', scale === 0
    ? { scaleMul: mul, action: 'squish' }
    : { scale, action: 'ringwave' },
  { aliases, related: ['shrink', 'expand', 'tiny'], demo: 'size' }),
)

/* ---- greetings & phrases ---- */
export const phraseCommands: CommandDef[] = [
  cmd('hello', 'special', 'The world says hello right back.', {
    action: ['greet', 'ripple', 'sparkburst'],
  }, { aliases: ['hi', 'hi there', 'hey', 'hello world', 'greetings'], related: ['wordy', 'sun'], demo: 'sparkle', sound: 'magic' }),

  cmd('goodbye', 'special', 'The core waves once and drifts off.', {
    action: ['featherfall', 'ripple'], motion: 'drift', trail: 'sparkle',
  }, { aliases: ['bye', 'farewell', 'good bye', 'see you'], related: ['fade', 'float'], demo: 'drift', sound: 'magic' }),

  cmd('good morning', 'special', 'The world stretches into first light.', {
    environment: 'dawn', action: ['flock', 'bloom'], weather: null, dim: 0,
  }, { aliases: ['sunrise greeting', 'top of the morning'], related: ['dawn', 'sun'], demo: 'environment', sound: 'magic' }),

  cmd('good night', 'special', 'Stars switch on, one by one.', {
    environment: 'night', weather: 'fireflies', dim: 0.2,
  }, { aliases: ['goodnight', 'night night', 'bedtime'], related: ['night', 'firefly'], demo: 'environment', sound: 'magic' }),

  cmd('please', 'special', 'The world appreciates good manners.', {
    action: ['sparkburst', 'heartburst'], glow: 1.2,
  }, { aliases: ['thank you in advance', 'kindly'], related: ['thank you', 'sparkle'], demo: 'sparkle', sound: 'magic' }),

  cmd('thank you', 'special', 'Warm light, briefly, in gratitude.', {
    action: ['flash', 'featherfall'], color: '#fde68a', glow: 1.25,
  }, { aliases: ['thanks', 'thankyou', 'gratitude', 'much appreciated'], related: ['please', 'gold'], demo: 'hearts', sound: 'magic' }),

  cmd('happy birthday', 'special', 'Confetti. Fireworks. Completely sincere.', {
    action: ['confettiburst', 'fireworks', 'flash'], glow: 1.4,
  }, { aliases: ['birthday', 'happy bday'], related: ['confetti', 'fireworks'], demo: 'confetti', sound: 'magic' }),

  cmd('congratulations', 'special', 'A standing ovation, briefly.', {
    action: ['confettiburst', 'starburst'], glow: 1.3,
  }, { aliases: ['congrats', 'well done', 'bravo'], related: ['confetti', 'celebrate'], demo: 'confetti', sound: 'magic' }),

  cmd('happy new year', 'special', 'The sky celebrates, quietly but thoroughly.', {
    action: ['fireworks', 'confettiburst', 'flash'], weather: 'confetti', glow: 1.3,
  }, { aliases: ['new year', 'happy nye', 'fireworks show'], related: ['fireworks', 'confetti'], demo: 'fireworks', sound: 'impact' }),

  cmd('merry christmas', 'special', 'Snow, warm light, and something like a tree.', {
    environment: 'winter', weather: 'snow', action: 'bloom', color: '#4ade80',
  }, { aliases: ['christmas', 'xmas', 'noel'], related: ['winter', 'snow'], demo: 'rain' }),

  cmd('happy halloween', 'special', 'The dark gets a little playful.', {
    environment: 'midnight', weather: 'fog', color: '#fb923c', shape: 'ghost', action: 'flock', dim: 0.25,
  }, { aliases: ['halloween', 'spooky', 'spooky season', 'trick or treat'], related: ['fog', 'ghost'], demo: 'environment' }),
]
