'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { SphereStyle, SphereDimension } from './types'
import type { SavedWorld, SavedCreation } from './knowledge/types'

/* ==========================================================================
   WORDY user state — everything lives locally, nothing leaves the device.
   Discovered words, saved spells, concept progress, creations, settings.
   ========================================================================== */

export interface Spell {
  id: string
  name: string
  steps: string[]
  createdAt: number
}

export interface HistoryEntry {
  word: string
  at: number
}

export interface GraphicsSettings {
  quality: 'low' | 'medium' | 'high' | 'ultra'
  fps: 30 | 60 | 120
  density: number    // 0.25 – 2
  bloom: number      // 0.4 – 1.6
  motion: boolean
  background: boolean
}

export interface AudioSettings {
  master: number     // 0 – 1
  commands: boolean
  ambient: boolean
  voice: boolean
}

export interface SphereSettings {
  style: SphereStyle
  dimension: SphereDimension
}

/** v2.0 — learning progress for one concept world */
export interface ConceptProgress {
  visitedAt: number
  explored: boolean       // clicked a hotspot or ran a contextual action
  experimented: boolean   // moved a parameter
  bestQuiz: number        // 0..3
  recallCorrect: boolean
  saved: boolean
}

export const emptyProgress = (): ConceptProgress => ({
  visitedAt: 0,
  explored: false,
  experimented: false,
  bestQuiz: 0,
  recallCorrect: false,
  saved: false,
})

const DEFAULT_GRAPHICS: GraphicsSettings = {
  quality: 'high',
  fps: 60,
  density: 1,
  bloom: 1,
  motion: true,
  background: true,
}

const DEFAULT_AUDIO: AudioSettings = {
  master: 0.7,
  commands: true,
  ambient: true,
  voice: true,
}

const DEFAULT_SPHERE: SphereSettings = {
  style: 'energy',
  dimension: '3d',
}

interface WordyState {
  /* discoveries */
  discovered: string[]          // visible commands the user has tried
  discoveredSecrets: string[]   // hidden words revealed
  discoveredCombos: string[]    // emergent combos witnessed

  /* history */
  history: HistoryEntry[]

  /* spells */
  spells: Spell[]

  /* v2.0 — concept worlds */
  conceptProgress: Record<string, ConceptProgress>
  savedWorlds: SavedWorld[]
  creations: SavedCreation[]
  recentConcepts: string[]
  dailyDone: Record<string, boolean>   // dayKey → challenge answered

  /* settings */
  graphics: GraphicsSettings
  audio: AudioSettings
  sphere: SphereSettings
  seenIntro: boolean

  /* actions */
  recordCommand: (name: string, hidden?: boolean) => void
  recordCombo: (id: string) => void
  pushHistory: (word: string) => void
  saveSpell: (spell: Spell) => void
  deleteSpell: (id: string) => void
  touchConcept: (id: string) => ConceptProgress
  markConcept: (id: string, patch: Partial<ConceptProgress>) => void
  pushRecentConcept: (id: string) => void
  saveWorld: (world: SavedWorld) => void
  removeWorld: (id: string) => void
  saveCreation: (creation: SavedCreation) => void
  deleteCreation: (id: string) => void
  markDailyDone: (dayKey: string) => void
  setGraphics: (p: Partial<GraphicsSettings>) => void
  setAudio: (p: Partial<AudioSettings>) => void
  setSphere: (p: Partial<SphereSettings>) => void
  setSeenIntro: (v: boolean) => void
  resetAll: () => void
}

export const useWordy = create<WordyState>()(
  persist(
    (set, get) => ({
      discovered: [],
      discoveredSecrets: [],
      discoveredCombos: [],
      history: [],
      spells: [],
      conceptProgress: {},
      savedWorlds: [],
      creations: [],
      recentConcepts: [],
      dailyDone: {},
      graphics: { ...DEFAULT_GRAPHICS },
      audio: { ...DEFAULT_AUDIO },
      sphere: { ...DEFAULT_SPHERE },
      seenIntro: false,

      recordCommand: (name, hidden) =>
        set((s) => {
          if (hidden) {
            if (s.discoveredSecrets.includes(name)) return s
            return { discoveredSecrets: [...s.discoveredSecrets, name] }
          }
          if (s.discovered.includes(name)) return s
          return { discovered: [...s.discovered, name] }
        }),

      recordCombo: (id) =>
        set((s) =>
          s.discoveredCombos.includes(id)
            ? s
            : { discoveredCombos: [...s.discoveredCombos, id] },
        ),

      pushHistory: (word) =>
        set((s) => ({
          history: [{ word, at: Date.now() }, ...s.history.filter((h) => h.word !== word)].slice(0, 40),
        })),

      saveSpell: (spell) =>
        set((s) => ({
          spells: [spell, ...s.spells.filter((p) => p.id !== spell.id)].slice(0, 24),
        })),

      deleteSpell: (id) =>
        set((s) => ({ spells: s.spells.filter((p) => p.id !== id) })),

      touchConcept: (id) => {
        const prev = get().conceptProgress[id] ?? emptyProgress()
        if (!prev.visitedAt) {
          set((s) => ({
            conceptProgress: { ...s.conceptProgress, [id]: { ...prev, visitedAt: Date.now() } },
          }))
          return { ...prev, visitedAt: Date.now() }
        }
        return prev
      },

      markConcept: (id, patch) =>
        set((s) => ({
          conceptProgress: {
            ...s.conceptProgress,
            [id]: { ...(s.conceptProgress[id] ?? emptyProgress()), ...patch },
          },
        })),

      pushRecentConcept: (id) =>
        set((s) => ({
          recentConcepts: [id, ...s.recentConcepts.filter((c) => c !== id)].slice(0, 12),
        })),

      saveWorld: (world) =>
        set((s) => ({
          savedWorlds: [world, ...s.savedWorlds.filter((w) => w.id !== world.id)].slice(0, 36),
          conceptProgress: {
            ...s.conceptProgress,
            [world.id]: { ...(s.conceptProgress[world.id] ?? emptyProgress()), saved: true },
          },
        })),

      removeWorld: (id) =>
        set((s) => ({ savedWorlds: s.savedWorlds.filter((w) => w.id !== id) })),

      saveCreation: (creation) =>
        set((s) => ({
          creations: [creation, ...s.creations.filter((c) => c.id !== creation.id)].slice(0, 36),
        })),

      deleteCreation: (id) =>
        set((s) => ({ creations: s.creations.filter((c) => c.id !== id) })),

      markDailyDone: (dayKey) =>
        set((s) => ({ dailyDone: { ...s.dailyDone, [dayKey]: true } })),

      setGraphics: (p) => set((s) => ({ graphics: { ...s.graphics, ...p } })),
      setAudio: (p) => set((s) => ({ audio: { ...s.audio, ...p } })),
      setSphere: (p) => set((s) => ({ sphere: { ...s.sphere, ...p } })),
      setSeenIntro: (v) => set({ seenIntro: v }),

      resetAll: () =>
        set({
          discovered: [],
          discoveredSecrets: [],
          discoveredCombos: [],
          history: [],
          spells: [],
          conceptProgress: {},
          savedWorlds: [],
          creations: [],
          recentConcepts: [],
          dailyDone: {},
          graphics: { ...DEFAULT_GRAPHICS },
          audio: { ...DEFAULT_AUDIO },
          sphere: { ...DEFAULT_SPHERE },
          seenIntro: false,
        }),
    }),
    {
      name: 'wordy-world-v1',
      version: 3,
      /* safe migrations — v1 stored { soundOn, quality } flat, v2 added settings objects */
      migrate: (persisted) => {
        const p = (persisted ?? {}) as Record<string, unknown>
        const out: Record<string, unknown> = {}
        // carry over the collections v1 knew about
        for (const key of ['discovered', 'discoveredSecrets', 'discoveredCombos', 'history', 'spells', 'seenIntro']) {
          if (Array.isArray(p[key]) || typeof p[key] === 'boolean') out[key] = p[key]
        }
        // v2/v3 collections
        if (p.conceptProgress && typeof p.conceptProgress === 'object') out.conceptProgress = p.conceptProgress
        if (Array.isArray(p.savedWorlds)) out.savedWorlds = p.savedWorlds
        if (Array.isArray(p.creations)) out.creations = p.creations
        if (Array.isArray(p.recentConcepts)) out.recentConcepts = p.recentConcepts
        if (p.dailyDone && typeof p.dailyDone === 'object') out.dailyDone = p.dailyDone
        // map old settings to the new shape
        const oldSound = typeof p.soundOn === 'boolean' ? p.soundOn : true
        const oldQuality = typeof p.quality === 'string' ? p.quality : 'auto'
        const prevGraphics = (p.graphics ?? {}) as Partial<GraphicsSettings>
        const prevAudio = (p.audio ?? {}) as Partial<AudioSettings>
        const prevSphere = (p.sphere ?? {}) as Partial<SphereSettings>
        out.graphics = {
          ...DEFAULT_GRAPHICS,
          ...prevGraphics,
          quality: prevGraphics.quality
            ?? (oldQuality === 'low' ? 'low' : oldQuality === 'high' ? 'ultra' : 'high'),
        }
        out.audio = {
          ...DEFAULT_AUDIO,
          ...prevAudio,
          master: typeof prevAudio.master === 'number' ? prevAudio.master : oldSound ? DEFAULT_AUDIO.master : 0,
          commands: prevAudio.commands ?? oldSound,
        }
        out.sphere = { ...DEFAULT_SPHERE, ...prevSphere }
        return out as unknown as WordyState
      },
    },
  ),
)
