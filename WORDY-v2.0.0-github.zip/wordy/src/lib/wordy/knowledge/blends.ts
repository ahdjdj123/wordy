import type { ConceptDef, LearningCategory } from './types'

/* ==========================================================================
   Word Blender — how two concept worlds combine.
   The blend is a creative visual interpretation (the UI labels it as such);
   the educational facts always belong to the primary concept.
   ========================================================================== */

/** curated blend names for memorable pairs (order-insensitive) */
const BLEND_NAMES: Record<string, string> = {
  'butterfly+volcano': 'Emberwing',
  'butterfly+rainbow': 'Prism Flutter',
  'butterfly+chaos': 'The Butterfly Effect',
  'ocean+volcano': 'Steam Sea',
  'ocean+aurora': 'Polar Tide',
  'whale+gravity': 'Sky Whale',
  'whale+rainbow': 'Painted Whale',
  'dinosaur+rainbow': 'Prism Rex',
  'rainbow+tornado': 'Colour Storm',
  'magnet+butterfly': 'Compass Moth',
  'time+tornado': 'Time Twister',
  'energy+atom': 'Star Seed',
  'joy+aurora': 'Celebration Sky',
  'sadness+ocean': 'Deep Blue',
  'anger+volcano': 'Rage Mountain',
  'calm+ocean': 'Still Water',
  'black hole+rainbow': 'Light Eater',
  'solar system+butterfly': 'Cosmic Migration',
  'frog+rainbow': 'Rainforest Gem',
  'electricity+ocean': 'Storm Surge',
  'moon landing+aurora': 'Polar Landing',
  'ancient egypt+time': 'Eternal Nile',
  'clock+chaos': 'Broken Metronome',
  'photosynthesis+aurora': 'Night Garden',
}

/** how each learning category colours a blend (weather / particles) */
const CATEGORY_INFLUENCE: Record<LearningCategory, { weather?: string; hue: number }> = {
  organisms: { weather: 'butterflies', hue: 300 },
  emotions: { weather: 'hearts', hue: 340 },
  phenomena: { weather: 'embers', hue: 20 },
  science: { weather: 'starfall', hue: 262 },
  processes: { weather: 'leaves', hue: 140 },
  abstract: { weather: 'sparks', hue: 200 },
  history: { weather: 'dust', hue: 40 },
  objects: { weather: 'fireflies', hue: 60 },
}

export interface BlendResult {
  name: string
  /** secondary concept's visual influence */
  weather: string | null
  hue: number
  /** honest label — this is a creative interpretation, not a lesson */
  isCurated: boolean
}

export function blendName(primaryId: string, secondaryId: string): string | null {
  return BLEND_NAMES[`${primaryId}+${secondaryId}`] ?? BLEND_NAMES[`${secondaryId}+${primaryId}`] ?? null
}

export function blendWorlds(primary: ConceptDef, secondary: ConceptDef): BlendResult {
  const curated = blendName(primary.id, secondary.id)
  const influence = CATEGORY_INFLUENCE[secondary.category]
  return {
    name: curated ?? `${primary.word} × ${secondary.word}`,
    weather: influence.weather ?? null,
    hue: influence.hue,
    isCurated: !!curated,
  }
}
