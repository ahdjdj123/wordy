import type { ConceptDef, LearningCategory } from './types'
import { objectConcepts } from './data/objects'
import { organismConcepts } from './data/organisms'
import { phenomenaConcepts } from './data/phenomena'
import { scienceConcepts } from './data/science'
import { processConcepts, abstractConcepts } from './data/processes-abstract'
import { emotionConcepts, historyConcepts } from './data/emotions-history'

/* ==========================================================================
   The concept registry + lookup. A word typed in the Playground resolves
   to a concept world BEFORE the command engine gets a chance — but curated
   concepts also carry an entry spec that preserves the old behaviour.
   ========================================================================== */

export const CONCEPTS: ConceptDef[] = [
  ...objectConcepts,
  ...organismConcepts,
  ...phenomenaConcepts,
  ...scienceConcepts,
  ...processConcepts,
  ...abstractConcepts,
  ...emotionConcepts,
  ...historyConcepts,
]

/** word → concept (id + word + aliases, all lowercased) */
export const CONCEPT_MAP: Map<string, ConceptDef> = (() => {
  const m = new Map<string, ConceptDef>()
  for (const c of CONCEPTS) {
    m.set(c.id, c)
    m.set(c.word, c)
    for (const a of c.aliases) m.set(a, c)
  }
  return m
})()

export const TOTAL_CONCEPTS = CONCEPTS.length

export function findConcept(raw: string): ConceptDef | undefined {
  const key = raw.trim().toLowerCase().replace(/\s+/g, ' ')
  if (!key) return undefined
  return CONCEPT_MAP.get(key) ?? CONCEPT_MAP.get(key.replace(/\s+/g, ''))
}

export function conceptsOfCategory(cat: LearningCategory): ConceptDef[] {
  return CONCEPTS.filter((c) => c.category === cat)
}

/** the daily discovery — deterministic per calendar day, everyone gets the same one */
export function conceptOfDay(date = new Date()): ConceptDef {
  const day = Math.floor(
    Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()) / 86400000,
  )
  // golden-ratio scramble keeps consecutive days feeling unrelated
  const idx = Math.abs(Math.round((day % CONCEPTS.length) * 0.61803398875)) % CONCEPTS.length
  return CONCEPTS[idx]
}

export function dayKey(d = new Date()): string {
  const p = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
}

/** a random world, gently preferring ones not yet visited */
export function randomConcept(visited: string[]): ConceptDef {
  const fresh = CONCEPTS.filter((c) => !visited.includes(c.id))
  const pool = fresh.length > 0 ? fresh : CONCEPTS
  return pool[Math.floor(Math.random() * pool.length)]
}

export { LEARNING_CATEGORY_META } from './types'
export type { LearningCategory, SceneKind, ConceptDef } from './types'
