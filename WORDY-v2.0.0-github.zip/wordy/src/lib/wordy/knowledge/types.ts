import type { EffectSpec } from '../types'

/* ==========================================================================
   WORDY 2.0 — the knowledge layer.
   A curated set of concept worlds. Each concept knows what it looks like,
   what it teaches, how it can be experimented with, and what to recall.
   Everything here is plain, factual, textbook-safe knowledge.
   ========================================================================== */

/** the eight learning categories a word can belong to */
export type LearningCategory =
  | 'objects'    // Objects
  | 'organisms'  // Animals & organisms
  | 'phenomena'  // Natural phenomena
  | 'science'    // Scientific concepts
  | 'processes'  // Processes
  | 'abstract'   // Abstract concepts
  | 'emotions'   // Emotions
  | 'history'    // Historical concepts

export const LEARNING_CATEGORY_META: Record<
  LearningCategory,
  { label: string; blurb: string; icon: string; hue: string }
> = {
  objects: { label: 'Objects', blurb: 'Things people built and use.', icon: '⚙️', hue: 'amber' },
  organisms: { label: 'Living things', blurb: 'Animals and how life grows.', icon: '🦋', hue: 'emerald' },
  phenomena: { label: 'Natural phenomena', blurb: 'The sky, the sea and the ground at work.', icon: '🌋', hue: 'orange' },
  science: { label: 'Science', blurb: 'The rules the universe runs on.', icon: '🔬', hue: 'violet' },
  processes: { label: 'Processes', blurb: 'How things change, step by step.', icon: '🔄', hue: 'cyan' },
  abstract: { label: 'Big ideas', blurb: 'Words you cannot touch.', icon: '💭', hue: 'fuchsia' },
  emotions: { label: 'Emotions', blurb: 'What feelings look like in motion.', icon: '💛', hue: 'rose' },
  history: { label: 'History', blurb: 'Moments the world still remembers.', icon: '🏛️', hue: 'yellow' },
}

/** the visualization templates the scene engine can perform */
export type SceneKind =
  | 'volcano'    // mountain, magma, eruption
  | 'lifecycle'  // egg → … → adult (butterfly / frog)
  | 'orbital'    // star + planets (solar / gravity / black hole)
  | 'plant'      // seed → plant (photosynthesis / germination)
  | 'watercycle' // evaporation → cloud → rain → sea
  | 'weather'    // tornado / earthquake
  | 'creature'   // bird / whale / dinosaur
  | 'field'      // emotions, rainbow, aurora, magnet, energy, chaos, time
  | 'timeline'   // history eras with event nodes
  | 'atom'       // atom / electric circuit
  | 'ocean'      // waves / coral reef
  | 'gears'      // clockwork / robot

export interface QuizQuestion {
  q: string
  options: string[]
  answer: number
  explain: string
}

export interface ExperimentParam {
  key: string
  label: string
  min: number
  max: number
  step: number
  def: number
  unit?: string
}

export interface WorldAction {
  id: string
  label: string
}

export interface ConceptDef {
  id: string
  word: string
  aliases: string[]
  category: LearningCategory
  icon: string
  tagline: string
  /** four facts, accurate and short */
  facts: string[]
  /** three knowledge checks */
  quiz: QuizQuestion[]
  params: ExperimentParam[]
  actions: WorldAction[]
  /** what the Explore panel suggests doing first */
  exploreHints: string[]
  /** what to watch for while experimenting */
  watchFor?: string
  scene: SceneKind
  sceneConfig?: Record<string, string | number | boolean>
  /** engine effects applied on world entry (preserves + upgrades the old command behaviour) */
  entry?: Partial<EffectSpec>
  /** shown on the empty-state hero */
  example?: boolean
}

/* ---- saved things (library / studio) ---- */

export interface SavedWorld {
  id: string            // concept id
  params: Record<string, number>
  savedAt: number
}

export interface SavedCreation {
  id: string
  name: string
  primary: string       // concept id
  secondary: string     // concept id
  createdAt: number
}
