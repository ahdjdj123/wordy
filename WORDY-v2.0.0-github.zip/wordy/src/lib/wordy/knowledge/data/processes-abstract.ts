import type { ConceptDef } from '../types'

/* ==========================================================================
   Processes — how things change, step by step. (plant, watercycle templates)
   ========================================================================== */

export const processConcepts: ConceptDef[] = [
  {
    id: 'photosynthesis',
    word: 'photosynthesis',
    aliases: ['photosynthesize'],
    category: 'processes',
    icon: '🌱',
    tagline: 'How plants eat sunlight and feed the world.',
    facts: [
      'Photosynthesis turns sunlight, water and carbon dioxide into glucose and oxygen.',
      'It happens inside chloroplasts, where the green pigment chlorophyll captures light.',
      'The oxygen released is a by-product — plants make sugar for themselves and share the rest with us.',
      'Nearly all food chains begin with photosynthesis — plants are the planet’s solar-powered kitchens.',
    ],
    quiz: [
      {
        q: 'What three ingredients does a plant need for photosynthesis?',
        options: [
          'Sunlight, water and carbon dioxide',
          'Soil, rain and wind',
          'Sugar, oxygen and heat',
          'Moonlight and minerals',
        ],
        answer: 0,
        explain: 'Light provides the energy; water and CO₂ provide the building blocks.',
      },
      {
        q: 'What does the plant make, and what is released?',
        options: [
          'Glucose is made; oxygen is released',
          'Oxygen is made; sugar released',
          'Protein made; CO₂ released',
          'Water made; light released',
        ],
        answer: 0,
        explain: 'Sugar feeds the plant; the oxygen it releases feeds the planet.',
      },
      {
        q: 'Where in the leaf does photosynthesis happen?',
        options: ['In the chloroplasts', 'In the veins', 'On the surface wax', 'In the stem only'],
        answer: 0,
        explain: 'Chloroplasts packed with chlorophyll are the leaf’s tiny solar factories.',
      },
    ],
    params: [
      { key: 'sunlight', label: 'Sunlight', min: 0, max: 2, step: 0.1, def: 1, unit: '×' },
      { key: 'water', label: 'Soil water', min: 0, max: 2, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'bloom', label: 'Hurry the bloom' },
      { id: 'cloud', label: 'Cloud the sun' },
    ],
    exploreHints: [
      'Tap a leaf to follow the carbon dioxide going in.',
      'Follow the gold specks — sugar flowing down to the roots.',
    ],
    watchFor: 'With no sunlight the plant droops; with plenty it stands tall and makes sugar fast.',
    scene: 'plant',
    sceneConfig: { variant: 'photosynthesis' },
    example: true,
    entry: { environment: 'forest', mood: 'calm' },
  },
  {
    id: 'germination',
    word: 'germination',
    aliases: ['sprout', 'germinate', 'seed'],
    category: 'processes',
    icon: '🌰',
    tagline: 'The first days of a plant’s life.',
    facts: [
      'A seed contains a tiny plant embryo plus a packed lunch of stored food.',
      'Germination begins when water, warmth and oxygen reach the seed.',
      'The root always grows first — anchoring the seed and drinking for it.',
      'Only then does the shoot push up, bending toward the light.',
    ],
    quiz: [
      {
        q: 'What three things start a seed germinating?',
        options: ['Water, warmth and oxygen', 'Light, salt and wind', 'Sugar, ice and dark', 'Music, soil and rain'],
        answer: 0,
        explain: 'Water wakes the embryo; warmth and oxygen fuel its first growth.',
      },
      {
        q: 'What emerges first from a germinating seed?',
        options: ['The root', 'The flower', 'A leaf', 'The fruit'],
        answer: 0,
        explain: 'Roots first — anchor and drink — before any shoot dares to rise.',
      },
      {
        q: 'What is inside a seed?',
        options: [
          'A tiny embryo plant and stored food',
          'Only water',
          'A miniature flower',
          'Soil',
        ],
        answer: 0,
        explain: 'The packed lunch fuels growth until the first leaves can photosynthesize.',
      },
    ],
    params: [
      { key: 'sunlight', label: 'Warmth & light', min: 0, max: 2, step: 0.1, def: 1, unit: '×' },
      { key: 'water', label: 'Soil water', min: 0, max: 2, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'water', label: 'Water the soil' },
      { id: 'restart', label: 'Plant a new seed' },
    ],
    exploreHints: [
      'Tap the soil to water it — the seed swells before it splits.',
      'Watch which way the first shoot bends — always toward the light.',
    ],
    watchFor: 'No water, no sprout. Dry seeds simply wait — some for years.',
    scene: 'plant',
    sceneConfig: { variant: 'germination' },
  },
  {
    id: 'water cycle',
    word: 'water cycle',
    aliases: ['watercycle', 'evaporation', 'condensation'],
    category: 'processes',
    icon: '💧',
    tagline: 'The same water, falling for four billion years.',
    facts: [
      'The water cycle runs on the Sun: evaporation lifts water into the sky as invisible vapour.',
      'High up the vapour cools and condenses into droplets — clouds.',
      'When droplets grow heavy, they fall as precipitation: rain, snow or hail.',
      'The water collects in rivers, lakes and oceans — ready to begin again.',
    ],
    quiz: [
      {
        q: 'What powers the water cycle?',
        options: ['The Sun', 'The Moon', 'Wind alone', 'Ocean tides'],
        answer: 0,
        explain: 'Solar energy evaporates water and keeps the whole loop turning.',
      },
      {
        q: 'How do clouds form?',
        options: [
          'Water vapour cools high up and condenses into droplets',
          'Smoke from the ground',
          'Dust drying out',
          'Rain freezing mid-air',
        ],
        answer: 0,
        explain: 'Rising vapour meets cold air and condenses onto tiny particles — a cloud is born.',
      },
      {
        q: 'What comes right after precipitation?',
        options: [
          'Collection — water gathers in rivers, lakes and oceans',
          'Evaporation again instantly',
          'The cycle stops',
          'Condensation',
        ],
        answer: 0,
        explain: 'Collected water waits in the sun — and the loop begins again.',
      },
    ],
    params: [
      { key: 'heat', label: 'Sun heat', min: 0, max: 2, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'rain', label: 'Make it rain' },
      { id: 'relax', label: 'Ease the heat' },
    ],
    exploreHints: [
      'Tap the sun to crank the heat and speed the loop.',
      'Tap the cloud when it is heavy — let it go.',
    ],
    watchFor: 'More heat means faster evaporation and a fatter cloud.',
    scene: 'watercycle',
    entry: { environment: 'ocean', mood: 'calm' },
  },
]

/* ==========================================================================
   Abstract — words you cannot touch. (field template)
   ========================================================================== */

export const abstractConcepts: ConceptDef[] = [
  {
    id: 'time',
    word: 'time',
    aliases: [],
    category: 'abstract',
    icon: '⏳',
    tagline: 'Measured by change, kept by atoms.',
    facts: [
      'We only ever measure time by watching change — a swing, a shadow, a heartbeat.',
      'One second is officially defined by 9,192,631,770 vibrations of a caesium atom.',
      'The world’s clocks are synchronised by atomic time, shared since 1967.',
      'Time zones were standardised in 1884, when railways made every town’s local time unworkable.',
    ],
    quiz: [
      {
        q: 'How is a second officially defined today?',
        options: [
          'By 9,192,631,770 vibrations of a caesium atom',
          'One sunrise',
          'A pendulum swing',
          '1/100 of an hour',
        ],
        answer: 0,
        explain: 'Since 1967 the second is atomic — identical everywhere in the universe.',
      },
      {
        q: 'What made the world standardise time zones in 1884?',
        options: ['Railways', 'Telephones', 'Air travel', 'Television'],
        answer: 0,
        explain: 'Trains ran on schedules — thousands of local times could not coexist.',
      },
      {
        q: 'How do we actually notice time passing?',
        options: ['Only through change', 'Through gravity', 'Through sound', 'We cannot'],
        answer: 0,
        explain: 'Clocks, shadows and seasons — every measure of time is a measure of change.',
      },
    ],
    params: [
      { key: 'intensity', label: 'Flow', min: 0.2, max: 2, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'pulse', label: 'Mark the moment' },
      { id: 'rewind', label: 'Rewind' },
    ],
    exploreHints: [
      'Tap the flow to freeze a moment — then let it run again.',
      'Each ripple is one second, counted out exactly.',
    ],
    watchFor: 'Faster flow makes the whole world hurry — particles, waves, everything.',
    scene: 'field',
    sceneConfig: { variant: 'time' },
    entry: { action: 'ripple', timeScale: 0.7, mood: 'calm' },
  },
  {
    id: 'energy',
    word: 'energy',
    aliases: [],
    category: 'abstract',
    icon: '✨',
    tagline: 'Never created, never destroyed — only transformed.',
    facts: [
      'Energy is the capacity to do work — to move, heat, glow or grow.',
      'The law of conservation says energy is never created or destroyed, only transformed.',
      'Plants convert sunlight into chemical energy; your body converts food into motion.',
      'A falling stone, a hot pan and a shout are all energy changing form.',
    ],
    quiz: [
      {
        q: 'What does the law of conservation of energy say?',
        options: [
          'Energy is only transformed, never created or destroyed',
          'Energy slowly disappears',
          'Energy doubles every day',
          'Energy is always lost as light',
        ],
        answer: 0,
        explain: 'Every joule is accounted for — it just keeps changing costume.',
      },
      {
        q: 'How do plants capture energy?',
        options: [
          'They convert sunlight into chemical energy (sugar)',
          'They eat soil',
          'They absorb heat from rocks',
          'They borrow it from animals',
        ],
        answer: 0,
        explain: 'Photosynthesis stores light energy in sugar — food chains start there.',
      },
      {
        q: 'Energy is best defined as…',
        options: ['The capacity to do work', 'A kind of matter', 'Only electricity', 'Movement'],
        answer: 0,
        explain: 'Whether motion, heat, light or growth — all are work being done.',
      },
    ],
    params: [
      { key: 'intensity', label: 'Flow', min: 0.2, max: 2, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'pulse', label: 'Send a pulse' },
      { id: 'transform', label: 'Transform it' },
    ],
    exploreHints: [
      'Tap the circuit to send a pulse of energy all the way around.',
      'Watch the flow split and rejoin — nothing is lost.',
    ],
    watchFor: 'The same pulse powers every node — energy transforms, it never vanishes.',
    scene: 'field',
    sceneConfig: { variant: 'energy' },
    entry: { glow: 1.4, mood: 'energetic' },
  },
  {
    id: 'chaos',
    word: 'chaos',
    aliases: ['butterfly effect'],
    category: 'abstract',
    icon: '🌀',
    tagline: 'Tiny causes, enormous consequences.',
    facts: [
      'In chaos theory, tiny differences in the start can grow into wildly different outcomes.',
      'Meteorologist Edward Lorenz found rounding a number by 0.0001 changed his weather forecast completely.',
      'The “butterfly effect” is chaos’s mascot: a small flap today may reshape next month’s storm.',
      'Chaotic systems follow strict rules — yet stay impossible to predict far ahead.',
    ],
    quiz: [
      {
        q: 'What is the “butterfly effect”?',
        options: [
          'Tiny changes at the start can lead to wildly different outcomes',
          'Butterflies cause storms',
          'Chaos is random',
          'Weather cannot be measured',
        ],
        answer: 0,
        explain: 'Small causes amplify through feedback — the heart of chaos theory.',
      },
      {
        q: 'What did Edward Lorenz discover?',
        options: [
          'Rounding a starting value slightly changed his weather forecast entirely',
          'Butterflies migrate',
          'Storms never repeat',
          'The atmosphere is stable',
        ],
        answer: 0,
        explain: 'His 1960s weather model showed extreme sensitivity to initial conditions.',
      },
      {
        q: 'Are chaotic systems lawless?',
        options: [
          'No — they follow strict rules but stay unpredictable far ahead',
          'Yes — anything can happen',
          'Only on weekends',
          'No one knows',
        ],
        answer: 0,
        explain: 'Deterministic yet unpredictable — the strange, beautiful paradox of chaos.',
      },
    ],
    params: [
      { key: 'intensity', label: 'Turbulence', min: 0.2, max: 2, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'nudge', label: 'Nudge the start' },
      { id: 'reset', label: 'Reset history' },
    ],
    exploreHints: [
      'Tap the swirl to nudge it — a whisper of change.',
      'Two almost-identical paths drift apart into entirely different shapes.',
    ],
    watchFor: 'One nudge, and the pattern never returns to its old road.',
    scene: 'field',
    sceneConfig: { variant: 'chaos' },
    entry: { mood: 'curious' },
  },
]
