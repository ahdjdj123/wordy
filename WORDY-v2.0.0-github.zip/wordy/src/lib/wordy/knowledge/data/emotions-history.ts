import type { ConceptDef } from '../types'

/* ==========================================================================
   Emotions — what feelings look like in motion. (field template)
   Psychologically grounded, framed honestly.
   ========================================================================== */

export const emotionConcepts: ConceptDef[] = [
  {
    id: 'joy',
    word: 'joy',
    aliases: ['happiness', 'happy'],
    category: 'emotions',
    icon: '😊',
    tagline: 'Light, rising, and impossible to hold still.',
    facts: [
      'Psychologists count joy among the basic human emotions, present across every culture studied.',
      'Joy broadens attention — people notice more possibilities when they feel good.',
      'The “Duchenne smile”, using the muscles around the eyes, is the signature of genuine joy.',
      'Joy is contagious: seeing someone’s smile activates the muscles for your own.',
    ],
    quiz: [
      {
        q: 'How does joy change what people notice?',
        options: [
          'It broadens attention — more possibilities come into view',
          'It narrows focus to one thing',
          'It shuts vision down',
          'It only affects hearing',
        ],
        answer: 0,
        explain: 'Positive emotions widen thinking — psychologists call this the broaden-and-build effect.',
      },
      {
        q: 'What marks a genuine, joyful smile?',
        options: [
          'The muscles around the eyes engage — the Duchenne smile',
          'Teeth only',
          'A tilt of the head',
          'A loud laugh',
        ],
        answer: 0,
        explain: 'Duchenne smiles involve the orbicularis oculi — nearly impossible to fake.',
      },
      {
        q: 'What happens when you see someone smile?',
        options: [
          'Your own smile muscles begin to activate',
          'Nothing measurable',
          'You yawn',
          'Your heart slows to a stop',
        ],
        answer: 0,
        explain: 'Faces mirror each other — joy spreads without a word.',
      },
    ],
    params: [
      { key: 'intensity', label: 'Intensity', min: 0.2, max: 2, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'burst', label: 'Let it burst' },
      { id: 'share', label: 'Share it' },
    ],
    exploreHints: [
      'Tap the feeling to let it burst outward.',
      'Notice the motion — everything rises.',
    ],
    watchFor: 'Turn up the intensity: joy spreads in widening circles, like news worth telling.',
    scene: 'field',
    sceneConfig: { variant: 'joy' },
    entry: { mood: 'jubilant' },
  },
  {
    id: 'sadness',
    word: 'sadness',
    aliases: ['sad', 'sorrow'],
    category: 'emotions',
    icon: '🌧️',
    tagline: 'Slow, heavy, and part of the process.',
    facts: [
      'Sadness slows the body and mind — researchers believe this creates space to process loss.',
      'Tears carry stress hormones away; emotional tears differ chemically from reflex tears.',
      'Feeling sad is universal and healthy — sadness that never lifts is when to seek help.',
      'Sharing sadness with someone who listens reliably makes it lighter.',
    ],
    quiz: [
      {
        q: 'What do researchers think sadness’s slowing effect is for?',
        options: [
          'It creates space to process loss',
          'It saves electricity',
          'It has no purpose',
          'It makes us faster',
        ],
        answer: 0,
        explain: 'Emotions have jobs — sadness pulls us inward to reflect and adapt.',
      },
      {
        q: 'How do emotional tears differ from reflex tears?',
        options: [
          'They carry more stress hormones',
          'They are saltier only',
          'They are pure water',
          'They are invisible',
        ],
        answer: 0,
        explain: 'Emotional tears flush stress chemistry — one reason a good cry can help.',
      },
      {
        q: 'What reliably helps sadness feel lighter?',
        options: [
          'Sharing it with someone who truly listens',
          'Hiding it perfectly',
          'Ignoring it forever',
          'Running away',
        ],
        answer: 0,
        explain: 'Connection is a buffer — sadness shared is sadness halved.',
      },
    ],
    params: [
      { key: 'intensity', label: 'Intensity', min: 0.2, max: 2, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'drift', label: 'Let it drift' },
      { id: 'clear', label: 'Part the clouds' },
    ],
    exploreHints: [
      'Tap the feeling to let a drop fall.',
      'Watch the motion — everything sinks slowly.',
    ],
    watchFor: 'Sadness in this world falls like gentle rain — slow, deliberate, not destructive.',
    scene: 'field',
    sceneConfig: { variant: 'sadness' },
    entry: { mood: 'calm', dim: 0.2 },
  },
  {
    id: 'anger',
    word: 'anger',
    aliases: ['angry', 'rage'],
    category: 'emotions',
    icon: '🔥',
    tagline: 'Fast, hot, and asking for change.',
    facts: [
      'Anger prepares the body for action: heart rate and breathing quicken.',
      'It often shows up as a guard at the door of another feeling — hurt, fear or unfairness.',
      'Naming anger precisely — “I feel angry because…” — measurably calms its grip.',
      'Anger can fuel fair change; the skill is aiming it, not feeding it.',
    ],
    quiz: [
      {
        q: 'What does anger do to the body?',
        options: [
          'Quickens heart rate and breathing, preparing for action',
          'Slows everything down',
          'Cools the skin',
          'Stops digestion only',
        ],
        answer: 0,
        explain: 'Anger is an arousal emotion — the body revs up, ready to respond.',
      },
      {
        q: 'What feeling often hides behind anger?',
        options: [
          'Hurt, fear or a sense of unfairness',
          'Only hunger',
          'Boredom',
          'Joy',
        ],
        answer: 0,
        explain: 'Anger is often the bodyguard for a softer feeling underneath.',
      },
      {
        q: 'What measurably helps calm anger?',
        options: [
          'Naming it precisely — “I feel angry because…”',
          'Bottling it up',
          'Shouting louder',
          'Pretending it is gone',
        ],
        answer: 0,
        explain: 'Labelling an emotion (“affect labelling”) reduces its intensity.',
      },
    ],
    params: [
      { key: 'intensity', label: 'Intensity', min: 0.2, max: 2, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'flare', label: 'Let it flare' },
      { id: 'breathe', label: 'Breathe it out' },
    ],
    exploreHints: [
      'Tap the feeling to see it flare — sharp and brief.',
      'Then use Breathe it out and watch the spikes soften.',
    ],
    watchFor: 'Anger moves in spikes; calm returns in waves. Notice the difference.',
    scene: 'field',
    sceneConfig: { variant: 'anger' },
    entry: { mood: 'tense' },
  },
  {
    id: 'calm',
    word: 'calm',
    aliases: ['peace', 'peaceful'],
    category: 'emotions',
    icon: '🌊',
    tagline: 'The nervous system at rest.',
    facts: [
      'Calm is what the parasympathetic nervous system feels like from inside — the body’s rest mode.',
      'Slow, deep breathing signals this system directly, lowering heart rate.',
      'Just six seconds of a slow exhale begins to shift the body toward calm.',
      'Calm is not the absence of feeling — it is feeling without the alarm.',
    ],
    quiz: [
      {
        q: 'Which system produces the feeling of calm?',
        options: [
          'The parasympathetic nervous system — the body’s rest mode',
          'The immune system',
          'The skeleton',
          'The digestive system only',
        ],
        answer: 0,
        explain: '“Rest and digest” is the parasympathetic system at work.',
      },
      {
        q: 'How does slow breathing help?',
        options: [
          'It directly signals the rest system and lowers heart rate',
          'It stops the heart',
          'It only distracts',
          'It adds oxygen to the blood only',
        ],
        answer: 0,
        explain: 'Long exhales stimulate the vagus nerve — a direct line to calm.',
      },
      {
        q: 'What is calm, really?',
        options: [
          'Feeling without the alarm',
          'The absence of all feeling',
          'Being asleep',
          'Being alone',
        ],
        answer: 0,
        explain: 'Emotions can still be present — calm is the quiet underneath them.',
      },
    ],
    params: [
      { key: 'intensity', label: 'Stillness', min: 0.2, max: 2, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'breathe', label: 'Breathe with it' },
      { id: 'ripple', label: 'One quiet ripple' },
    ],
    exploreHints: [
      'Tap the centre and breathe with the rings — in, and slowly out.',
      'Watch how each ripple fades completely before the next begins.',
    ],
    watchFor: 'The rhythm here is about six seconds per wave — try matching your breath to it.',
    scene: 'field',
    sceneConfig: { variant: 'calm' },
    entry: { mood: 'calm', glow: 0.7 },
  },
]

/* ==========================================================================
   History — moments the world still remembers. (timeline template)
   ========================================================================== */

export const historyConcepts: ConceptDef[] = [
  {
    id: 'ancient egypt',
    word: 'ancient egypt',
    aliases: ['egypt', 'pyramids', 'pharaoh'],
    category: 'history',
    icon: '🏜️',
    tagline: 'Three thousand years along one river.',
    facts: [
      'Ancient Egypt grew along the Nile, whose yearly floods made farming possible in the desert.',
      'The pyramids were royal tombs; the Great Pyramid of Giza is the only surviving ancient wonder.',
      'Egyptians wrote in hieroglyphs — decoded after the Rosetta Stone was found in 1799.',
      'Cleopatra lived closer in time to the Moon landing than to the building of the Great Pyramid.',
    ],
    quiz: [
      {
        q: 'Why did Egyptian civilisation flourish along the Nile?',
        options: [
          'Yearly floods made the land fertile for farming',
          'The river was paved with gold',
          'It never rained there',
          'The desert kept enemies away only',
        ],
        answer: 0,
        explain: 'The flood left rich silt each year — bread for a kingdom in the desert.',
      },
      {
        q: 'What were the pyramids built as?',
        options: ['Royal tombs', 'Granaries', 'Temples of the sun', 'Watchtowers'],
        answer: 0,
        explain: 'Pyramids were stairways to eternity for pharaohs — the Great Pyramid is ~4,500 years old.',
      },
      {
        q: 'What made hieroglyphs readable again?',
        options: [
          'The Rosetta Stone, found in 1799, matched them to Greek',
          'A pharaoh explained them',
          'They were never lost',
          'Computers decoded them',
        ],
        answer: 0,
        explain: 'The stone repeated one text in three scripts — the key that unlocked the rest.',
      },
    ],
    params: [
      { key: 'pace', label: 'Story pace', min: 0.3, max: 3, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'next', label: 'Next moment' },
      { id: 'replay', label: 'Replay the era' },
    ],
    exploreHints: [
      'Tap a marker on the timeline to visit that moment.',
      'Follow the sun — it crosses the pyramids every single day, as it has for millennia.',
    ],
    watchFor: 'The Nile floods, the crops rise, the pyramids rise — one rhythm, three thousand years.',
    scene: 'timeline',
    sceneConfig: { variant: 'egypt' },
    entry: { environment: 'desert', mood: 'curious' },
  },
  {
    id: 'roman empire',
    word: 'roman empire',
    aliases: ['rome', 'romans'],
    category: 'history',
    icon: '🏛️',
    tagline: 'Concrete, roads and laws, from Britain to Egypt.',
    facts: [
      'The Roman Empire began in 27 BC under Augustus and its western half fell in 476 AD.',
      'Roman roads were built so well that pieces still carry traffic today.',
      'The Colosseum seated some 50,000 spectators for gladiatorial games.',
      'Rome’s language, Latin, lives on as Italian, Spanish, French, Portuguese and Romanian.',
    ],
    quiz: [
      {
        q: 'Who was the first Roman emperor?',
        options: ['Augustus', 'Julius Caesar', 'Nero', 'Constantine'],
        answer: 0,
        explain: 'In 27 BC Augustus took supreme power — the Republic became an Empire.',
      },
      {
        q: 'What survives of Roman engineering in daily use?',
        options: [
          'Roads, bridges and aqueducts — some still standing',
          'Spaceships',
          'Printing presses',
          'Telegraph lines',
        ],
        answer: 0,
        explain: 'Roman concrete and road-building outlasted the empire itself.',
      },
      {
        q: 'Which modern languages grew from Latin?',
        options: [
          'Italian, Spanish, French, Portuguese and Romanian',
          'English and German only',
          'Greek',
          'None',
        ],
        answer: 0,
        explain: 'The Romance languages are Rome’s spoken legacy.',
      },
    ],
    params: [
      { key: 'pace', label: 'Story pace', min: 0.3, max: 3, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'next', label: 'Next moment' },
      { id: 'replay', label: 'Replay the era' },
    ],
    exploreHints: [
      'Tap a marker on the timeline to visit that moment.',
      'Count the arches — Roman builders repeated one strong shape everywhere.',
    ],
    watchFor: 'Roads, aqueducts, arenas — the same engineering, empire-wide.',
    scene: 'timeline',
    sceneConfig: { variant: 'rome' },
    entry: { environment: 'sunset', mood: 'curious' },
  },
  {
    id: 'great wall',
    word: 'great wall',
    aliases: ['great wall of china'],
    category: 'history',
    icon: '🧱',
    tagline: 'A wall built by many dynasties, over two thousand years.',
    facts: [
      'The Great Wall is not one wall but many, linked and rebuilt by successive dynasties over 2,000 years.',
      'The famous stone-and-brick sections mostly date from the Ming dynasty.',
      'Surveyors measured the whole network at about 21,196 kilometres.',
      'Watchtowers relayed warnings with smoke and fire signals — faster than any rider.',
    ],
    quiz: [
      {
        q: 'How long is the Great Wall network, as officially surveyed?',
        options: ['About 21,196 km', '500 km', '2,000 km', '100 km'],
        answer: 0,
        explain: 'A 2012 survey counted all branches: about 21,196 kilometres.',
      },
      {
        q: 'Which dynasty built the most famous surviving sections?',
        options: ['The Ming dynasty', 'The Tang', 'The Song', 'The Yuan'],
        answer: 0,
        explain: 'Ming-era stone and brick form the iconic wall of photographs.',
      },
      {
        q: 'How did watchtowers send warnings quickly?',
        options: [
          'Smoke and fire signals, tower to tower',
          'Carrier pigeons',
          'Written letters',
          'Trumpets only',
        ],
        answer: 0,
        explain: 'A beacon chain could carry word across hundreds of kilometres in hours.',
      },
    ],
    params: [
      { key: 'pace', label: 'Story pace', min: 0.3, max: 3, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'next', label: 'Next moment' },
      { id: 'replay', label: 'Replay the era' },
    ],
    exploreHints: [
      'Tap a marker on the timeline to visit that moment.',
      'The wall follows the ridgelines — builders used the terrain as part of the defence.',
    ],
    watchFor: 'Watch the beacon chain light up: news travels tower to tower in seconds.',
    scene: 'timeline',
    sceneConfig: { variant: 'wall' },
    entry: { environment: 'sunset', mood: 'curious' },
  },
  {
    id: 'moon landing',
    word: 'moon landing',
    aliases: ['apollo', 'apollo 11'],
    category: 'history',
    icon: '🚀',
    tagline: 'Three people, one small step, the whole world watching.',
    facts: [
      'Apollo 11 landed on the Moon on 20 July 1969, with Neil Armstrong and Buzz Aldrin aboard.',
      'Michael Collins stayed in orbit — the loneliest human, behind the Moon, out of all contact.',
      'In total, twelve astronauts walked on the Moon between 1969 and 1972.',
      'With no wind or rain, their footprints could last for millions of years.',
    ],
    quiz: [
      {
        q: 'When did Apollo 11 land on the Moon?',
        options: ['20 July 1969', '1 January 1950', '25 December 1971', '4 October 1957'],
        answer: 0,
        explain: 'Armstrong and Aldrin touched down on 20 July 1969.',
      },
      {
        q: 'What was Michael Collins doing during the landing?',
        options: [
          'Orbiting the Moon alone in the command module',
          'Waiting on Earth',
          'Walking on the Moon too',
          'Filming from a satellite',
        ],
        answer: 0,
        explain: 'While his crewmates landed, Collins circled — even passing behind the Moon, out of contact.',
      },
      {
        q: 'Why will the footprints last so long?',
        options: [
          'The Moon has no wind or rain to erase them',
          'They are made of metal',
          'The Moon is hot enough to harden them',
          'They were carved in stone',
        ],
        answer: 0,
        explain: 'No atmosphere means no weather — only tiny micrometeorites slowly stir the dust.',
      },
    ],
    params: [
      { key: 'pace', label: 'Story pace', min: 0.3, max: 3, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'next', label: 'Next moment' },
      { id: 'replay', label: 'Replay the era' },
    ],
    exploreHints: [
      'Tap a marker on the timeline to visit that moment.',
      'Look back at the sky — from the Moon, Earth is just a bright, blue dot.',
    ],
    watchFor: 'The lander descends slowly — the last metres were flown by hand, almost out of fuel.',
    scene: 'timeline',
    sceneConfig: { variant: 'apollo' },
    entry: { environment: 'space', mood: 'jubilant' },
  },
]
