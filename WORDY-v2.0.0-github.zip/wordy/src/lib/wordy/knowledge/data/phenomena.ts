import type { ConceptDef } from '../types'

/* ==========================================================================
   Natural phenomena — sky, sea and ground at work.
   (volcano, weather, field-prism, field-aurora, ocean templates)
   ========================================================================== */

export const phenomenaConcepts: ConceptDef[] = [
  {
    id: 'volcano',
    word: 'volcano',
    aliases: ['volcanoes', 'eruption', 'lava'],
    category: 'phenomena',
    icon: '🌋',
    tagline: 'A window into the molten rock beneath your feet.',
    facts: [
      'A volcano is an opening in Earth’s crust where molten rock, ash and gas escape from deep underground.',
      'Molten rock is called magma underground and lava once it erupts.',
      'Earth has roughly 1,350 potentially active volcanoes — not counting the many hidden under the oceans.',
      'Volcanoes erupt where tectonic plates pull apart or collide, letting pressure escape.',
    ],
    quiz: [
      {
        q: 'What is the difference between magma and lava?',
        options: [
          'Magma is underground; lava has erupted to the surface',
          'Lava is hotter than magma',
          'They are different rocks',
          'Magma is underwater',
        ],
        answer: 0,
        explain: 'Same molten rock — the name changes when it breaks the surface.',
      },
      {
        q: 'Roughly how many potentially active volcanoes does Earth have on land?',
        options: ['About 50', 'About 200', 'About 1,350', 'About 100,000'],
        answer: 2,
        explain: 'Around 1,350 on land have erupted in recent history or may again — plus many under the sea.',
      },
      {
        q: 'Why do volcanoes usually form near plate boundaries?',
        options: [
          'Plates pulling apart or colliding lets molten rock and pressure escape',
          'The wind piles up the lava',
          'Lightning strikes create them',
          'Rivers carve them',
        ],
        answer: 0,
        explain: 'Plate movement creates weak zones and melts rock — a path to the surface.',
      },
    ],
    params: [
      { key: 'pressure', label: 'Chamber pressure', min: 0.15, max: 1, step: 0.05, def: 0.45 },
    ],
    actions: [
      { id: 'erupt', label: 'Erupt!' },
      { id: 'ease', label: 'Ease the pressure' },
    ],
    exploreHints: [
      'Tap the crater to set off an eruption.',
      'Tap the slope while lava flows to watch it cool into dark crust.',
    ],
    watchFor: 'Raise the pressure slowly — tremors begin before the mountain gives way.',
    scene: 'volcano',
    example: true,
    entry: { environment: 'volcano', mood: 'tense' },
  },
  {
    id: 'tornado',
    word: 'tornado',
    aliases: ['tornados', 'twister', 'cyclone'],
    category: 'phenomena',
    icon: '🌪️',
    tagline: 'A column of spinning air, touching the ground.',
    facts: [
      'A tornado is a violently rotating column of air stretching from a storm cloud to the ground.',
      'Tornadoes form inside thunderstorms when wind changes speed and direction with height — wind shear — tilting rising air into a spin.',
      'Most tornadoes last under ten minutes, yet the strongest exceed 400 km/h winds.',
      'The Enhanced Fujita scale rates tornadoes EF0 to EF5 by the damage they leave behind.',
    ],
    quiz: [
      {
        q: 'What key ingredient spins a thunderstorm into a tornado?',
        options: [
          'Wind shear — wind changing speed and direction with height',
          'Heavy rain',
          'Cold oceans',
          'Mountain shadows',
        ],
        answer: 0,
        explain: 'Shear tilts rising air into rotation, which the updraft stretches into a tight, fast spin.',
      },
      {
        q: 'How long does a typical tornado last?',
        options: ['Under ten minutes', 'A whole day', 'One week', 'Several hours'],
        answer: 0,
        explain: 'Most are brief — but a few churning monsters can last hours.',
      },
      {
        q: 'What does the EF scale measure?',
        options: ['Wind speed measured directly', 'Damage left behind', 'Tornado colour', 'Loudness'],
        answer: 1,
        explain: 'The Enhanced Fujita scale estimates wind strength from observed damage, EF0 to EF5.',
      },
    ],
    params: [
      { key: 'shear', label: 'Wind shear', min: 0, max: 2, step: 0.1, def: 1, unit: '×' },
      { key: 'humidity', label: 'Storm humidity', min: 0, max: 2, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'spinup', label: 'Spin it up' },
      { id: 'settle', label: 'Let it settle' },
    ],
    exploreHints: [
      'Spin the shear up, then tap the cloud to drop the funnel.',
      'Watch the debris orbit the base — the fastest winds are near the ground.',
    ],
    watchFor: 'More shear tightens the funnel; humidity fattens the storm cloud feeding it.',
    scene: 'weather',
    sceneConfig: { variant: 'tornado' },
    entry: { environment: 'storm', weather: 'storm', mood: 'tense' },
  },
  {
    id: 'earthquake',
    word: 'earthquake',
    aliases: ['quakes', 'seism'],
    category: 'phenomena',
    icon: '🌎',
    tagline: 'The ground announcing that the plates are moving.',
    facts: [
      'An earthquake is the sudden release of built-up energy along a fault, racing out as seismic waves.',
      'Tectonic plates creep a few centimetres per year — about as fast as fingernails grow — storing stress as they stick.',
      'Each step up in magnitude releases roughly 32 times more energy than the step below.',
      'Seismometers detect quakes worldwide, even ones no human ever feels.',
    ],
    quiz: [
      {
        q: 'What triggers most earthquakes?',
        options: [
          'Sudden release of built-up stress along a fault',
          'Heavy rain',
          'The Moon’s gravity alone',
          'Wind against mountains',
        ],
        answer: 0,
        explain: 'Plates stick, stress accumulates, then the fault slips — and the energy radiates as waves.',
      },
      {
        q: 'How fast do tectonic plates typically move?',
        options: ['A few centimetres per year', 'A metre per day', 'A kilometre per century', 'They never move'],
        answer: 0,
        explain: 'A few cm/year — about fingernail growth speed, but relentless.',
      },
      {
        q: 'One magnitude step up means roughly how much more energy?',
        options: ['2× more', '10× more', 'About 32× more', '1,000× more'],
        answer: 2,
        explain: 'The scale is logarithmic — each whole step is ~32 times more energy.',
      },
    ],
    params: [
      { key: 'stress', label: 'Fault stress', min: 0, max: 1, step: 0.05, def: 0.4 },
    ],
    actions: [
      { id: 'quake', label: 'Let it slip' },
      { id: 'relax', label: 'Relax the fault' },
    ],
    exploreHints: [
      'Tap the fault line to release the built-up stress.',
      'Watch the strata — surface waves arrive after the first jolt.',
    ],
    watchFor: 'Let stress build fully: the next slip is always the biggest.',
    scene: 'weather',
    sceneConfig: { variant: 'earthquake' },
  },
  {
    id: 'rainbow',
    word: 'rainbow',
    aliases: ['rainbows', 'prism', 'spectrum'],
    category: 'phenomena',
    icon: '🌈',
    tagline: 'Sunlight, bent by raindrops into a band of colour.',
    facts: [
      'A rainbow appears when sunlight is refracted, reflected and refracted again inside millions of raindrops.',
      'Each drop returns the light at about 42° from the sun’s direction — that is why rainbows form arcs.',
      'Red always sits on the outside of the primary arc; violet on the inside.',
      'In a double rainbow, the outer bow’s colours are reversed, because light bounced twice inside the drops.',
    ],
    quiz: [
      {
        q: 'What creates a rainbow?',
        options: [
          'Sunlight refracted and reflected inside raindrops',
          'Clouds painted by sunset light',
          'Rain cooling the sky',
          'Oxygen glowing',
        ],
        answer: 0,
        explain: 'Droplets split white light into colours and return it toward you at ~42°.',
      },
      {
        q: 'Which colour is on the outside of a primary rainbow?',
        options: ['Violet', 'Red', 'Green', 'White'],
        answer: 1,
        explain: 'Red bends least, so it outlines the outer edge of the arc.',
      },
      {
        q: 'What is different about a double rainbow’s outer bow?',
        options: [
          'Its colours are reversed — violet outside',
          'It has no colours',
          'It appears before rain',
          'It is always larger than the sun',
        ],
        answer: 0,
        explain: 'A second internal reflection flips the colour order.',
      },
    ],
    params: [
      { key: 'intensity', label: 'Sunlight', min: 0.2, max: 2, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'shine', label: 'Let the sun through' },
      { id: 'mist', label: 'Add fine mist' },
    ],
    exploreHints: [
      'Tap the prism to open the spectrum wide.',
      'You always stand with the sun behind you to see a rainbow — the arc faces you.',
    ],
    watchFor: 'Dim the sunlight and the fainter colours vanish first — violet needs the most light.',
    scene: 'field',
    sceneConfig: { variant: 'prism' },
    example: true,
    entry: { trail: 'rainbow', mood: 'jubilant' },
  },
  {
    id: 'aurora',
    word: 'aurora',
    aliases: ['northern lights', 'polar lights'],
    category: 'phenomena',
    icon: '🌌',
    tagline: 'The sky glowing where solar wind meets Earth’s shield.',
    facts: [
      'Auroras glow when particles from the Sun are guided by Earth’s magnetic field into the upper atmosphere.',
      'The particles excite gases: oxygen glows green and red, nitrogen glows blue and purple.',
      'The northern lights are aurora borealis; the southern are aurora australis.',
      'Auroras circle the magnetic poles — that is why they are best seen near the Arctic and Antarctic.',
    ],
    quiz: [
      {
        q: 'What makes auroras glow?',
        options: [
          'Solar particles exciting gases in the upper atmosphere',
          'Moonlight reflecting off snow',
          'Lightning frozen in clouds',
          'Stars burning green',
        ],
        answer: 0,
        explain: 'Earth’s magnetic field steers solar wind particles into polar skies, where they excite air gases.',
      },
      {
        q: 'Which gas glows green in an aurora?',
        options: ['Nitrogen', 'Oxygen', 'Carbon dioxide', 'Helium'],
        answer: 1,
        explain: 'Oxygen at ~100 km altitude emits the famous green light.',
      },
      {
        q: 'Where are auroras seen best?',
        options: ['Near the equator', 'Near the magnetic poles', 'Only over oceans', 'Anywhere at noon'],
        answer: 1,
        explain: 'The magnetic field funnels particles toward the poles, forming glowing auroral ovals.',
      },
    ],
    params: [
      { key: 'intensity', label: 'Solar wind', min: 0.2, max: 2, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'gust', label: 'Solar gust' },
      { id: 'calm', label: 'Quiet sky' },
    ],
    exploreHints: [
      'Tap the sky to send a solar gust through the curtains.',
      'Notice the green hangs low, the purple higher — different gases at different heights.',
    ],
    watchFor: 'Stronger solar wind pushes the curtains further from the poles — and faster.',
    scene: 'field',
    sceneConfig: { variant: 'aurora' },
    entry: { environment: 'aurora', mood: 'calm' },
  },
  {
    id: 'ocean',
    word: 'ocean',
    aliases: ['sea', 'waves'],
    category: 'phenomena',
    icon: '🌊',
    tagline: 'One connected sea that covers most of the planet.',
    facts: [
      'The ocean covers about 71% of Earth’s surface and holds about 97% of its water.',
      'Tiny drifting plants — phytoplankton — produce roughly half of the oxygen you breathe.',
      'The deepest point, the Mariana Trench, lies almost 11 kilometres down.',
      'Waves are mostly made by wind: energy moves through water while the water itself barely travels.',
    ],
    quiz: [
      {
        q: 'How much of Earth’s surface water is in the ocean?',
        options: ['About half', 'About 97%', 'About 10%', 'All of it'],
        answer: 1,
        explain: 'About 97% — the rest is ice, groundwater, lakes and rivers.',
      },
      {
        q: 'What produces roughly half of Earth’s oxygen?',
        options: ['Forests only', 'Phytoplankton in the ocean', 'Volcanoes', 'Grasslands'],
        answer: 1,
        explain: 'Countless drifting algae photosynthesize — an invisible forest of the sea.',
      },
      {
        q: 'When a wave crosses the ocean, what mostly travels forward?',
        options: ['The water itself', 'Energy, not the water', 'Salt', 'Fish pushing it'],
        answer: 1,
        explain: 'Water particles mostly move in circles — the wave passes energy along.',
      },
    ],
    params: [
      { key: 'waves', label: 'Wave height', min: 0, max: 2, step: 0.1, def: 1, unit: '×' },
      { key: 'fish', label: 'Fish', min: 2, max: 12, step: 1, def: 6 },
    ],
    actions: [
      { id: 'bigwave', label: 'Send a swell' },
      { id: 'school', label: 'Gather the fish' },
    ],
    exploreHints: [
      'Tap the water to send a swell rolling through.',
      'Tap a fish to see the school scatter and reform.',
    ],
    watchFor: 'Higher wind-built waves carry more energy — watch the spray fly at the crest.',
    scene: 'ocean',
    sceneConfig: { variant: 'waves' },
    example: true,
    entry: { environment: 'ocean', mood: 'calm' },
  },
  {
    id: 'coral reef',
    word: 'coral reef',
    aliases: ['coral', 'reef'],
    category: 'phenomena',
    icon: '🪸',
    tagline: 'A city built by animals the size of your fingernail.',
    facts: [
      'Coral reefs are built by tiny animals called polyps, whose calcium skeletons stack up over centuries.',
      'Inside each polyp live microscopic algae that give the coral its colour and most of its food.',
      'Reefs cover a fraction of the ocean floor yet shelter about a quarter of all marine species.',
      'When water gets too warm, corals expel their algae and turn white — coral bleaching.',
    ],
    quiz: [
      {
        q: 'Who actually builds a coral reef?',
        options: ['Tiny animals called polyps', 'Rocks growing', 'Fish stacking sand', 'Seaweed'],
        answer: 0,
        explain: 'Each polyp lays down a calcium carbonate skeleton — colonies build entire reefs.',
      },
      {
        q: 'What lives inside a coral polyp and feeds it?',
        options: ['Microscopic algae', 'Shrimp', 'Bacteria only', 'Nothing'],
        answer: 0,
        explain: 'The algae photosynthesize and share sugars — a partnership that powers the reef.',
      },
      {
        q: 'What is coral bleaching?',
        options: [
          'Corals expel their algae and turn white under heat stress',
          'Corals being eaten',
          'Reefs turning blue',
          'A cleaning fish ritual',
        ],
        answer: 0,
        explain: 'Stressed polyps lose their colourful algae partners — repeated bleaching can kill the coral.',
      },
    ],
    params: [
      { key: 'waves', label: 'Swell', min: 0, max: 2, step: 0.1, def: 0.6, unit: '×' },
      { key: 'fish', label: 'Reef fish', min: 2, max: 12, step: 1, def: 8 },
    ],
    actions: [
      { id: 'bigwave', label: 'Send a swell' },
      { id: 'school', label: 'Gather the fish' },
    ],
    exploreHints: [
      'Tap the coral to spot the polyps’ glow.',
      'Watch how fish hover near the branching coral for shelter.',
    ],
    watchFor: 'A calm swell keeps the reef lively — the fish feed in the rhythm of the water.',
    scene: 'ocean',
    sceneConfig: { variant: 'reef' },
    entry: { environment: 'ocean', mood: 'calm' },
  },
]
