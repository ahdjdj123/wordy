import type { ConceptDef } from '../types'

/* ==========================================================================
   Objects — things people built. (gears template)
   ========================================================================== */

export const objectConcepts: ConceptDef[] = [
  {
    id: 'clock',
    word: 'clock',
    aliases: ['timekeeper', 'clockwork', 'watch'],
    category: 'objects',
    icon: '🕰️',
    tagline: 'A machine for catching the one thing you cannot hold.',
    facts: [
      'The first mechanical clocks, built in Europe in the 1300s, had no hands — they rang bells to mark the hours.',
      'A pendulum swings at a steady rhythm no matter how far it travels, which made clocks far more accurate from 1656 onward.',
      'A quartz watch counts the vibrations of a tiny quartz crystal — 32,768 every second — to keep time.',
      'Atomic clocks are so precise they would drift by only about one second after millions of years of running.',
    ],
    quiz: [
      {
        q: 'What made clocks dramatically more accurate from 1656 onward?',
        options: ['The pendulum', 'Bigger bells', 'Water wheels', 'Sun dials'],
        answer: 0,
        explain: 'A pendulum keeps a steady beat regardless of how far it swings, so it made timekeeping reliable.',
      },
      {
        q: 'How many vibrations does a quartz watch count each second?',
        options: ['60', '1,000', '32,768', '1 million'],
        answer: 2,
        explain: 'A tiny quartz crystal vibrates exactly 32,768 times per second — the watch counts them.',
      },
      {
        q: 'Why are atomic clocks special?',
        options: [
          'They are the loudest clocks',
          'They are extremely precise, drifting about a second in millions of years',
          'They run without any energy',
          'They can stop time',
        ],
        answer: 1,
        explain: 'Atomic clocks measure the ultra-stable behaviour of atoms — they set the world’s time standard.',
      },
    ],
    params: [
      { key: 'speed', label: 'Tick speed', min: 0.2, max: 3, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'wind', label: 'Wind it up' },
      { id: 'chime', label: 'Chime the hour' },
    ],
    exploreHints: [
      'Tap a gear to see how neighbours turn in opposite directions.',
      'Watch the pendulum — its beat stays even as the gears speed up.',
    ],
    watchFor: 'Gears mesh so their teeth always interlock — fast gears drive slow ones.',
    scene: 'gears',
    sceneConfig: { variant: 'clock' },
    entry: { action: 'ripple', timeScale: 0.7, mood: 'calm' },
  },
  {
    id: 'robot',
    word: 'robot',
    aliases: ['android', 'machine'],
    category: 'objects',
    icon: '🤖',
    tagline: 'A machine that senses, thinks and acts.',
    facts: [
      'The word “robot” comes from “robota”, meaning forced labour, coined in a 1920 Czech play.',
      'A robot works in three steps: it senses the world with sensors, decides with a program, then acts with motors.',
      'Most robots in the world today are industrial arms in factories — welding, painting and lifting with tireless precision.',
      'Robotic rovers on Mars cannot be driven live: radio signals take minutes to arrive, so they navigate on their own.',
    ],
    quiz: [
      {
        q: 'What are the three steps every robot follows?',
        options: [
          'Sense → decide → act',
          'Sleep → wake → repeat',
          'Build → paint → ship',
          'Listen → copy → forget',
        ],
        answer: 0,
        explain: 'Sensors gather data, the program decides, and motors make the robot act on the world.',
      },
      {
        q: 'Where does the word “robot” come from?',
        options: ['Greek for “machine”', 'Czech for “forced labour”', 'Latin for “helper”', 'Japanese for “automaton”'],
        answer: 1,
        explain: 'It appeared in Karel Čapek’s 1920 play R.U.R., from the Czech word “robota”.',
      },
      {
        q: 'Why do Mars rovers drive themselves instead of waiting for commands?',
        options: [
          'Radio signals take minutes to travel, so live driving is impossible',
          'They enjoy the independence',
          'Their antennas are decorative',
          'Earth has no maps of Mars',
        ],
        answer: 0,
        explain: 'The signal delay is minutes each way, so rovers sense hazards and steer autonomously.',
      },
    ],
    params: [
      { key: 'activity', label: 'Activity', min: 0, max: 2, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'scan', label: 'Run a scan' },
      { id: 'salute', label: 'Salute' },
    ],
    exploreHints: [
      'Tap the robot to trigger a scan sweep.',
      'The eye follows your pointer — it is sensing you.',
    ],
    watchFor: 'Raise activity and the arm moves faster — motors respond to their program.',
    scene: 'gears',
    sceneConfig: { variant: 'robot' },
    entry: { element: 'electric', mood: 'curious' },
  },
]
