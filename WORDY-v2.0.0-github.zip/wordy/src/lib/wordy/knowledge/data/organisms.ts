import type { ConceptDef } from '../types'

/* ==========================================================================
   Living things — animals and how life grows. (lifecycle + creature templates)
   ========================================================================== */

export const organismConcepts: ConceptDef[] = [
  {
    id: 'butterfly',
    word: 'butterfly',
    aliases: ['butterflies', 'metamorphosis'],
    category: 'organisms',
    icon: '🦋',
    tagline: 'One life, four completely different bodies.',
    facts: [
      'A butterfly’s life has four stages: egg, caterpillar, chrysalis, then adult.',
      'Inside the chrysalis the caterpillar breaks down almost completely and rebuilds itself into a butterfly.',
      'Butterflies taste with their feet — special receptors there detect the right plants instantly.',
      'Adults sip nectar through a tube-like proboscis, and many live only two to four weeks.',
    ],
    quiz: [
      {
        q: 'Put the butterfly’s life stages in order.',
        options: [
          'Egg → caterpillar → chrysalis → adult',
          'Caterpillar → egg → adult → chrysalis',
          'Egg → chrysalis → caterpillar → adult',
          'Chrysalis → egg → caterpillar → adult',
        ],
        answer: 0,
        explain: 'This dramatic makeover is called complete metamorphosis.',
      },
      {
        q: 'What happens inside the chrysalis?',
        options: [
          'The caterpillar just sleeps',
          'The caterpillar mostly dissolves and reorganizes into a butterfly',
          'It grows wings on the outside',
          'It lays its eggs',
        ],
        answer: 1,
        explain: 'The caterpillar’s body breaks down into a soup of cells that reassemble as a butterfly.',
      },
      {
        q: 'How do butterflies taste?',
        options: ['With their antennae', 'With their feet', 'With their wings', 'With their proboscis'],
        answer: 1,
        explain: 'Chemical sensors on their feet let them land on a leaf and know instantly if it is edible.',
      },
    ],
    params: [
      { key: 'speed', label: 'Cycle speed', min: 0.2, max: 3, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'next', label: 'Next stage' },
      { id: 'restart', label: 'Restart the cycle' },
    ],
    exploreHints: [
      'Tap a stage pod to jump straight to it.',
      'Watch the chrysalis — wing patterns appear inside before it opens.',
    ],
    watchFor: 'Speed the cycle up and notice: every stage is fully formed before the next begins.',
    scene: 'lifecycle',
    sceneConfig: { variant: 'butterfly' },
    example: true,
    entry: { weather: 'butterflies', mood: 'curious' },
  },
  {
    id: 'frog',
    word: 'frog',
    aliases: ['tadpole'],
    category: 'organisms',
    icon: '🐸',
    tagline: 'A swimming vegetarian that becomes a hopping hunter.',
    facts: [
      'Frog life runs through egg, tadpole, froglet and adult — a water-breathing swimmer becomes an air-breathing hopper.',
      'Tadpoles breathe with gills and eat algae; adult frogs breathe with lungs and skin, and eat insects.',
      'Frogs drink through their skin and must keep it moist to survive.',
      '“Amphibian” means “double life” — one part in water, one part on land.',
    ],
    quiz: [
      {
        q: 'How do tadpoles breathe?',
        options: ['With lungs', 'With gills', 'Through their skin only', 'They hold their breath'],
        answer: 1,
        explain: 'Gills work underwater; lungs develop later as the tadpole becomes a frog.',
      },
      {
        q: 'What does “amphibian” mean?',
        options: ['Double life', 'Cold blood', 'Long tongue', 'Green skin'],
        answer: 0,
        explain: 'Amphibians live one part of life in water and another on land.',
      },
      {
        q: 'How do frogs drink water?',
        options: ['Through their mouths', 'Through their skin', 'They never drink', 'With their tongues'],
        answer: 1,
        explain: 'Frog skin absorbs water directly — that is why frogs stay near moisture.',
      },
    ],
    params: [
      { key: 'speed', label: 'Cycle speed', min: 0.2, max: 3, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'next', label: 'Next stage' },
      { id: 'restart', label: 'Restart the cycle' },
    ],
    exploreHints: [
      'Tap a stage pod to see it up close.',
      'Notice the tail disappearing as legs grow in.',
    ],
    watchFor: 'Front legs appear last — the tail is absorbed as food for the growing froglet.',
    scene: 'lifecycle',
    sceneConfig: { variant: 'frog' },
  },
  {
    id: 'bird',
    word: 'bird',
    aliases: ['birds'],
    category: 'organisms',
    icon: '🐦',
    tagline: 'A dinosaur that learned to fly.',
    facts: [
      'Feathers are unique to birds — lightweight, waterproof and shaped for flight.',
      'Many bird bones are hollow, keeping the skeleton light enough for the air.',
      'Birds are living dinosaurs: they descend directly from a group of theropod dinosaurs.',
      'Migrating birds navigate using the stars, landmarks and even Earth’s magnetic field.',
    ],
    quiz: [
      {
        q: 'Which animals are birds’ closest living relatives?',
        options: ['Bats', 'Dinosaurs — birds are living dinosaurs', 'Flying fish', 'Dragonflies'],
        answer: 1,
        explain: 'Birds descended from feathered theropod dinosaurs; that lineage never fully went extinct.',
      },
      {
        q: 'Why are many bird bones hollow?',
        options: ['To store air for singing', 'To keep the body light for flight', 'Because they never walk', 'To float on water'],
        answer: 1,
        explain: 'A hollow but strong skeleton lowers the energy needed to stay airborne.',
      },
      {
        q: 'What helps migrating birds find their way?',
        options: [
          'Stars, landmarks and Earth’s magnetic field',
          'They follow airplanes',
          'Random luck',
          'The wind decides',
        ],
        answer: 0,
        explain: 'Birds combine several senses and cues — a built-in navigation system.',
      },
    ],
    params: [
      { key: 'energy', label: 'Flight energy', min: 0, max: 2, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'perform', label: 'Call the flock' },
      { id: 'dive', label: 'Ask for a dive' },
    ],
    exploreHints: [
      'Tap the bird to call its flock.',
      'Follow the wingbeat — the wing curves on the downstroke, lifting the body.',
    ],
    watchFor: 'More energy means faster wingbeats and wider flight loops.',
    scene: 'creature',
    sceneConfig: { variant: 'bird' },
    entry: { environment: 'dawn', mood: 'jubilant' },
  },
  {
    id: 'whale',
    word: 'whale',
    aliases: ['whales'],
    category: 'organisms',
    icon: '🐋',
    tagline: 'A mammal the size of a ship, breathing air like you.',
    facts: [
      'Whales are mammals: they breathe air, give birth to live young and nurse them with milk.',
      'The blue whale is the largest animal known to have ever lived — up to about 30 metres long.',
      'Whale songs can travel for hundreds of kilometres through the ocean.',
      'Baleen whales gulp water and filter krill through comb-like plates; toothed whales hunt fish and squid.',
    ],
    quiz: [
      {
        q: 'Why are whales classified as mammals?',
        options: [
          'They breathe air and nurse their young with milk',
          'They live in water',
          'They have fins',
          'They lay eggs',
        ],
        answer: 0,
        explain: 'Air-breathing, warm-blooded, live birth and milk — all mammal traits.',
      },
      {
        q: 'How far can whale songs travel?',
        options: ['A few metres', 'Hundreds of kilometres', 'Into space', 'Only within a pod'],
        answer: 1,
        explain: 'Sound travels extremely well in water, carrying songs across entire ocean basins.',
      },
      {
        q: 'How do baleen whales eat?',
        options: [
          'They filter krill from gulps of water',
          'They chew large fish',
          'They hunt in packs',
          'They eat seaweed',
        ],
        answer: 0,
        explain: 'Comb-like baleen plates trap tiny prey while the water drains out.',
      },
    ],
    params: [
      { key: 'energy', label: 'Swim energy', min: 0, max: 2, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'perform', label: 'Breach!' },
      { id: 'song', label: 'Listen for song' },
    ],
    exploreHints: [
      'Ask for a breach — then watch the splash.',
      'Tap the whale to hear where its song travels.',
    ],
    watchFor: 'The tail pushes up and down, not side to side — a mammal’s swim, not a fish’s.',
    scene: 'creature',
    sceneConfig: { variant: 'whale' },
  },
  {
    id: 'dinosaur',
    word: 'dinosaur',
    aliases: ['dinosaurs', 'trex', 't-rex'],
    category: 'organisms',
    icon: '🦖',
    tagline: 'Ruled the Earth for over 165 million years.',
    facts: [
      'Dinosaurs dominated land for more than 165 million years — far longer than humans have existed.',
      'An asteroid impact about 66 million years ago ended the non-bird dinosaurs.',
      'Fossils form when minerals slowly replace bone, turning remains into stone.',
      'The name “dinosaur” means “terrible lizard”, coined in 1842 — but dinosaurs were not lizards.',
    ],
    quiz: [
      {
        q: 'What ended the reign of the non-bird dinosaurs?',
        options: ['An asteroid impact ~66 million years ago', 'A flood', 'Ice age winter', 'Volcanoes only'],
        answer: 0,
        explain: 'The Chicxulub asteroid impact abruptly ended the Cretaceous period.',
      },
      {
        q: 'How long did dinosaurs dominate the land?',
        options: ['A few thousand years', 'About 165 million years', 'Exactly 100 years', 'One ice age'],
        answer: 1,
        explain: 'Over 165 million years — modern humans have been around less than 1 million.',
      },
      {
        q: 'What does “dinosaur” mean?',
        options: ['Terrible lizard', 'Ancient bird', 'Giant tooth', 'Thunder beast'],
        answer: 0,
        explain: 'Richard Owen coined it in 1842 — though dinosaurs were not true lizards.',
      },
    ],
    params: [
      { key: 'energy', label: 'Stride energy', min: 0, max: 2, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'perform', label: 'Hear a roar' },
      { id: 'stampede', label: 'Stampede' },
    ],
    exploreHints: [
      'Tap the dinosaur for a roar.',
      'Watch the walk: heavy steps shake dust from the ground.',
    ],
    watchFor: 'The tail swings opposite the legs to balance a heavy head.',
    scene: 'creature',
    sceneConfig: { variant: 'dinosaur' },
  },
]
