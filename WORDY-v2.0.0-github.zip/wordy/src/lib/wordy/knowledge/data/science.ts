import type { ConceptDef } from '../types'

/* ==========================================================================
   Science — the rules the universe runs on.
   (orbital, atom, field-magnet templates)
   ========================================================================== */

export const scienceConcepts: ConceptDef[] = [
  {
    id: 'gravity',
    word: 'gravity',
    aliases: ['gravitation'],
    category: 'science',
    icon: '🪐',
    tagline: 'Every object pulls on every other object.',
    facts: [
      'Gravity is the mutual attraction of all masses — the more mass, the stronger the pull.',
      'Earth’s gravity accelerates falling objects at about 9.8 metres per second, every second.',
      'An orbit is really falling: the Moon keeps missing Earth because it moves sideways fast enough.',
      'Astronauts float on the space station not because gravity is gone, but because everything falls together.',
    ],
    quiz: [
      {
        q: 'What makes gravity stronger?',
        options: ['More mass', 'Brighter colour', 'Faster spinning', 'Closeness to the sun only'],
        answer: 0,
        explain: 'Mass and distance set the strength — every object with mass pulls on every other.',
      },
      {
        q: 'What is an orbit, really?',
        options: [
          'Falling around a planet while moving sideways fast enough',
          'Floating without forces',
          'Being held up by air',
          'A magnetic loop',
        ],
        answer: 0,
        explain: 'Newton’s insight: orbiting is continuous free-fall with enough sideways speed to keep missing.',
      },
      {
        q: 'Why do space-station astronauts float?',
        options: [
          'They are in continuous free fall with the station',
          'There is no gravity up there',
          'They wear magnetic boots',
          'Space is a vacuum',
        ],
        answer: 0,
        explain: 'The station and everything in it fall together around Earth — that shared fall feels like weightlessness.',
      },
    ],
    params: [
      { key: 'mass', label: 'Star mass', min: 0.4, max: 2.5, step: 0.1, def: 1, unit: '×' },
      { key: 'speed', label: 'Time flow', min: 0.2, max: 3, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'addplanet', label: 'Add a planet' },
      { id: 'clearplanets', label: 'Clear the sky' },
    ],
    exploreHints: [
      'Tap empty space to launch a new planet.',
      'Tap the star to see what holds the system together.',
    ],
    watchFor: 'Heavier star, faster orbits — the same law that runs the real solar system.',
    scene: 'orbital',
    sceneConfig: { variant: 'gravity' },
    example: true,
    entry: { environment: 'space', mood: 'curious' },
  },
  {
    id: 'solar system',
    word: 'solar system',
    aliases: ['planets', 'sun'],
    category: 'science',
    icon: '☀️',
    tagline: 'The Sun and everything bound to it by gravity.',
    facts: [
      'The Sun holds about 99.8% of all the mass in the solar system.',
      'Eight planets orbit the Sun: four rocky inner worlds and four giants of gas and ice.',
      'Sunlight takes about eight minutes and twenty seconds to reach Earth.',
      'Everything in the solar system — planets, moons, asteroids, comets — orbits the Sun in the same direction.',
    ],
    quiz: [
      {
        q: 'How much of the solar system’s mass is the Sun?',
        options: ['About half', 'About 99.8%', 'About 10%', '75%'],
        answer: 1,
        explain: 'The planets are a rounding error — the Sun utterly dominates.',
      },
      {
        q: 'How long does sunlight take to reach Earth?',
        options: ['8 seconds', 'About 8 minutes', '1 hour', 'Instantly'],
        answer: 1,
        explain: 'Light travels ~300,000 km/s but the Sun is 150 million km away — about 8 min 20 s.',
      },
      {
        q: 'Which statement is true?',
        options: [
          'All planets orbit the Sun in the same direction',
          'Each planet orbits a different way',
          'Only Earth orbits the Sun',
          'The planets orbit the Moon',
        ],
        answer: 0,
        explain: 'One shared direction — a fingerprint of how the system formed from one spinning disk.',
      },
    ],
    params: [
      { key: 'mass', label: 'Sun mass', min: 0.6, max: 2, step: 0.1, def: 1, unit: '×' },
      { key: 'speed', label: 'Time flow', min: 0.2, max: 3, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'addplanet', label: 'Add a planet' },
      { id: 'clearplanets', label: 'Clear the sky' },
    ],
    exploreHints: [
      'Tap a planet for its story.',
      'Add planets and watch the spacing — no two orbits collide.',
    ],
    watchFor: 'Inner planets complete a year far faster than the outer giants.',
    scene: 'orbital',
    sceneConfig: { variant: 'solar' },
    entry: { environment: 'space', mood: 'curious' },
  },
  {
    id: 'black hole',
    word: 'black hole',
    aliases: ['blackhole', 'event horizon'],
    category: 'science',
    icon: '🕳️',
    tagline: 'Where gravity wins against light itself.',
    facts: [
      'A black hole is a region where gravity is so strong that nothing — not even light — can escape.',
      'Its boundary is the event horizon: the point of no return.',
      'Stellar black holes form when massive stars collapse at the end of their lives.',
      'A giant black hole called Sagittarius A* sits at the centre of our Milky Way.',
    ],
    quiz: [
      {
        q: 'What can escape from inside a black hole’s event horizon?',
        options: ['Nothing, not even light', 'Only light', 'Radio waves', 'Spacecraft'],
        answer: 0,
        explain: 'The event horizon marks where escape velocity exceeds the speed of light.',
      },
      {
        q: 'How do stellar black holes form?',
        options: [
          'Massive stars collapse at the end of their lives',
          'Planets crash together',
          'The Moon shrinks',
          'Dark clouds condense',
        ],
        answer: 0,
        explain: 'After a supernova, the core can collapse into a black hole.',
      },
      {
        q: 'What is Sagittarius A*?',
        options: [
          'The giant black hole at the centre of the Milky Way',
          'A nearby star',
          'A comet',
          'A telescope',
        ],
        answer: 0,
        explain: 'Stars at our galaxy’s heart orbit an invisible mass millions of times the Sun’s.',
      },
    ],
    params: [
      { key: 'mass', label: 'Mass', min: 0.5, max: 2.5, step: 0.1, def: 1.2, unit: '×' },
      { key: 'speed', label: 'Time flow', min: 0.2, max: 3, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'feed', label: 'Feed it a star' },
      { id: 'clearplanets', label: 'Quiet the disk' },
    ],
    exploreHints: [
      'Tap the dark core to feed it — watch the disk flare.',
      'Notice the glowing ring: light orbiting close to the horizon.',
    ],
    watchFor: 'More mass widens the event horizon — the dark heart grows.',
    scene: 'orbital',
    sceneConfig: { variant: 'blackhole' },
    entry: { environment: 'galaxy', mood: 'tense' },
  },
  {
    id: 'atom',
    word: 'atom',
    aliases: ['atoms', 'electron', 'nucleus'],
    category: 'science',
    icon: '⚛️',
    tagline: 'The smallest piece of an element — and it is mostly space.',
    facts: [
      'An atom has a nucleus of protons and neutrons, with electrons around it.',
      'The number of protons defines the element — hydrogen has one, helium two.',
      'Atoms are mostly empty space: if the nucleus were a marble, the atom would span a stadium.',
      'About 118 elements are known — everything around you is built from them.',
    ],
    quiz: [
      {
        q: 'What is inside an atom’s nucleus?',
        options: ['Protons and neutrons', 'Electrons only', 'Molecules', 'Light'],
        answer: 0,
        explain: 'Protons (positive) and neutrons (neutral) cluster in the centre; electrons orbit far outside.',
      },
      {
        q: 'What defines an element?',
        options: [
          'The number of protons in its atoms',
          'Its colour',
          'The number of electrons it shares',
          'Its temperature',
        ],
        answer: 0,
        explain: 'Change the proton count and you have a different element entirely.',
      },
      {
        q: 'Atoms are mostly…',
        options: ['Empty space', 'Solid rock', 'Water', 'Fire'],
        answer: 0,
        explain: 'The nucleus is tiny compared with the electron cloud — matter is mostly space.',
      },
    ],
    params: [
      { key: 'energy', label: 'Electron energy', min: 0.5, max: 3, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'excite', label: 'Excite the atom' },
      { id: 'cool', label: 'Cool it down' },
    ],
    exploreHints: [
      'Tap the nucleus to excite the electrons.',
      'Watch closely when an electron jumps back — that flash is a photon of light.',
    ],
    watchFor: 'Higher energy makes electrons jump to outer shells, then snap back with a flash.',
    scene: 'atom',
    sceneConfig: { variant: 'atom' },
  },
  {
    id: 'electricity',
    word: 'electricity',
    aliases: ['electric', 'current', 'circuit'],
    category: 'science',
    icon: '⚡',
    tagline: 'A river of electrons, doing your work.',
    facts: [
      'Electric current is the flow of tiny negatively-charged electrons through a conductor.',
      'A circuit must form a complete loop — a gap anywhere stops the flow.',
      'Lightning is a giant static discharge, equalising charge between cloud and ground.',
      'Electricity is measured in volts (the push) and amperes (the flow).',
    ],
    quiz: [
      {
        q: 'What is electric current?',
        options: [
          'A flow of electrons through a conductor',
          'Air moving in wires',
          'Light trapped in metal',
          'Heat in a cable',
        ],
        answer: 0,
        explain: 'Electrons drift along the conductor — billions of them, pushed by voltage.',
      },
      {
        q: 'What happens if a circuit has a gap?',
        options: ['The current stops', 'Nothing changes', 'It speeds up', 'It glows brighter'],
        answer: 0,
        explain: 'A complete loop is required — that is exactly what a switch opens and closes.',
      },
      {
        q: 'What is lightning?',
        options: [
          'A giant static discharge between cloud and ground',
          'Rain glowing',
          'The sun reflected on clouds',
          'Hot wind',
        ],
        answer: 0,
        explain: 'Charge builds in the cloud until the air itself breaks down and conducts.',
      },
    ],
    params: [
      { key: 'current', label: 'Current', min: 0, max: 2, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'toggle', label: 'Open / close the switch' },
      { id: 'surge', label: 'Surge!' },
    ],
    exploreHints: [
      'Tap the switch to break the loop — the lamp goes dark.',
      'Follow one electron all the way around; it comes back to where it started.',
    ],
    watchFor: 'The lamp’s glow tracks the current — brightness is the flow made visible.',
    scene: 'atom',
    sceneConfig: { variant: 'circuit' },
    entry: { element: 'electric', mood: 'energetic' },
  },
  {
    id: 'magnet',
    word: 'magnet',
    aliases: ['magnets', 'magnetism', 'compass', 'magnetic field'],
    category: 'science',
    icon: '🧲',
    tagline: 'An invisible field you can always feel.',
    facts: [
      'Every magnet has two poles — north and south — and like poles repel while opposites attract.',
      'Iron filings sprinkled near a magnet trace the invisible field lines curving pole to pole.',
      'Earth itself is a giant magnet: its churning iron core generates the field a compass follows.',
      'A compass needle points to magnetic north, which sits apart from the geographic North Pole.',
    ],
    quiz: [
      {
        q: 'What happens when two north poles face each other?',
        options: ['They repel', 'They attract', 'Nothing', 'They melt'],
        answer: 0,
        explain: 'Like poles push apart; opposite poles pull together.',
      },
      {
        q: 'Why does a compass work?',
        options: [
          'Earth is a giant magnet and the needle aligns with its field',
          'It points to the sun',
          'Wind turns the needle',
          'It remembers north',
        ],
        answer: 0,
        explain: 'The churning liquid-iron core generates a planet-wide magnetic field.',
      },
      {
        q: 'What do iron filings reveal?',
        options: [
          'The shape of the invisible magnetic field lines',
          'The magnet’s temperature',
          'Its age',
          'The number of poles',
        ],
        answer: 0,
        explain: 'Each filing turns along the local field direction — thousands of tiny compasses.',
      },
    ],
    params: [
      { key: 'intensity', label: 'Field strength', min: 0.3, max: 2, step: 0.1, def: 1, unit: '×' },
    ],
    actions: [
      { id: 'flip', label: 'Flip the poles' },
      { id: 'shake', label: 'Sprinkle filings' },
    ],
    exploreHints: [
      'Tap the magnet to flip its poles — watch every filing swing around.',
      'Move your pointer through the field: the filings lean toward it.',
    ],
    watchFor: 'Stronger fields pull the filings into tighter, denser arcs near the poles.',
    scene: 'field',
    sceneConfig: { variant: 'magnet' },
    entry: { attract: 'attract', action: 'sparkburst', color: '#94a3b8', mood: 'curious' },
  },
]
