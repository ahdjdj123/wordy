/* ==========================================================================
   WORDY — Core Types
   The command system is declarative: every command maps to an EffectSpec
   that the WorldEngine knows how to apply. Adding a command never requires
   touching the UI or the engine — only this registry.
   ========================================================================== */

import type { LearningCategory } from './knowledge/types'

export type Category =
  | 'movement'
  | 'physics'
  | 'elements'
  | 'nature'
  | 'visual'
  | 'environment'
  | 'objects'
  | 'special'

export const CATEGORY_META: Record<Category, { label: string; blurb: string }> = {
  movement: { label: 'Movement', blurb: 'How the core travels through the world.' },
  physics: { label: 'Physics', blurb: 'Bend the rules that hold everything together.' },
  elements: { label: 'Elements', blurb: 'Raw forces you can summon and combine.' },
  nature: { label: 'Nature', blurb: 'Weather, seasons and living things.' },
  visual: { label: 'Visual', blurb: 'Light, color and afterimages.' },
  environment: { label: 'Environment', blurb: 'Whole worlds to shift into.' },
  objects: { label: 'Objects', blurb: 'Transform the core into something new.' },
  special: { label: 'Special', blurb: 'Experimental — and a few secrets.' },
}

export type SoundFamily =
  | 'whoosh' | 'impact' | 'shimmer' | 'zap' | 'freeze' | 'portal'
  | 'rain' | 'magic' | 'wind' | 'water' | 'none'

/** Orb motion modes — composable state channels */
export type MotionMode =
  | 'idle' | 'fly' | 'floor' | 'orbit' | 'figure8' | 'zigzag'
  | 'spiral' | 'drift' | 'bounce' | 'sway' | 'float'
  | 'run' | 'walk' | 'go' | 'stop' | 'hover-wait' | 'climb' | 'guide'

export type OrbShape =
  | 'orb' | 'cube' | 'star' | 'ring' | 'crystal' | 'heart' | 'diamond'
  | 'planet' | 'rocket' | 'ball' | 'moon' | 'comet' | 'asteroid' | 'flower'
  | 'portal' | 'eye' | 'ghost' | 'balloon'

export type TrailKind =
  | 'rainbow' | 'sparkle' | 'gold' | 'fire' | 'ice' | 'comet'
  | 'heart' | 'star' | 'echo' | 'bubble' | 'musical' | null

export type ElementKind =
  | 'fire' | 'water' | 'ice' | 'wind' | 'earth' | 'electric'
  | 'lava' | 'smoke' | 'steam' | 'void'

export type WeatherKind =
  | 'rain' | 'snow' | 'storm' | 'fog' | 'leaves' | 'petals'
  | 'bubbles' | 'embers' | 'starfall' | 'confetti' | 'fireflies'
  | 'hearts' | 'sparks' | 'dust' | 'clouds' | 'matrix' | 'butterflies' | null

export type EnvironmentKind =
  | 'space' | 'galaxy' | 'night' | 'midnight' | 'sunset' | 'dawn'
  | 'ocean' | 'forest' | 'desert' | 'winter' | 'arctic' | 'storm'
  | 'void' | 'dream' | 'volcano' | 'jungle' | 'neon' | 'aurora'

/** One-shot actions the engine performs immediately */
export type ActionName =
  | 'explode' | 'implode' | 'shockwave' | 'flash' | 'ripple'
  | 'lightning' | 'zoompulse' | 'shake' | 'sparkburst' | 'confettiburst'
  | 'heartburst' | 'starburst' | 'meteor' | 'cometfly' | 'supernova'
  | 'bigbang' | 'portalopen' | 'blackhole' | 'ringwave' | 'shatter'
  | 'frostburst' | 'splash' | 'greet' | 'toss' | 'bloom' | 'orbiters'
  | 'satellite' | 'squish' | 'wobble' | 'clone' | 'mirrorworld'
  | 'jump' | 'dash' | 'dive' | 'teleport' | 'boomerang' | 'swing'
  | 'fireworks' | 'ufo' | 'galaxyburst' | 'featherfall' | 'summon'
  | 'boom' | 'flip' | 'growtree' | 'flock' | 'sing' | 'sleep' | 'wake'
  | 'speak' | 'strobe' | 'melt'

/** v1.2 — the sphere's emotional weather. Always drifts back to neutral. */
export type MoodKind =
  | 'energetic' | 'calm' | 'tense' | 'curious' | 'jubilant' | 'sleepy'

/** Declarative description of what a command does to the world */
export interface EffectSpec {
  motion?: MotionMode
  spin?: number            // radians/sec target
  scale?: number           // absolute target scale (1 = default)
  scaleMul?: number        // multiply current scale
  shape?: OrbShape
  color?: string           // hex tint for the core
  glow?: number            // 0..2 glow intensity target
  element?: ElementKind | null
  clearElements?: boolean
  weather?: WeatherKind
  clearWeather?: boolean
  environment?: EnvironmentKind
  trail?: TrailKind
  action?: ActionName | ActionName[]
  timeScale?: number
  gravity?: number
  wind?: number
  attract?: 'attract' | 'repel' | null
  mirror?: boolean
  invert?: boolean
  dim?: number
  sound?: SoundFamily
  /** persistence: some states naturally decay back to idle */
  decay?: boolean
  /** voice: the words the sphere should speak (speak/say/talk) */
  text?: string
  /** a quiet ring of light that stays above the core */
  halo?: boolean
  /** rhythmic glow, like a heartbeat */
  heartbeat?: boolean
  /** chrome sheen sweeping across the surface */
  chrome?: boolean
  /** v1.2 — emotional reaction of the sphere (auto-inferred from the command family when unset) */
  mood?: MoodKind
  /** v1.2 — overall opacity of the core (fade / ghost). 1 = solid. */
  alpha?: number
}

export const WORDY_VERSION = '2.0.0'
export const WORDY_CODENAME = 'The Learning Universe'

export interface CommandDef {
  name: string
  aliases: string[]
  category: Category
  description: string
  effect: EffectSpec
  related?: string[]
  hidden?: boolean      // secret — excluded from Library until discovered
  gold?: boolean        // gold-trimmed card (rare discoveries)
  demo?: string         // key for the Library live mini preview
  /** commands that accept free text after the word (speak, say…) */
  takesText?: boolean
}

/* ---- sphere appearance ---- */

export type SphereStyle = 'energy' | 'crystal' | 'galaxy' | 'liquid' | 'pixel'
export type SphereDimension = '3d' | '2d'

export interface Suggestion {
  word: string
  category: Category | LearningCategory
  /** v2.0 — marks a concept-world suggestion (🪐 chip) */
  isWorld?: boolean
}

/* ---- discovery ---- */

export interface ComboDef {
  id: string
  name: string
  recipe: string              // "fire + rain"
  description: string
}

export interface SecretHint {
  name: string                // command name (hidden)
  hint: string                // playful nudge shown in Surprises
}
