import type { SoundFamily } from './types'

/* ==========================================================================
   WORDY sound — everything synthesized live with WebAudio.
   Subtle, optional, never annoying. Families have personalities:
   movement → soft whoosh · boom → low impact · rain → atmospheric
   magic → soft shimmer · portal → deep ambient tone
   Plus: master volume, a deep space ambience loop, and a gentle
   speech voice for when the sphere has something to say.
   ========================================================================== */

class SoundEngine {
  private ctx: AudioContext | null = null
  private master: GainNode | null = null
  private rainNode: { src: AudioBufferSourceNode; gain: GainNode } | null = null
  private spaceNode: { osc: OscillatorNode; osc2: OscillatorNode; gain: GainNode } | null = null
  private noiseBuffer: AudioBuffer | null = null

  enabled = true        // master: anything can play at all
  masterVolume = 0.7    // 0..1
  sfxEnabled = true     // command sounds
  ambientEnabled = true // rain + space loops
  voiceEnabled = true   // speech synthesis

  private ensure(): boolean {
    if (typeof window === 'undefined') return false
    if (!this.ctx) {
      const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
      if (!AC) return false
      this.ctx = new AC()
      this.master = this.ctx.createGain()
      this.master.gain.value = 0.2 * this.masterVolume
      this.master.connect(this.ctx.destination)
    }
    if (this.ctx.state === 'suspended') void this.ctx.resume()
    return !!this.ctx && !!this.master
  }

  private noise(): AudioBuffer {
    if (!this.noiseBuffer && this.ctx) {
      const len = this.ctx.sampleRate * 2
      this.noiseBuffer = this.ctx.createBuffer(1, len, this.ctx.sampleRate)
      const data = this.noiseBuffer.getChannelData(0)
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1
    }
    return this.noiseBuffer!
  }

  /* ---------------- settings (applied instantly) ---------------- */

  setVolume(v: number) {
    this.masterVolume = Math.max(0, Math.min(1, v))
    this.enabled = this.masterVolume > 0.001
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(0.2 * this.masterVolume, this.ctx.currentTime, 0.05)
    }
    if (!this.enabled) {
      this.setRainAmbience(false)
      this.setSpaceAmbience(false)
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        try { window.speechSynthesis.cancel() } catch { /* noop */ }
      }
    }
  }

  setSfx(on: boolean) { this.sfxEnabled = on }
  setAmbient(on: boolean) {
    this.ambientEnabled = on
    if (!on) {
      this.setRainAmbience(false)
      this.setSpaceAmbience(false)
    }
  }
  setVoice(on: boolean) {
    this.voiceEnabled = on
    if (!on && typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try { window.speechSynthesis.cancel() } catch { /* noop */ }
    }
  }

  /** legacy single switch — maps to master */
  setEnabled(v: boolean) {
    this.setVolume(v ? Math.max(0.35, this.masterVolume) : 0)
  }

  /* ---------------- one-shot families ---------------- */

  play(family: SoundFamily) {
    if (!this.enabled || !this.sfxEnabled || family === 'none') return
    if (!this.ensure() || !this.ctx || !this.master) return
    const ctx = this.ctx
    const t = ctx.currentTime

    switch (family) {
      case 'whoosh': {
        const src = ctx.createBufferSource()
        src.buffer = this.noise()
        const filter = ctx.createBiquadFilter()
        filter.type = 'bandpass'
        filter.frequency.setValueAtTime(280, t)
        filter.frequency.exponentialRampToValueAtTime(1400, t + 0.22)
        filter.Q.value = 1.4
        const gain = ctx.createGain()
        gain.gain.setValueAtTime(0, t)
        gain.gain.linearRampToValueAtTime(0.5, t + 0.06)
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.34)
        src.connect(filter).connect(gain).connect(this.master)
        src.start(t)
        src.stop(t + 0.4)
        break
      }
      case 'impact': {
        const osc = ctx.createOscillator()
        osc.type = 'sine'
        osc.frequency.setValueAtTime(120, t)
        osc.frequency.exponentialRampToValueAtTime(36, t + 0.4)
        const gain = ctx.createGain()
        gain.gain.setValueAtTime(0.9, t)
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.5)
        osc.connect(gain).connect(this.master)
        osc.start(t)
        osc.stop(t + 0.55)
        // noise thump
        const src = ctx.createBufferSource()
        src.buffer = this.noise()
        const f2 = ctx.createBiquadFilter()
        f2.type = 'lowpass'
        f2.frequency.value = 420
        const g2 = ctx.createGain()
        g2.gain.setValueAtTime(0.55, t)
        g2.gain.exponentialRampToValueAtTime(0.001, t + 0.3)
        src.connect(f2).connect(g2).connect(this.master)
        src.start(t)
        src.stop(t + 0.32)
        break
      }
      case 'shimmer':
      case 'magic': {
        const notes = family === 'magic' ? [523.25, 659.25, 783.99, 1046.5] : [1046.5, 1318.5, 1568]
        notes.forEach((freq, i) => {
          const osc = this.ctx!.createOscillator()
          osc.type = 'sine'
          osc.frequency.value = freq
          const gain = this.ctx!.createGain()
          const start = t + i * 0.05
          gain.gain.setValueAtTime(0, start)
          gain.gain.linearRampToValueAtTime(0.16, start + 0.03)
          gain.gain.exponentialRampToValueAtTime(0.001, start + 0.6)
          osc.connect(gain).connect(this.master!)
          osc.start(start)
          osc.stop(start + 0.65)
        })
        break
      }
      case 'zap': {
        const osc = ctx.createOscillator()
        osc.type = 'sawtooth'
        osc.frequency.setValueAtTime(1600, t)
        osc.frequency.exponentialRampToValueAtTime(120, t + 0.16)
        const gain = ctx.createGain()
        gain.gain.setValueAtTime(0.3, t)
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.2)
        osc.connect(gain).connect(this.master)
        osc.start(t)
        osc.stop(t + 0.22)
        break
      }
      case 'freeze': {
        [1318.5, 1568, 2093].forEach((freq, i) => {
          const osc = this.ctx!.createOscillator()
          osc.type = 'triangle'
          osc.frequency.value = freq
          const gain = this.ctx!.createGain()
          const start = t + i * 0.07
          gain.gain.setValueAtTime(0, start)
          gain.gain.linearRampToValueAtTime(0.12, start + 0.02)
          gain.gain.exponentialRampToValueAtTime(0.001, start + 0.5)
          osc.connect(gain).connect(this.master!)
          osc.start(start)
          osc.stop(start + 0.55)
        })
        break
      }
      case 'portal': {
        const osc = ctx.createOscillator()
        osc.type = 'sine'
        osc.frequency.setValueAtTime(60, t)
        osc.frequency.linearRampToValueAtTime(180, t + 0.9)
        const osc2 = ctx.createOscillator()
        osc2.type = 'sine'
        osc2.frequency.setValueAtTime(90.5, t)
        osc2.frequency.linearRampToValueAtTime(271.5, t + 0.9)
        const gain = ctx.createGain()
        gain.gain.setValueAtTime(0, t)
        gain.gain.linearRampToValueAtTime(0.3, t + 0.25)
        gain.gain.linearRampToValueAtTime(0.001, t + 1.1)
        osc.connect(gain)
        osc2.connect(gain)
        gain.connect(this.master)
        osc.start(t)
        osc2.start(t)
        osc.stop(t + 1.2)
        osc2.stop(t + 1.2)
        break
      }
      case 'rain':
      case 'wind':
      case 'water': {
        const src = ctx.createBufferSource()
        src.buffer = this.noise()
        const filter = ctx.createBiquadFilter()
        filter.type = family === 'water' ? 'lowpass' : 'bandpass'
        filter.frequency.value = family === 'water' ? 700 : 1800
        filter.Q.value = 1
        const gain = ctx.createGain()
        gain.gain.setValueAtTime(0, t)
        gain.gain.linearRampToValueAtTime(0.16, t + 0.1)
        gain.gain.exponentialRampToValueAtTime(0.001, t + 1.4)
        src.connect(filter).connect(gain).connect(this.master)
        src.start(t)
        src.stop(t + 1.5)
        break
      }
    }
  }

  /* ---------------- continuous ambience ---------------- */

  /* rain while stormy weather is active */
  setRainAmbience(on: boolean) {
    if (!this.enabled || !this.ambientEnabled || !this.ensure() || !this.ctx || !this.master) {
      if (!on && this.rainNode) {
        try { this.rainNode.src.stop() } catch { /* already stopped */ }
        this.rainNode = null
      }
      return
    }
    if (on && !this.rainNode) {
      const src = this.ctx.createBufferSource()
      src.buffer = this.noise()
      src.loop = true
      const filter = this.ctx.createBiquadFilter()
      filter.type = 'bandpass'
      filter.frequency.value = 2400
      filter.Q.value = 0.4
      const gain = this.ctx.createGain()
      gain.gain.setValueAtTime(0, this.ctx.currentTime)
      gain.gain.linearRampToValueAtTime(0.05, this.ctx.currentTime + 1.5)
      src.connect(filter).connect(gain).connect(this.master)
      src.start()
      this.rainNode = { src, gain }
    } else if (!on && this.rainNode) {
      const node = this.rainNode
      this.rainNode = null
      const ct = this.ctx.currentTime
      node.gain.gain.cancelScheduledValues(ct)
      node.gain.gain.setValueAtTime(node.gain.gain.value, ct)
      node.gain.gain.linearRampToValueAtTime(0, ct + 1.2)
      try { node.src.stop(ct + 1.3) } catch { /* noop */ }
    }
  }

  /* deep space drone — two detuned sines breathing very slowly */
  setSpaceAmbience(on: boolean) {
    if (!this.enabled || !this.ambientEnabled || !this.ensure() || !this.ctx || !this.master) {
      if (!on && this.spaceNode) {
        try {
          this.spaceNode.osc.stop()
          this.spaceNode.osc2.stop()
        } catch { /* already stopped */ }
        this.spaceNode = null
      }
      return
    }
    if (on && !this.spaceNode) {
      const osc = this.ctx.createOscillator()
      osc.type = 'sine'
      osc.frequency.value = 55
      const osc2 = this.ctx.createOscillator()
      osc2.type = 'sine'
      osc2.frequency.value = 82.7
      const lp = this.ctx.createBiquadFilter()
      lp.type = 'lowpass'
      lp.frequency.value = 220
      const gain = this.ctx.createGain()
      const ct = this.ctx.currentTime
      gain.gain.setValueAtTime(0, ct)
      gain.gain.linearRampToValueAtTime(0.035, ct + 2.5)
      // slow breathing
      const lfo = this.ctx.createOscillator()
      lfo.frequency.value = 0.07
      const lfoGain = this.ctx.createGain()
      lfoGain.gain.value = 0.012
      lfo.connect(lfoGain).connect(gain.gain)
      lfo.start()
      osc.connect(lp)
      osc2.connect(lp)
      lp.connect(gain).connect(this.master)
      osc.start()
      osc2.start()
      this.spaceNode = { osc, osc2, gain }
    } else if (!on && this.spaceNode) {
      const node = this.spaceNode
      this.spaceNode = null
      const ct = this.ctx.currentTime
      node.gain.gain.cancelScheduledValues(ct)
      node.gain.gain.setValueAtTime(node.gain.gain.value, ct)
      node.gain.gain.linearRampToValueAtTime(0, ct + 1)
      try {
        node.osc.stop(ct + 1.1)
        node.osc2.stop(ct + 1.1)
      } catch { /* noop */ }
    }
  }

  /* ---------------- speech — the sphere's own voice ---------------- */

  speak(text: string) {
    if (!this.enabled || !this.voiceEnabled || !this.masterVolume) return
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return
    try {
      const synth = window.speechSynthesis
      const utter = new SpeechSynthesisUtterance(text)
      utter.rate = 0.98
      utter.pitch = 1.15
      utter.volume = Math.min(1, this.masterVolume)
      synth.cancel()
      synth.speak(utter)
    } catch {
      /* voice is a luxury, never a requirement */
    }
  }
}

export const sound = new SoundEngine()
