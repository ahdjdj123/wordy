'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  X, Compass, SlidersHorizontal, Trophy, Brain, RotateCcw,
  Bookmark, Check, Lightbulb, Sparkles,
} from 'lucide-react'
import { LEARNING_CATEGORY_META } from '@/lib/wordy/knowledge'
import type { ConceptDef } from '@/lib/wordy/knowledge/types'
import { useWordy, emptyProgress } from '@/lib/wordy/store'
import { useWordyUI } from './wordy-context'
import type { WorldMode } from './wordy-context'
import { CONCEPTS } from '@/lib/wordy/knowledge'
import { Slider } from '@/components/ui/slider'

/* ==========================================================================
   WorldStage — the learning UI that appears when a concept world is open.
   Four modes: EXPLORE · EXPERIMENT · CHALLENGE · REMEMBER.
   ========================================================================== */

const MODES: Array<{ id: WorldMode; label: string; icon: typeof Compass }> = [
  { id: 'explore', label: 'Explore', icon: Compass },
  { id: 'experiment', label: 'Experiment', icon: SlidersHorizontal },
  { id: 'challenge', label: 'Challenge', icon: Trophy },
  { id: 'remember', label: 'Remember', icon: Brain },
]

function shuffle<T>(arr: T[], seed = Math.random()): T[] {
  const out = [...arr]
  let s = Math.floor(seed * 100000) + 7
  const rnd = () => {
    s = (s * 9301 + 49297) % 233280
    return s / 233280
  }
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1))
    ;[out[i], out[j]] = [out[j], out[i]]
  }
  return out
}

/* ---------------- Explore ---------------- */

function ExplorePanel({ concept, factIndex, onAction }: {
  concept: ConceptDef
  factIndex: number
  onAction: (id: string) => void
}) {
  const [fact, setFact] = useState(0)
  const factSeedRef = useRef(0)

  // rotate a fact every 9 s — unless the world just told us one
  useEffect(() => {
    setFact(factIndex)
  }, [factIndex])

  useEffect(() => {
    const iv = setInterval(() => {
      factSeedRef.current += 1
      setFact((f) => (f + 1) % concept.facts.length)
    }, 9000)
    return () => clearInterval(iv)
  }, [concept.facts.length])

  return (
    <div className="flex flex-col gap-4">
      {/* contextual actions */}
      <div>
        <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.26em] text-white/30">
          what you can do
        </p>
        <div className="flex flex-wrap gap-2">
          {concept.actions.map((a) => (
            <button
              key={a.id}
              onClick={() => onAction(a.id)}
              className="flex items-center gap-1.5 rounded-full border border-violet-400/25 bg-violet-500/12 px-3.5 py-2 text-xs font-medium text-violet-100 transition-all hover:border-violet-400/50 hover:bg-violet-500/22 active:scale-95"
            >
              <Sparkles size={12} className="text-violet-300" />
              {a.label}
            </button>
          ))}
        </div>
        <ul className="mt-3 space-y-1.5">
          {concept.exploreHints.map((h) => (
            <li key={h} className="flex items-start gap-2 text-xs leading-relaxed text-white/50">
              <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-violet-300/60" />
              {h}
            </li>
          ))}
        </ul>
      </div>

      {/* rotating fact */}
      <div className="rounded-2xl border border-amber-300/15 bg-amber-400/[0.06] p-4">
        <p className="mb-1.5 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.26em] text-amber-200/70">
          <Lightbulb size={11} /> did you know
        </p>
        <AnimatePresence mode="wait">
          <motion.p
            key={fact}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.3 }}
            className="text-[13px] leading-relaxed text-white/80"
          >
            {concept.facts[fact]}
          </motion.p>
        </AnimatePresence>
        <div className="mt-3 flex gap-1.5">
          {concept.facts.map((_, i) => (
            <button
              key={i}
              onClick={() => setFact(i)}
              aria-label={`Fact ${i + 1}`}
              className={`h-1.5 rounded-full transition-all ${
                i === fact ? 'w-5 bg-amber-300/80' : 'w-1.5 bg-white/15 hover:bg-white/30'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  )
}

/* ---------------- Experiment ---------------- */

function ExperimentPanel({ concept, params, onParam, onAction }: {
  concept: ConceptDef
  params: Record<string, number>
  onParam: (key: string, value: number) => void
  onAction: (id: string) => void
}) {
  return (
    <div className="flex flex-col gap-4">
      <p className="text-xs leading-relaxed text-white/55">
        Turn the dials and watch the world answer.{' '}
        {concept.watchFor && <span className="text-white/75">{concept.watchFor}</span>}
      </p>
      {concept.params.map((p) => (
        <div key={p.key} className="rounded-2xl border border-white/8 bg-white/[0.03] p-4">
          <div className="mb-3 flex items-center justify-between">
            <span className="text-xs font-medium text-white/80">{p.label}</span>
            <span className="rounded-full bg-cyan-400/10 px-2 py-0.5 font-display text-[11px] text-cyan-200">
              {params[p.key] !== undefined ? params[p.key].toFixed(1) : p.def.toFixed(1)}
              {p.unit ?? ''}
            </span>
          </div>
          <Slider
            value={[params[p.key] ?? p.def]}
            min={p.min}
            max={p.max}
            step={p.step}
            onValueChange={(v) => onParam(p.key, v[0])}
            aria-label={p.label}
          />
          <div className="mt-1.5 flex justify-between text-[10px] text-white/25">
            <span>{p.min}{p.unit ?? ''}</span>
            <span>{p.max}{p.unit ?? ''}</span>
          </div>
        </div>
      ))}
      {/* actions still reachable while experimenting */}
      <div className="flex flex-wrap gap-2">
        {concept.actions.map((a) => (
          <button
            key={a.id}
            onClick={() => onAction(a.id)}
            className="rounded-full border border-cyan-400/25 bg-cyan-400/10 px-3.5 py-2 text-xs font-medium text-cyan-100 transition-all hover:border-cyan-400/50 hover:bg-cyan-400/20 active:scale-95"
          >
            {a.label}
          </button>
        ))}
        <button
          onClick={() => concept.params.forEach((p) => onParam(p.key, p.def))}
          className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3.5 py-2 text-xs text-white/60 transition-all hover:text-white active:scale-95"
        >
          <RotateCcw size={12} />
          Reset
        </button>
      </div>
    </div>
  )
}

/* ---------------- Challenge ---------------- */

function ChallengePanel({ concept }: { concept: ConceptDef }) {
  const [round, setRound] = useState(0)
  const [qIndex, setQIndex] = useState(0)
  const [picked, setPicked] = useState<number | null>(null)
  const [score, setScore] = useState(0)
  const [done, setDone] = useState(false)
  const { markConcept } = useWordy()

  const questions = useMemo(
    () => shuffle(concept.quiz).slice(0, 3),
    [concept.id, concept.quiz, round],
  )
  const q = questions[qIndex]

  const pick = (i: number) => {
    if (picked !== null) return
    setPicked(i)
    if (i === q.answer) setScore((s) => s + 1)
  }

  const next = () => {
    if (qIndex + 1 >= questions.length) {
      const final = score
      setDone(true)
      markConcept(concept.id, { bestQuiz: Math.max(0, final) })
      if (final === 3) markConcept(concept.id, { bestQuiz: 3 })
    } else {
      setQIndex((i) => i + 1)
      setPicked(null)
    }
  }

  const restart = () => {
    setRound((r) => r + 1)
    setQIndex(0)
    setPicked(null)
    setScore(0)
    setDone(false)
  }

  if (done) {
    const perfect = score === questions.length
    return (
      <motion.div
        key={`done-${round}`}
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        className="flex flex-col items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.03] p-6 text-center"
      >
        <div className={`flex items-center justify-center rounded-full p-4 ${perfect ? 'bg-amber-400/15' : 'bg-violet-500/15'}`}>
          <Trophy size={26} className={perfect ? 'text-amber-300' : 'text-violet-300'} />
        </div>
        <div>
          <p className="font-display text-xl font-bold text-white">
            {score} / {questions.length}
          </p>
          <p className="mt-1 text-sm text-white/60">
            {perfect
              ? `You’ve mastered ${concept.word}. 🎉`
              : score >= 2
                ? 'Strong — one more run and it’s yours.'
                : 'Every pass teaches the world to you.'}
          </p>
        </div>
        <div className="flex gap-1">
          {questions.map((_, i) => (
            <span
              key={i}
              className={`h-2 w-2 rounded-full ${i < score ? 'bg-emerald-300' : 'bg-white/15'}`}
            />
          ))}
        </div>
        <button
          onClick={restart}
          className="rounded-full border border-violet-400/30 bg-violet-500/15 px-5 py-2 text-sm font-medium text-violet-100 transition-all hover:bg-violet-500/25 active:scale-95"
        >
          Try again
        </button>
      </motion.div>
    )
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <p className="text-[10px] font-semibold uppercase tracking-[0.26em] text-white/30">
          knowledge check
        </p>
        <div className="flex items-center gap-1.5">
          {questions.map((_, i) => (
            <span
              key={i}
              className={`h-1.5 w-1.5 rounded-full transition-colors ${
                i < qIndex ? 'bg-emerald-300' : i === qIndex ? 'bg-violet-300' : 'bg-white/15'
              }`}
            />
          ))}
        </div>
      </div>
      <AnimatePresence mode="wait">
        <motion.div
          key={`${round}-${qIndex}`}
          initial={{ opacity: 0, x: 16 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -16 }}
          transition={{ duration: 0.25 }}
          className="flex flex-col gap-3"
        >
          <p className="text-sm font-medium leading-relaxed text-white/90">{q.q}</p>
          <div className="flex flex-col gap-2">
            {q.options.map((opt, i) => {
              const isRight = i === q.answer
              const isPicked = picked === i
              const revealed = picked !== null
              return (
                <button
                  key={opt}
                  onClick={() => pick(i)}
                  disabled={revealed}
                  className={`rounded-xl border px-4 py-2.5 text-left text-[13px] leading-snug transition-all ${
                    revealed
                      ? isRight
                        ? 'border-emerald-400/50 bg-emerald-400/12 text-emerald-100'
                        : isPicked
                          ? 'border-rose-400/40 bg-rose-400/10 text-rose-100'
                          : 'border-white/6 bg-white/[0.02] text-white/35'
                      : 'border-white/10 bg-white/[0.04] text-white/80 hover:border-violet-400/40 hover:bg-violet-500/12 active:scale-[0.98]'
                  }`}
                >
                  <span className="mr-2 font-display text-[10px] text-white/35">
                    {String.fromCharCode(65 + i)}
                  </span>
                  {opt}
                  {revealed && isRight && <Check size={13} className="ml-1.5 inline text-emerald-300" />}
                </button>
              )
            })}
          </div>
          <AnimatePresence>
            {picked !== null && (
              <motion.div
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                className="rounded-xl border border-white/8 bg-white/[0.03] p-3.5"
              >
                <p className="text-xs leading-relaxed text-white/65">
                  <span className={picked === q.answer ? 'text-emerald-300' : 'text-amber-300'}>
                    {picked === q.answer ? 'Right. ' : 'Not quite. '}
                  </span>
                  {q.explain}
                </p>
                <button
                  onClick={next}
                  className="mt-3 w-full rounded-full border border-violet-400/30 bg-violet-500/15 py-2 text-xs font-semibold uppercase tracking-[0.15em] text-violet-100 transition-all hover:bg-violet-500/25 active:scale-[0.98]"
                >
                  {qIndex + 1 >= questions.length ? 'See the result' : 'Next question'}
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </AnimatePresence>
    </div>
  )
}

/* ---------------- Remember ---------------- */

function RememberPanel({ concept, params }: {
  concept: ConceptDef
  params: Record<string, number>
}) {
  const { saveWorld, conceptProgress, markConcept } = useWordy()
  const [round, setRound] = useState(0)
  const [picked, setPicked] = useState<number | null>(null)
  const progress = conceptProgress[concept.id] ?? emptyProgress()

  // recall triple: one real fact + two from other worlds
  const recall = useMemo(() => {
    const others = CONCEPTS.filter((c) => c.id !== concept.id)
    const distractors = shuffle(others)
      .slice(0, 2)
      .map((c) => ({ text: c.facts[Math.floor(Math.random() * c.facts.length)], from: c.word }))
    const real = concept.facts[Math.floor(Math.random() * concept.facts.length)]
    return { options: shuffle([real, distractors[0].text, distractors[1].text]), real }
  }, [concept.id, concept.facts, round])

  const pick = (text: string) => {
    if (picked !== null) return
    const right = text === recall.real
    setPicked(right ? 1 : -1)
    if (right) markConcept(concept.id, { recallCorrect: true })
  }

  const saved = progress.saved

  return (
    <div className="flex flex-col gap-4">
      {/* recall game */}
      <div>
        <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.26em] text-white/30">
          quick recall
        </p>
        <p className="mb-3 text-sm leading-relaxed text-white/85">
          Which of these belongs to <span className="text-white">{concept.word}</span>?
        </p>
        <div className="flex flex-col gap-2">
          {recall.options.map((opt) => {
            const revealed = picked !== null
            const isReal = opt === recall.real
            return (
              <button
                key={opt}
                onClick={() => pick(opt)}
                disabled={revealed}
                className={`rounded-xl border px-4 py-2.5 text-left text-[13px] leading-snug transition-all ${
                  revealed
                    ? isReal
                      ? 'border-emerald-400/50 bg-emerald-400/12 text-emerald-100'
                      : 'border-white/6 bg-white/[0.02] text-white/40'
                    : 'border-white/10 bg-white/[0.04] text-white/80 hover:border-violet-400/40 hover:bg-violet-500/12 active:scale-[0.98]'
                }`}
              >
                {opt}
              </button>
            )
          })}
        </div>
        <AnimatePresence>
          {picked !== null && (
            <motion.button
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              onClick={() => { setPicked(null); setRound((r) => r + 1) }}
              className="mt-2.5 self-start rounded-full border border-white/10 px-3.5 py-1.5 text-[11px] text-white/55 transition-colors hover:text-white"
            >
              Another round
            </motion.button>
          )}
        </AnimatePresence>
      </div>

      {/* the facts, for keeps */}
      <div className="rounded-2xl border border-white/8 bg-white/[0.03] p-4">
        <p className="mb-2.5 text-[10px] font-semibold uppercase tracking-[0.26em] text-white/30">
          what {concept.word} taught you
        </p>
        <ul className="space-y-2">
          {concept.facts.map((f) => (
            <li key={f} className="flex items-start gap-2 text-xs leading-relaxed text-white/65">
              <Check size={12} className="mt-0.5 shrink-0 text-emerald-300/70" />
              {f}
            </li>
          ))}
        </ul>
      </div>

      {/* save */}
      <button
        onClick={() => {
          saveWorld({ id: concept.id, params, savedAt: Date.now() })
        }}
        disabled={saved}
        className={`flex items-center justify-center gap-2 rounded-full border py-3 text-sm font-medium transition-all active:scale-[0.98] ${
          saved
            ? 'border-emerald-400/30 bg-emerald-400/10 text-emerald-200'
            : 'border-violet-400/30 bg-violet-500/15 text-violet-100 hover:bg-violet-500/25'
        }`}
      >
        <Bookmark size={14} />
        {saved ? 'Saved to your Library' : 'Save this world'}
      </button>
    </div>
  )
}

/* ---------------- the stage itself ---------------- */

export function WorldStage() {
  const {
    activeWorld, worldMode, setWorldMode, exitWorld,
    setWorldParam, worldAction, sceneFact,
  } = useWordyUI()

  if (!activeWorld) return null
  const { concept, params, blend } = activeWorld
  const meta = LEARNING_CATEGORY_META[concept.category]

  const factPulse = sceneFact?.index ?? 0

  return (
    <>
      {/* world header — floats top-left below the app bar */}
      <motion.div
        initial={{ opacity: 0, x: -18 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        className="pointer-events-auto fixed left-4 top-20 z-30 max-w-[min(21rem,calc(100vw-6rem))] sm:left-6 sm:top-24"
      >
        <div className="glass flex items-center gap-3 rounded-2xl px-4 py-3">
          <span className="text-2xl leading-none">{concept.icon}</span>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="truncate font-display text-lg font-bold tracking-wide text-white">
                {concept.word}
              </h2>
              <button
                onClick={exitWorld}
                aria-label="Leave this world"
                className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-white/10 text-white/40 transition-all hover:border-rose-400/40 hover:text-rose-300 active:scale-90"
              >
                <X size={12} />
              </button>
            </div>
            <p className="text-[10px] font-medium uppercase tracking-[0.22em] text-white/40">
              {meta.icon} {meta.label}
            </p>
          </div>
        </div>
        {blend && (
          <div className="glass mt-2 rounded-xl px-3 py-2">
            <p className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-fuchsia-300/80">
              <Sparkles size={10} /> blend — {blend.name}
            </p>
            <p className="mt-0.5 text-[11px] leading-snug text-white/45">
              {concept.word} × {blend.secondary.word} · a creative interpretation
            </p>
          </div>
        )}
        {!blend && (
          <p className="mt-2 max-w-[min(19rem,calc(100vw-6rem))] pl-1 text-[11px] leading-snug text-white/35">
            {concept.tagline}
          </p>
        )}
      </motion.div>

      {/* mode panel */}
      <motion.div
        initial={{ opacity: 0, y: 18, filter: 'blur(6px)' }}
        animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
        transition={{ duration: 0.4, delay: 0.08 }}
        className="relative z-20 flex w-full max-w-lg flex-col gap-3"
      >
        {/* tabs */}
        <div className="glass scroll-thin flex items-center gap-1 overflow-x-auto rounded-full p-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden" role="tablist" aria-label="Learning modes">
          {MODES.map((m) => {
            const active = worldMode === m.id
            return (
              <button
                key={m.id}
                role="tab"
                aria-selected={active}
                onClick={() => setWorldMode(m.id)}
                className={`relative flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-medium transition-colors sm:px-4 ${
                  active ? 'text-white' : 'text-white/45 hover:text-white/80'
                }`}
              >
                {active && (
                  <motion.span
                    layoutId="world-mode-pill"
                    transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                    className="absolute inset-0 rounded-full border border-violet-400/30 bg-violet-500/20 shadow-[0_0_20px_rgba(124,58,237,0.25)]"
                  />
                )}
                <m.icon size={12} className="relative" />
                <span className="relative">{m.label}</span>
              </button>
            )
          })}
        </div>

        {/* panel */}
        <div className="glass max-h-[44dvh] overflow-y-auto rounded-3xl p-4 scroll-thin sm:p-5 lg:max-h-none">
          <AnimatePresence mode="wait">
            <motion.div
              key={worldMode}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2 }}
            >
              {worldMode === 'explore' && (
                <ExplorePanel concept={concept} factIndex={factPulse} onAction={worldAction} />
              )}
              {worldMode === 'experiment' && (
                <ExperimentPanel
                  concept={concept}
                  params={params}
                  onParam={setWorldParam}
                  onAction={worldAction}
                />
              )}
              {worldMode === 'challenge' && <ChallengePanel concept={concept} />}
              {worldMode === 'remember' && <RememberPanel concept={concept} params={params} />}
            </motion.div>
          </AnimatePresence>
        </div>
      </motion.div>
    </>
  )
}
