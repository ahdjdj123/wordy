'use client'

import { motion } from 'framer-motion'
import { Globe2, Wand2, Zap, BookOpen } from 'lucide-react'
import { CONCEPTS, LEARNING_CATEGORY_META } from '@/lib/wordy/knowledge'
import { useWordyUI } from './wordy-context'
import { useWordy } from '@/lib/wordy/store'

/**
 * v2.0 — the empty state of the Playground.
 * A quiet hero: what WORDY is, a prominent invitation, and example worlds.
 */
export function WordHero() {
  const { enterWorld } = useWordyUI()
  const progress = useWordy((s) => s.conceptProgress)
  const recent = useWordy((s) => s.recentConcepts)

  const examples = CONCEPTS.filter((c) => c.example).slice(0, 6)
  const recents = recent
    .map((id) => CONCEPTS.find((c) => c.id === id))
    .filter((c): c is NonNullable<typeof c> => !!c)
    .slice(0, 4)
  const visited = Object.keys(progress).length

  return (
    <div className="mx-auto flex w-full max-w-2xl flex-col items-center gap-8 pb-6 text-center">
      <motion.div
        initial={{ opacity: 0, y: 18, filter: 'blur(6px)' }}
        animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="flex flex-col items-center gap-3"
      >
        <span className="glass flex items-center gap-2 rounded-full px-4 py-1.5 text-[11px] font-medium uppercase tracking-[0.28em] text-violet-200/80">
          <Globe2 size={13} className="text-violet-300" />
          an interactive learning universe
        </span>
        <h1 className="font-display text-4xl font-bold leading-tight tracking-wide text-white sm:text-5xl">
          Type a word.
          <br />
          <span className="wordy-gradient-text">Change the world.</span>
        </h1>
        <p className="max-w-md text-sm leading-relaxed text-white/50">
          Every word opens a living world — erupt a volcano, grow a plant,
          spin a solar system. Explore it, experiment with it, then see what
          you remember.
        </p>
      </motion.div>

      {/* example worlds */}
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.15 }}
        className="grid w-full grid-cols-2 gap-2.5 sm:grid-cols-3"
      >
        {examples.map((c, i) => (
          <motion.button
            key={c.id}
            onClick={() => enterWorld(c.id)}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 + i * 0.05 }}
            className="glass group flex flex-col items-start gap-1.5 rounded-2xl p-4 text-left transition-all hover:-translate-y-0.5 hover:border-violet-400/35 hover:shadow-[0_8px_36px_rgba(124,58,237,0.22)] active:scale-[0.97]"
          >
            <span className="text-2xl leading-none">{c.icon}</span>
            <span className="font-display text-sm font-semibold tracking-wide text-white/95">
              {c.word}
            </span>
            <span className="text-[11px] leading-snug text-white/40 line-clamp-2">
              {c.tagline}
            </span>
          </motion.button>
        ))}
      </motion.div>

      {/* recently explored */}
      {recents.length > 0 && (
        <div className="flex w-full flex-col items-center gap-2">
          <p className="text-[10px] font-medium uppercase tracking-[0.3em] text-white/30">
            continue exploring
          </p>
          <div className="flex flex-wrap items-center justify-center gap-1.5">
            {recents.map((c) => (
              <button
                key={c.id}
                onClick={() => enterWorld(c.id)}
                className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-xs text-white/70 transition-all hover:border-violet-400/35 hover:text-white active:scale-95"
              >
                <span>{c.icon}</span>
                {c.word}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* classic words nudge */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="flex flex-col items-center gap-1.5"
      >
        <p className="text-[11px] text-white/35">
          or try the classic words — the sphere still answers every one
        </p>
        <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-xs">
          {['fly', 'fire', 'boom', 'rain', 'freeze'].map((w) => (
            <span key={w} className="font-display tracking-[0.2em] text-white/45">
              {w.toUpperCase()}
            </span>
          ))}
        </div>
        {visited > 0 && (
          <p className="mt-1 flex items-center gap-1 text-[10px] uppercase tracking-[0.22em] text-white/25">
            <BookOpen size={10} />
            {visited} of {CONCEPTS.length} worlds visited
          </p>
        )}
      </motion.div>
    </div>
  )
}

/** tiny mode badge line used under the hero on tall screens */
export function HeroModes() {
  return (
    <div className="flex items-center justify-center gap-4 text-white/25">
      <span className="flex items-center gap-1 text-[10px] uppercase tracking-[0.22em]">
        <Zap size={10} /> explore
      </span>
      <span className="flex items-center gap-1 text-[10px] uppercase tracking-[0.22em]">
        <Wand2 size={10} /> experiment
      </span>
      <span className="flex items-center gap-1 text-[10px] uppercase tracking-[0.22em]">
        challenge
      </span>
      <span className="flex items-center gap-1 text-[10px] uppercase tracking-[0.22em]">
        remember
      </span>
    </div>
  )
}
