'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { Sparkles, ArrowUpRight, Compass, Globe2, Bookmark } from 'lucide-react'
import { COMMANDS } from '@/lib/wordy/commands'
import type { CommandDef, Category } from '@/lib/wordy/types'
import { CATEGORY_META } from '@/lib/wordy/types'
import { CONCEPTS, LEARNING_CATEGORY_META } from '@/lib/wordy/knowledge'
import type { ConceptDef, LearningCategory } from '@/lib/wordy/knowledge/types'
import { useWordy, emptyProgress } from '@/lib/wordy/store'
import { useWordyUI } from './wordy-context'
import { MiniDemo } from './MiniDemo'
import { SoftSearch } from './CommandDeck'

const CATEGORIES: Array<Category | 'all'> = ['all', 'movement', 'physics', 'elements', 'nature', 'visual', 'environment', 'objects', 'special']
const LEARNING_CATS: Array<LearningCategory | 'all'> = ['all', 'objects', 'organisms', 'phenomena', 'science', 'processes', 'abstract', 'emotions', 'history']

const CATEGORY_TAG: Record<Category, string> = {
  movement: 'bg-cyan-500/12 text-cyan-300 border-cyan-400/20',
  physics: 'bg-violet-500/12 text-violet-300 border-violet-400/20',
  elements: 'bg-orange-500/12 text-orange-300 border-orange-400/20',
  nature: 'bg-emerald-500/12 text-emerald-300 border-emerald-400/20',
  visual: 'bg-pink-500/12 text-pink-300 border-pink-400/20',
  environment: 'bg-blue-500/12 text-blue-300 border-blue-400/20',
  objects: 'bg-amber-500/12 text-amber-300 border-amber-400/20',
  special: 'bg-fuchsia-500/12 text-fuchsia-300 border-fuchsia-400/20',
}

const LEARNING_TAG: Record<LearningCategory, string> = {
  objects: 'bg-amber-500/12 text-amber-300 border-amber-400/20',
  organisms: 'bg-emerald-500/12 text-emerald-300 border-emerald-400/20',
  phenomena: 'bg-orange-500/12 text-orange-300 border-orange-400/20',
  science: 'bg-violet-500/12 text-violet-300 border-violet-400/20',
  processes: 'bg-cyan-500/12 text-cyan-300 border-cyan-400/20',
  abstract: 'bg-fuchsia-500/12 text-fuchsia-300 border-fuchsia-400/20',
  emotions: 'bg-rose-500/12 text-rose-300 border-rose-400/20',
  history: 'bg-yellow-500/12 text-yellow-200 border-yellow-400/20',
}

/* ---------------- Worlds tab ---------------- */

/** progress ring: visited → explored → experimented → challenged → remembered */
function progressK(p: ReturnType<typeof emptyProgress>): number {
  let k = 0
  if (p.visitedAt) k += 0.25
  if (p.explored) k += 0.2
  if (p.experimented) k += 0.2
  k += (p.bestQuiz / 3) * 0.25
  if (p.recallCorrect) k += 0.1
  return Math.min(1, k)
}

function ConceptCard({ concept, index }: { concept: ConceptDef; index: number }) {
  const { enterWorld } = useWordyUI()
  const progress = useWordy((s) => s.conceptProgress[concept.id]) ?? emptyProgress()
  const mastered = progress.bestQuiz >= 3
  const k = progressK(progress)
  const meta = LEARNING_CATEGORY_META[concept.category]

  return (
    <motion.article
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '40px' }}
      transition={{ duration: 0.4, delay: (index % 8) * 0.035 }}
      className={`group relative flex flex-col gap-3 overflow-hidden rounded-3xl p-5 transition-transform duration-300 hover:-translate-y-1 ${
        mastered ? 'glass ring-1 ring-amber-400/30' : 'glass'
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <span className="text-3xl leading-none">{concept.icon}</span>
        {mastered && (
          <span className="rounded-full border border-amber-400/30 bg-amber-400/15 px-2 py-0.5 text-[9px] font-semibold uppercase tracking-[0.2em] text-amber-300">
            mastered
          </span>
        )}
      </div>
      <div>
        <h3 className="font-display text-lg font-semibold tracking-wide text-white">{concept.word}</h3>
        <span className={`mt-1 inline-block rounded-full border px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider ${LEARNING_TAG[concept.category]}`}>
          {meta.label}
        </span>
      </div>
      <p className="flex-1 text-[13px] leading-relaxed text-white/55">{concept.tagline}</p>

      {/* progress */}
      <div className="flex items-center gap-2.5">
        <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/8">
          <motion.div
            initial={{ width: 0 }}
            whileInView={{ width: `${Math.max(k * 100, 3)}%` }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className={`h-full rounded-full ${
              mastered
                ? 'bg-gradient-to-r from-amber-300 to-amber-500 shadow-[0_0_10px_rgba(251,191,36,0.5)]'
                : 'bg-gradient-to-r from-violet-400 to-cyan-300'
            }`}
          />
        </div>
        <span className="text-[10px] font-medium text-white/35">
          {progress.visitedAt ? `${Math.round(k * 100)}%` : 'new'}
        </span>
      </div>

      <button
        onClick={() => enterWorld(concept.id)}
        className="flex items-center justify-center gap-1.5 rounded-xl border border-violet-400/25 bg-violet-500/12 py-2 text-xs font-semibold uppercase tracking-[0.15em] text-violet-200 transition-all hover:bg-violet-500/25 hover:shadow-[0_0_24px_rgba(124,58,237,0.3)] active:scale-[0.97]"
      >
        Open world
        <ArrowUpRight size={13} />
      </button>
    </motion.article>
  )
}

/* ---------------- Collection tab ---------------- */

function CollectionTab() {
  const { savedWorlds, creations, removeWorld, deleteCreation } = useWordy()
  const { enterWorld, enterBlend, setView } = useWordyUI()

  return (
    <div className="flex flex-col gap-8">
      {/* saved worlds */}
      <section>
        <h2 className="mb-3 font-display text-xl font-semibold text-white/90">Saved worlds</h2>
        {savedWorlds.length === 0 ? (
          <div className="glass flex flex-col items-center gap-2 rounded-3xl px-6 py-10 text-center">
            <p className="text-sm text-white/50">No saved worlds yet.</p>
            <p className="max-w-xs text-xs text-white/30">
              Open any world, switch to Remember, and save it — parameters included.
            </p>
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {savedWorlds.map((w) => {
              const concept = CONCEPTS.find((c) => c.id === w.id)
              if (!concept) return null
              return (
                <motion.div
                  key={`${w.id}-${w.savedAt}`}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="glass group flex items-center gap-3 rounded-2xl p-4"
                >
                  <span className="text-2xl leading-none">{concept.icon}</span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-display text-sm font-semibold text-white/90">{concept.word}</p>
                    <p className="mt-0.5 text-[11px] text-white/35">
                      {new Date(w.savedAt).toLocaleDateString()} · {Object.keys(w.params).length} dials set
                    </p>
                  </div>
                  <button
                    onClick={() => enterWorld(concept.id, { params: w.params })}
                    aria-label={`Reopen ${concept.word}`}
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-violet-500/15 text-violet-200 transition-all hover:bg-violet-500/30 active:scale-90"
                  >
                    <ArrowUpRight size={14} />
                  </button>
                  <button
                    onClick={() => removeWorld(w.id)}
                    aria-label="Remove"
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-white/8 text-white/30 transition-all hover:border-rose-400/35 hover:text-rose-300 active:scale-90"
                  >
                    ✕
                  </button>
                </motion.div>
              )
            })}
          </div>
        )}
      </section>

      {/* creations */}
      <section>
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="font-display text-xl font-semibold text-white/90">Creations</h2>
          <button
            onClick={() => setView('studio')}
            className="rounded-full border border-fuchsia-400/25 bg-fuchsia-500/12 px-3.5 py-1.5 text-[11px] font-medium text-fuchsia-200 transition-all hover:bg-fuchsia-500/22 active:scale-95"
          >
            Blend two words →
          </button>
        </div>
        {creations.length === 0 ? (
          <div className="glass flex flex-col items-center gap-2 rounded-3xl px-6 py-10 text-center">
            <p className="text-sm text-white/50">Nothing blended yet.</p>
            <p className="max-w-xs text-xs text-white/30">
              In the Spell Studio, combine two words into a world only you could make.
            </p>
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">
            {creations.map((c) => {
              const p = CONCEPTS.find((x) => x.id === c.primary)
              const s = CONCEPTS.find((x) => x.id === c.secondary)
              if (!p || !s) return null
              return (
                <motion.div
                  key={c.id}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="glass flex items-center gap-3 rounded-2xl p-4"
                >
                  <span className="text-xl leading-none">{p.icon}</span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-display text-sm font-semibold text-white/90">{c.name}</p>
                    <p className="mt-0.5 truncate text-[11px] text-white/35">{p.word} × {s.word}</p>
                  </div>
                  <button
                    onClick={() => enterBlend(c.primary, c.secondary)}
                    aria-label={`Play ${c.name}`}
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-fuchsia-500/15 text-fuchsia-200 transition-all hover:bg-fuchsia-500/30 active:scale-90"
                  >
                    <ArrowUpRight size={14} />
                  </button>
                  <button
                    onClick={() => deleteCreation(c.id)}
                    aria-label="Delete"
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-white/8 text-white/30 transition-all hover:border-rose-400/35 hover:text-rose-300 active:scale-90"
                  >
                    ✕
                  </button>
                </motion.div>
              )
            })}
          </div>
        )}
      </section>
    </div>
  )
}

/* ---------------- Words tab (the original command library) ---------------- */

function CommandCard({ cmd, index }: { cmd: CommandDef; index: number }) {
  const { tryCommandByName } = useWordyUI()
  const related = (cmd.related ?? []).filter((r) => r !== cmd.name).slice(0, 3)

  return (
    <motion.article
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '40px' }}
      transition={{ duration: 0.4, delay: (index % 6) * 0.04 }}
      className={`group relative flex flex-col overflow-hidden rounded-3xl transition-transform duration-300 hover:-translate-y-1 ${
        cmd.gold ? 'glass ring-1 ring-amber-400/25' : 'glass'
      }`}
    >
      <div className="relative h-[86px] overflow-hidden border-b border-white/6">
        <MiniDemo kind={cmd.demo ?? 'glow'} />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#080B1A]/50 to-transparent" />
        {cmd.gold && (
          <span className="absolute right-3 top-2.5 rounded-full border border-amber-400/30 bg-amber-400/15 px-2 py-0.5 text-[9px] font-semibold uppercase tracking-[0.2em] text-amber-300">
            rare
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col gap-2.5 p-4">
        <div className="flex items-center justify-between gap-2">
          <h3 className="font-display text-lg font-semibold tracking-wide text-white">
            {cmd.name}
          </h3>
          <span className={`rounded-full border px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider ${CATEGORY_TAG[cmd.category]}`}>
            {CATEGORY_META[cmd.category].label}
          </span>
        </div>
        <p className="flex-1 text-[13px] leading-relaxed text-white/55">{cmd.description}</p>
        {related.length > 0 && (
          <div className="flex flex-wrap items-center gap-1">
            <span className="text-[10px] uppercase tracking-widest text-white/25">also</span>
            {related.map((r) => (
              <button
                key={r}
                onClick={() => tryCommandByName(r)}
                className="rounded-full border border-white/8 bg-white/[0.04] px-2 py-0.5 text-[11px] text-white/50 transition-colors hover:border-violet-400/30 hover:text-white/90"
              >
                {r}
              </button>
            ))}
          </div>
        )}
        <button
          onClick={() => tryCommandByName(cmd.name)}
          className={`mt-1 flex items-center justify-center gap-1.5 rounded-xl border py-2 text-xs font-semibold uppercase tracking-[0.15em] transition-all active:scale-[0.97] ${
            cmd.gold
              ? 'border-amber-400/30 bg-amber-400/10 text-amber-200 hover:bg-amber-400/20 hover:shadow-[0_0_24px_rgba(251,191,36,0.25)]'
              : 'border-violet-400/25 bg-violet-500/12 text-violet-200 hover:bg-violet-500/25 hover:shadow-[0_0_24px_rgba(124,58,237,0.3)]'
          }`}
        >
          Try it
          <ArrowUpRight size={13} />
        </button>
      </div>
    </motion.article>
  )
}

/* ---------------- the library itself ---------------- */

type LibTab = 'worlds' | 'collection' | 'words'

export function LibraryView() {
  const [tab, setTab] = useState<LibTab>('worlds')
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState<'all' | LearningCategory>('all')
  const [cmdCategory, setCmdCategory] = useState<Category | 'all'>('all')
  const [limit, setLimit] = useState(24)
  const discoveredSecrets = useWordy((s) => s.discoveredSecrets)
  const conceptProgress = useWordy((s) => s.conceptProgress)
  const sentinelRef = useRef<HTMLDivElement | null>(null)
  const { setView } = useWordyUI()

  const filteredConcepts = useMemo(() => {
    const q = query.trim().toLowerCase()
    return CONCEPTS.filter((c) => {
      if (category !== 'all' && c.category !== category) return false
      if (!q) return true
      return (
        c.word.includes(q) ||
        c.tagline.toLowerCase().includes(q) ||
        c.aliases.some((a) => a.includes(q))
      )
    })
  }, [query, category])

  const filteredCommands = useMemo(() => {
    const q = query.trim().toLowerCase()
    return COMMANDS.filter((c) => {
      if (c.hidden && !discoveredSecrets.includes(c.name)) return false
      if (cmdCategory !== 'all' && c.category !== cmdCategory) return false
      if (!q) return true
      return (
        c.name.includes(q) ||
        c.description.toLowerCase().includes(q) ||
        c.aliases.some((a) => a.includes(q))
      )
    })
  }, [query, cmdCategory, discoveredSecrets])

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: COMMANDS.filter((c) => !c.hidden || discoveredSecrets.includes(c.name)).length }
    for (const c of COMMANDS) {
      if (c.hidden && !discoveredSecrets.includes(c.name)) continue
      map[c.category] = (map[c.category] ?? 0) + 1
    }
    return map
  }, [discoveredSecrets])

  useEffect(() => {
    const el = sentinelRef.current
    if (!el) return
    const io = new IntersectionObserver((entries) => {
      if (entries[0]?.isIntersecting) {
        setLimit((l) => (l < filteredCommands.length ? l + 24 : l))
      }
    }, { rootMargin: '600px' })
    io.observe(el)
    return () => io.disconnect()
  }, [filteredCommands.length])

  const visibleCommands = filteredCommands.slice(0, limit)
  const visited = Object.values(conceptProgress).filter((p) => p.visitedAt).length
  const mastered = Object.values(conceptProgress).filter((p) => p.bestQuiz >= 3).length

  const TABS: Array<{ id: LibTab; label: string; icon: typeof Globe2 }> = [
    { id: 'worlds', label: 'Worlds', icon: Globe2 },
    { id: 'collection', label: 'Collection', icon: Bookmark },
    { id: 'words', label: 'Words', icon: Compass },
  ]

  return (
    <div className="mx-auto w-full max-w-6xl px-4 pb-24 pt-4 sm:px-6">
      {/* heading */}
      <header className="mb-5 flex flex-col gap-1">
        <h1 className="font-display text-3xl font-bold tracking-wide text-white sm:text-4xl">
          The <span className="wordy-gradient-text">Library</span>
        </h1>
        <p className="text-sm text-white/45">
          {CONCEPTS.length} worlds to learn · {COMMANDS.length} words the sphere answers · a few it keeps to itself.
        </p>
      </header>

      {/* tabs */}
      <div className="glass mb-4 inline-flex items-center gap-1 rounded-full p-1">
        {TABS.map((t) => {
          const active = tab === t.id
          return (
            <button
              key={t.id}
              onClick={() => { setTab(t.id); setQuery(''); setLimit(24) }}
              aria-pressed={active}
              className={`relative flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-medium transition-colors ${
                active ? 'text-white' : 'text-white/45 hover:text-white/80'
              }`}
            >
              {active && (
                <motion.span
                  layoutId="lib-tab-pill"
                  transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                  className="absolute inset-0 rounded-full border border-violet-400/30 bg-violet-500/20"
                />
              )}
              <t.icon size={13} className="relative" />
              <span className="relative">{t.label}</span>
            </button>
          )
        })}
      </div>

      {/* learning progress line */}
      {tab === 'worlds' && (
        <div className="glass mb-5 flex flex-wrap items-center gap-x-6 gap-y-2 rounded-2xl px-5 py-3.5">
          <div className="flex items-center gap-2 text-xs text-white/60">
            <Globe2 size={13} className="text-violet-300" />
            {visited} / {CONCEPTS.length} worlds visited
          </div>
          <div className="flex items-center gap-2 text-xs text-white/60">
            <Sparkles size={13} className="text-amber-300" />
            {mastered} mastered
          </div>
          <div className="ml-auto h-1.5 w-32 overflow-hidden rounded-full bg-white/8 sm:w-48">
            <div
              className="h-full rounded-full bg-gradient-to-r from-violet-400 to-cyan-300"
              style={{ width: `${Math.max(3, (visited / CONCEPTS.length) * 100)}%` }}
            />
          </div>
        </div>
      )}

      {/* controls */}
      {(tab === 'worlds' || tab === 'words') && (
        <div className="sticky top-16 z-20 -mx-4 mb-6 flex flex-col gap-3 bg-[#080B1A]/72 px-4 py-3 backdrop-blur-xl sm:-mx-6 sm:px-6">
          <SoftSearch
            value={query}
            onChange={(v) => { setQuery(v); setLimit(24) }}
            placeholder={tab === 'worlds' ? 'Search the worlds — try “volcano”' : 'Search the words — try “storm”'}
          />
          <div className="scroll-thin -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-0.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {tab === 'worlds'
              ? LEARNING_CATS.map((c) => {
                const active = category === c
                const count = c === 'all' ? CONCEPTS.length : CONCEPTS.filter((x) => x.category === c).length
                return (
                  <button
                    key={c}
                    onClick={() => { setCategory(c); setLimit(24) }}
                    className={`shrink-0 rounded-full border px-3.5 py-1.5 text-xs font-medium transition-all active:scale-95 ${
                      active
                        ? 'border-violet-400/45 bg-violet-500/20 text-white'
                        : 'border-white/8 bg-white/[0.03] text-white/50 hover:border-white/20 hover:text-white/80'
                    }`}
                  >
                    {c === 'all' ? 'Everything' : `${LEARNING_CATEGORY_META[c].icon} ${LEARNING_CATEGORY_META[c].label}`}
                    <span className={`ml-1.5 text-[10px] ${active ? 'text-white/60' : 'text-white/25'}`}>{count}</span>
                  </button>
                )
              })
              : CATEGORIES.map((c) => {
                const active = cmdCategory === c
                return (
                  <button
                    key={c}
                    onClick={() => { setCmdCategory(c); setLimit(24) }}
                    className={`shrink-0 rounded-full border px-3.5 py-1.5 text-xs font-medium transition-all active:scale-95 ${
                      active
                        ? 'border-violet-400/45 bg-violet-500/20 text-white'
                        : 'border-white/8 bg-white/[0.03] text-white/50 hover:border-white/20 hover:text-white/80'
                    }`}
                  >
                    {c === 'all' ? 'Everything' : CATEGORY_META[c].label}
                    <span className={`ml-1.5 text-[10px] ${active ? 'text-white/60' : 'text-white/25'}`}>
                      {counts[c] ?? 0}
                    </span>
                  </button>
                )
              })}
          </div>
        </div>
      )}

      {/* grids */}
      {tab === 'worlds' && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredConcepts.map((c, i) => (
            <ConceptCard key={c.id} concept={c} index={i} />
          ))}
        </div>
      )}
      {tab === 'collection' && <CollectionTab />}
      {tab === 'words' && (
        visibleCommands.length > 0 ? (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {visibleCommands.map((cmd, i) => (
              <CommandCard key={cmd.name} cmd={cmd} index={i} />
            ))}
          </div>
        ) : (
          <div className="glass mx-auto mt-10 flex max-w-md flex-col items-center gap-4 rounded-3xl px-8 py-14 text-center">
            <Compass className="h-8 w-8 text-violet-300/60" />
            <p className="text-sm text-white/60">
              Hmm… no words match <span className="text-white/95">“{query}”</span>.
            </p>
            <button
              onClick={() => { setQuery(''); setCmdCategory('all') }}
              className="rounded-full border border-violet-400/30 bg-violet-500/15 px-4 py-1.5 text-xs font-medium text-violet-200 transition-colors hover:bg-violet-500/25"
            >
              Show everything
            </button>
          </div>
        )
      )}
      {tab === 'words' && limit < filteredCommands.length && <div ref={sentinelRef} className="h-4" />}

      {/* footer nudge */}
      <div className="mt-10 flex flex-col items-center gap-3 text-center">
        <p className="max-w-sm text-xs leading-relaxed text-white/30">
          Words marked <span className="text-amber-300/80">rare</span> were secrets once. Some still are —
          they only appear after you discover them.
        </p>
        <button
          onClick={() => setView('surprises')}
          className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-4 py-2 text-xs text-white/70 transition-colors hover:border-fuchsia-400/30 hover:text-white"
        >
          <Sparkles size={13} className="text-fuchsia-300" />
          What’s still hidden?
        </button>
      </div>
    </div>
  )
}
