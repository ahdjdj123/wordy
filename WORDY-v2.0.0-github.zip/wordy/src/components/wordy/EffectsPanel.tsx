'use client'

import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { X, Eraser, Sparkles } from 'lucide-react'
import { getEngine, type EffectChip } from '@/lib/wordy/engine/engine'

/**
 * Active Effects — floating chips for everything currently
 * happening to the world. Each chip can be dismissed (×),
 * everything can be cleared softly, and the whole world
 * can be reset in one breath.
 */
export function EffectsPanel() {
  const [chips, setChips] = useState<EffectChip[]>([])

  useEffect(() => {
    const iv = setInterval(() => {
      const e = getEngine()
      if (e) setChips(e.getActiveEffects())
    }, 400)
    return () => clearInterval(iv)
  }, [])

  const remove = (id: string) => {
    getEngine()?.removeEffect(id)
    setChips((cs) => cs.filter((c) => c.id !== id))
  }

  const clearAll = () => {
    getEngine()?.clearEffects()
    setChips([])
  }

  const clearWorld = () => {
    getEngine()?.clearWorld()
    setChips([])
  }

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-40 z-30 flex justify-center px-4 sm:bottom-36 md:bottom-32">
      <div className="pointer-events-auto flex max-w-full items-center gap-2 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        <AnimatePresence mode="popLayout">
          {chips.map((c) => (
            <motion.button
              key={c.id}
              layout
              initial={{ opacity: 0, y: 12, scale: 0.8 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.8, filter: 'blur(4px)' }}
              transition={{ type: 'spring', stiffness: 380, damping: 30 }}
              onClick={() => remove(c.id)}
              title={`Dismiss ${c.label.toLowerCase()}`}
              className="group relative flex shrink-0 items-center gap-2 overflow-hidden rounded-full border border-white/12 bg-[#0B1026]/80 py-2 pl-3 pr-2.5 text-xs font-medium text-white/80 shadow-[0_4px_24px_rgba(2,3,10,0.4)] backdrop-blur-xl transition-all hover:border-violet-400/40 hover:bg-violet-500/15 active:scale-95"
            >
              {/* accent dot — a whisper of the effect's color */}
              {c.accent && (
                <span
                  className="h-1.5 w-1.5 shrink-0 rounded-full"
                  style={{ backgroundColor: c.accent, boxShadow: `0 0 6px ${c.accent}` }}
                />
              )}
              <span className="text-[13px] leading-none">{c.icon}</span>
              <span className="leading-none">{c.label}</span>
              {/* duration indicator — transient effects quietly count down */}
              {c.progress !== undefined && (
                <span className="absolute bottom-0.5 left-3 right-6 h-0.5 overflow-hidden rounded-full bg-white/8">
                  <span
                    className="block h-full rounded-full transition-[width] duration-400 ease-linear"
                    style={{ width: `${Math.max(0, Math.min(1, c.progress)) * 100}%`, backgroundColor: c.accent ?? '#67e8f9' }}
                  />
                </span>
              )}
              <span className="ml-0.5 flex h-4 w-4 items-center justify-center rounded-full text-[10px] text-white/35 transition-colors group-hover:bg-white/15 group-hover:text-white">
                <X size={9} strokeWidth={3} />
              </span>
            </motion.button>
          ))}
        </AnimatePresence>

        <div className="flex shrink-0 items-center gap-2 pl-1">
          {/* clear all — dismiss every effect, softly */}
          <AnimatePresence>
            {chips.length > 1 && (
              <motion.button
                key="clear-all"
                initial={{ opacity: 0, scale: 0.85 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.85, filter: 'blur(3px)' }}
                transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                onClick={clearAll}
                title="Dismiss every active effect"
                className="flex items-center gap-1.5 rounded-full border border-white/12 bg-[#0B1026]/70 px-3 py-2 text-xs font-medium text-white/60 backdrop-blur-xl transition-all hover:border-violet-300/40 hover:text-white/90 active:scale-95"
              >
                <Sparkles size={11} />
                Clear all
              </motion.button>
            )}
          </AnimatePresence>

          {/* clear world — one breath, and everything begins again */}
          <motion.button
            key="clear-world"
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ type: 'spring', stiffness: 380, damping: 30 }}
            onClick={clearWorld}
            title="Fade everything out and begin again"
            className={`flex items-center gap-1.5 rounded-full border px-3 py-2 text-xs font-medium backdrop-blur-xl transition-all active:scale-95 ${
              chips.length > 0
                ? 'border-rose-300/25 bg-rose-500/10 text-rose-200/90 hover:border-rose-300/50 hover:bg-rose-500/20'
                : 'border-white/10 bg-[#0B1026]/50 text-white/40 hover:border-white/25 hover:text-white/70'
            }`}
          >
            <Eraser size={11} />
            Clear world
          </motion.button>
        </div>
      </div>
    </div>
  )
}
