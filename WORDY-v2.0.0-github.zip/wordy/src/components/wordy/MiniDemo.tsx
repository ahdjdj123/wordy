'use client'

import { useEffect, useRef } from 'react'

/* ==========================================================================
   WORDY mini demos — tiny living previews for Library cards.
   One canvas per card, animated only while visible.
   ========================================================================== */

interface DemoCtx {
  ctx: CanvasRenderingContext2D
  w: number
  h: number
  t: number
  parts: Array<{ x: number; y: number; vx: number; vy: number; s: number; hue: number; seed: number; life: number }>
  burst: number
}

function makeParts(n: number, w: number, h: number): DemoCtx['parts'] {
  return Array.from({ length: n }, () => ({
    x: Math.random() * w,
    y: Math.random() * h,
    vx: 0,
    vy: 0,
    s: 1 + Math.random() * 2,
    hue: 250 + Math.random() * 60,
    seed: Math.random() * 100,
    life: 0,
  }))
}

function orb(c: DemoCtx, x: number, y: number, r: number, hue = 262, glow = true) {
  const { ctx } = c
  if (glow) {
    const g = ctx.createRadialGradient(x, y, 0, x, y, r * 2.6)
    g.addColorStop(0, `hsla(${hue},85%,72%,0.35)`)
    g.addColorStop(1, 'rgba(0,0,0,0)')
    ctx.fillStyle = g
    ctx.beginPath()
    ctx.arc(x, y, r * 2.6, 0, Math.PI * 2)
    ctx.fill()
  }
  const g2 = ctx.createRadialGradient(x - r * 0.3, y - r * 0.3, r * 0.05, x, y, r)
  g2.addColorStop(0, '#ede9fe')
  g2.addColorStop(0.45, `hsl(${hue},80%,68%)`)
  g2.addColorStop(1, `hsl(${hue},70%,32%)`)
  ctx.fillStyle = g2
  ctx.beginPath()
  ctx.arc(x, y, r, 0, Math.PI * 2)
  ctx.fill()
}

function heart(c: DemoCtx, x: number, y: number, s: number, col: string) {
  const { ctx } = c
  ctx.save()
  ctx.translate(x, y)
  ctx.scale(s / 10, s / 10)
  ctx.fillStyle = col
  ctx.beginPath()
  ctx.moveTo(0, 3.2)
  ctx.bezierCurveTo(-5.6, -1.6, -3.4, -6, 0, -3)
  ctx.bezierCurveTo(3.4, -6, 5.6, -1.6, 0, 3.2)
  ctx.fill()
  ctx.restore()
}

function drawDemo(kind: string, c: DemoCtx) {
  const { ctx, w, h, t } = c
  const cx = w / 2
  const cy = h / 2
  const R = Math.min(w, h) * 0.22

  switch (kind) {
    case 'rise':
    case 'hop':
    case 'fall':
    case 'bounce': {
      let y: number
      if (kind === 'rise') y = cy - Math.sin(t * 2) * h * 0.22 - h * 0.08
      else if (kind === 'hop') {
        const p = (t * 1.2) % 1
        y = h * 0.78 - Math.sin(p * Math.PI) * h * 0.5
      } else if (kind === 'fall') y = cy + Math.abs(Math.sin(t * 1.6)) * h * 0.26
      else {
        const p = Math.abs(Math.sin(t * 2.6))
        y = h * 0.72 - p * h * 0.42
      }
      // shadow
      ctx.fillStyle = 'rgba(124,58,237,0.16)'
      ctx.beginPath()
      ctx.ellipse(cx, h * 0.84, R * (0.7 + (y / h) * 0.5), 2.5, 0, 0, Math.PI * 2)
      ctx.fill()
      orb(c, cx, y, R)
      for (const p of c.parts) {
        if (kind === 'bounce') break
        const k = 1 - ((t * 0.8 + p.seed) % 1)
        ctx.fillStyle = `hsla(${p.hue},80%,75%,${k * 0.5})`
        ctx.beginPath()
        ctx.arc(cx + Math.sin(p.seed * 7) * 14, y + (1 - k) * -30 + Math.cos(p.seed) * 6, 1.5, 0, Math.PI * 2)
        ctx.fill()
      }
      break
    }
    case 'drift': {
      const x = cx + Math.sin(t * 0.7) * w * 0.26
      const y = cy + Math.sin(t * 1.1 + 1) * h * 0.18
      // fading path
      for (let i = 0; i < 8; i++) {
        const tt = t - i * 0.22
        ctx.fillStyle = `rgba(167,139,250,${0.36 - i * 0.045})`
        ctx.beginPath()
        ctx.arc(cx + Math.sin(tt * 0.7) * w * 0.26, cy + Math.sin(tt * 1.1 + 1) * h * 0.18, R * (1 - i * 0.09), 0, Math.PI * 2)
        ctx.fill()
      }
      orb(c, x, y, R)
      break
    }
    case 'spin': {
      ctx.save()
      ctx.translate(cx, cy)
      ctx.rotate(t * 3)
      ctx.strokeStyle = 'rgba(167,139,250,0.5)'
      ctx.lineWidth = 1.6
      ctx.setLineDash([6, 5])
      ctx.beginPath()
      ctx.arc(0, 0, R * 2, 0, Math.PI * 2)
      ctx.stroke()
      ctx.setLineDash([])
      ctx.restore()
      orb(c, cx, cy, R)
      // rotation marker
      const a = t * 3
      ctx.fillStyle = '#67e8f9'
      ctx.beginPath()
      ctx.arc(cx + Math.cos(a) * R * 2, cy + Math.sin(a) * R * 2, 2.4, 0, Math.PI * 2)
      ctx.fill()
      break
    }
    case 'orbit': {
      const a = t * 1.8
      ctx.strokeStyle = 'rgba(255,255,255,0.08)'
      ctx.beginPath()
      ctx.ellipse(cx, cy, R * 2.1, R * 1.1, 0, 0, Math.PI * 2)
      ctx.stroke()
      ctx.fillStyle = 'rgba(255,255,255,0.22)'
      ctx.beginPath()
      ctx.arc(cx, cy, 3, 0, Math.PI * 2)
      ctx.fill()
      orb(c, cx + Math.cos(a) * R * 2.1, cy + Math.sin(a) * R * 1.1, R * 0.8, 250)
      break
    }
    case 'zigzag': {
      ctx.strokeStyle = 'rgba(167,139,250,0.6)'
      ctx.lineWidth = 1.6
      ctx.beginPath()
      for (let i = 0; i <= 40; i++) {
        const p = i / 40
        const x = w * 0.12 + p * w * 0.76 - (t * 40) % (w * 0.76)
        const xx = ((x % (w * 0.76)) + w * 0.76) % (w * 0.76) + w * 0.12
        const y = cy + Math.sin(p * 16 + t * 6) * h * 0.24
        if (i === 0) ctx.moveTo(xx, y)
        else ctx.lineTo(xx, y)
      }
      ctx.stroke()
      const p2 = (t * 0.35) % 1
      const xx = w * 0.12 + p2 * w * 0.76
      orb(c, xx, cy + Math.sin(p2 * 16 + t * 6 - (t * 6 % (Math.PI * 2))) * h * 0.24, R * 0.8)
      break
    }
    case 'dash': {
      const p = (t * 0.9) % 1
      const x = w * 0.1 + p * w * 0.8
      for (let i = 0; i < 5; i++) {
        ctx.fillStyle = `rgba(103,232,249,${0.4 - i * 0.08})`
        ctx.beginPath()
        ctx.arc(x - i * 10, cy + Math.sin(i) * 2, R * (0.75 - i * 0.12), 0, Math.PI * 2)
        ctx.fill()
      }
      orb(c, x, cy, R, 195)
      break
    }
    case 'slide': {
      const p = Math.sin(t * 1.2) * 0.5 + 0.5
      ctx.strokeStyle = 'rgba(255,255,255,0.1)'
      ctx.beginPath()
      ctx.moveTo(w * 0.1, h * 0.78)
      ctx.lineTo(w * 0.9, h * 0.78)
      ctx.stroke()
      orb(c, w * 0.15 + p * w * 0.7, h * 0.78 - R * 0.7, R * 0.85)
      break
    }
    case 'swing': {
      const a = Math.sin(t * 1.6) * 0.5
      ctx.strokeStyle = 'rgba(255,255,255,0.14)'
      ctx.beginPath()
      ctx.moveTo(cx, 0)
      ctx.lineTo(cx + Math.sin(a) * h * 0.7, h * 0.7)
      ctx.stroke()
      orb(c, cx + Math.sin(a) * h * 0.7, h * 0.7, R * 0.85)
      break
    }
    case 'wobble': {
      const sq = Math.sin(t * 7) * 0.22
      ctx.save()
      ctx.translate(cx, cy)
      ctx.scale(1 + sq, 1 - sq)
      orb(c, 0, 0, R)
      ctx.restore()
      break
    }
    case 'gravity': {
      for (const p of c.parts) {
        p.y += (60 + p.s * 40) * 0.016
        if (p.y > h) p.y = -4
        ctx.fillStyle = `hsla(${p.hue},70%,75%,0.7)`
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.s, 0, Math.PI * 2)
        ctx.fill()
      }
      orb(c, cx, cy, R * 0.9)
      break
    }
    case 'freeze': {
      orb(c, cx, cy, R, 210)
      const grow = (Math.sin(t * 0.8) + 1) / 2
      ctx.strokeStyle = `rgba(224,242,254,${0.3 + grow * 0.5})`
      ctx.lineWidth = 1.4
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2 + 0.4
        ctx.beginPath()
        ctx.moveTo(cx + Math.cos(a) * R * 0.3, cy + Math.sin(a) * R * 0.3)
        ctx.lineTo(cx + Math.cos(a + 0.5) * R * 1.3 * grow, cy + Math.sin(a + 0.5) * R * 1.3 * grow)
        ctx.stroke()
      }
      for (const p of c.parts) {
        const k = 1 - ((t + p.seed) % 1)
        ctx.fillStyle = `rgba(224,242,254,${k * 0.7})`
        ctx.beginPath()
        ctx.arc(cx + Math.cos(p.seed) * R * 2 * k, cy + Math.sin(p.seed * 3) * R * 2 * k, 1.2, 0, Math.PI * 2)
        ctx.fill()
      }
      break
    }
    case 'fire': {
      orb(c, cx, cy, R, 22)
      for (const p of c.parts) {
        p.y -= (40 + p.s * 30) * 0.016
        p.x += Math.sin(t * 3 + p.seed) * 0.5
        if (p.y < -4) { p.y = h + 4; p.x = cx + (Math.random() - 0.5) * R * 2 }
        const k = 1 - p.y / h
        ctx.fillStyle = `hsla(${18 + p.s * 16},95%,${52 + k * 18}%,${0.3 + k * 0.6})`
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.s * 1.4, 0, Math.PI * 2)
        ctx.fill()
      }
      break
    }
    case 'water': {
      orb(c, cx, cy, R, 210)
      for (const p of c.parts) {
        const a = t * 1.4 + p.seed
        const rr = R * 1.5 + Math.sin(a * 1.3) * 6
        const x = cx + Math.cos(a) * rr
        const y = cy + Math.sin(a) * rr * 0.7
        ctx.fillStyle = `rgba(96,165,250,${0.4 + Math.sin(a * 2) * 0.3})`
        ctx.beginPath()
        ctx.arc(x, y, 1.8, 0, Math.PI * 2)
        ctx.fill()
      }
      break
    }
    case 'wind': {
      for (const p of c.parts) {
        const speed = 60 + p.s * 24
        p.x += speed * 0.016
        if (p.x > w + 20) p.x = -20
        const y = p.y + Math.sin(t * 2 + p.seed) * 3
        ctx.strokeStyle = `rgba(186,230,253,${0.16 + p.s * 0.1})`
        ctx.lineWidth = 1
        ctx.beginPath()
        ctx.moveTo(p.x - 14, y)
        ctx.lineTo(p.x, y)
        ctx.stroke()
      }
      orb(c, cx - Math.sin(t * 1.5) * 4, cy, R * 0.95, 250)
      break
    }
    case 'earth': {
      orb(c, cx, cy, R, 30)
      for (let i = 0; i < 4; i++) {
        const a = t * 1.2 + (i / 4) * Math.PI * 2
        ctx.fillStyle = `hsla(28,25%,${42 + i * 5}%,0.95)`
        ctx.save()
        ctx.translate(cx + Math.cos(a) * R * 1.9, cy + Math.sin(a) * R * 1.05)
        ctx.rotate(a * 2)
        ctx.fillRect(-3, -2.4, 6, 4.8)
        ctx.restore()
      }
      break
    }
    case 'smoke': {
      for (const p of c.parts) {
        p.y -= (18 + p.s * 10) * 0.016
        if (p.y < -10) { p.y = h + 10; p.x = cx + (Math.random() - 0.5) * 30 }
        const k = 1 - p.y / h
        ctx.fillStyle = `rgba(148,163,184,${0.06 + k * 0.08})`
        ctx.beginPath()
        ctx.arc(p.x, p.y, 8 + (1 - k) * 14, 0, Math.PI * 2)
        ctx.fill()
      }
      orb(c, cx, cy, R, 255)
      break
    }
    case 'lightning': {
      const cycle = (t % 1.8)
      if (cycle < 0.28) {
        const flick = Math.sin(cycle * 40) > -0.3
        if (flick) {
          ctx.strokeStyle = 'rgba(196,181,253,0.9)'
          ctx.lineWidth = 2
          ctx.beginPath()
          ctx.moveTo(cx + 12, 0)
          let y = 0
          let x = cx + 12
          while (y < h * 0.8) {
            y += h * 0.14
            x += (Math.random() - 0.5) * 22
            ctx.lineTo(x, y)
          }
          ctx.stroke()
          ctx.fillStyle = 'rgba(196,181,253,0.1)'
          ctx.fillRect(0, 0, w, h)
        }
      }
      orb(c, cx, cy + R * 0.2, R * 0.9, 255)
      break
    }
    case 'rain':
    case 'storm': {
      for (const p of c.parts) {
        p.y += (140 + p.s * 60) * 0.016
        p.x -= 24 * 0.016
        if (p.y > h) { p.y = -6; p.x = Math.random() * (w + 30) }
        ctx.strokeStyle = `rgba(148,197,255,${0.2 + p.s * 0.12})`
        ctx.lineWidth = 1
        ctx.beginPath()
        ctx.moveTo(p.x, p.y)
        ctx.lineTo(p.x - 3, p.y + 9 + p.s * 2)
        ctx.stroke()
      }
      if (kind === 'storm' && (t % 2.4) < 0.2) {
        ctx.fillStyle = 'rgba(196,181,253,0.12)'
        ctx.fillRect(0, 0, w, h)
      }
      orb(c, cx, cy - R * 0.1, R * 0.9, 252)
      break
    }
    case 'fog': {
      for (let i = 0; i < 4; i++) {
        const x = ((t * 12 + i * 47) % (w + 80)) - 40
        const y = h * 0.4 + Math.sin(i * 2 + t * 0.4) * h * 0.2
        const g = ctx.createRadialGradient(x, y, 0, x, y, 36)
        g.addColorStop(0, 'rgba(203,213,225,0.14)')
        g.addColorStop(1, 'rgba(203,213,225,0)')
        ctx.fillStyle = g
        ctx.beginPath()
        ctx.arc(x, y, 36, 0, Math.PI * 2)
        ctx.fill()
      }
      orb(c, cx, cy - R * 0.2, R * 0.9, 252)
      break
    }
    case 'sun': {
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 3)
      g.addColorStop(0, 'rgba(251,191,36,0.4)')
      g.addColorStop(1, 'rgba(251,191,36,0)')
      ctx.fillStyle = g
      ctx.fillRect(0, 0, w, h)
      orb(c, cx, cy, R, 42)
      ctx.strokeStyle = 'rgba(251,191,36,0.4)'
      ctx.lineWidth = 1.4
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2 + t * 0.3
        ctx.beginPath()
        ctx.moveTo(cx + Math.cos(a) * R * 1.4, cy + Math.sin(a) * R * 1.4)
        ctx.lineTo(cx + Math.cos(a) * R * (2 + Math.sin(t * 2 + i) * 0.3), cy + Math.sin(a) * R * (2 + Math.sin(t * 2 + i) * 0.3))
        ctx.stroke()
      }
      break
    }
    case 'moon': {
      for (const p of c.parts) {
        const tw = 0.4 + Math.sin(t * 2 + p.seed) * 0.5
        ctx.fillStyle = `rgba(226,232,240,${tw * 0.7})`
        ctx.beginPath()
        ctx.arc(p.x, p.y * 0.5, 1, 0, Math.PI * 2)
        ctx.fill()
      }
      orb(c, cx, cy, R, 226)
      ctx.fillStyle = 'rgba(148,163,184,0.3)'
      ctx.beginPath()
      ctx.arc(cx - 4, cy - 3, 3, 0, Math.PI * 2)
      ctx.arc(cx + 5, cy + 4, 2.2, 0, Math.PI * 2)
      ctx.fill()
      break
    }
    case 'sparkle':
    case 'stars': {
      for (const p of c.parts) {
        const tw = Math.max(0, Math.sin(t * 2.4 + p.seed * 3))
        ctx.fillStyle = `rgba(253,246,220,${tw * 0.85})`
        const s = 1 + p.s * 0.8
        ctx.beginPath()
        ctx.arc(p.x, p.y, s * 0.7, 0, Math.PI * 2)
        ctx.fill()
        if (tw > 0.75) {
          ctx.strokeStyle = `rgba(253,230,138,${tw * 0.6})`
          ctx.lineWidth = 0.7
          ctx.beginPath()
          ctx.moveTo(p.x - s * 2.6, p.y)
          ctx.lineTo(p.x + s * 2.6, p.y)
          ctx.moveTo(p.x, p.y - s * 2.6)
          ctx.lineTo(p.x, p.y + s * 2.6)
          ctx.stroke()
        }
      }
      if (kind === 'sparkle') orb(c, cx, cy, R, 262)
      break
    }
    case 'fireflies': {
      for (const p of c.parts) {
        const x = cx + Math.sin(t * 0.7 + p.seed * 4) * w * 0.36
        const y = cy + Math.cos(t * 0.5 + p.seed * 6) * h * 0.3
        const blink = Math.max(0, Math.sin(t * 1.8 + p.seed * 9))
        const g = ctx.createRadialGradient(x, y, 0, x, y, 6)
        g.addColorStop(0, `rgba(253,230,138,${blink})`)
        g.addColorStop(1, 'rgba(253,230,138,0)')
        ctx.fillStyle = g
        ctx.beginPath()
        ctx.arc(x, y, 6, 0, Math.PI * 2)
        ctx.fill()
      }
      break
    }
    case 'glow': {
      const pulse = 1 + Math.sin(t * 1.8) * 0.16
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 3.2 * pulse)
      g.addColorStop(0, 'rgba(167,139,250,0.5)')
      g.addColorStop(1, 'rgba(167,139,250,0)')
      ctx.fillStyle = g
      ctx.beginPath()
      ctx.arc(cx, cy, R * 3.2 * pulse, 0, Math.PI * 2)
      ctx.fill()
      orb(c, cx, cy, R * pulse, 262)
      break
    }
    case 'flash': {
      const cycle = t % 1.6
      const k = cycle < 0.15 ? 1 - cycle / 0.15 : cycle < 0.3 ? (cycle - 0.15) / 0.15 : 0
      orb(c, cx, cy, R, 262)
      ctx.fillStyle = `rgba(240,249,255,${k * 0.5})`
      ctx.fillRect(0, 0, w, h)
      break
    }
    case 'rainbow': {
      for (let i = 0; i < 14; i++) {
        const p = i / 14
        const x = ((t * 30 - i * 9) % (w + 40) + w + 40) % (w + 40) - 20
        const y = cy + Math.sin(t * 2 - i * 0.4) * h * 0.2
        ctx.fillStyle = `hsla(${(t * 60 + i * 26) % 360},90%,68%,${0.25 + p * 0.6})`
        ctx.beginPath()
        ctx.arc(x, y, 2.4 + p * 3.4, 0, Math.PI * 2)
        ctx.fill()
      }
      orb(c, cx, cy, R, 262)
      break
    }
    case 'explode': {
      if (c.burst < 0) c.burst = 0
      const cycle = (t % 2)
      const k = cycle < 1.2 ? cycle / 1.2 : 1.4
      if (cycle < 0.05) c.parts.forEach((p) => { p.x = cx; p.y = cy; p.life = 0 })
      c.parts.forEach((p, i) => {
        if (cycle < 1.2) {
          const a = (i / c.parts.length) * Math.PI * 2
          const d = k * R * 2.6 * (0.5 + (p.seed % 1) * 0.6)
          ctx.fillStyle = `hsla(${260 + (i % 5) * 24},90%,${72 - k * 30}%,${1 - k})`
          ctx.beginPath()
          ctx.arc(cx + Math.cos(a) * d, cy + Math.sin(a) * d * 0.8, 2.2 * (1 - k * 0.6), 0, Math.PI * 2)
          ctx.fill()
        }
      })
      if (cycle < 0.3) {
        ctx.strokeStyle = `rgba(196,181,253,${0.7 - cycle * 2})`
        ctx.lineWidth = 2.4
        ctx.beginPath()
        ctx.arc(cx, cy, cycle * R * 4.2, 0, Math.PI * 2)
        ctx.stroke()
      }
      if (cycle > 1.2) orb(c, cx, cy, R * (1 - (1.4 - cycle) * 2), 262)
      break
    }
    case 'ripple': {
      for (let i = 0; i < 3; i++) {
        const p = ((t * 0.7 + i / 3) % 1)
        ctx.strokeStyle = `rgba(103,232,249,${(1 - p) * 0.6})`
        ctx.lineWidth = 1.4
        ctx.beginPath()
        ctx.ellipse(cx, cy + R, p * R * 3.2, p * R * 1.2, 0, 0, Math.PI * 2)
        ctx.stroke()
      }
      orb(c, cx, cy - R * 0.4, R * 0.85, 195)
      break
    }
    case 'portal': {
      ctx.save()
      ctx.translate(cx, cy)
      ctx.rotate(t * 1.6)
      for (let i = 0; i < 3; i++) {
        ctx.strokeStyle = `hsla(${262 + i * 20},90%,${66 + i * 8}%,${0.7 - i * 0.16})`
        ctx.lineWidth = 2
        ctx.beginPath()
        ctx.ellipse(0, 0, R * (1.5 - i * 0.3), R * (0.6 - i * 0.13), i * 0.5, 0, Math.PI * 2)
        ctx.stroke()
      }
      ctx.restore()
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 0.8)
      g.addColorStop(0, 'rgba(237,233,254,0.8)')
      g.addColorStop(1, 'rgba(167,139,250,0)')
      ctx.fillStyle = g
      ctx.beginPath()
      ctx.ellipse(cx, cy, R * 0.8, R * 0.4, 0, 0, Math.PI * 2)
      ctx.fill()
      break
    }
    case 'shape': {
      const cycle = t % 3
      const kinds = ['circle', 'square', 'triangle', 'star']
      const idx = Math.floor(cycle)
      const k = cycle - idx
      const scaleIn = k < 0.5 ? k * 2 : 1
      const g2 = ctx.createRadialGradient(cx - R * 0.24, cy - R * 0.24, R * 0.05, cx, cy, R * scaleIn)
      g2.addColorStop(0, '#ede9fe')
      g2.addColorStop(0.45, '#a78bfa')
      g2.addColorStop(1, '#4c1d95')
      ctx.fillStyle = g2
      const r = R * scaleIn
      ctx.beginPath()
      if (kinds[idx] === 'circle') ctx.arc(cx, cy, r, 0, Math.PI * 2)
      else if (kinds[idx] === 'square') {
        const rr = r * 0.16
        ctx.moveTo(cx - r + rr, cy - r)
        ctx.arcTo(cx + r, cy - r, cx + r, cy + r, rr)
        ctx.arcTo(cx + r, cy + r, cx - r, cy + r, rr)
        ctx.arcTo(cx - r, cy + r, cx - r, cy - r, rr)
        ctx.arcTo(cx - r, cy - r, cx + r, cy - r, rr)
      } else if (kinds[idx] === 'triangle') {
        ctx.moveTo(cx, cy - r)
        ctx.lineTo(cx + r * 0.9, cy + r * 0.7)
        ctx.lineTo(cx - r * 0.9, cy + r * 0.7)
      } else {
        for (let i = 0; i < 10; i++) {
          const a = (i / 10) * Math.PI * 2 - Math.PI / 2
          const rr = i % 2 === 0 ? r : r * 0.44
          const x = cx + Math.cos(a) * rr
          const y = cy + Math.sin(a) * rr
          if (i === 0) ctx.moveTo(x, y)
          else ctx.lineTo(x, y)
        }
      }
      ctx.closePath()
      ctx.fill()
      break
    }
    case 'color': {
      const hue = (t * 40) % 360
      orb(c, cx, cy, R, hue)
      for (let i = 0; i < 5; i++) {
        const a = t * 1.2 + (i / 5) * Math.PI * 2
        ctx.fillStyle = `hsla(${(hue + i * 30) % 360},85%,70%,0.6)`
        ctx.beginPath()
        ctx.arc(cx + Math.cos(a) * R * 2, cy + Math.sin(a) * R * 2, 1.6, 0, Math.PI * 2)
        ctx.fill()
      }
      break
    }
    case 'size': {
      const s = 0.55 + Math.abs(Math.sin(t * 1.4)) * 0.85
      orb(c, cx, cy, R * s)
      ctx.strokeStyle = 'rgba(255,255,255,0.12)'
      ctx.setLineDash([4, 4])
      ctx.beginPath()
      ctx.arc(cx, cy, R * 1.5, 0, Math.PI * 2)
      ctx.stroke()
      ctx.setLineDash([])
      break
    }
    case 'hearts': {
      for (const p of c.parts) {
        p.y -= (16 + p.s * 10) * 0.016
        p.x += Math.sin(t * 2 + p.seed) * 0.4
        if (p.y < -8) { p.y = h + 8; p.x = cx + (Math.random() - 0.5) * w * 0.5 }
        const k = 1 - p.y / h
        heart(c, p.x, p.y, 3 + p.s * 2.4, `rgba(251,113,133,${k * 0.8})`)
      }
      heart(c, cx, cy, R * 1.15, '#fb7185')
      break
    }
    case 'confetti': {
      for (const p of c.parts) {
        p.y += (30 + p.s * 24) * 0.016
        if (p.y > h) { p.y = -6; p.x = Math.random() * w }
        const sq = Math.abs(Math.cos(t * 4 + p.seed))
        ctx.fillStyle = `hsla(${p.hue},85%,65%,0.9)`
        ctx.save()
        ctx.translate(p.x, p.y)
        ctx.rotate(t * 3 + p.seed)
        ctx.fillRect(-2.6, -2.6 * sq, 5.2, 5.2 * sq)
        ctx.restore()
      }
      break
    }
    case 'disco': {
      const hue = (t * 120) % 360
      orb(c, cx, cy + Math.sin(t * 4) * h * 0.1, R, hue)
      for (let i = 0; i < 6; i++) {
        ctx.fillStyle = `hsla(${(hue + i * 60) % 360},85%,65%,0.5)`
        ctx.beginPath()
        ctx.arc((i / 5) * w, h * 0.16, 2.2, 0, Math.PI * 2)
        ctx.fill()
      }
      break
    }
    case 'mirror': {
      ctx.save()
      ctx.translate(cx, 0)
      ctx.scale(-1, 1)
      orb(c, cx - w * 0.28 + Math.sin(t) * 5, cy, R * 0.8)
      ctx.restore()
      orb(c, cx + w * 0.28 + Math.sin(t) * 5, cy, R * 0.8)
      ctx.strokeStyle = 'rgba(255,255,255,0.14)'
      ctx.setLineDash([3, 5])
      ctx.beginPath()
      ctx.moveTo(cx, 4)
      ctx.lineTo(cx, h - 4)
      ctx.stroke()
      ctx.setLineDash([])
      break
    }
    case 'time': {
      const slow = Math.sin(t * 0.6) > 0
      const speed = slow ? 0.4 : 2.4
      const a = t * speed
      orb(c, cx + Math.sin(a) * w * 0.3, cy + Math.cos(a) * h * 0.22, R * 0.85)
      for (let i = 1; i < 4; i++) {
        ctx.strokeStyle = `rgba(167,139,250,${0.3 - i * 0.07})`
        ctx.beginPath()
        ctx.arc(cx + Math.sin(a - i * 0.5) * w * 0.3, cy + Math.cos(a - i * 0.5) * h * 0.22, R * 0.85, 0, Math.PI * 2)
        ctx.stroke()
      }
      break
    }
    case 'chaos': {
      const jx = Math.sin(t * 13) * w * 0.16 + Math.sin(t * 7.3) * w * 0.1
      const jy = Math.cos(t * 11 + 2) * h * 0.14
      orb(c, cx + jx, cy + jy, R)
      for (const p of c.parts) {
        const a = t * 4 + p.seed * 9
        ctx.fillStyle = `hsla(${p.hue},85%,72%,${0.3 + Math.sin(a) * 0.3})`
        ctx.beginPath()
        ctx.arc(cx + Math.cos(a) * w * 0.3 * Math.sin(p.seed), cy + Math.sin(a * 1.3) * h * 0.3, 1.4, 0, Math.PI * 2)
        ctx.fill()
      }
      break
    }
    case 'fireworks': {
      const cycle = (t % 2.6)
      const hue = (Math.floor(t / 2.6) * 67) % 360
      if (cycle < 0.03) c.parts.forEach((p, i) => { p.x = cx; p.y = cy; p.vx = Math.cos((i / c.parts.length) * Math.PI * 2) * (60 + Math.random() * 90); p.vy = Math.sin((i / c.parts.length) * Math.PI * 2) * (60 + Math.random() * 90) })
      if (cycle < 1.4) {
        c.parts.forEach((p) => {
          p.x += p.vx * 0.016
          p.y += p.vy * 0.016
          p.vy += 40 * 0.016
          const k = 1 - cycle / 1.4
          ctx.fillStyle = `hsla(${hue},90%,70%,${k})`
          ctx.beginPath()
          ctx.arc(p.x, p.y, 1.8 * k + 0.6, 0, Math.PI * 2)
          ctx.fill()
        })
      }
      break
    }
    case 'petal': {
      for (const p of c.parts) {
        p.y += (22 + p.s * 14) * 0.016
        p.x += Math.sin(t * 1.4 + p.seed) * 0.5
        if (p.y > h) { p.y = -6; p.x = Math.random() * w }
        ctx.save()
        ctx.translate(p.x, p.y)
        ctx.rotate(t * 2 + p.seed)
        ctx.fillStyle = `hsla(330,80%,${76 + Math.sin(p.seed) * 6}%,0.85)`
        ctx.beginPath()
        ctx.ellipse(0, 0, 3.4 + p.s, 1.9 + p.s * 0.5, 0, 0, Math.PI * 2)
        ctx.fill()
        ctx.restore()
      }
      orb(c, cx, cy - R * 0.2, R * 0.9, 320)
      break
    }
    case 'shadow': {
      for (let i = 2; i >= 0; i--) {
        ctx.globalAlpha = 0.16 + i * 0.08
        ctx.fillStyle = '#312e81'
        ctx.beginPath()
        ctx.arc(cx - (3 - i) * 10, cy + (3 - i) * 4, R * 0.9, 0, Math.PI * 2)
        ctx.fill()
      }
      ctx.globalAlpha = 1
      orb(c, cx, cy, R * 0.9, 250)
      break
    }
    case 'meteor': {
      const p = (t * 0.7) % 1
      const x = w * (0.15 + p * 0.7)
      const y = h * 0.2 + p * h * 0.5
      const g = ctx.createLinearGradient(x - 34, y - 20, x, y)
      g.addColorStop(0, 'rgba(165,243,252,0)')
      g.addColorStop(1, 'rgba(165,243,252,0.9)')
      ctx.strokeStyle = g
      ctx.lineWidth = 2.4
      ctx.beginPath()
      ctx.moveTo(x - 34, y - 20)
      ctx.lineTo(x, y)
      ctx.stroke()
      ctx.fillStyle = '#f0fdff'
      ctx.beginPath()
      ctx.arc(x, y, 2.4, 0, Math.PI * 2)
      ctx.fill()
      break
    }
    case 'environment': {
      const hue = (t * 24) % 360
      const g = ctx.createLinearGradient(0, 0, w, h)
      g.addColorStop(0, `hsla(${hue},45%,16%,1)`)
      g.addColorStop(1, `hsla(${(hue + 80) % 360},50%,22%,1)`)
      ctx.fillStyle = g
      ctx.fillRect(0, 0, w, h)
      ctx.fillStyle = `hsla(${(hue + 140) % 360},60%,60%,0.5)`
      ctx.beginPath()
      ctx.arc(w * 0.75, h * 0.3, 9, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = `hsla(${(hue + 220) % 360},40%,30%,0.8)`
      ctx.beginPath()
      ctx.moveTo(0, h)
      for (let x = 0; x <= w; x += 8) ctx.lineTo(x, h * 0.72 + Math.sin(x * 0.08 + t) * 5)
      ctx.lineTo(w, h)
      ctx.fill()
      orb(c, cx, cy, R * 0.8)
      break
    }
    default: {
      orb(c, cx, cy, R)
      break
    }
  }
}

export function MiniDemo({ kind, className }: { kind: string; className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const stateRef = useRef<{ parts: DemoCtx['parts']; burst: number } | null>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let raf = 0
    let visible = false
    let t = Math.random() * 10
    let last = performance.now()

    const setup = () => {
      const rect = canvas.getBoundingClientRect()
      const w = Math.max(40, rect.width)
      const h = Math.max(36, rect.height)
      canvas.width = w
      canvas.height = h
      if (!stateRef.current) {
        stateRef.current = { parts: makeParts(26, w, h), burst: -1 }
      }
    }

    const frame = (now: number) => {
      raf = requestAnimationFrame(frame)
      const dt = Math.min(0.05, (now - last) / 1000)
      // half framerate for minis — plenty and gentle
      if (dt < 0.033) return
      last = now
      if (!visible) return
      t += dt
      const rect = canvas.getBoundingClientRect()
      const demo: DemoCtx = {
        ctx,
        w: rect.width,
        h: rect.height,
        t,
        parts: stateRef.current?.parts ?? [],
        burst: stateRef.current?.burst ?? -1,
      }
      ctx.clearRect(0, 0, demo.w, demo.h)
      drawDemo(kind, demo)
    }

    setup()
    const ro = new ResizeObserver(() => setup())
    ro.observe(canvas)
    const io = new IntersectionObserver((entries) => {
      visible = entries[0]?.isIntersecting ?? false
    }, { threshold: 0.05 })
    io.observe(canvas)
    raf = requestAnimationFrame(frame)

    return () => {
      cancelAnimationFrame(raf)
      ro.disconnect()
      io.disconnect()
    }
  }, [kind])

  return (
    <canvas
      ref={canvasRef}
      aria-hidden
      className={`block h-full w-full ${className ?? ''}`}
      style={{ display: 'block' }}
    />
  )
}
