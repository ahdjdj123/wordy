'use client'

import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import type { Category } from '@/lib/wordy/types'
import { parse } from '@/lib/wordy/parser'
import { findCommand } from '@/lib/wordy/commands'
import { getEngine } from '@/lib/wordy/engine/engine'
import { sound } from '@/lib/wordy/audio'
import { useWordy } from '@/lib/wordy/store'
import type { Suggestion } from '@/lib/wordy/types'
import { COMBOS } from '@/lib/wordy/commands'
import { findConcept, CONCEPTS } from '@/lib/wordy/knowledge'
import type { ConceptDef } from '@/lib/wordy/knowledge/types'
import { blendWorlds } from '@/lib/wordy/knowledge/blends'

export type ViewKind = 'playground' | 'library' | 'studio' | 'surprises'

/** the four learning modes available inside every concept world */
export type WorldMode = 'explore' | 'experiment' | 'challenge' | 'remember'

export interface ActiveWorld {
  concept: ConceptDef
  params: Record<string, number>
  /** present when this world came out of the Word Blender */
  blend?: {
    secondary: ConceptDef
    name: string
    curated: boolean
  }
}

export interface Confirmation {
  id: number
  word: string
  category: Category | 'secret'
  gold: boolean
  secret: boolean
}

export interface GentleNotice {
  id: number
  word: string
  suggestions: Suggestion[]
}

export interface WordyToast {
  id: number
  title: string
  body?: string
  gold?: boolean
}

export interface SceneFactEvent {
  index: number
  at: number
}

interface WordyUI {
  view: ViewKind
  setView: (v: ViewKind) => void
  execute: (raw: string) => boolean
  tryCommandByName: (name: string) => void
  castSpell: (steps: string[]) => void
  casting: boolean
  confirmations: Confirmation[]
  notice: GentleNotice | null
  toasts: WordyToast[]
  dismissToast: (id: number) => void

  /* v2.0 — concept worlds */
  activeWorld: ActiveWorld | null
  worldMode: WorldMode
  sceneFact: SceneFactEvent | null
  enterWorld: (idOrWord: string, opts?: { params?: Record<string, number> }) => boolean
  enterBlend: (primaryId: string, secondaryId: string) => void
  exitWorld: () => void
  setWorldMode: (m: WorldMode) => void
  setWorldParam: (key: string, value: number) => void
  worldAction: (actionId: string) => void
}

const Ctx = createContext<WordyUI | null>(null)

export function useWordyUI(): WordyUI {
  const c = useContext(Ctx)
  if (!c) throw new Error('useWordyUI must be used inside WordyProvider')
  return c
}

let uid = 1
const nextId = () => uid++

export function WordyProvider({ children }: { children: ReactNode }) {
  const [view, setView] = useState<ViewKind>('playground')
  const [confirmations, setConfirmations] = useState<Confirmation[]>([])
  const [notice, setNotice] = useState<GentleNotice | null>(null)
  const [toasts, setToasts] = useState<WordyToast[]>([])
  const [casting, setCasting] = useState(false)
  const castTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  /* v2.0 — the concept world the user is inside */
  const [activeWorld, setActiveWorld] = useState<ActiveWorld | null>(null)
  const [worldMode, setWorldMode] = useState<WorldMode>('explore')
  const [sceneFact, setSceneFact] = useState<SceneFactEvent | null>(null)

  const {
    discoveredSecrets,
    recordCommand,
    recordCombo,
    pushHistory,
    audio,
    touchConcept,
    markConcept,
    pushRecentConcept,
  } = useWordy()

  const pushToast = useCallback((t: Omit<WordyToast, 'id'>) => {
    const id = nextId()
    setToasts((ts) => [...ts.slice(-3), { ...t, id }])
    setTimeout(() => setToasts((ts) => ts.filter((x) => x.id !== id)), 4200)
  }, [])

  const dismissToast = useCallback((id: number) => {
    setToasts((ts) => ts.filter((x) => x.id !== id))
  }, [])

  const showConfirmation = useCallback((word: string, category: Category, gold: boolean, secret: boolean) => {
    const id = nextId()
    setConfirmations((cs) => [...cs.slice(-2), { id, word, category, gold, secret }])
    setTimeout(() => setConfirmations((cs) => cs.filter((c) => c.id !== id)), secret ? 3200 : 2200)
  }, [])

  const handleCombo = useCallback((comboId: string) => {
    const combo = COMBOS.find((c) => c.id === comboId)
    if (!combo) return
    recordCombo(comboId)
    pushToast({ title: `Combination discovered — ${combo.name}`, body: `${combo.recipe}: ${combo.description}`, gold: true })
  }, [recordCombo, pushToast])

  const applySoundAmbience = useCallback(() => {
    const engine = getEngine()
    const w = engine?.currentWeather()
    sound.setRainAmbience(audio.master > 0 && audio.ambient && (w === 'rain' || w === 'storm'))
  }, [audio])

  /* ---------------- v2.0 — concept worlds ---------------- */

  const enterWorldInternal = useCallback((concept: ConceptDef, params: Record<string, number>, blend?: ActiveWorld['blend']) => {
    const engine = getEngine()
    if (!engine) return
    // entry effects first (environment / weather / trail — preserves the old command behaviour)
    if (concept.entry) engine.apply(concept.entry)
    // blend influence — the secondary world colours the scene
    if (blend) {
      const influence = blendWorlds(concept, blend.secondary)
      if (influence.weather) engine.apply({ weather: influence.weather as never })
      engine.apply({ color: `hsl(${influence.hue} 80% 65%)` })
    }
    engine.setScene(concept.scene, concept.sceneConfig ?? {}, params)
    // scene hotspot → fact surfacing
    engine.scene.onFact = (index) => {
      setSceneFact({ index, at: Date.now() })
      markConcept(concept.id, { explored: true })
    }
    setActiveWorld({ concept, params, blend })
    setWorldMode('explore')
    setSceneFact(null)
    setNotice(null)
    touchConcept(concept.id)
    pushRecentConcept(concept.id)
    showConfirmation(concept.word, (concept.category as unknown as Category), !!blend, false)
    if (audio.master > 0 && audio.commands) sound.play('magic')
    const engine2 = getEngine()
    void engine2
  }, [audio, markConcept, pushRecentConcept, showConfirmation, touchConcept])

  const enterWorld = useCallback((idOrWord: string, opts?: { params?: Record<string, number> }) => {
    const concept = findConcept(idOrWord)
    if (!concept) return false
    const params: Record<string, number> = {}
    for (const p of concept.params) params[p.key] = opts?.params?.[p.key] ?? p.def
    setView('playground')
    enterWorldInternal(concept, params)
    return true
  }, [enterWorldInternal])

  const enterBlend = useCallback((primaryId: string, secondaryId: string) => {
    const primary = findConcept(primaryId)
    const secondary = findConcept(secondaryId)
    if (!primary || !secondary || primary.id === secondary.id) return
    const result = blendWorlds(primary, secondary)
    const params: Record<string, number> = {}
    for (const p of primary.params) params[p.key] = p.def
    setView('playground')
    enterWorldInternal(primary, params, {
      secondary,
      name: result.name,
      curated: result.isCurated,
    })
    pushToast({
      title: `New creation — ${result.name}`,
      body: result.isCurated
        ? `${primary.word} + ${secondary.word}: a curated surprise.`
        : `${primary.word} + ${secondary.word}: a creative interpretation, not a science lesson.`,
      gold: result.isCurated,
    })
  }, [enterWorldInternal, pushToast])

  const exitWorld = useCallback(() => {
    const engine = getEngine()
    engine?.clearWorld()      // fades the scene out and resets the stage
    setActiveWorld(null)
    setWorldMode('explore')
    setSceneFact(null)
  }, [])

  const setWorldParam = useCallback((key: string, value: number) => {
    setActiveWorld((w) => {
      if (!w) return w
      getEngine()?.setSceneParam(key, value)
      return { ...w, params: { ...w.params, [key]: value } }
    })
    if (activeWorld) markConcept(activeWorld.concept.id, { experimented: true })
  }, [activeWorld, markConcept])

  const worldAction = useCallback((actionId: string) => {
    if (!activeWorld) return
    const engine = getEngine()
    const fired = engine?.sceneTrigger(actionId) ?? false
    if (fired) {
      markConcept(activeWorld.concept.id, { explored: true })
      if (audio.master > 0 && audio.commands) sound.play('shimmer')
    }
  }, [activeWorld, audio, markConcept])

  /* ---------------- command execution ---------------- */

  const execute = useCallback((raw: string): boolean => {
    const input = raw.trim()
    if (!input) return false
    const result = parse(input, discoveredSecrets)
    const engine = getEngine()

    /* v2.0 — concept worlds take the stage. A concept's own primary word wins
       over the command of the same name (its entry spec preserves that
       behaviour); command-owned aliases stay commands. */
    const concept = findConcept(input)
    if (concept) {
      const isPrimary = input.toLowerCase() === concept.word || input.toLowerCase() === concept.id
      const cmd = findCommand(input)
      if (isPrimary || !cmd) {
        enterWorld(concept.id)
        return true
      }
    }

    if (result.command) {
      const cmd = result.command
      const effect = result.text ? { ...cmd.effect, text: result.text } : cmd.effect
      engine?.apply(effect)
      const family = cmd.effect.sound
        ?? (cmd.category === 'movement' ? 'whoosh'
          : cmd.category === 'nature' ? 'magic'
            : cmd.category === 'elements' ? 'magic'
              : 'shimmer')
      if (audio.master > 0 && audio.commands) sound.play(family)
      // the sphere says it out loud, if voices are welcome
      if (result.text && audio.master > 0 && audio.voice) sound.speak(result.text)
      recordCommand(cmd.name, cmd.hidden)
      pushHistory(cmd.name)
      showConfirmation(cmd.name, cmd.category, !!cmd.gold, !!cmd.hidden)
      if (result.isSecretReveal) {
        pushToast({ title: 'Secret discovered', body: `“${cmd.name}” joined your collection.`, gold: true })
      }
      // elements that affect ambience
      applySoundAmbience()
      setNotice(null)
      return true
    }

    // unknown word — respond softly
    setNotice({ id: nextId(), word: input, suggestions: result.unknown?.suggestions ?? [] })
    setTimeout(() => {
      setNotice((n) => (n && n.word === input ? null : n))
    }, 5200)
    return false
  }, [discoveredSecrets, recordCommand, pushHistory, showConfirmation, pushToast, applySoundAmbience, audio, enterWorld])

  const tryCommandByName = useCallback((name: string) => {
    const concept = findConcept(name)
    if (concept) {
      setView('playground')
      setTimeout(() => enterWorld(concept.id), 200)
      return
    }
    const cmd = findCommand(name)
    if (cmd) {
      setView('playground')
      // small delay so the view transition breathes
      setTimeout(() => execute(cmd.name), 240)
    }
  }, [execute, enterWorld])

  const executeWithComboWatch = useCallback((raw: string) => {
    const engine = getEngine()
    if (!engine) return execute(raw)
    const prevOnCombo = engine.onCombo
    engine.onCombo = handleCombo
    const ok = execute(raw)
    engine.onCombo = prevOnCombo ?? handleCombo
    return ok
  }, [execute, handleCombo])

  const castSpell = useCallback((steps: string[]) => {
    if (!steps.length || casting) return
    setView('playground')
    setCasting(true)
    let i = 0
    const step = () => {
      if (i >= steps.length) {
        setCasting(false)
        return
      }
      executeWithComboWatch(steps[i])
      i += 1
      castTimer.current = setTimeout(step, 1500)
    }
    castTimer.current = setTimeout(step, 420)
  }, [casting, executeWithComboWatch])

  // wire engine combo callbacks permanently once engine exists
  const engine = getEngine()
  if (engine && engine.onCombo !== handleCombo) {
    engine.onCombo = handleCombo
  }
  // expose the concept registry for e2e smoke tests (mirrors the __wordy engine hook)
  useEffect(() => {
    const w = window as unknown as Record<string, unknown>
    if (!w.__WORDY_CONCEPTS) {
      w.__WORDY_CONCEPTS = Object.fromEntries(CONCEPTS.map((c) => [c.id, c]))
    }
  }, [])

  const value: WordyUI = {
    view,
    setView,
    execute: executeWithComboWatch,
    tryCommandByName,
    castSpell,
    casting,
    confirmations,
    notice,
    toasts,
    dismissToast,
    activeWorld,
    worldMode,
    sceneFact,
    enterWorld,
    enterBlend,
    exitWorld,
    setWorldMode,
    setWorldParam,
    worldAction,
  }

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}
