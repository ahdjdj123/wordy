'use client'

import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Lock, Sparkles, Telescope, ArrowRight, Blend, Shuffle,
  CalendarHeart, Brain, Check,
} from 'lucide-react'
import { COMMANDS, COMBOS, secretCommands, hintFor } from '@/lib/wordy/commands'
import type { CommandDef, ComboDef } from '@/lib/wordy/types'
import {
  CONCEPTS, conceptOfDay, dayKey, randomConcept,
  LEARNING_CATEGORY_META,
} from '@/lib/wordy/knowledge'
import { useWordy } from '@/lib/wordy/store'
import { useWordyUI } from './wordy-context'

/* a poetic nudge that rotates daily */
function todaysWhisper(undiscoveredSecrets: string[], undiscoveredCombos: string[], unvisitedConcepts: number): string {
  const day = Math.floor(Date.now() / 86400000)
  const pool: string[] = []
  for (const name of undiscoveredSecrets) {
    pool.push(hintFor(name))
  }
  for (const id of undiscoveredCombos) {
    const c = COMBOS.find((x) => x.id === id)
    if (c) pool.push(`Try ${c.recipe} — something new appears.`)
  }
  if (unvisitedConcepts > 0) {
    pool.push(`There are still ${unvisitedConcepts} worlds you have never opened.`)
  }
  if (pool.length === 0) return 'You have found everything. The world is quietly impressed.'
  return pool[day % pool.length]
}

function SecretCard({ cmd, discovered }: { cmd: CommandDef; discovered: boolean }) {
  const { tryCommandByName } = useWordyUI()
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className={`relative overflow-hidden rounded-3xl p-5 ${discovered ? 'glass ring-1 ring-amber-400/30' : 'glass'}`}
    >
      {discovered ? (
        <>
          <div className="mb-2 flex items-center justify-between">
            <span className="rounded-full border border-amber-400/30 bg-amber-400/12 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-300">
              discovered
            </span>
            <button
              onClick={() => tryCommandByName(cmd.name)}
              className="rounded-full border border-amber-400/25 bg-amber-400/10 px-3 py-1 text-[11px] font-medium text-amber-200 transition-all hover:bg-amber-400/20 active:scale-95"
            >
              again
            </button>
          </div>
          <h3 className="wordy-gold-gradient-text font-display text-xl font-bold tracking-wide">{cmd.name}</h3>
          <p className="mt-1.5 text-[13px] leading-relaxed text-white/55">{cmd.description}</p>
        </>
      ) : (
        <>
          <div className="mb-3 flex h-8 w-8 items-center justify-center rounded-full bg-white/[0.05] text-white/35">
            <Lock size={13} />
          </div>
          <h3 className="font-display text-xl font-bold tracking-[0.3em] text-white/30">???</h3>
          <p className="mt-1.5 text-[13px] leading-relaxed text-white/45 italic">{hintFor(cmd.name)}</p>
        </>
      )}
    </motion.div>
  )
}

function ComboCard({ combo, discovered }: { combo: ComboDef; discovered: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className={`rounded-3xl p-5 ${discovered ? 'glass ring-1 ring-fuchsia-400/25' : 'glass'}`}
    >
      <div className="mb-2 flex items-center gap-2 text-xs text-white/40">
        <Blend size={13} className="text-fuchsia-300/70" />
        <span className="font-display tracking-wide text-white/70">{combo.recipe}</span>
      </div>
      {discovered ? (
        <p className="text-[13px] leading-relaxed text-white/60">
          <span className="font-semibold text-fuchsia-200">{combo.name}.</span> {combo.description}
        </p>
      ) : (
        <p className="text-[13px] text-white/35 italic">
          Cast both words, one after the other — and watch what appears.
        </p>
      )}
    </motion.div>
  )
}

/* ---------------- daily learning challenge ---------------- */

function DailyChallenge() {
  const concept = useMemo(() => conceptOfDay(), [])
  const { dailyDone, markDailyDone } = useWordy()
  const { enterWorld } = useWordyUI()
  const today = dayKey()
  const done = !!dailyDone[today]
  const q = concept.quiz[0]
  const [picked, setPicked] = useState<number | null>(null)

  const pick = (i: number) => {
    if (picked !== null || done) return
    setPicked(i)
    markDailyDone(today)
  }

  return (
    <div className="glass mb-6 overflow-hidden rounded-3xl p-5">
      <div className="mb-3 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-cyan-500/15 text-cyan-300">
            <Brain size={16} />
          </span>
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.25em] text-cyan-300/70">Daily challenge</p>
            <p className="text-xs text-white/50">One question about today’s discovery</p>
          </div>
        </div>
        {(done || picked !== null) && (
          <span className="flex items-center gap-1 rounded-full border border-emerald-400/25 bg-emerald-400/10 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.15em] text-emerald-300">
            <Check size={10} /> done
          </span>
        )}
      </div>

      {done && picked === null ? (
        <div className="flex flex-col gap-3">
          <p className="text-sm text-white/60">You answered today’s challenge. Come back tomorrow — a new world arrives each day.</p>
          <button
            onClick={() => enterWorld(concept.id)}
            className="self-start rounded-full border border-cyan-400/25 bg-cyan-400/10 px-4 py-1.5 text-xs font-medium text-cyan-200 transition-all hover:bg-cyan-400/20 active:scale-95"
          >
            Open {concept.word} anyway
          </button>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          <p className="text-sm font-medium leading-relaxed text-white/90">{q.q}</p>
          <div className="flex flex-col gap-2">
            {q.options.map((opt, i) => {
              const revealed = picked !== null
              const isRight = i === q.answer
              return (
                <button
                  key={opt}
                  onClick={() => pick(i)}
                  disabled={revealed}
                  className={`rounded-xl border px-4 py-2.5 text-left text-[13px] leading-snug transition-all ${
                    revealed
                      ? isRight
                        ? 'border-emerald-400/50 bg-emerald-400/12 text-emerald-100'
                        : picked === i
                          ? 'border-rose-400/40 bg-rose-400/10 text-rose-100'
                          : 'border-white/6 bg-white/[0.02] text-white/35'
                      : 'border-white/10 bg-white/[0.04] text-white/80 hover:border-cyan-400/40 hover:bg-cyan-500/12 active:scale-[0.98]'
                  }`}
                >
                  {opt}
                </button>
              )
            })}
          </div>
          {picked !== null && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col gap-3">
              <p className="rounded-xl border border-white/8 bg-white/[0.03] p-3 text-xs leading-relaxed text-white/65">
                <span className={picked === q.answer ? 'text-emerald-300' : 'text-amber-300'}>
                  {picked === q.answer ? 'Right. ' : 'Not quite. '}
                </span>
                {q.explain}
              </p>
              <button
                onClick={() => enterWorld(concept.id)}
                className="flex items-center gap-1.5 self-start rounded-full border border-cyan-400/25 bg-cyan-400/10 px-4 py-1.5 text-xs font-medium text-cyan-200 transition-all hover:bg-cyan-400/20 active:scale-95"
              >
                Explore {concept.word}
                <ArrowRight size={12} />
              </button>
            </motion.div>
          )}
        </div>
      )}
    </div>
  )
}

/* ---------------- the view ---------------- */

export function SurprisesView() {
  const discoveredSecrets = useWordy((s) => s.discoveredSecrets)
  const discoveredCombos = useWordy((s) => s.discoveredCombos)
  const discovered = useWordy((s) => s.discovered)
  const conceptProgress = useWordy((s) => s.conceptProgress)
  const { setView, enterWorld } = useWordyUI()

  const secrets = secretCommands
  const secretsFound = secrets.filter((s) => discoveredSecrets.includes(s.name))
  const secretsHidden = secrets.filter((s) => !discoveredSecrets.includes(s.name))
  const combosFound = COMBOS.filter((c) => discoveredCombos.includes(c.id))
  const combosHidden = COMBOS.filter((c) => !discoveredCombos.includes(c.id))

  const visitedIds = Object.entries(conceptProgress)
    .filter(([, p]) => p.visitedAt)
    .map(([id]) => id)
  const unvisited = CONCEPTS.filter((c) => !visitedIds.includes(c.id)).length

  const daily = useMemo(() => conceptOfDay(), [])

  const whisper = useMemo(
    () => todaysWhisper(secretsHidden.map((s) => s.name), combosHidden.map((c) => c.id), unvisited),
    [secretsHidden, combosHidden, unvisited],
  )

  const pct = Math.round(((secretsFound.length + combosFound.length) / (secrets.length + COMBOS.length)) * 100)

  const anywhere = () => {
    const c = randomConcept(visitedIds)
    enterWorld(c.id)
  }

  return (
    <div className="mx-auto w-full max-w-4xl px-4 pb-24 pt-4 sm:px-6">
      <header className="mb-6">
        <h1 className="font-display text-3xl font-bold tracking-wide text-white sm:text-4xl">
          <span className="wordy-gold-gradient-text">Surprises</span>
        </h1>
        <p className="text-sm text-white/45">
          The world keeps a few things to itself. It hopes you’ll try anyway.
        </p>
      </header>

      {/* progress */}
      <div className="glass mb-6 rounded-3xl p-5">
        <div className="mb-3 flex items-end justify-between">
          <div>
            <p className="font-display text-lg font-semibold text-white">Your collection</p>
            <p className="text-xs text-white/40">
              {secretsFound.length}/{secrets.length} secrets · {combosFound.length}/{COMBOS.length} combinations · {visitedIds.length}/{CONCEPTS.length} worlds · {discovered.length} words tried
            </p>
          </div>
          <span className="font-display text-2xl font-bold wordy-gold-gradient-text">{pct}%</span>
        </div>
        <div className="h-1.5 overflow-hidden rounded-full bg-white/8">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${Math.max(pct, 2)}%` }}
            transition={{ duration: 1, ease: 'easeOut' }}
            className="h-full rounded-full bg-gradient-to-r from-amber-300 via-amber-400 to-amber-500 shadow-[0_0_12px_rgba(251,191,36,0.5)]"
          />
        </div>
      </div>

      {/* today's discovery */}
      <div className="mb-6 overflow-hidden rounded-3xl border border-amber-300/20 bg-gradient-to-br from-amber-400/10 via-violet-500/5 to-transparent p-5">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
          <div className="flex items-center gap-3.5">
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-amber-400/15 text-2xl">
              {daily.icon}
            </span>
            <div>
              <p className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.25em] text-amber-300/70">
                <CalendarHeart size={11} /> today’s discovery
              </p>
              <h3 className="mt-0.5 font-display text-xl font-bold tracking-wide text-white">{daily.word}</h3>
              <p className="text-xs text-white/50">
                {LEARNING_CATEGORY_META[daily.category].icon} {LEARNING_CATEGORY_META[daily.category].label} · {daily.tagline}
              </p>
            </div>
          </div>
          <div className="flex flex-1 items-center justify-end gap-2.5">
            <button
              onClick={() => enterWorld(daily.id)}
              className="flex items-center gap-1.5 rounded-full border border-amber-400/30 bg-amber-400/12 px-4 py-2 text-xs font-medium text-amber-100 transition-all hover:bg-amber-400/22 active:scale-95"
            >
              Open it
              <ArrowRight size={12} />
            </button>
          </div>
        </div>
      </div>

      {/* take me anywhere */}
      <div className="mb-6 flex flex-col gap-3 rounded-3xl border border-violet-400/15 bg-violet-500/[0.06] p-5 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="font-display text-base font-semibold text-white/90">Take me somewhere</p>
          <p className="mt-0.5 text-xs text-white/45">
            {unvisited > 0
              ? `${unvisited} worlds you have never opened are waiting.`
              : 'You have seen every world — the shuffle still loves you.'}
          </p>
        </div>
        <button
          onClick={anywhere}
          className="flex items-center justify-center gap-2 rounded-full bg-gradient-to-r from-violet-500 to-blue-600 px-5 py-2.5 text-xs font-semibold text-white shadow-[0_0_24px_rgba(124,58,237,0.35)] transition-all hover:scale-[1.03] active:scale-95"
        >
          <Shuffle size={13} />
          Random world
        </button>
      </div>

      {/* daily challenge */}
      <DailyChallenge />

      {/* today's whisper */}
      <div className="mb-8 overflow-hidden rounded-3xl border border-fuchsia-400/15 bg-gradient-to-br from-fuchsia-500/10 via-violet-500/5 to-transparent p-5">
        <div className="flex items-start gap-3.5">
          <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-fuchsia-500/15 text-fuchsia-300">
            <Telescope size={16} />
          </span>
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.25em] text-fuchsia-300/70">Today’s whisper</p>
            <p className="mt-1 text-sm leading-relaxed text-white/70">{whisper}</p>
            <button
              onClick={() => setView('playground')}
              className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-fuchsia-400/25 bg-fuchsia-500/12 px-4 py-1.5 text-xs font-medium text-fuchsia-200 transition-all hover:bg-fuchsia-500/22 active:scale-95"
            >
              Go experiment
              <ArrowRight size={12} />
            </button>
          </div>
        </div>
      </div>

      {/* secrets */}
      <section className="mb-10">
        <h2 className="mb-1 font-display text-xl font-semibold text-white/90">Hidden words</h2>
        <p className="mb-4 text-xs text-white/35">Type them in the Playground. That’s the whole game.</p>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {secretsFound.map((c) => (
            <SecretCard key={c.name} cmd={c} discovered />
          ))}
          {secretsHidden.map((c) => (
            <SecretCard key={c.name} cmd={c} discovered={false} />
          ))}
        </div>
      </section>

      {/* combos */}
      <section className="mb-10">
        <h2 className="mb-1 font-display text-xl font-semibold text-white/90">Unusual combinations</h2>
        <p className="mb-4 text-xs text-white/35">Some words react to each other. Nobody will tell you which.</p>
        <div className="grid gap-3 sm:grid-cols-2">
          {combosFound.map((c) => (
            <ComboCard key={c.id} combo={c} discovered />
          ))}
          {combosHidden.map((c) => (
            <ComboCard key={c.id} combo={c} discovered={false} />
          ))}
        </div>
      </section>

      <div className="glass rounded-3xl p-6 text-center">
        <Sparkles className="mx-auto mb-3 h-5 w-5 text-amber-300/80" />
        <p className="mx-auto max-w-md text-sm leading-relaxed text-white/50">
          Nothing here is a test. Every wrong word is just the world saying
          <span className="text-white/80"> “not this one — try another.”</span>
        </p>
        <p className="mt-3 text-[10px] uppercase tracking-[0.3em] text-white/25">
          {COMMANDS.filter((c) => !c.hidden).length} known words · {secrets.length} secrets · {COMBOS.length} combinations · {CONCEPTS.length} worlds
        </p>
      </div>
    </div>
  )
}
