'use client'

import { useMemo, useState } from 'react'
import { Reorder, motion, AnimatePresence } from 'framer-motion'
import {
  Play, Plus, Save, Trash2, X, Wand2, ScrollText, GripVertical,
  Blend, Shuffle, Sparkles,
} from 'lucide-react'
import { COMMANDS, findCommand } from '@/lib/wordy/commands'
import type { CommandDef } from '@/lib/wordy/types'
import { CATEGORY_META } from '@/lib/wordy/types'
import { CONCEPTS, LEARNING_CATEGORY_META } from '@/lib/wordy/knowledge'
import type { ConceptDef } from '@/lib/wordy/knowledge/types'
import { blendWorlds, blendName } from '@/lib/wordy/knowledge/blends'
import type { SavedCreation } from '@/lib/wordy/knowledge/types'
import { useWordy, type Spell } from '@/lib/wordy/store'
import { useWordyUI } from './wordy-context'
import { MiniDemo } from './MiniDemo'
import { SoftSearch } from './CommandDeck'

const HUE_BY_CATEGORY: Record<string, string> = {
  movement: 'from-cyan-500/25 to-cyan-500/5 border-cyan-400/25 text-cyan-200',
  physics: 'from-violet-500/25 to-violet-500/5 border-violet-400/25 text-violet-200',
  elements: 'from-orange-500/25 to-orange-500/5 border-orange-400/25 text-orange-200',
  nature: 'from-emerald-500/25 to-emerald-500/5 border-emerald-400/25 text-emerald-200',
  visual: 'from-pink-500/25 to-pink-500/5 border-pink-400/25 text-pink-200',
  environment: 'from-blue-500/25 to-blue-500/5 border-blue-400/25 text-blue-200',
  objects: 'from-amber-500/25 to-amber-500/5 border-amber-400/25 text-amber-200',
  special: 'from-fuchsia-500/25 to-fuchsia-500/5 border-fuchsia-400/25 text-fuchsia-200',
}

/* ---------------- Word Blender ---------------- */

function ConceptPicker({ label, value, onChange }: {
  label: string
  value: ConceptDef | null
  onChange: (c: ConceptDef | null) => void
}) {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState('')
  const results = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return CONCEPTS.slice(0, 12)
    return CONCEPTS.filter(
      (c) => c.word.includes(q) || c.aliases.some((a) => a.includes(q)),
    ).slice(0, 12)
  }, [query])

  return (
    <div className="flex-1">
      <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.26em] text-white/30">{label}</p>
      {value ? (
        <div className="glass flex items-center gap-2.5 rounded-2xl px-4 py-3">
          <span className="text-2xl leading-none">{value.icon}</span>
          <div className="min-w-0 flex-1">
            <p className="truncate font-display text-sm font-semibold text-white">{value.word}</p>
            <p className="text-[10px] uppercase tracking-widest text-white/35">
              {LEARNING_CATEGORY_META[value.category].label}
            </p>
          </div>
          <button
            onClick={() => onChange(null)}
            aria-label={`Clear ${label}`}
            className="flex h-7 w-7 items-center justify-center rounded-full border border-white/10 text-white/40 transition-all hover:border-rose-400/40 hover:text-rose-300"
          >
            <X size={12} />
          </button>
        </div>
      ) : (
        <button
          onClick={() => setOpen(!open)}
          className="flex w-full items-center justify-center gap-2 rounded-2xl border border-dashed border-white/15 py-4 text-sm text-white/50 transition-colors hover:border-violet-400/40 hover:text-white/80"
        >
          <Plus size={15} />
          Choose a word
        </button>
      )}
      <AnimatePresence>
        {open && !value && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            className="glass mt-2 rounded-2xl p-3"
          >
            <SoftSearch value={query} onChange={setQuery} placeholder="Find a world…" />
            <div className="scroll-thin mt-3 grid max-h-56 grid-cols-2 gap-1.5 overflow-y-auto pr-1">
              {results.map((c) => (
                <button
                  key={c.id}
                  onClick={() => { onChange(c); setOpen(false); setQuery('') }}
                  className="flex items-center gap-2 rounded-xl border border-white/8 bg-white/[0.03] px-3 py-2 text-left text-xs text-white/75 transition-all hover:border-violet-400/35 hover:bg-violet-500/15 hover:text-white active:scale-[0.97]"
                >
                  <span>{c.icon}</span>
                  <span className="truncate font-medium">{c.word}</span>
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

function BlenderTab() {
  const [primary, setPrimary] = useState<ConceptDef | null>(null)
  const [secondary, setSecondary] = useState<ConceptDef | null>(null)
  const { enterBlend, setView } = useWordyUI()
  const { creations, saveCreation, deleteCreation } = useWordy()
  const [savedFlash, setSavedFlash] = useState(false)

  const preview = useMemo(() => {
    if (!primary || !secondary || primary.id === secondary.id) return null
    return blendWorlds(primary, secondary)
  }, [primary, secondary])

  const blendNow = () => {
    if (primary && secondary) enterBlend(primary.id, secondary.id)
  }

  const saveIt = () => {
    if (!primary || !secondary || !preview) return
    const creation: SavedCreation = {
      id: `creation-${primary.id}-${secondary.id}`,
      name: preview.name,
      primary: primary.id,
      secondary: secondary.id,
      createdAt: Date.now(),
    }
    saveCreation(creation)
    setSavedFlash(true)
    setTimeout(() => setSavedFlash(false), 1800)
  }

  const surprise = () => {
    const a = CONCEPTS[Math.floor(Math.random() * CONCEPTS.length)]
    let b = CONCEPTS[Math.floor(Math.random() * CONCEPTS.length)]
    while (b.id === a.id) b = CONCEPTS[Math.floor(Math.random() * CONCEPTS.length)]
    setPrimary(a)
    setSecondary(b)
  }

  return (
    <div className="flex flex-col gap-6">
      <p className="max-w-lg text-sm leading-relaxed text-white/50">
        Combine two worlds into something new. A blend is a{' '}
        <span className="text-white/80">creative interpretation</span> — beautiful, playful,
        and clearly labelled as such, so it never masquerades as a science lesson.
      </p>

      {/* the two slots */}
      <div className="flex flex-col items-stretch gap-3 sm:flex-row sm:items-center">
        <ConceptPicker label="first word" value={primary} onChange={setPrimary} />
        <div className="flex items-center justify-center sm:px-1">
          <span className="glass flex h-10 w-10 items-center justify-center rounded-full text-fuchsia-300">
            <Blend size={16} />
          </span>
        </div>
        <ConceptPicker label="second word" value={secondary} onChange={setSecondary} />
      </div>

      {/* actions */}
      <div className="flex flex-wrap items-center gap-3">
        <button
          onClick={blendNow}
          disabled={!preview}
          className="flex items-center gap-2 rounded-full bg-gradient-to-r from-fuchsia-500 to-violet-600 px-6 py-3 text-sm font-semibold text-white shadow-[0_0_32px_rgba(192,38,211,0.35)] transition-all hover:scale-[1.03] active:scale-95 disabled:cursor-not-allowed disabled:opacity-30 disabled:shadow-none disabled:hover:scale-100"
        >
          <Wand2 size={15} />
          Blend it
        </button>
        <button
          onClick={surprise}
          className="flex items-center gap-2 rounded-full border border-white/12 bg-white/[0.05] px-5 py-3 text-sm font-medium text-white/80 transition-all hover:border-fuchsia-400/35 hover:text-white active:scale-95"
        >
          <Shuffle size={14} />
          Surprise me
        </button>
        <button
          onClick={saveIt}
          disabled={!preview}
          className="flex items-center gap-2 rounded-full border border-white/12 bg-white/[0.05] px-5 py-3 text-sm font-medium text-white/80 transition-all hover:border-violet-400/35 hover:text-white active:scale-95 disabled:cursor-not-allowed disabled:opacity-30"
        >
          <Save size={14} />
          {savedFlash ? 'Saved ✓' : 'Save creation'}
        </button>
      </div>

      {/* preview card */}
      <AnimatePresence>
        {preview && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 12 }}
            className="relative overflow-hidden rounded-3xl border border-fuchsia-400/20 bg-gradient-to-br from-fuchsia-500/10 via-violet-500/5 to-transparent p-5"
          >
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.25em] text-fuchsia-300/70">
                  <Sparkles size={11} />
                  {preview.isCurated ? 'curated discovery' : 'fresh invention'}
                </p>
                <h3 className="wordy-gradient-text mt-1 font-display text-2xl font-bold tracking-wide">
                  {preview.name}
                </h3>
                <p className="mt-1 text-xs text-white/45">
                  {primary?.word} × {secondary?.word} — opens as a creative interpretation of{' '}
                  {primary?.word}.
                </p>
              </div>
              <button
                onClick={blendNow}
                aria-label="Open this blend"
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-fuchsia-500/20 text-fuchsia-200 transition-all hover:bg-fuchsia-500/35 active:scale-90"
              >
                <Play size={16} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* saved creations */}
      <section>
        <h2 className="mb-3 flex items-center gap-2 font-display text-lg font-semibold text-white/85">
          <ScrollText size={16} className="text-fuchsia-300" />
          Saved creations
        </h2>
        {creations.length === 0 ? (
          <div className="glass flex flex-col items-center gap-2 rounded-3xl px-6 py-10 text-center">
            <p className="text-sm text-white/50">Nothing blended yet.</p>
            <p className="max-w-xs text-xs text-white/30">
              Some pairs have secret names. Try butterfly + volcano.
            </p>
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">
            {creations.map((c) => {
              const p = CONCEPTS.find((x) => x.id === c.primary)
              const s = CONCEPTS.find((x) => x.id === c.secondary)
              if (!p || !s) return null
              return (
                <motion.div
                  key={c.id}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="glass flex items-center gap-3 rounded-2xl p-4"
                >
                  <span className="text-xl leading-none">{p.icon}</span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-display text-sm font-semibold text-white/90">{c.name}</p>
                    <p className="mt-0.5 truncate text-xs text-white/40">{p.word} × {s.word}</p>
                  </div>
                  <button
                    onClick={() => { enterBlend(c.primary, c.secondary); setView('playground') }}
                    aria-label={`Play ${c.name}`}
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-fuchsia-500/15 text-fuchsia-200 transition-all hover:bg-fuchsia-500/30 active:scale-90"
                  >
                    <Play size={14} />
                  </button>
                  <button
                    onClick={() => deleteCreation(c.id)}
                    aria-label={`Delete ${c.name}`}
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-white/8 text-white/30 transition-all hover:border-rose-400/35 hover:text-rose-300 active:scale-90"
                  >
                    <Trash2 size={13} />
                  </button>
                </motion.div>
              )
            })}
          </div>
        )}
      </section>
    </div>
  )
}

/* ---------------- Spell sequencer (unchanged behaviour, new tab) ---------------- */

function SpellCard({ name, onRemove }: { name: string; onRemove: () => void }) {
  const cmd = findCommand(name)
  const hue = cmd ? HUE_BY_CATEGORY[cmd.category] : HUE_BY_CATEGORY.special
  return (
    <div className={`group relative flex w-36 shrink-0 flex-col overflow-hidden rounded-2xl border bg-gradient-to-br ${hue} backdrop-blur-xl`}>
      <div className="relative h-14 border-b border-white/8">
        <MiniDemo kind={cmd?.demo ?? 'glow'} />
      </div>
      <div className="flex items-center justify-between gap-1 px-3 py-2.5">
        <div className="min-w-0">
          <p className="truncate font-display text-sm font-semibold tracking-wide">{name}</p>
          <p className="text-[10px] uppercase tracking-widest text-white/35">
            {cmd ? CATEGORY_META[cmd.category].label : 'word'}
          </p>
        </div>
        <button
          onClick={onRemove}
          aria-label={`Remove ${name}`}
          className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-white/10 bg-white/[0.04] text-white/40 opacity-0 transition-all hover:border-rose-400/40 hover:text-rose-300 group-hover:opacity-100"
        >
          <X size={12} />
        </button>
      </div>
      <div className="absolute left-2 top-2 text-white/20">
        <GripVertical size={13} className="opacity-60" />
      </div>
    </div>
  )
}

function AddCommandSheet({ open, onAdd }: { open: boolean; onAdd: (name: string) => void }) {
  const [query, setQuery] = useState('')
  const results = useMemo(() => {
    const q = query.trim().toLowerCase()
    const pool = COMMANDS.filter((c) => !c.hidden)
    if (!q) return pool.slice(0, 18)
    return pool.filter((c) => c.name.includes(q) || c.aliases.some((a) => a.includes(q))).slice(0, 18)
  }, [query])

  if (!open) return null

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 12 }}
      className="glass rounded-3xl p-5"
    >
      <SoftSearch value={query} onChange={setQuery} placeholder="Find a word to add…" />
      <div className="scroll-thin mt-4 grid max-h-72 grid-cols-2 gap-2 overflow-y-auto pr-1 sm:grid-cols-3">
        {results.map((c) => (
          <button
            key={c.name}
            onClick={() => { onAdd(c.name); setQuery('') }}
            className="flex items-center justify-between gap-2 rounded-xl border border-white/8 bg-white/[0.03] px-3 py-2 text-left text-xs text-white/75 transition-all hover:border-violet-400/35 hover:bg-violet-500/15 hover:text-white active:scale-[0.97]"
          >
            <span className="truncate font-medium">{c.name}</span>
            <Plus size={12} className="shrink-0 text-white/30" />
          </button>
        ))}
        {results.length === 0 && (
          <p className="col-span-full py-6 text-center text-xs text-white/35">
            Nothing matches “{query}” — the library might know it though.
          </p>
        )}
      </div>
    </motion.div>
  )
}

function SequencerTab() {
  const [steps, setSteps] = useState<string[]>([])
  const [name, setName] = useState('')
  const [adding, setAdding] = useState(false)
  const [savedFlash, setSavedFlash] = useState(false)
  const { spells, saveSpell, deleteSpell } = useWordy()
  const { castSpell, casting } = useWordyUI()

  const canCast = steps.length > 0 && !casting
  const canSave = steps.length > 0 && name.trim().length > 0

  const handleSave = () => {
    if (!canSave) return
    const spell: Spell = {
      id: `spell-${Date.now()}`,
      name: name.trim(),
      steps: [...steps],
      createdAt: Date.now(),
    }
    saveSpell(spell)
    setSavedFlash(true)
    setTimeout(() => setSavedFlash(false), 1800)
  }

  return (
    <div className="flex flex-col gap-5">
      {/* name */}
      <div className="focus-glow flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3 backdrop-blur-xl">
        <Wand2 size={16} className="shrink-0 text-fuchsia-300" />
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Name your experiment — “Night Flight”, “Storm Dance”…"
          maxLength={42}
          className="min-w-0 flex-1 bg-transparent text-sm text-white placeholder:text-white/30 focus:outline-none"
        />
      </div>

      {/* the sequence */}
      <div className="glass rounded-3xl p-5">
        {steps.length === 0 ? (
          <button
            onClick={() => setAdding(true)}
            className="flex w-full flex-col items-center gap-3 rounded-2xl border border-dashed border-white/12 py-12 text-center transition-colors hover:border-violet-400/35"
          >
            <span className="flex h-11 w-11 items-center justify-center rounded-full bg-violet-500/15 text-violet-300">
              <Plus size={18} />
            </span>
            <div>
              <p className="text-sm font-medium text-white/75">Begin with a word</p>
              <p className="mt-1 text-xs text-white/35">Each card plays in order — FLY → SPIN → RAINBOW → BOOM</p>
            </div>
          </button>
        ) : (
          <>
            <Reorder.Group
              axis="x"
              values={steps}
              onReorder={setSteps}
              className="scroll-thin flex gap-3 overflow-x-auto pb-2 [scrollbar-width:thin]"
            >
              {steps.map((s, i) => (
                <Reorder.Item key={`${s}-${i}`} value={s} className="cursor-grab active:cursor-grabbing">
                  <div className="relative">
                    <SpellCard name={s} onRemove={() => setSteps((st) => st.filter((_, idx) => idx !== i))} />
                    {i < steps.length - 1 && (
                      <span className="pointer-events-none absolute -right-3 top-1/2 -translate-y-1/2 font-display text-xs text-white/30">→</span>
                    )}
                  </div>
                </Reorder.Item>
              ))}
              <button
                onClick={() => setAdding(true)}
                aria-label="Add a word"
                className="flex h-[126px] w-14 shrink-0 items-center justify-center rounded-2xl border border-dashed border-white/12 text-white/30 transition-colors hover:border-violet-400/40 hover:text-violet-300"
              >
                <Plus size={18} />
              </button>
            </Reorder.Group>
            <p className="mt-2 truncate font-display text-sm tracking-[0.2em] text-white/40">
              {steps.map((s) => s.toUpperCase()).join(' → ')}
            </p>
          </>
        )}
      </div>

      <AnimatePresence>
        {adding && (
          <div>
            <AddCommandSheet
              open={adding}
              onAdd={(n) => {
                setSteps((st) => [...st, n])
                setAdding(false)
              }}
            />
          </div>
        )}
      </AnimatePresence>

      {/* actions */}
      <div className="flex flex-wrap items-center gap-3">
        <button
          onClick={() => castSpell(steps)}
          disabled={!canCast}
          className="flex items-center gap-2 rounded-full bg-gradient-to-r from-violet-500 to-blue-600 px-6 py-3 text-sm font-semibold text-white shadow-[0_0_32px_rgba(124,58,237,0.4)] transition-all hover:scale-[1.03] active:scale-95 disabled:cursor-not-allowed disabled:opacity-30 disabled:shadow-none disabled:hover:scale-100"
        >
          <Play size={15} />
          {casting ? 'Casting…' : 'Cast Spell'}
        </button>
        <button
          onClick={handleSave}
          disabled={!canSave}
          className="flex items-center gap-2 rounded-full border border-white/12 bg-white/[0.05] px-5 py-3 text-sm font-medium text-white/80 transition-all hover:border-violet-400/35 hover:text-white active:scale-95 disabled:cursor-not-allowed disabled:opacity-30"
        >
          <Save size={15} />
          {savedFlash ? 'Saved ✓' : 'Save'}
        </button>
        {steps.length > 0 && (
          <button
            onClick={() => setSteps([])}
            className="rounded-full border border-white/8 px-4 py-3 text-xs text-white/40 transition-colors hover:border-rose-400/30 hover:text-rose-300"
          >
            Clear
          </button>
        )}
      </div>

      {/* saved spells */}
      <section>
        <h2 className="mb-3 flex items-center gap-2 font-display text-lg font-semibold text-white/85">
          <ScrollText size={16} className="text-violet-300" />
          Saved experiments
        </h2>
        {spells.length === 0 ? (
          <div className="glass flex flex-col items-center gap-2 rounded-3xl px-6 py-10 text-center">
            <p className="text-sm text-white/50">Nothing saved yet.</p>
            <p className="max-w-xs text-xs text-white/30">
              Cast something you love, name it, and it will wait for you here.
            </p>
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">
            {spells.map((s) => (
              <motion.div
                key={s.id}
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="glass group flex items-center gap-3 rounded-2xl p-4"
              >
                <div className="min-w-0 flex-1">
                  <p className="truncate font-display text-sm font-semibold text-white/90">{s.name}</p>
                  <p className="mt-0.5 truncate text-xs text-white/40">{s.steps.map((x) => x.toUpperCase()).join(' → ')}</p>
                </div>
                <button
                  onClick={() => castSpell(s.steps)}
                  aria-label={`Cast ${s.name}`}
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-violet-500/15 text-violet-200 transition-all hover:bg-violet-500/30 active:scale-90"
                >
                  <Play size={14} />
                </button>
                <button
                  onClick={() => deleteSpell(s.id)}
                  aria-label={`Delete ${s.name}`}
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-white/8 text-white/30 transition-all hover:border-rose-400/35 hover:text-rose-300 active:scale-90"
                >
                  <Trash2 size={13} />
                </button>
              </motion.div>
            ))}
          </div>
        )}
      </section>
    </div>
  )
}

/* ---------------- the studio ---------------- */

type StudioTab = 'blender' | 'sequencer'

export function StudioView() {
  const [tab, setTab] = useState<StudioTab>('blender')

  const TABS: Array<{ id: StudioTab; label: string; icon: typeof Blend }> = [
    { id: 'blender', label: 'Word Blender', icon: Blend },
    { id: 'sequencer', label: 'Spell Builder', icon: Wand2 },
  ]

  return (
    <div className="mx-auto w-full max-w-4xl px-4 pb-24 pt-4 sm:px-6">
      <header className="mb-5">
        <h1 className="font-display text-3xl font-bold tracking-wide text-white sm:text-4xl">
          Spell <span className="wordy-gradient-text">Studio</span>
        </h1>
        <p className="text-sm text-white/45">A place for making things the world has never seen.</p>
      </header>

      <div className="glass mb-5 inline-flex items-center gap-1 rounded-full p-1">
        {TABS.map((t) => {
          const active = tab === t.id
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              aria-pressed={active}
              className={`relative flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-medium transition-colors ${
                active ? 'text-white' : 'text-white/45 hover:text-white/80'
              }`}
            >
              {active && (
                <motion.span
                  layoutId="studio-tab-pill"
                  transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                  className="absolute inset-0 rounded-full border border-fuchsia-400/30 bg-fuchsia-500/18"
                />
              )}
              <t.icon size={13} className="relative" />
              <span className="relative">{t.label}</span>
            </button>
          )
        })}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={tab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.22 }}
        >
          {tab === 'blender' ? <BlenderTab /> : <SequencerTab />}
        </motion.div>
      </AnimatePresence>
    </div>
  )
}

export { blendName }
