'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Sparkles, CornerDownLeft, Search } from 'lucide-react'
import { suggest } from '@/lib/wordy/parser'
import { STARTER_WORDS } from '@/lib/wordy/commands'
import { CONCEPTS } from '@/lib/wordy/knowledge'
import { useWordyUI } from './wordy-context'
import { useWordy } from '@/lib/wordy/store'
import { CATEGORY_META } from '@/lib/wordy/types'
import type { Category } from '@/lib/wordy/types'

/** words that open concept worlds (starter chips get the 🪐 mark) */
const CONCEPT_WORDS = new Set(CONCEPTS.map((c) => c.word))

const CATEGORY_DOT: Record<Category, string> = {
  movement: 'text-cyan-300',
  physics: 'text-violet-300',
  elements: 'text-orange-300',
  nature: 'text-emerald-300',
  visual: 'text-pink-300',
  environment: 'text-blue-300',
  objects: 'text-amber-300',
  special: 'text-fuchsia-300',
}

/** v2.0 — learning categories get their own chip hue */
const LEARNING_DOT: Record<string, string> = {
  objects: 'text-amber-300',
  organisms: 'text-emerald-300',
  phenomena: 'text-orange-300',
  science: 'text-violet-300',
  processes: 'text-cyan-300',
  abstract: 'text-fuchsia-300',
  emotions: 'text-rose-300',
  history: 'text-yellow-300',
}

/** the word + glow that appears when a command lands */
function Confirmations() {
  const { confirmations } = useWordyUI()
  return (
    <div className="pointer-events-none absolute bottom-full left-1/2 mb-5 flex w-full -translate-x-1/2 flex-col items-center gap-2">
      <AnimatePresence>
        {confirmations.map((c) => (
          <motion.div
            key={c.id}
            initial={{ opacity: 0, y: 14, scale: 0.92, filter: 'blur(6px)' }}
            animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
            exit={{ opacity: 0, y: -18, scale: 1.04, filter: 'blur(5px)' }}
            transition={{ type: 'spring', stiffness: 320, damping: 24 }}
            className="flex flex-col items-center"
          >
            <span
              className={`font-display text-4xl font-bold tracking-[0.18em] sm:text-5xl ${
                c.gold ? 'wordy-gold-gradient-text text-glow-gold' : 'wordy-gradient-text text-glow'
              }`}
            >
              {c.word.toUpperCase()}
            </span>
            <span className="mt-1.5 text-[11px] font-medium uppercase tracking-[0.3em] text-white/40">
              {c.secret ? 'secret discovered' : c.category}
            </span>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  )
}

/** the soft, never-technical "hmm" notice */
function GentleNotice() {
  const { notice, tryCommandByName } = useWordyUI()
  return (
    <AnimatePresence>
      {notice && (
        <motion.div
          key={notice.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 6 }}
          className="absolute bottom-full left-1/2 mb-5 w-full -translate-x-1/2"
        >
          <div className="mx-auto flex max-w-md flex-col items-center gap-3 rounded-2xl border border-white/8 bg-white/[0.04] px-5 py-3.5 backdrop-blur-xl">
            <p className="text-center text-sm text-white/70">
              Hmm… WORDY doesn’t know <span className="text-white/95">“{notice.word}”</span> yet.
            </p>
            {notice.suggestions.length > 0 && (
              <div className="flex flex-wrap items-center justify-center gap-1.5">
                <span className="text-[11px] uppercase tracking-widest text-white/30">try</span>
                {notice.suggestions.map((s) => (
                  <button
                    key={s.word}
                    onClick={() => tryCommandByName(s.word)}
                    className="rounded-full border border-white/10 bg-white/[0.05] px-3 py-1 text-xs text-white/80 transition-all hover:border-violet-400/40 hover:bg-violet-500/15 hover:text-white active:scale-95"
                  >
                    {s.word}
                  </button>
                ))}
              </div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

export function CommandDeck() {
  const { execute, notice } = useWordyUI()
  const history = useWordy((s) => s.history)
  const seenIntro = useWordy((s) => s.seenIntro)
  const [value, setValue] = useState('')
  const [focused, setFocused] = useState(false)
  const [selected, setSelected] = useState(-1)
  const inputRef = useRef<HTMLInputElement | null>(null)
  const [firstCommand, setFirstCommand] = useState(() => history.length > 0)

  const suggestions = useMemo(() => suggest(value), [value])

  const submit = (word: string) => {
    const ok = execute(word)
    if (ok) {
      setValue('')
      setFirstCommand(true)
      inputRef.current?.blur()
    }
  }

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      if (selected >= 0 && suggestions[selected]) submit(suggestions[selected].word)
      else if (value.trim()) submit(value)
    } else if (e.key === 'Tab' && suggestions.length > 0 && value.trim()) {
      e.preventDefault()
      const pick = selected >= 0 ? suggestions[selected].word : suggestions[0].word
      setValue(pick)
    } else if (e.key === 'ArrowDown' && suggestions.length > 0) {
      e.preventDefault()
      setSelected((s) => (s + 1) % suggestions.length)
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      if (suggestions.length > 0) {
        setSelected((s) => (s <= 0 ? suggestions.length - 1 : s - 1))
      } else if (value === '' && history.length > 0) {
        setValue(history[0].word)
      }
    } else if (e.key === 'Escape') {
      setValue('')
      inputRef.current?.blur()
    }
  }

  const showStarters = focused && !value.trim() && !firstCommand
  const chipList = value.trim()
    ? suggestions
    : (showStarters
      ? STARTER_WORDS.slice(0, 8).map((w) => ({
        word: w,
        category: 'special' as Category,
        isWorld: CONCEPT_WORDS.has(w),
      }))
      : [])

  return (
    <div className="relative mx-auto w-full max-w-xl">
      <GentleNotice />
      <Confirmations />

      {/* suggestion chips */}
      <AnimatePresence>
        {chipList.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            className="absolute bottom-full left-1/2 mb-4 flex w-full -translate-x-1/2 items-center justify-center gap-1.5 overflow-x-auto px-2 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
          >
            {value.trim() && (
              <span className="shrink-0 text-[10px] font-medium uppercase tracking-[0.25em] text-white/30">
                {showStarters ? '' : ''}
              </span>
            )}
            {chipList.map((s, i) => {
              const isSel = i === selected
              const dot = s.isWorld
                ? (LEARNING_DOT[s.category as string] ?? 'text-violet-300')
                : (CATEGORY_DOT[s.category as Category] ?? 'bg-violet-300')
              return (
                <button
                  key={s.word}
                  onClick={() => submit(s.word)}
                  onMouseEnter={() => setSelected(i)}
                  className={`group shrink-0 rounded-full border px-3.5 py-1.5 text-xs font-medium backdrop-blur-xl transition-all active:scale-95 ${
                    isSel
                      ? 'border-violet-400/50 bg-violet-500/20 text-white shadow-[0_0_20px_rgba(124,58,237,0.3)]'
                      : 'border-white/10 bg-white/[0.05] text-white/70 hover:border-violet-400/35 hover:bg-violet-500/15 hover:text-white'
                  }`}
                >
                  {s.isWorld ? (
                    <span className="mr-1 inline-block align-middle text-[10px] leading-none">🪐</span>
                  ) : (
                    <span className={`mr-1.5 inline-block h-1 w-1 rounded-full align-middle ${dot} bg-current`} />
                  )}
                  {s.word}
                </button>
              )
            })}
          </motion.div>
        )}
      </AnimatePresence>

      {/* the input */}
      <motion.div
        layout
        className={`focus-glow relative flex items-center gap-3 rounded-full border bg-[#0B1026]/70 py-2 pl-5 pr-2.5 backdrop-blur-2xl transition-colors ${
          focused ? 'border-violet-400/40' : 'border-white/10'
        }`}
      >
        <Sparkles
          className={`h-4.5 w-4.5 shrink-0 transition-colors ${focused ? 'text-violet-300' : 'text-white/35'}`}
          size={18}
        />
        <input
          ref={inputRef}
          value={value}
          onChange={(e) => {
            setValue(e.target.value)
            setSelected(-1)
          }}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          onKeyDown={onKeyDown}
          placeholder={"Type a word — volcano, gravity, fly…"}
          aria-label="Type a word or command"
          autoCapitalize="off"
          autoCorrect="off"
          spellCheck={false}
          className="min-w-0 flex-1 bg-transparent py-2.5 text-base text-white placeholder:text-white/30 focus:outline-none"
        />
        <AnimatePresence>
          {value.trim() && (
            <motion.button
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              onClick={() => submit(value)}
              aria-label="Run this word"
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-blue-600 text-white shadow-[0_0_24px_rgba(124,58,237,0.45)] transition-transform hover:scale-105 active:scale-95"
            >
              <CornerDownLeft size={16} />
            </motion.button>
          )}
        </AnimatePresence>
      </motion.div>

      {/* first-visit hint */}
      <AnimatePresence>
        {!firstCommand && !seenIntro && !focused && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute left-1/2 top-full mt-3.5 -translate-x-1/2 whitespace-nowrap text-xs tracking-wide text-white/35"
          >
            words open worlds — try <button onClick={() => submit('volcano')} className="text-violet-300 underline-offset-4 hover:underline">volcano</button>
            {' '}or <button onClick={() => submit('fly')} className="text-violet-300 underline-offset-4 hover:underline">fly</button>
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  )
}

/** small search input used in Library & Studio (shares the language, not the drama) */
export function SoftSearch({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder: string }) {
  return (
    <div className="focus-glow flex items-center gap-2.5 rounded-full border border-white/10 bg-white/[0.04] px-4 py-2.5 backdrop-blur-xl">
      <Search size={15} className="shrink-0 text-white/35" />
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        aria-label="Search"
        className="min-w-0 flex-1 bg-transparent text-sm text-white placeholder:text-white/30 focus:outline-none"
      />
      {value && (
        <button
          onClick={() => onChange('')}
          aria-label="Clear search"
          className="text-xs text-white/40 hover:text-white/80"
        >
          clear
        </button>
      )}
    </div>
  )
}

export { CATEGORY_META }
