import type { Metadata, Viewport } from "next";
import { Space_Grotesk, Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const display = Space_Grotesk({
  variable: "--font-display",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

const body = Inter({
  variable: "--font-body",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "WORDY — Type a word. Change the world.",
  description:
    "An interactive word-controlled playground. Type a word — fly, boom, rain, rainbow — and watch the world react. Discover secrets, combine elements, cast spells.",
  keywords: ["WORDY", "interactive playground", "words", "experiment", "creative"],
  icons: {
    icon: "/wordy-icon.svg",
  },
  openGraph: {
    title: "WORDY",
    description: "Type a word. Change the world.",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#080B1A",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="dark">
      <body
        className={`${display.variable} ${body.variable} antialiased bg-background text-foreground font-sans`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
