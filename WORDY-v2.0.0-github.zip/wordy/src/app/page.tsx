'use client'

import { WordyProvider } from '@/components/wordy/wordy-context'
import { AppShell } from '@/components/wordy/AppShell'

export default function Home() {
  return (
    <WordyProvider>
      <AppShell />
    </WordyProvider>
  )
}
